
  # ORCHESTRATOR

  This is a code bundle for ORCHESTRATOR. The original project is available at https://www.figma.com/design/vG4JKnVIwTwXj3RbBGw7oo/ORCHESTRATOR.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  