import { useState, useRef, useEffect } from "react";
import {
  Home, Briefcase, Scale, FileText, Search, Bell, HelpCircle,
  Settings, ChevronRight, ChevronDown, Plus, Check,
  AlertTriangle, Clock, ArrowRight, MoreHorizontal, Edit2,
  Eye, Paperclip, Mic, MessageSquare, Download, Upload, Link,
  Info, CheckCircle, RefreshCw, Lock, StopCircle, Send,
  Sparkles, Circle, User, ChevronLeft, GitBranch, X,
} from "lucide-react";

// ─── DESIGN SYSTEM V6.1 ───────────────────────────────────────────────────────

const N = {
  canvas:    "#F8FAFC",
  surface:   "#FFFFFF",
  subtle:    "#F1F5F9",
  text:      "#0F172A",
  textSec:   "#475569",
  textDis:   "#94A3B8",
  border:    "#E2E8F0",
  borderMd:  "#CBD5E1",
  borderSt:  "#94A3B8",
  action:    "#1D4ED8",
  actionHv:  "#1E40AF",
  actionBg:  "#EFF6FF",
  successBg: "#F0FDF4",
  success:   "#166534",
  warnBg:    "#FFFBEB",
  warn:      "#92400E",
  critBg:    "#FEF2F2",
  crit:      "#991B1B",
  innoBg:    "#F5F3FF",
  inno:      "#6D28D9",
  innoBrd:   "#DDD6FE",
};

const SH = {
  card:    "0 1px 3px rgba(15,23,42,.06), 0 1px 2px rgba(15,23,42,.04)",
  cardHv:  "0 4px 12px rgba(15,23,42,.08), 0 2px 4px rgba(15,23,42,.04)",
  overlay: "0 20px 48px rgba(15,23,42,.16), 0 4px 8px rgba(15,23,42,.08)",
  hero:    "0 2px 20px rgba(29,78,216,.10), 0 1px 4px rgba(29,78,216,.06)",
};

const FONT = '"Inter", system-ui, -apple-system, sans-serif';
const MONO = '"Roboto Mono","SF Mono",ui-monospace,monospace';
const ease = "cubic-bezier(.2,0,0,1)";
const T = { fast:`all 120ms ${ease}`, std:`all 200ms ${ease}` };

// ─── TYPES ────────────────────────────────────────────────────────────────────

type View = "home"|"clarify"|"canvas"|"plan"|"confirm"|"work"
  |"global-decisions"|"global-deliverables"|"decision-package"
  |"decision-pause"|"decision-receipt";
type WorkTab = "overview"|"plan"|"activity"|"people"|"sources"|"decisions"|"deliverables";
type Health  = "active"|"attention"|"blocked"|"complete";
type DecStatus = "pending"|"waiting"|"decided";

// ─── DATA ─────────────────────────────────────────────────────────────────────

const WORK_ITEMS = [
  { id:"w1", outcome:"Prepare Q3 budget review presentation for the board", type:"Produce deliverable", health:"attention" as Health,
    heroSentence:"Your board presentation is blocked by 3 open comments and a missing CRM source.",
    heroGain:"Spend 15 minutes resolving the comments today and validation probability rises from 76% to 92%.",
    nextAction:"Review Sarah Chen's 3 comments in the revenue section",
    nextActionTime:"~15 min", nextActionGain:"Unblocks CFO review", nextActionConfDelta:"76% → 92%",
    nextActionWhy:"These 3 comments block the CFO pre-review, which is required before the 18 July board deadline. The CRM export is separately missing — NOVA estimates 1–2 days to obtain it from IT.",
    laterActions:["Refresh the Product Roadmap deck (6 days old)","Request CRM export from IT"],
    backgroundActions:["NOVA final consistency check before publication"],
    owner:"Sarah Chen", updated:"2 hours ago", progress:72, deadline:"18 Jul",
    phaseNum:3, phaseTotal:4,
    confidence:76, confAfterAction:92,
    confReasons:["3 comments unresolved in revenue section","Product Roadmap source outdated","CFO review not started"],
    confPositive:["Financial model cross-checked — capex section clear","Sarah Chen validated financial assumptions"],
    confMissing:"CRM export — revenue section provisional until loaded",
    decisions:1, deliverables:2, blockers:[] as string[] },
  { id:"w2", outcome:"Analyze reasons for customer churn increase in June", type:"Analyze situation", health:"active" as Health,
    heroSentence:"NOVA finished the research synthesis 20 minutes ago.",
    heroGain:"One review of the draft saves you approximately 6 hours of document analysis.",
    nextAction:"Review NOVA synthesis draft",
    nextActionTime:"~30 min", nextActionGain:"Validates main finding", nextActionConfDelta:"41% → 68%",
    nextActionWhy:"NOVA detected 2 contradictory assumptions that require your judgment. Resolving them determines which hypothesis becomes the primary finding and enables Phase 3.",
    laterActions:["Approve CRM export access with IT"],
    backgroundActions:["NOVA preparing recommendation draft"],
    owner:"You", updated:"20 min ago", progress:45, deadline:"22 Jul",
    phaseNum:2, phaseTotal:4,
    confidence:41, confAfterAction:68,
    confReasons:["2 contradictory assumptions unresolved","CRM data source missing","No human review yet"],
    confPositive:["Research scope confirmed","Phase 1 sources fully loaded"],
    confMissing:"CRM Pipeline Export — revenue section cannot be validated",
    decisions:0, deliverables:1, blockers:["CRM export access pending IT approval"] },
  { id:"w3", outcome:"Onboard new supply chain partner for EU operations", type:"Create work", health:"blocked" as Health,
    heroSentence:"This item has been blocked for 4 days. Legal review has no owner.",
    heroGain:"Assigning an owner now is the only action that can unblock the entire program.",
    nextAction:"Assign an owner to the overdue legal review",
    nextActionTime:"~5 min", nextActionGain:"Unblocks Phase 2", nextActionConfDelta:"22% → 45%",
    nextActionWhy:"The legal review has been overdue 4 days with no assigned owner. Every additional day delays the partner onboarding deadline by one day.",
    laterActions:["Chase vendor NDA","Schedule partner kickoff once legal clears"],
    backgroundActions:[],
    owner:"Thomas Vidal", updated:"4 days ago", progress:28, deadline:"31 Jul",
    phaseNum:1, phaseTotal:4,
    confidence:22, confAfterAction:45,
    confReasons:["Legal review overdue — no owner","Vendor NDA not returned","2 blockers with no resolution date"],
    confPositive:["Partner selected and qualified","Scope of work agreed"],
    confMissing:"Legal sign-off — required before contract can be issued",
    decisions:2, deliverables:0, blockers:["Legal review overdue — no owner assigned","Vendor NDA not returned"] },
];

const DECISIONS_DATA = [
  { id:"d1", statement:"Approve Q3 budget increase of €420k for cloud infrastructure",
    authority:"CFO approval required", deadline:"15 Jul", deadlineDays:4, status:"pending" as DecStatus,
    workOutcome:"Q3 budget review presentation", workId:"w1",
    heroSentence:"Without this decision by 15 July, the Q3 product launch is cancelled.",
    recommendation:"Approve €420k in full — the only path that preserves the 23 August launch date.",
    ifApproved:"Infrastructure procurement starts 16 Jul. Full Q3 roadmap preserved. Board presentation on track.",
    ifRejected:"Q3 launch cancelled. Engineering reallocation required. Estimated €2.1M revenue impact.",
    rationale:"The €420k cost increase is offset by €680k projected Q3 revenue. Options 2 and 3 both result in launch delay or cancellation.",
    uncertainty:"Revenue projection relies on July pipeline data and excludes 3 pending enterprise deals.",
    dissent:"Finance partner notes this exceeds the pre-approved variance threshold and recommends a board memo regardless.",
    options:[
      { id:"o1", label:"Approve €420k in full",                         consequence:"Full Q3 roadmap. Launch 23 Aug.",          risk:"Low",    recommended:true  },
      { id:"o2", label:"Approve €280k — defer infrastructure phase 2",  consequence:"Partial roadmap. Launch delayed 3 weeks.", risk:"Medium", recommended:false },
      { id:"o3", label:"Reject and reschedule",                         consequence:"Q3 launch cancelled.",                     risk:"High",   recommended:false },
    ],
    confidence:82, confAfterAction:92,
    confReasons:["3 options evaluated with risk assessment","Revenue projection provisional — CRM pending","CFO pre-review not started"],
    confPositive:["Financial model cross-checked across 3 sources","Infrastructure capacity validated"],
    confMissing:"CRM export — revenue projection in Section 3 is provisional",
    financialImpact:"€420k capex · €35k/month opex · €680k Q3 revenue offset",
    businessImpact:"Preserves Q3 launch 23 Aug. Rejection cancels launch — €2.1M revenue impact.",
    riskImpact:"Approval: Low. Rejection: High — launch cancellation, pipeline disruption.",
    sources:["Q3 Financial Model v4 (14 Jul)","Infrastructure Capacity Report (11 Jul)","Product Roadmap Board Deck (8 Jul)"],
    expertsConsulted:["Sarah Chen — Finance Partner","Thomas Vidal — Head of Infrastructure"],
    outcome:undefined as string|undefined },
  { id:"d2", statement:"Select primary data analytics vendor for 2025–2027 contract",
    authority:"Procurement committee", deadline:"22 Jul", deadlineDays:11, status:"waiting" as DecStatus,
    workOutcome:"Technology vendor consolidation", workId:"w2",
    heroSentence:"Three vendors evaluated. Waiting for procurement committee to convene.",
    recommendation:"", ifApproved:"", ifRejected:"", rationale:"", uncertainty:"", dissent:"",
    options:[] as {id:string;label:string;consequence:string;risk:string;recommended:boolean}[],
    confidence:0, confAfterAction:0, confReasons:[] as string[], confPositive:[] as string[], confMissing:"",
    financialImpact:"", businessImpact:"", riskImpact:"",
    sources:[] as string[], expertsConsulted:[] as string[], outcome:undefined as string|undefined },
  { id:"d3", statement:"Extend remote work policy to all EU entities",
    authority:"HR Director + Legal", deadline:"30 Jun", deadlineDays:-11, status:"decided" as DecStatus,
    workOutcome:"HR policy harmonization", workId:"w3",
    heroSentence:"", recommendation:"", ifApproved:"", ifRejected:"", rationale:"", uncertainty:"", dissent:"",
    options:[] as {id:string;label:string;consequence:string;risk:string;recommended:boolean}[],
    confidence:91, confAfterAction:91, confReasons:[] as string[], confPositive:[] as string[], confMissing:"",
    financialImpact:"", businessImpact:"", riskImpact:"",
    sources:[] as string[], expertsConsulted:[] as string[], outcome:"Approved with conditions" },
];

const ACTIVITY_FEED = [
  { id:"a1", actor:"NOVA", actorType:"ai" as const,
    headline:"Detected contradiction in revenue assumptions",
    change:"Revenue forecast differs from CRM pipeline by 23%",
    why:"Board presentation references June CRM data that has not been loaded — assumptions are inconsistent.",
    impact:"Revenue section confidence decreased from 82% to 76%",
    confDelta:{ from:82, to:76 }, sources:["Q3 Financial Model v4","CRM Pipeline Export"], time:"20 min ago", tags:["critical","ai"] },
  { id:"a2", actor:"Sarah Chen", actorType:"human" as const,
    headline:"Commented on Section 3",
    change:"Revenue projection needs to account for 3 pending enterprise deals",
    why:"", impact:"Section 3 flagged for revision before CFO review",
    confDelta:null as null|{from:number;to:number}, sources:[] as string[], time:"2 hours ago", tags:["human"] },
  { id:"a3", actor:"NOVA", actorType:"ai" as const,
    headline:"Merged 3 duplicated evidence sources",
    change:"Overlapping infrastructure cost data consolidated into 1 authoritative source",
    why:"Infrastructure Capacity Report contained the same figures as the Financial Model — redundancy removed.",
    impact:"Source set consolidated — draft v1 ready for review. No change to confidence.",
    confDelta:null, sources:["Infrastructure Capacity Report","Q3 Financial Model v4"], time:"4 hours ago", tags:["ai","sources"] },
  { id:"a4", actor:"Thomas Vidal", actorType:"human" as const,
    headline:"Added source",
    change:"Infrastructure Capacity Report July 2025 uploaded",
    why:"", impact:"Infrastructure cost section can now be validated",
    confDelta:{ from:68, to:75 }, sources:["Infrastructure Capacity Report — July 2025"], time:"Yesterday", tags:["human","sources"] },
  { id:"a5", actor:"NOVA", actorType:"ai" as const,
    headline:"Detected missing source",
    change:"CRM Pipeline Export is absent from the source set",
    why:"Revenue Section 3 references CRM data that has not been loaded. Without it, the projection is unverified.",
    impact:"Revenue section confidence decreased from 87% to 76%",
    confDelta:{ from:87, to:76 }, sources:["CRM Pipeline Export — June 2025"], time:"Yesterday", tags:["critical","ai","sources"] },
  { id:"a6", actor:"NOVA", actorType:"ai" as const,
    headline:"Re-ranked phase priorities",
    change:"Phase 3 started 1 day ahead of schedule",
    why:"Phase 2 dependencies resolved — NOVA advanced the timeline.",
    impact:"Estimated timeline reduced by 1 day. No confidence change.",
    confDelta:null, sources:[] as string[], time:"Yesterday", tags:["ai"] },
  { id:"a7", actor:"You", actorType:"human" as const,
    headline:"Confirmed target audience",
    change:"Board members and executive team only",
    why:"", impact:"Slide detail level updated in outline",
    confDelta:null, sources:[] as string[], time:"2 days ago", tags:["human"] },
  { id:"a8", actor:"NOVA", actorType:"ai" as const,
    headline:"Validated capex consistency",
    change:"Financial figures cross-checked across 3 sources — no discrepancies",
    why:"Capex figures were referenced in 3 different documents. NOVA verified all three agree.",
    impact:"Capex section confidence increased from 74% to 96%",
    confDelta:{ from:74, to:96 }, sources:["Q3 Financial Model v4","Infrastructure Capacity Report"], time:"2 days ago", tags:["ai"] },
];

const PEOPLE_DATA = [
  { id:"p1", name:"Sarah Chen",   role:"Finance Partner",        type:"human" as const, status:"active",
    availability:"Available now", workload:72, pendingRequests:2, responseTime:"< 2 hours", trustScore:91,
    contribution:"Can unblock financial review — 2 pending requests awaiting her input",
    expertise:["Financial modelling","Board presentations","Capex analysis"],
    docsReviewed:7, validationCount:4, novaState:null as string|null },
  { id:"p2", name:"NOVA",         role:"AI collaborator",        type:"ai" as const,    status:"working",
    availability:"Active", workload:100, pendingRequests:0, responseTime:"< 1 min", trustScore:94,
    contribution:"Cross-checking sources · waiting for CRM export to resolve contradiction in Section 3",
    expertise:["Document analysis","Contradiction detection","Evidence synthesis"],
    docsReviewed:42, validationCount:18,
    novaState:"Synthesizing revenue assumptions across 3 sources — waiting for CRM export to resolve contradiction in Section 3." },
  { id:"p3", name:"Thomas Vidal", role:"Head of Infrastructure", type:"human" as const, status:"pending",
    availability:"Available from 14 Jul", workload:45, pendingRequests:1, responseTime:"< 24 hours", trustScore:78,
    contribution:"1 pending request — technical cost validation not yet started",
    expertise:["Infrastructure architecture","Cloud costs","Vendor management"],
    docsReviewed:3, validationCount:1, novaState:null },
  { id:"p4", name:"Marie Dupont", role:"Legal Counsel",          type:"human" as const, status:"available",
    availability:"Available", workload:30, pendingRequests:0, responseTime:"Unknown", trustScore:0,
    contribution:"Not yet assigned to any section",
    expertise:["Contract law","EU compliance","NDAs"],
    docsReviewed:0, validationCount:0, novaState:null },
];

const SOURCES_DATA = [
  { id:"s1", name:"Q3 Financial Model v4",                      type:"Internal",  status:"available" as const, quality:"verified" as const,
    freshness:"2 days", uses:8, conflicts:0, lastVerified:"11 Jul",
    aiComment:"Cross-checked against 2 sources. No discrepancies in capex section. Revenue projection provisional pending CRM data.",
    qualityScore:92, reliability:94, evidenceScore:89,
    referencedBy:["Board Presentation v1.2","Infrastructure Summary v0.3"],
    decisionsImpacted:["Approve Q3 budget increase"] },
  { id:"s2", name:"Infrastructure Capacity Report — July 2025", type:"Official",  status:"available" as const, quality:"official" as const,
    freshness:"4 days", uses:5, conflicts:0, lastVerified:"9 Jul",
    aiComment:"Authoritative for infrastructure capacity claims. Validated against 2025 procurement contracts.",
    qualityScore:88, reliability:91, evidenceScore:91,
    referencedBy:["Board Presentation v1.2"],
    decisionsImpacted:["Approve Q3 budget increase"] },
  { id:"s3", name:"Product Roadmap Board Deck",                 type:"Internal",  status:"stale" as const,     quality:"outdated" as const,
    freshness:"6 days", uses:3, conflicts:1, lastVerified:"7 Jul",
    aiComment:"6 days old. 1 timeline conflict with Infrastructure Report. Refresh before final presentation.",
    qualityScore:61, reliability:65, evidenceScore:58,
    referencedBy:["Board Presentation v1.2"],
    decisionsImpacted:[] as string[] },
  { id:"s4", name:"CRM Pipeline Export — June 2025",            type:"External",  status:"missing" as const,   quality:"missing" as const,
    freshness:"—",    uses:0, conflicts:0, lastVerified:"—",
    aiComment:"Absent. Revenue projection in Section 3 is provisional. Load this source to raise confidence from 76% to 92%.",
    qualityScore:0, reliability:0, evidenceScore:0,
    referencedBy:[] as string[],
    decisionsImpacted:["Approve Q3 budget increase"] },
];

const DELIVERABLES_DATA = [
  { id:"del1", name:"Q3 Budget Review — Board Presentation", format:"Presentation", status:"review" as const, version:"v1.2",
    audience:"Board of Directors", updated:"4 hours ago",
    publicationScore:64, confidence:76, confAfterAction:92,
    blockerMain:"3 unresolved comments in revenue section",
    nextAction:"Resolve comments to reach publication readiness",
    aiSummary:"3 comments block CFO review. CRM source missing — revenue figures provisional. Resolve comments and load CRM to reach publication readiness.",
    generatedBy:"NOVA", reviewedBy:"Sarah Chen", validatedBy:null as string|null,
    evidenceCoverage:87, completeness:78, pendingComments:3, outstandingReviews:1,
    missingInfo:["CRM pipeline data for revenue section","CFO sign-off pending"],
    versionHistory:[{v:"v1.2",date:"11 Jul",note:"Sarah Chen comments incorporated"},{v:"v1.1",date:"10 Jul",note:"CFO section added"},{v:"v1.0",date:"9 Jul",note:"Initial NOVA draft"}] },
  { id:"del2", name:"Infrastructure Investment Summary", format:"Executive summary", status:"draft" as const, version:"v0.3",
    audience:"CFO", updated:"Yesterday",
    publicationScore:31, confidence:41, confAfterAction:72,
    blockerMain:"CRM source missing — revenue figures provisional",
    nextAction:"Load CRM export and request Thomas Vidal validation",
    aiSummary:"Evidence coverage too low for executive distribution. CRM source and expert validation required before any review can start.",
    generatedBy:"NOVA", reviewedBy:null, validatedBy:null,
    evidenceCoverage:62, completeness:54, pendingComments:0, outstandingReviews:2,
    missingInfo:["CRM source missing — revenue figures provisional","Expert validation not started"],
    versionHistory:[{v:"v0.3",date:"10 Jul",note:"Option comparison added"},{v:"v0.2",date:"9 Jul",note:"Risk section added"},{v:"v0.1",date:"8 Jul",note:"Initial draft"}] },
];

const CLARIFY_QS = [
  { question:"Who needs to act on this, and by when?", rationale:"Knowing the decision-maker and deadline shapes how much depth NOVA prepares and which options matter most.", suggestions:["Board — before the 18 July meeting","CFO only — this week","Full executive team — no fixed deadline"] },
  { question:"What would make this a success?", rationale:"A clear success criterion helps NOVA structure the narrative and prioritise which information to include.", suggestions:["Budget approved with full amount","Board has a clear picture of trade-offs","Decision reached in the meeting"] },
  { question:"Are there constraints I should know about?", rationale:"Constraints affect both the outline and the sources NOVA can use.", suggestions:["Max 12 slides, highly confidential","No constraints","Confidential — board members only"] },
];

// ─── UTILITIES ────────────────────────────────────────────────────────────────

function confColor(pct:number) {
  if (pct>=80) return { color:N.success, bg:N.successBg, brd:"#BBF7D0" };
  if (pct>=55) return { color:"#B45309", bg:N.warnBg,    brd:"#FDE68A" };
  return { color:N.crit, bg:N.critBg, brd:"#FECACA" };
}

// ─── ATOMS ────────────────────────────────────────────────────────────────────

function NOVALabel() {
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:11, fontWeight:650, color:N.inno, background:N.innoBg, border:`1px solid ${N.innoBrd}`, borderRadius:6, padding:"2px 7px", letterSpacing:"-0.01em", fontFamily:FONT }}>
      <Sparkles size={9} strokeWidth={2.5} /> NOVA
    </span>
  );
}

// V6.1 — Confidence chip: "76% confidence" + Why? popover with delta after action
function ConfChip({ pct, afterAction, reasons, positive, missing }:{
  pct:number; afterAction?:number;
  reasons:string[]; positive?:string[]; missing?:string;
}) {
  const [open, setOpen] = useState(false);
  const c = confColor(pct);
  return (
    <div style={{ position:"relative", display:"inline-flex" }}>
      <button onClick={()=>setOpen(!open)}
        style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:12, fontWeight:700, color:c.color, background:"transparent", border:"none", cursor:"pointer", fontFamily:MONO, padding:0, lineHeight:1 }}>
        {pct}%
        <span style={{ fontSize:10, fontFamily:FONT, fontWeight:500, color:c.color, opacity:.7, marginLeft:1 }}>confidence</span>
        <ChevronDown size={9} strokeWidth={2.5} style={{ opacity:.5, transform:open?"rotate(180deg)":"none", transition:T.std }} />
      </button>
      {open && (
        <div style={{ position:"absolute", top:"calc(100% + 8px)", left:0, zIndex:30, background:N.surface, border:`1px solid ${N.border}`, borderRadius:12, boxShadow:SH.overlay, padding:"16px 18px", minWidth:240, width:"max-content", maxWidth:300 }} onClick={e=>e.stopPropagation()}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:12 }}>
            <span style={{ fontSize:11, fontWeight:700, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.05em", fontFamily:FONT }}>Why {pct}%</span>
            {afterAction && afterAction>pct && (
              <span style={{ fontSize:11, fontWeight:700, color:N.success, fontFamily:MONO }}>{pct}% → {afterAction}% after action</span>
            )}
          </div>
          {reasons.map((r,i)=>(
            <div key={i} style={{ display:"flex", gap:7, fontSize:12, color:N.crit, marginBottom:5, lineHeight:1.4, fontFamily:FONT }}>
              <div style={{ width:4, height:4, borderRadius:"50%", background:N.crit, flexShrink:0, marginTop:5 }} />{r}
            </div>
          ))}
          {positive&&positive.length>0 && <>
            <div style={{ height:1, background:N.border, margin:"10px 0 8px" }} />
            {positive.map((r,i)=>(
              <div key={i} style={{ display:"flex", gap:7, fontSize:12, color:N.success, marginBottom:4, lineHeight:1.4, fontFamily:FONT }}>
                <div style={{ width:4, height:4, borderRadius:"50%", background:N.success, flexShrink:0, marginTop:5 }} />{r}
              </div>
            ))}
          </>}
          {missing && <div style={{ marginTop:8, padding:"8px 10px", background:N.warnBg, borderRadius:7, border:`1px solid #FDE68A`, fontSize:11, color:N.warn, fontFamily:FONT }}>Missing: {missing}</div>}
          <button onClick={()=>setOpen(false)} style={{ position:"absolute", top:10, right:10, background:"none", border:"none", cursor:"pointer", color:N.textDis }}><X size={12} strokeWidth={2} /></button>
        </div>
      )}
    </div>
  );
}

// V6.1 — Max 2 badges per card. Urgency badge only.
function DeadlineBadge({ days }:{ days:number }) {
  const variant = days<=4 ? N.crit : days<=10 ? N.warn : N.textSec;
  const bg      = days<=4 ? N.critBg : days<=10 ? N.warnBg : N.subtle;
  const brd     = days<=4 ? "#FECACA" : days<=10 ? "#FDE68A" : N.border;
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:11, fontWeight:600, color:variant, background:bg, border:`1px solid ${brd}`, borderRadius:999, padding:"2px 9px", fontFamily:FONT, whiteSpace:"nowrap" }}>
      <Clock size={9} strokeWidth={2.5} /> Due in {days} day{days!==1?"s":""}
    </span>
  );
}

function StatusDot({ ok }:{ ok:boolean }) {
  return <div style={{ width:7, height:7, borderRadius:"50%", background:ok?N.success:N.border, flexShrink:0 }} />;
}

function Btn({ variant="primary", size="md", children, onClick, disabled, full }:{
  variant?:"primary"|"secondary"|"quiet";
  size?:"sm"|"md"|"lg";
  children:React.ReactNode; onClick?:()=>void; disabled?:boolean; full?:boolean;
}) {
  const [hov, setHov] = useState(false);
  const base:React.CSSProperties = { display:"inline-flex", alignItems:"center", justifyContent:"center", gap:6, borderRadius:9, fontFamily:FONT, fontWeight:600, letterSpacing:"-0.01em", cursor:disabled?"not-allowed":"pointer", transition:T.std, border:"none", outline:"none", width:full?"100%":undefined, opacity:disabled?.4:1, userSelect:"none" };
  const sz:Record<string,React.CSSProperties> = { sm:{ height:32,padding:"0 12px",fontSize:13 }, md:{ height:40,padding:"0 16px",fontSize:14 }, lg:{ height:48,padding:"0 20px",fontSize:15 } };
  const v:Record<string,React.CSSProperties> = {
    primary:   { background:hov&&!disabled?N.actionHv:N.action, color:"#fff", boxShadow:hov&&!disabled?"0 2px 8px rgba(29,78,216,.24)":"none", transform:hov&&!disabled?"translateY(-1px)":"none" },
    secondary: { background:hov&&!disabled?N.subtle:N.surface, color:N.text, border:`1px solid ${hov&&!disabled?N.borderSt:N.borderMd}`, boxShadow:SH.card },
    quiet:     { background:hov&&!disabled?N.subtle:"transparent", color:hov&&!disabled?N.text:N.textSec },
  };
  return <button style={{...base,...sz[size],...v[variant]}} onClick={onClick} disabled={disabled} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>{children}</button>;
}

function Card({ children, style, onClick, accent }:{ children:React.ReactNode; style?:React.CSSProperties; onClick?:()=>void; accent?:string }) {
  const [hov, setHov] = useState(false);
  return (
    <div onClick={onClick} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ background:N.surface, borderRadius:12, border:`1px solid ${hov&&onClick?N.borderMd:N.border}`, boxShadow:hov&&onClick?SH.cardHv:SH.card, transition:T.std, cursor:onClick?"pointer":undefined, borderLeft:accent?`3px solid ${accent}`:undefined, ...style }}>
      {children}
    </div>
  );
}

// V6.1 — Why? inline expandable
function WhyInline({ children }:{ children:React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button onClick={()=>setOpen(!open)}
        style={{ fontSize:12, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, padding:0, textDecoration:"underline", textDecorationStyle:"dotted", textUnderlineOffset:3, display:"inline-flex", alignItems:"center", gap:3 }}>
        Why? <ChevronDown size={9} strokeWidth={2.5} style={{ transform:open?"rotate(180deg)":"none", transition:T.std }} />
      </button>
      {open && (
        <div style={{ marginTop:10, padding:"12px 14px", background:N.innoBg, borderRadius:9, border:`1px solid ${N.innoBrd}`, fontSize:12, color:N.inno, lineHeight:1.6, fontFamily:FONT }}>
          {children}
        </div>
      )}
    </div>
  );
}

// V6.1 — Drawer with narrative structure: Summary → Why → Blocking → Evidence → History → Technical
function Drawer({ open, onClose, title, children }:{ open:boolean; onClose:()=>void; title:string; children:React.ReactNode }) {
  if (!open) return null;
  return (
    <div style={{ position:"fixed", inset:0, zIndex:50 }}>
      <div style={{ position:"absolute", inset:0, background:"rgba(15,23,42,.2)", backdropFilter:"blur(2px)" }} onClick={onClose} />
      <div style={{ position:"absolute", top:0, right:0, bottom:0, width:460, background:N.surface, boxShadow:SH.overlay, display:"flex", flexDirection:"column" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"20px 24px", borderBottom:`1px solid ${N.border}`, flexShrink:0 }}>
          <span style={{ fontSize:15, fontWeight:650, color:N.text, fontFamily:FONT, letterSpacing:"-0.015em" }}>{title}</span>
          <button onClick={onClose} style={{ background:"none", border:"none", cursor:"pointer", color:N.textDis, padding:4 }}><X size={15} strokeWidth={2} /></button>
        </div>
        <div style={{ flex:1, overflowY:"auto", padding:"24px" }}>{children}</div>
      </div>
    </div>
  );
}

function DrawerSection({ label, children }:{ label:string; children:React.ReactNode }) {
  return (
    <div style={{ marginBottom:24 }}>
      <div style={{ fontSize:10, fontWeight:700, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:10, fontFamily:FONT }}>{label}</div>
      {children}
    </div>
  );
}

function DrawerRow({ label, value, color }:{ label:string; value:string|number; color?:string }) {
  return (
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", padding:"9px 0", borderBottom:`1px solid ${N.border}` }}>
      <span style={{ fontSize:13, color:N.textSec, fontFamily:FONT }}>{label}</span>
      <span style={{ fontSize:13, fontWeight:600, color:color??N.text, fontFamily:FONT, textAlign:"right", maxWidth:220 }}>{value}</span>
    </div>
  );
}

function Divider() { return <div style={{ height:1, background:N.border }} />; }

// ─── NAV RAIL ─────────────────────────────────────────────────────────────────

function NavRail({ view, setView, onSearch }:{ view:View; setView:(v:View)=>void; onSearch:()=>void }) {
  const primary = [
    { id:"home" as View,                icon:<Home size={16} strokeWidth={2} />,       label:"Home" },
    { id:"work" as View,                icon:<Briefcase size={16} strokeWidth={2} />,  label:"Work" },
    { id:"global-decisions" as View,    icon:<Scale size={16} strokeWidth={2} />,      label:"Decisions" },
    { id:"global-deliverables" as View, icon:<FileText size={16} strokeWidth={2} />,   label:"Deliverables" },
  ];
  const isAct = (id:string) => view===id||(id==="work"&&["clarify","canvas","plan","confirm","work"].includes(view));

  function Item({ icon, label, id, action, badge }:{ icon:React.ReactNode; label:string; id?:string; action?:()=>void; badge?:string }) {
    const [hov, setHov] = useState(false);
    const act = id ? isAct(id) : false;
    return (
      <button onClick={action??(id?()=>setView(id as View):undefined)} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
        style={{ width:"100%", display:"flex", alignItems:"center", gap:9, padding:"8px 12px 8px 14px", borderRadius:8, border:"none", borderLeft:`2px solid ${act?N.action:"transparent"}`, background:act?N.actionBg:hov?"rgba(15,23,42,.04)":"transparent", color:act?N.action:hov?N.text:N.textSec, fontFamily:FONT, fontSize:13, fontWeight:act?600:400, cursor:"pointer", transition:T.std, textAlign:"left", marginLeft:"-2px", letterSpacing:"-0.01em" }}>
        <span style={{ flexShrink:0, opacity:act?1:.7 }}>{icon}</span>
        <span style={{ flex:1 }}>{label}</span>
        {badge && <span style={{ fontSize:11, fontWeight:700, background:N.critBg, color:N.crit, borderRadius:999, padding:"1px 6px" }}>{badge}</span>}
      </button>
    );
  }

  return (
    <aside style={{ width:220, flexShrink:0, background:N.surface, borderRight:`1px solid ${N.border}`, display:"flex", flexDirection:"column", padding:"24px 16px 20px", height:"100vh", position:"sticky", top:0 }}>
      <div style={{ display:"flex", alignItems:"center", gap:9, paddingLeft:14, marginBottom:28 }}>
        <div style={{ width:26, height:26, borderRadius:8, background:`linear-gradient(135deg, ${N.action} 0%, #6D28D9 100%)`, display:"flex", alignItems:"center", justifyContent:"center" }}>
          <Sparkles size={13} color="#fff" strokeWidth={2.5} />
        </div>
        <span style={{ fontSize:15, fontWeight:700, color:N.text, letterSpacing:"-0.03em", fontFamily:FONT }}>NOVA</span>
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:1, flex:1 }}>
        {primary.map(item=><Item key={item.id} {...item} badge={item.id==="global-decisions"?"1":undefined} />)}
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:1 }}>
        <Divider /><div style={{ height:10 }} />
        <Item icon={<Search size={16} strokeWidth={2} />}     label="Search"       action={onSearch} />
        <Item icon={<Bell size={16} strokeWidth={2} />}       label="Notifications" />
        <Item icon={<HelpCircle size={16} strokeWidth={2} />} label="Help" />
        <Item icon={<Settings size={16} strokeWidth={2} />}   label="Preferences" />
        <div style={{ height:10 }} /><Divider />
        <div style={{ display:"flex", alignItems:"center", gap:9, padding:"10px 14px", borderRadius:8, cursor:"pointer" }}
          onMouseEnter={e=>e.currentTarget.style.background="rgba(15,23,42,.04)"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
          <div style={{ width:26, height:26, borderRadius:"50%", background:`linear-gradient(135deg, #2563EB, #7C3AED)`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:700, color:"#fff", flexShrink:0 }}>SC</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:13, fontWeight:600, color:N.text, fontFamily:FONT }}>Sarah Chen</div>
            <div style={{ fontSize:11, color:N.textDis, fontFamily:FONT }}>Standard</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

// ─── HOME V6.1 ────────────────────────────────────────────────────────────────

function HomeView({ setView, setActiveWork, setActiveDecision }:{ setView:(v:View)=>void; setActiveWork:(id:string)=>void; setActiveDecision:(id:string)=>void }) {
  const [val, setVal] = useState("");
  const [composerOpen, setComposerOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const ref = useRef<HTMLTextAreaElement>(null);
  const EXAMPLES = ["Prepare a board presentation on Q3 results","Analyse reasons for the drop in NPS","Draft a proposal for a new supplier partnership"];

  return (
    <div style={{ maxWidth:880, margin:"0 auto", padding:"52px 52px 100px" }}>
      <div style={{ marginBottom:32 }}>
        <h1 style={{ fontSize:27, fontWeight:650, color:N.text, margin:"0 0 4px", letterSpacing:"-0.03em", fontFamily:FONT }}>Good afternoon, Sarah.</h1>
        <p style={{ fontSize:14, color:N.textDis, margin:0, fontFamily:FONT }}>1 decision due in 4 days · 2 active work items</p>
      </div>

      {/* Composer */}
      <div style={{ marginBottom:44 }}>
        <div style={{ background:N.surface, borderRadius:14, border:`1.5px solid ${composerOpen?N.action:N.borderMd}`, boxShadow:composerOpen?`${SH.overlay},0 0 0 4px rgba(29,78,216,.07)`:SH.cardHv, transition:"all 280ms "+ease, overflow:"hidden" }}>
          {!composerOpen ? (
            <button onClick={()=>{ setComposerOpen(true); setTimeout(()=>ref.current?.focus(),50); }}
              style={{ width:"100%", padding:"20px 24px", background:"none", border:"none", textAlign:"left", cursor:"text", display:"flex", alignItems:"center", gap:14, fontFamily:FONT }}>
              <div style={{ width:36, height:36, borderRadius:10, background:N.actionBg, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                <Sparkles size={15} color={N.action} strokeWidth={2} />
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:15, color:N.textDis }}>What would you like to achieve?</div>
                <div style={{ fontSize:12, color:N.textDis, marginTop:3, opacity:.65 }}>Describe your objective. NOVA builds the work, coordinates contributors, validates evidence and prepares the final deliverables.</div>
              </div>
            </button>
          ) : (
            <div style={{ padding:"20px 24px 0" }}>
              <label style={{ display:"block", fontSize:13, fontWeight:600, color:N.textSec, marginBottom:8, fontFamily:FONT }}>What would you like to achieve?</label>
              <textarea ref={ref} value={val} onChange={e=>setVal(e.target.value)} onKeyDown={e=>{ if(e.key==="Enter"&&e.metaKey){ setLoading(true); setTimeout(()=>{ setLoading(false); setView("clarify"); },500); } }}
                placeholder="Describe your goal. NOVA will ask only what's needed."
                style={{ width:"100%", border:"none", outline:"none", fontSize:15, color:N.text, fontFamily:FONT, resize:"none", lineHeight:1.65, background:"transparent", minHeight:80, boxSizing:"border-box" }} />
            </div>
          )}
          {composerOpen && (
            <div style={{ padding:"10px 22px 16px", borderTop:`1px solid ${N.border}`, display:"flex", alignItems:"center", gap:8, marginTop:4 }}>
              <button style={{ display:"flex", alignItems:"center", gap:4, padding:"5px 10px", background:"none", border:`1px solid ${N.border}`, borderRadius:7, fontSize:12, color:N.textSec, cursor:"pointer", fontFamily:FONT }}><Paperclip size={11} strokeWidth={2} /> Attach</button>
              <button style={{ display:"flex", alignItems:"center", gap:4, padding:"5px 10px", background:"none", border:`1px solid ${N.border}`, borderRadius:7, fontSize:12, color:N.textSec, cursor:"pointer", fontFamily:FONT }}><Mic size={11} strokeWidth={2} /> Voice</button>
              <div style={{ flex:1 }} />
              <button onClick={()=>{ setComposerOpen(false); setVal(""); }} style={{ padding:"5px 12px", background:"none", border:"none", fontSize:13, color:N.textSec, cursor:"pointer", fontFamily:FONT }}>Cancel</button>
              <Btn variant="primary" size="sm" onClick={()=>{ if(!val.trim())return; setLoading(true); setTimeout(()=>{ setLoading(false); setView("clarify"); },500); }} disabled={!val.trim()||loading}>
                {loading ? <><RefreshCw size={12} strokeWidth={2.5} style={{ animation:"spin 1s linear infinite" }} /> Working…</> : <>Continue <ArrowRight size={13} strokeWidth={2.5} /></>}
              </Btn>
            </div>
          )}
        </div>
        {!composerOpen && (
          <div style={{ display:"flex", gap:8, marginTop:10, flexWrap:"wrap" }}>
            <span style={{ fontSize:12, color:N.textDis, fontFamily:FONT }}>Try:</span>
            {EXAMPLES.map((ex,i)=>(
              <button key={i} onClick={()=>{ setComposerOpen(true); setVal(ex); setTimeout(()=>ref.current?.focus(),50); }}
                style={{ padding:"3px 11px", background:"transparent", border:`1px solid ${N.border}`, borderRadius:999, fontSize:12, color:N.textSec, cursor:"pointer", fontFamily:FONT, transition:T.fast }}
                onMouseEnter={e=>{ e.currentTarget.style.borderColor=N.action; e.currentTarget.style.color=N.action; e.currentTarget.style.background=N.actionBg; }}
                onMouseLeave={e=>{ e.currentTarget.style.borderColor=N.border; e.currentTarget.style.color=N.textSec; e.currentTarget.style.background="transparent"; }}>
                {ex}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── FOCAL POINT: Hero block ── */}
      <div style={{ padding:"28px 32px", background:`linear-gradient(135deg,${N.actionBg} 0%,${N.innoBg} 100%)`, borderRadius:16, border:`1px solid ${N.innoBrd}`, boxShadow:SH.hero, marginBottom:24 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:14 }}>
          <NOVALabel />
          <span style={{ fontSize:12, color:N.textDis, fontFamily:FONT }}>Situation · now</span>
        </div>
        <p style={{ fontSize:15, fontWeight:400, color:N.textSec, margin:"0 0 8px", lineHeight:1.6, fontFamily:FONT }}>{WORK_ITEMS[0].heroSentence}</p>
        <p style={{ fontSize:19, fontWeight:700, color:N.text, margin:"0 0 22px", lineHeight:1.5, letterSpacing:"-0.022em", fontFamily:FONT }}>{WORK_ITEMS[0].heroGain}</p>
        <div style={{ display:"flex", alignItems:"center", gap:12, flexWrap:"wrap" }}>
          <Btn variant="primary" size="md" onClick={()=>{ setActiveWork("w1"); setView("work"); }}>
            Open presentation <ArrowRight size={14} strokeWidth={2.5} />
          </Btn>
          <WhyInline>{WORK_ITEMS[0].nextActionWhy}</WhyInline>
          <button onClick={()=>setDetailOpen(true)} style={{ fontSize:12, color:N.textDis, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, marginLeft:"auto", display:"flex", alignItems:"center", gap:3 }}>
            Details <ChevronRight size={11} strokeWidth={2} />
          </button>
        </div>
      </div>

      {/* ── Decision — secondary focal */}
      <div style={{ marginBottom:24 }}>
        <Card onClick={()=>{ setActiveDecision("d1"); setView("decision-package"); }} accent={N.crit} style={{ padding:"18px 24px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <div style={{ width:36, height:36, borderRadius:10, background:N.critBg, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
              <Scale size={15} color={N.crit} strokeWidth={2} />
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              {/* V6.1: exactly 2 badges — deadline + confidence */}
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                <DeadlineBadge days={4} />
                <ConfChip pct={82} afterAction={92} reasons={["Revenue projection provisional — CRM pending","CFO pre-review not started"]} positive={["3 options fully evaluated","Infrastructure capacity validated"]} missing="CRM export — revenue section provisional" />
              </div>
              <div style={{ fontSize:14, fontWeight:600, color:N.text, fontFamily:FONT, lineHeight:1.4 }}>Approve Q3 budget increase of €420k for cloud infrastructure</div>
              <div style={{ fontSize:13, color:N.crit, marginTop:3, fontFamily:FONT }}>Without this decision by 15 July, the Q3 product launch is cancelled.</div>
            </div>
            <ArrowRight size={15} color={N.textDis} strokeWidth={2} style={{ flexShrink:0 }} />
          </div>
        </Card>
      </div>

      {/* ── Active work — visually secondary ── */}
      <div style={{ marginBottom:20 }}>
        <div style={{ fontSize:11, fontWeight:600, color:N.textDis, letterSpacing:"0.04em", textTransform:"uppercase", fontFamily:FONT, marginBottom:10 }}>Active work</div>
        <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
          {WORK_ITEMS.map(w=>(
            <div key={w.id} onClick={()=>{ setActiveWork(w.id); setView("work"); }}
              style={{ display:"flex", alignItems:"center", gap:14, padding:"13px 18px", background:N.surface, borderRadius:10, border:`1px solid ${N.border}`, cursor:"pointer", transition:T.std, boxShadow:SH.card }}
              onMouseEnter={e=>{ e.currentTarget.style.borderColor=N.borderMd; e.currentTarget.style.boxShadow=SH.cardHv; }}
              onMouseLeave={e=>{ e.currentTarget.style.borderColor=N.border; e.currentTarget.style.boxShadow=SH.card; }}>
              <StatusDot ok={w.health==="active"||w.health==="complete"} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:13, fontWeight:500, color:N.text, fontFamily:FONT, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{w.outcome}</div>
                <div style={{ fontSize:12, color:w.health==="blocked"?N.crit:N.textSec, marginTop:2, fontFamily:FONT }}>{w.nextAction}</div>
              </div>
              {/* V6.1: confidence only — no health badge */}
              <ConfChip pct={w.confidence} afterAction={w.confAfterAction} reasons={w.confReasons} positive={[]} missing={w.confMissing} />
              <div style={{ fontSize:12, color:N.textDis, fontFamily:FONT, flexShrink:0 }}>{w.deadline}</div>
            </div>
          ))}
        </div>
      </div>

      {/* NOVA background row */}
      <div style={{ padding:"12px 18px", background:N.innoBg, borderRadius:10, border:`1px solid ${N.innoBrd}`, display:"flex", alignItems:"center", gap:10 }}>
        <NOVALabel />
        <span style={{ fontSize:13, color:N.inno, fontFamily:FONT, flex:1 }}>Working in background · You save approximately <strong>6 hours of review</strong> this week · 1 conflict detected</span>
        <button onClick={()=>setDetailOpen(true)} style={{ fontSize:12, color:N.inno, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, display:"flex", alignItems:"center", gap:3 }}>Details <ChevronRight size={11} strokeWidth={2} /></button>
      </div>

      {/* Details drawer — narrative order */}
      <Drawer open={detailOpen} onClose={()=>setDetailOpen(false)} title="Situation details">
        <DrawerSection label="Summary">
          <p style={{ fontSize:14, color:N.text, fontFamily:FONT, lineHeight:1.65, margin:0 }}>
            The board presentation is the highest priority item. It is 72% complete and blocked by 3 open comments and 1 missing source. Resolving these raises confidence from 76% to 92% and unblocks the CFO review.
          </p>
        </DrawerSection>
        <DrawerSection label="Why it matters">
          <p style={{ fontSize:13, color:N.textSec, fontFamily:FONT, lineHeight:1.6, margin:0 }}>
            The CFO must review and pre-approve the budget figures before the 18 July board meeting. Without his sign-off, the budget decision cannot be made at the meeting.
          </p>
        </DrawerSection>
        <DrawerSection label="What is blocking">
          {["3 open comments in revenue section — Sarah Chen","CRM Pipeline Export not loaded — revenue projection provisional","Product Roadmap deck outdated by 6 days"].map((b,i)=>(
            <div key={i} style={{ display:"flex", gap:8, fontSize:13, color:N.crit, marginBottom:5, fontFamily:FONT }}><AlertTriangle size={11} style={{ flexShrink:0, marginTop:2 }} strokeWidth={2} />{b}</div>
          ))}
        </DrawerSection>
        <DrawerSection label="Later actions">
          {WORK_ITEMS.flatMap(w=>[...w.laterActions,...w.backgroundActions]).map((a,i)=>(
            <div key={i} style={{ fontSize:13, color:N.textSec, fontFamily:FONT, padding:"8px 0", borderBottom:`1px solid ${N.border}` }}>{a}</div>
          ))}
        </DrawerSection>
        <DrawerSection label="Technical details">
          {[["Documents analysed","42"],["Sources validated","3 of 4"],["Time saved","~6 h"],["Conflicts detected","1"]].map(([l,v],i)=>(
            <DrawerRow key={i} label={l} value={v} />
          ))}
        </DrawerSection>
      </Drawer>
    </div>
  );
}

// ─── CLARIFY ──────────────────────────────────────────────────────────────────

function ClarifyView({ setView }:{ setView:(v:View)=>void }) {
  const [step, setStep] = useState(0);
  const [current, setCurrent] = useState("");
  const q = CLARIFY_QS[step];
  function next() { setCurrent(""); step<CLARIFY_QS.length-1?setStep(step+1):setView("canvas"); }
  return (
    <div style={{ maxWidth:600, margin:"0 auto", padding:"72px 48px" }}>
      <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:52 }}>
        <button onClick={()=>step>0?setStep(step-1):setView("home")} style={{ fontSize:13, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, display:"flex", alignItems:"center", gap:4 }}><ChevronLeft size={13} strokeWidth={2.5} /> Back</button>
        <div style={{ flex:1, height:2, background:N.border, borderRadius:999, overflow:"hidden" }}><div style={{ width:`${((step+1)/CLARIFY_QS.length)*100}%`, height:"100%", background:N.action, borderRadius:999 }} /></div>
        <span style={{ fontSize:12, color:N.textDis, fontFamily:FONT }}>{step+1} / {CLARIFY_QS.length}</span>
      </div>
      <div style={{ padding:"12px 16px", background:N.subtle, borderRadius:9, border:`1px solid ${N.border}`, marginBottom:36 }}>
        <div style={{ fontSize:10, fontWeight:600, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4, fontFamily:FONT }}>Your objective</div>
        <p style={{ fontSize:13, color:N.textSec, margin:0, lineHeight:1.55, fontFamily:FONT }}>Prepare a board presentation on Q3 budget results and the infrastructure investment needed for Q4.</p>
      </div>
      <h2 style={{ fontSize:22, fontWeight:650, color:N.text, margin:"0 0 18px", letterSpacing:"-0.025em", fontFamily:FONT }}>{q.question}</h2>
      <details style={{ marginBottom:20 }}>
        <summary style={{ fontSize:12, color:N.textSec, cursor:"pointer", listStyle:"none", display:"flex", alignItems:"center", gap:4, fontFamily:FONT }}><Info size={11} strokeWidth={2} /> Why does this matter?</summary>
        <p style={{ fontSize:12, color:N.textSec, margin:"7px 0 0 15px", lineHeight:1.6, fontFamily:FONT }}>{q.rationale}</p>
      </details>
      <div style={{ display:"flex", flexDirection:"column", gap:7, marginBottom:20 }}>
        {q.suggestions.map((s,i)=>(
          <button key={i} onClick={()=>setCurrent(s)}
            style={{ padding:"12px 16px", background:current===s?N.actionBg:N.surface, border:`1.5px solid ${current===s?N.action:N.border}`, borderRadius:10, fontSize:13, color:current===s?N.action:N.text, cursor:"pointer", textAlign:"left", fontFamily:FONT, transition:T.std, display:"flex", alignItems:"center", gap:10, boxShadow:SH.card }}>
            <div style={{ width:16, height:16, borderRadius:"50%", border:`2px solid ${current===s?N.action:N.borderMd}`, background:current===s?N.action:"transparent", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
              {current===s && <Check size={8} color="#fff" strokeWidth={3} />}
            </div>{s}
          </button>
        ))}
      </div>
      <textarea value={current} onChange={e=>setCurrent(e.target.value)} placeholder="Or describe in your own words…"
        style={{ width:"100%", minHeight:72, border:`1.5px solid ${current&&!q.suggestions.includes(current)?N.action:N.border}`, borderRadius:10, padding:"12px 14px", fontSize:13, color:N.text, fontFamily:FONT, resize:"none", outline:"none", lineHeight:1.6, boxSizing:"border-box", marginBottom:32 }} />
      <div style={{ display:"flex", gap:10 }}>
        <Btn variant="primary" size="md" onClick={next} disabled={!current}>{step<CLARIFY_QS.length-1?"Continue":"Review understanding"} <ArrowRight size={13} strokeWidth={2.5} /></Btn>
        <Btn variant="quiet" size="md" onClick={next}>Skip</Btn>
      </div>
    </div>
  );
}

// ─── CANVAS ───────────────────────────────────────────────────────────────────

function CanvasView({ setView }:{ setView:(v:View)=>void }) {
  const sections = [
    { label:"Outcome",              value:"Prepare a clear, decision-ready Q3 budget review presentation for the board, including the infrastructure investment case for Q4." },
    { label:"Audience and purpose", value:"Board of directors. Secure approval for the €420k infrastructure investment and align on Q3 performance." },
    { label:"Success",              value:"Board has a clear picture of Q3 results and options. Investment decision reached in the meeting." },
    { label:"Constraints",          value:"Maximum 12 slides. Highly confidential — board members only. Deadline: 18 July." },
    { label:"Assumptions",          value:"Revenue projections use June pipeline data. CRM export assumed available by 15 July.", warn:true },
    { label:"People and authority", value:"You own the work. Sarah Chen reviews financial sections. CFO approves budget decision." },
  ];
  const [editing, setEditing] = useState<number|null>(null);
  return (
    <div style={{ maxWidth:680, margin:"0 auto", padding:"64px 48px" }}>
      <button onClick={()=>setView("clarify")} style={{ fontSize:13, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, marginBottom:28, display:"flex", alignItems:"center", gap:4 }}>
        <ChevronLeft size={13} strokeWidth={2.5} /> Back
      </button>
      <NOVALabel />
      <h1 style={{ fontSize:24, fontWeight:650, color:N.text, margin:"10px 0 6px", letterSpacing:"-0.025em", fontFamily:FONT }}>Here's what I understand about your work</h1>
      <p style={{ fontSize:14, color:N.textSec, margin:"0 0 36px", lineHeight:1.6, fontFamily:FONT }}>Review and correct anything before I prepare a plan.</p>
      <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:36 }}>
        {sections.map((s,i)=>(
          <Card key={i} style={{ padding:"16px 20px" }}>
            <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:10, fontWeight:600, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:5, fontFamily:FONT }}>{s.label}</div>
                {editing===i ? <textarea defaultValue={s.value} style={{ width:"100%", border:`1.5px solid ${N.action}`, borderRadius:8, padding:"8px 12px", fontSize:13, fontFamily:FONT, resize:"vertical", outline:"none", lineHeight:1.6, boxSizing:"border-box", minHeight:64 }} autoFocus /> : <p style={{ fontSize:13, color:N.text, margin:0, lineHeight:1.6, fontFamily:FONT }}>{s.value}</p>}
              </div>
              <button onClick={()=>setEditing(editing===i?null:i)} style={{ display:"flex", alignItems:"center", gap:3, padding:"3px 9px", background:"none", border:`1px solid ${N.border}`, borderRadius:6, fontSize:11, color:N.textSec, cursor:"pointer", fontFamily:FONT, flexShrink:0 }}>
                {editing===i ? <><Check size={9} strokeWidth={3} /> Save</> : <><Edit2 size={9} strokeWidth={2} /> Edit</>}
              </button>
            </div>
            {s.warn && (
              <div style={{ marginTop:12, padding:"10px 12px", background:N.warnBg, borderRadius:7, border:`1px solid #FDE68A`, display:"flex", gap:8 }}>
                <AlertTriangle size={12} color={N.warn} style={{ flexShrink:0, marginTop:1 }} strokeWidth={2} />
                <div style={{ fontSize:12, color:N.warn, fontFamily:FONT }}>Assumption to confirm: CRM export availability is unconfirmed. This affects revenue projections.</div>
              </div>
            )}
          </Card>
        ))}
      </div>
      <Btn variant="primary" size="lg" onClick={()=>setView("plan")}>Prepare a plan <ArrowRight size={14} strokeWidth={2.5} /></Btn>
    </div>
  );
}

// ─── PLAN V6.1 ────────────────────────────────────────────────────────────────
// Each phase: expected outcome + status + remaining + main blocker + probability

function PlanView({ setView }:{ setView:(v:View)=>void }) {
  const phases = [
    { name:"Research and sources",   outcome:"All data assembled and contradiction-free",                 status:"complete" as const, days:"Jul 9–11",  prob:98, remaining:"0 h",  blocker:null as string|null,
      detail:{ ai:"Load and analyse financial and technical sources", human:"Thomas Vidal validates infrastructure figures" },
      actions:[{l:"Load Q3 financial model",d:true},{l:"Review infrastructure report",d:true},{l:"Request CRM export access",d:true}] },
    { name:"Analysis and synthesis", outcome:"3 options ranked with risk and financial impact",           status:"complete" as const, days:"Jul 11–14", prob:94, remaining:"0 h",  blocker:null,
      detail:{ ai:"Cross-reference sources, synthesize options", human:"Sarah Chen reviews financial assumptions" },
      actions:[{l:"Synthesize Q3 performance",d:true},{l:"Develop investment case",d:true},{l:"Sarah Chen financial review",d:true}] },
    { name:"Draft and review",       outcome:"Board-ready draft approved by all reviewers",               status:"active" as const,   days:"Jul 14–18", prob:81, remaining:"~6 h", blocker:"3 comments unresolved · CRM source missing",
      detail:{ ai:"Generate slide deck, narrative structure, consistency check", human:"Resolve 3 open comments, CFO pre-review" },
      actions:[{l:"Generate slide draft v1",d:true},{l:"Resolve 3 open comments",d:false},{l:"CFO pre-review",d:false}] },
    { name:"Finalize and deliver",   outcome:"Approved presentation delivered to board",                  status:"future" as const,   days:"Jul 18",    prob:74, remaining:"~4 h", blocker:"CFO approval not yet secured",
      detail:{ ai:"Export, final consistency check, delivery package", human:"CFO approval, board distribution" },
      actions:[{l:"Final approval",d:false},{l:"Board delivery",d:false}] },
  ];
  const [exp, setExp] = useState<number|null>(2);
  return (
    <div style={{ maxWidth:720, margin:"0 auto", padding:"64px 48px" }}>
      <button onClick={()=>setView("canvas")} style={{ fontSize:13, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, marginBottom:32, display:"flex", alignItems:"center", gap:4 }}>
        <ChevronLeft size={13} strokeWidth={2.5} /> Back
      </button>
      <NOVALabel />
      <h1 style={{ fontSize:24, fontWeight:650, color:N.text, margin:"10px 0 6px", letterSpacing:"-0.025em", fontFamily:FONT }}>Here's a plan for your work</h1>
      <p style={{ fontSize:14, color:N.textSec, margin:"0 0 36px", lineHeight:1.6, fontFamily:FONT }}>Review phases and decisions before you start.</p>
      <div style={{ display:"flex", flexDirection:"column", marginBottom:36 }}>
        {phases.map((p,i)=>(
          <div key={i} style={{ display:"flex", gap:0 }}>
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center", width:38, flexShrink:0 }}>
              <div style={{ width:24, height:24, borderRadius:"50%", border:`2px solid ${exp===i?N.action:p.status==="complete"?N.success:N.border}`, background:exp===i?N.actionBg:p.status==="complete"?N.successBg:N.surface, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:700, color:exp===i?N.action:p.status==="complete"?N.success:N.textDis, transition:T.std, fontFamily:FONT }}>{p.status==="complete"?<Check size={10} strokeWidth={3} />:i+1}</div>
              {i<phases.length-1 && <div style={{ width:1.5, flex:1, background:N.border, minHeight:22, margin:"3px 0" }} />}
            </div>
            <div style={{ flex:1, paddingLeft:14, paddingBottom:i<phases.length-1?20:0 }}>
              <button onClick={()=>setExp(exp===i?null:i)} style={{ width:"100%", textAlign:"left", background:"none", border:"none", cursor:"pointer", padding:0, display:"flex", gap:10, marginBottom:exp===i?10:0 }}>
                <div style={{ flex:1 }}>
                  {/* V6.1: outcome first, metadata secondary */}
                  <div style={{ fontSize:14, fontWeight:600, color:N.text, fontFamily:FONT, marginBottom:2 }}>{p.outcome}</div>
                  <div style={{ fontSize:12, color:N.textSec, fontFamily:FONT, display:"flex", gap:10 }}>
                    <span>{p.days}</span><span>·</span>
                    <span style={{ fontWeight:600, color:confColor(p.prob).color }}>{p.prob}% probability</span>
                    <span>·</span><span>Remaining: {p.remaining}</span>
                  </div>
                  {p.blocker && <div style={{ fontSize:11, color:N.warn, marginTop:3, fontFamily:FONT, display:"flex", alignItems:"center", gap:4 }}><AlertTriangle size={9} strokeWidth={2} /> {p.blocker}</div>}
                </div>
                <ChevronDown size={12} color={N.textDis} strokeWidth={2} style={{ transform:exp===i?"rotate(180deg)":"none", transition:T.std, flexShrink:0, marginTop:4 }} />
              </button>
              {exp===i && (
                <div style={{ background:N.subtle, borderRadius:10, padding:"14px 16px", border:`1px solid ${N.border}`, marginBottom:2 }}>
                  {/* V6.1: AI/Human detail hidden in expanded section */}
                  <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:12 }}>
                    <div><div style={{ fontSize:10, fontWeight:700, color:N.inno, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:3, fontFamily:FONT }}>AI contribution</div><div style={{ fontSize:12, color:N.textSec, fontFamily:FONT, lineHeight:1.5 }}>{p.detail.ai}</div></div>
                    <div><div style={{ fontSize:10, fontWeight:700, color:N.textSec, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:3, fontFamily:FONT }}>Human contribution</div><div style={{ fontSize:12, color:N.textSec, fontFamily:FONT, lineHeight:1.5 }}>{p.detail.human}</div></div>
                  </div>
                  {p.actions.map((a,j)=>(
                    <div key={j} style={{ display:"flex", alignItems:"center", gap:8, fontSize:12, color:a.d?N.textDis:N.text, fontFamily:FONT, marginBottom:5 }}>
                      <div style={{ width:14, height:14, borderRadius:"50%", border:`1.5px solid ${a.d?N.success:N.borderMd}`, background:a.d?N.success:"transparent", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                        {a.d && <Check size={7} color="#fff" strokeWidth={3} />}
                      </div>
                      <span style={{ textDecoration:a.d?"line-through":"none" }}>{a.l}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding:"14px 18px", background:N.innoBg, borderRadius:10, border:`1px solid ${N.innoBrd}`, marginBottom:28 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4 }}><NOVALabel /><ConfChip pct={68} afterAction={88} reasons={["CRM export access unconfirmed — may delay Phase 1","Revenue projection provisional"]} positive={["Scope and team confirmed"]} missing="CRM export access" /></div>
        <p style={{ fontSize:13, color:N.inno, margin:0, fontFamily:FONT, lineHeight:1.5 }}>CRM export access unconfirmed — may delay Phase 1 by 1–2 days.</p>
      </div>
      <Btn variant="primary" size="lg" onClick={()=>setView("confirm")}>Review and start <ArrowRight size={14} strokeWidth={2.5} /></Btn>
    </div>
  );
}

// ─── CONFIRM ─────────────────────────────────────────────────────────────────

function ConfirmView({ setView, setActiveWork }:{ setView:(v:View)=>void; setActiveWork:(id:string)=>void }) {
  const [aut, setAut] = useState(1);
  const levels = [
    { level:0, sub:"A0", label:"Ask me first",      will:[] as string[], ask:["Search sources","Draft any content","Send any message"] },
    { level:1, sub:"A1", label:"Guided execution",  will:["Research and read sources in scope","Draft content for your review"], ask:["Use external data","Make changes visible to others"] },
    { level:2, sub:"A2", label:"Active assistance", will:["Research, draft and synthesize","Notify you when input is needed"], ask:["Share externally","Record any decision"] },
    { level:3, sub:"A3", label:"Full autonomy",     will:["Execute the full plan within agreed scope","Surface exceptions only"], ask:["Any legal, financial or external commitments"] },
  ];
  const sel = levels[aut];
  return (
    <div style={{ maxWidth:580, margin:"0 auto", padding:"64px 48px" }}>
      <button onClick={()=>setView("plan")} style={{ fontSize:13, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, marginBottom:36, display:"flex", alignItems:"center", gap:4 }}>
        <ChevronLeft size={13} strokeWidth={2.5} /> Back to plan
      </button>
      <h1 style={{ fontSize:24, fontWeight:650, color:N.text, margin:"0 0 6px", letterSpacing:"-0.025em", fontFamily:FONT }}>Set autonomy</h1>
      <p style={{ fontSize:14, color:N.textSec, margin:"0 0 28px", lineHeight:1.6, fontFamily:FONT }}>Choose how much NOVA should do without checking with you first.</p>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:22 }}>
        {levels.map(l=>(
          <button key={l.level} onClick={()=>setAut(l.level)}
            style={{ padding:"14px 16px", background:aut===l.level?N.actionBg:N.surface, border:`1.5px solid ${aut===l.level?N.action:N.border}`, borderRadius:10, cursor:"pointer", textAlign:"left", fontFamily:FONT, transition:T.std }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
              <span style={{ fontSize:13, fontWeight:600, color:aut===l.level?N.action:N.text, fontFamily:FONT }}>{l.label}</span>
              <span style={{ fontSize:10, fontWeight:700, color:aut===l.level?N.action:N.textDis, background:aut===l.level?"rgba(29,78,216,.12)":N.subtle, borderRadius:4, padding:"1px 5px", fontFamily:MONO }}>{l.sub}</span>
            </div>
          </button>
        ))}
      </div>
      <Card style={{ padding:"16px 20px", marginBottom:36 }}>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18 }}>
          {sel.will.length>0 && <div><div style={{ fontSize:10, fontWeight:600, color:N.success, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:7, fontFamily:FONT }}>NOVA will</div>{sel.will.map((item,i)=><div key={i} style={{ display:"flex", gap:7, fontSize:12, color:N.textSec, marginBottom:4, fontFamily:FONT }}><CheckCircle size={11} color={N.success} strokeWidth={2.5} style={{ flexShrink:0, marginTop:2 }} />{item}</div>)}</div>}
          <div><div style={{ fontSize:10, fontWeight:600, color:N.warn, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:7, fontFamily:FONT }}>NOVA will ask first</div>{sel.ask.map((item,i)=><div key={i} style={{ display:"flex", gap:7, fontSize:12, color:N.textSec, marginBottom:4, fontFamily:FONT }}><AlertTriangle size={11} color={N.warn} strokeWidth={2.5} style={{ flexShrink:0, marginTop:2 }} />{item}</div>)}</div>
        </div>
      </Card>
      <Btn variant="primary" size="lg" full onClick={()=>{ setActiveWork("w1"); setView("work"); }}>Start work <ArrowRight size={14} strokeWidth={2.5} /></Btn>
    </div>
  );
}

// ─── WORK SHELL ───────────────────────────────────────────────────────────────

function WorkView({ workId, setView, setActiveDecision }:{ workId:string; setView:(v:View)=>void; setActiveDecision:(id:string)=>void }) {
  const [tab, setTab] = useState<WorkTab>("overview");
  const work = WORK_ITEMS.find(w=>w.id===workId)??WORK_ITEMS[0];
  const TABS: {id:WorkTab;label:string}[] = [
    {id:"overview",label:"Overview"},{id:"plan",label:"Plan"},{id:"activity",label:"Activity"},
    {id:"people",label:"People"},{id:"sources",label:"Sources"},
    {id:"decisions",label:`Decisions${work.decisions>0?` (${work.decisions})`:""}`},
    {id:"deliverables",label:`Deliverables (${work.deliverables})`},
  ];
  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100%", overflow:"hidden" }}>
      <div style={{ background:N.surface, borderBottom:`1px solid ${N.border}`, padding:"18px 32px 0", flexShrink:0 }}>
        <div style={{ maxWidth:1060, margin:"0 auto" }}>
          <div style={{ display:"flex", alignItems:"flex-start", gap:14, marginBottom:12 }}>
            <div style={{ flex:1, minWidth:0 }}>
              {/* V6.1: max 2 items in header — confidence + deadline */}
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                <ConfChip pct={work.confidence} afterAction={work.confAfterAction} reasons={work.confReasons} positive={[]} missing={work.confMissing} />
                <span style={{ fontSize:12, color:N.textDis, fontFamily:FONT }}>Phase {work.phaseNum}/{work.phaseTotal} · Due {work.deadline}</span>
              </div>
              <h1 style={{ fontSize:17, fontWeight:650, color:N.text, margin:0, letterSpacing:"-0.02em", lineHeight:1.3, fontFamily:FONT }}>{work.outcome}</h1>
            </div>
            <div style={{ display:"flex", gap:8, flexShrink:0 }}>
              <Btn variant="secondary" size="sm"><StopCircle size={11} strokeWidth={2} /> Pause</Btn>
              <Btn variant="secondary" size="sm"><MoreHorizontal size={12} strokeWidth={2} /></Btn>
            </div>
          </div>
          <div style={{ display:"flex", gap:0 }}>
            {TABS.map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)}
                style={{ padding:"9px 13px", background:"none", border:"none", borderBottom:`2px solid ${tab===t.id?N.action:"transparent"}`, color:tab===t.id?N.action:N.textSec, fontSize:13, fontWeight:tab===t.id?600:400, cursor:"pointer", fontFamily:FONT, transition:T.std, whiteSpace:"nowrap" }}>
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>
      <div style={{ flex:1, overflowY:"auto", padding:"28px 32px", background:N.canvas }}>
        <div style={{ maxWidth:1060, margin:"0 auto" }}>
          {tab==="overview"    && <WorkOverviewTab work={work} setActiveDecision={setActiveDecision} setView={setView} />}
          {tab==="plan"        && <WorkPlanTab />}
          {tab==="activity"    && <WorkActivityTab />}
          {tab==="people"      && <WorkPeopleTab />}
          {tab==="sources"     && <WorkSourcesTab />}
          {tab==="decisions"   && <WorkDecisionsTab setActiveDecision={setActiveDecision} setView={setView} workId={workId} />}
          {tab==="deliverables"&& <WorkDeliverablesTab />}
        </div>
      </div>
    </div>
  );
}

// ─── WORK OVERVIEW V6.1 ───────────────────────────────────────────────────────
// Single focal point: Next Best Action card.

function WorkOverviewTab({ work, setActiveDecision, setView }:{ work:typeof WORK_ITEMS[0]; setActiveDecision:(id:string)=>void; setView:(v:View)=>void }) {
  const [detailOpen, setDetailOpen] = useState(false);
  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 280px", gap:20, alignItems:"start" }}>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>

        {/* Blockers */}
        {work.blockers.length>0 && (
          <div style={{ padding:"14px 18px", background:N.critBg, border:`1px solid #FECACA`, borderRadius:11, borderLeft:`3px solid ${N.crit}`, display:"flex", gap:10 }}>
            <StopCircle size={13} color={N.crit} strokeWidth={2} style={{ flexShrink:0, marginTop:1 }} />
            <div>{work.blockers.map((b,i)=><div key={i} style={{ fontSize:13, color:N.crit, fontFamily:FONT, marginBottom:i<work.blockers.length-1?4:0 }}>{b}</div>)}</div>
          </div>
        )}

        {/* NOVA situation — hero */}
        <div style={{ padding:"20px 24px", background:`linear-gradient(135deg,${N.actionBg},${N.innoBg})`, borderRadius:14, border:`1px solid ${N.innoBrd}`, boxShadow:SH.hero }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:10 }}>
            <NOVALabel />
            <ConfChip pct={work.confidence} afterAction={work.confAfterAction} reasons={work.confReasons} positive={[]} missing={work.confMissing} />
          </div>
          <p style={{ fontSize:14, color:N.textSec, margin:"0 0 4px", fontFamily:FONT }}>{work.heroSentence}</p>
          <p style={{ fontSize:16, fontWeight:700, color:N.text, margin:0, lineHeight:1.5, letterSpacing:"-0.015em", fontFamily:FONT }}>{work.heroGain}</p>
        </div>

        {/* ── FOCAL: Next Best Action ── */}
        <div style={{ padding:"22px 26px", background:N.surface, borderRadius:14, border:`2px solid ${N.action}`, boxShadow:`0 0 0 4px rgba(29,78,216,.06),${SH.card}` }}>
          <div style={{ fontSize:10, fontWeight:700, color:N.action, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:14, fontFamily:FONT }}>Next best action</div>
          <div style={{ fontSize:18, fontWeight:700, color:N.text, marginBottom:12, lineHeight:1.4, fontFamily:FONT, letterSpacing:"-0.02em" }}>{work.nextAction}</div>
          {/* V6.1: time + gain + confidence delta — all in one row */}
          <div style={{ display:"flex", gap:18, marginBottom:20, flexWrap:"wrap" }}>
            <div style={{ fontSize:13, color:N.textSec, fontFamily:FONT, display:"flex", alignItems:"center", gap:5 }}><Clock size={11} strokeWidth={2} />{work.nextActionTime}</div>
            <div style={{ fontSize:13, fontWeight:600, color:N.success, fontFamily:FONT }}>{work.nextActionGain}</div>
            <div style={{ fontSize:13, fontWeight:700, color:N.success, fontFamily:MONO }}>{work.nextActionConfDelta}</div>
          </div>
          <div style={{ display:"flex", gap:10, alignItems:"center" }}>
            <Btn variant="primary" size="md">Open <ArrowRight size={13} strokeWidth={2.5} /></Btn>
            <WhyInline>{work.nextActionWhy}</WhyInline>
          </div>
        </div>

        {/* Later — collapsed */}
        {(work.laterActions.length>0||work.backgroundActions.length>0) && (
          <details style={{ background:N.surface, borderRadius:10, border:`1px solid ${N.border}`, overflow:"hidden" }}>
            <summary style={{ padding:"12px 18px", cursor:"pointer", listStyle:"none", display:"flex", alignItems:"center", gap:7, fontSize:13, color:N.textSec, fontFamily:FONT }}>
              <ChevronRight size={12} strokeWidth={2} style={{ transition:T.std }} />
              {work.laterActions.length+work.backgroundActions.length} more — Later &amp; Background
            </summary>
            <div style={{ padding:"0 18px 14px", display:"flex", flexDirection:"column", gap:5 }}>
              {[...work.laterActions.map(a=>({a,type:"Later"})),...work.backgroundActions.map(a=>({a,type:"Background"}))].map(({a,type},i)=>(
                <div key={i} style={{ display:"flex", gap:8, padding:"7px 0", borderBottom:`1px solid ${N.border}` }}>
                  <span style={{ fontSize:10, color:type==="Background"?N.inno:N.textDis, background:type==="Background"?N.innoBg:N.subtle, border:`1px solid ${type==="Background"?N.innoBrd:N.border}`, borderRadius:4, padding:"1px 6px", fontFamily:FONT, flexShrink:0 }}>{type}</span>
                  <span style={{ fontSize:13, color:N.textSec, fontFamily:FONT }}>{a}</span>
                </div>
              ))}
            </div>
          </details>
        )}

        {/* Decision pending */}
        {work.decisions>0 && DECISIONS_DATA.filter(d=>d.workId===work.id&&d.status==="pending").map(d=>(
          <Card key={d.id} onClick={()=>{ setActiveDecision(d.id); setView("decision-package"); }} accent={N.crit} style={{ padding:"16px 22px" }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <Scale size={14} color={N.crit} strokeWidth={2} style={{ flexShrink:0 }} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:"flex", gap:8, marginBottom:6 }}>
                  <DeadlineBadge days={d.deadlineDays} />
                  <ConfChip pct={d.confidence} afterAction={d.confAfterAction} reasons={d.confReasons} positive={d.confPositive} missing={d.confMissing} />
                </div>
                <div style={{ fontSize:14, fontWeight:600, color:N.text, fontFamily:FONT }}>{d.statement}</div>
                <div style={{ fontSize:12, color:N.crit, marginTop:3, fontFamily:FONT }}>{d.heroSentence}</div>
              </div>
              <ArrowRight size={13} color={N.textDis} strokeWidth={2} />
            </div>
          </Card>
        ))}
      </div>

      {/* ── Sidebar — lean ── */}
      <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
        {/* Progress */}
        <Card style={{ padding:"16px 18px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8 }}>
            <span style={{ fontSize:11, fontWeight:600, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.04em", fontFamily:FONT }}>Progress</span>
            <span style={{ fontSize:20, fontWeight:700, color:N.text, fontFamily:MONO }}>{work.progress}%</span>
          </div>
          <div style={{ height:4, background:N.border, borderRadius:999, marginBottom:12, overflow:"hidden" }}>
            <div style={{ width:`${work.progress}%`, height:"100%", background:work.health==="blocked"?N.crit:work.health==="attention"?"#D97706":N.action, borderRadius:999 }} />
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
            {[{l:"Owner",v:work.owner},{l:"Deadline",v:work.deadline},{l:"Phase",v:`${work.phaseNum}/${work.phaseTotal}`},{l:"Updated",v:work.updated}].map((m,i)=>(
              <div key={i}><div style={{ fontSize:10, fontWeight:600, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.04em", marginBottom:2, fontFamily:FONT }}>{m.l}</div><div style={{ fontSize:12, color:N.text, fontFamily:FONT }}>{m.v}</div></div>
            ))}
          </div>
          <button onClick={()=>setDetailOpen(true)} style={{ marginTop:10, fontSize:11, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, display:"flex", alignItems:"center", gap:3 }}>Full analysis <ChevronRight size={10} strokeWidth={2} /></button>
        </Card>

        {/* Deliverables */}
        <Card style={{ padding:"16px 18px" }}>
          <div style={{ fontSize:10, fontWeight:600, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.04em", marginBottom:10, fontFamily:FONT }}>Deliverables</div>
          {DELIVERABLES_DATA.map((d,i)=>(
            <div key={d.id} style={{ padding:"9px 0", borderBottom:i<DELIVERABLES_DATA.length-1?`1px solid ${N.border}`:"none" }}>
              <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                <FileText size={11} color={N.textSec} strokeWidth={2} style={{ flexShrink:0 }} />
                <span style={{ fontSize:12, color:N.text, fontFamily:FONT, flex:1 }}>{d.name}</span>
                <ConfChip pct={d.confidence} afterAction={d.confAfterAction} reasons={[`Evidence: ${d.evidenceCoverage}%`,d.blockerMain]} positive={[]} missing={d.missingInfo[0]} />
              </div>
            </div>
          ))}
        </Card>

        {/* People — lean */}
        <Card style={{ padding:"16px 18px" }}>
          <div style={{ fontSize:10, fontWeight:600, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.04em", marginBottom:10, fontFamily:FONT }}>People</div>
          {PEOPLE_DATA.slice(0,3).map((p,i)=>(
            <div key={p.id} style={{ display:"flex", alignItems:"center", gap:9, padding:"7px 0", borderBottom:i<2?`1px solid ${N.border}`:"none" }}>
              <div style={{ width:22, height:22, borderRadius:"50%", background:p.type==="ai"?N.innoBg:N.subtle, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, border:`1px solid ${p.type==="ai"?N.innoBrd:N.border}` }}>
                {p.type==="ai"?<Sparkles size={9} color={N.inno} strokeWidth={2.5} />:<User size={9} color={N.textSec} strokeWidth={2} />}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:12, fontWeight:500, color:N.text, fontFamily:FONT }}>{p.name}</div>
                <div style={{ fontSize:11, color:N.textSec, fontFamily:FONT }}>{p.availability}</div>
              </div>
              <StatusDot ok={p.status==="active"||p.status==="working"} />
            </div>
          ))}
        </Card>

        {/* NOVA state — one message */}
        <div style={{ padding:"12px 14px", background:N.innoBg, borderRadius:10, border:`1px solid ${N.innoBrd}` }}>
          <div style={{ display:"flex", alignItems:"center", gap:5, marginBottom:5 }}>
            <div style={{ width:5, height:5, borderRadius:"50%", background:N.inno, animation:"pulse 2s ease-in-out infinite" }} />
            <NOVALabel />
          </div>
          <p style={{ fontSize:12, color:N.inno, margin:0, fontFamily:FONT, lineHeight:1.5 }}>{PEOPLE_DATA[1].novaState}</p>
        </div>
      </div>

      {/* Full analysis drawer — narrative order */}
      <Drawer open={detailOpen} onClose={()=>setDetailOpen(false)} title="Full analysis">
        <DrawerSection label="Summary">
          <p style={{ fontSize:13, color:N.text, fontFamily:FONT, lineHeight:1.65, margin:0 }}>Phase 3 active. Draft complete but blocked by 3 unresolved comments. Sarah Chen has validated all financial assumptions except revenue projection, which depends on the missing CRM export. CFO pre-review is the critical path item before the 18 July deadline. NOVA estimates ~6 hours remaining if CRM data is loaded today.</p>
        </DrawerSection>
        <DrawerSection label="Why it matters">
          <p style={{ fontSize:13, color:N.textSec, fontFamily:FONT, lineHeight:1.6, margin:0 }}>The CFO must review and pre-approve the budget figures before the 18 July board meeting. Without his sign-off, the budget decision cannot be made at the meeting. Resolving the 3 comments unblocks the entire review chain.</p>
        </DrawerSection>
        <DrawerSection label="What is blocking">
          {["3 open comments in revenue section — Sarah Chen","CRM Pipeline Export not loaded — revenue projection provisional","Product Roadmap deck outdated — 1 timeline conflict detected"].map((b,i)=>(
            <div key={i} style={{ display:"flex", gap:7, fontSize:13, color:N.crit, marginBottom:5, fontFamily:FONT }}><AlertTriangle size={11} style={{ flexShrink:0, marginTop:2 }} strokeWidth={2} />{b}</div>
          ))}
        </DrawerSection>
        <DrawerSection label="Key evidence">
          {[{l:"Planning",s:85},{l:"Budget",s:72},{l:"Risks",s:61},{l:"Sources",s:75},{l:"Decisions",s:40},{l:"Documentation",s:78},{l:"Team",s:88}].map((h,i)=>{
            const c=confColor(h.s);
            return (<div key={i} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:7 }}>
              <span style={{ fontSize:12, color:N.textSec, fontFamily:FONT, width:110 }}>{h.l}</span>
              <div style={{ flex:1, height:3, background:N.border, borderRadius:999, overflow:"hidden" }}><div style={{ width:`${h.s}%`, height:"100%", background:c.color, borderRadius:999 }} /></div>
              <span style={{ fontSize:11, fontWeight:700, color:c.color, fontFamily:MONO, width:28, textAlign:"right" }}>{h.s}</span>
            </div>);
          })}
        </DrawerSection>
        <DrawerSection label="History">
          {[{a:"Load CRM export",i:"Confidence 76% → 92%"},{a:"Refresh Product Roadmap deck",i:"Removes 1 conflict"},{a:"Prepare CFO pre-review package",i:"Unlocks Phase 4"},{a:"Final consistency check",i:"Validates all figures"}].map((item,i)=>(
            <div key={i} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:`1px solid ${N.border}` }}>
              <span style={{ fontSize:13, color:N.text, fontFamily:FONT }}>{item.a}</span>
              <span style={{ fontSize:11, color:N.success, fontFamily:FONT, fontWeight:600 }}>{item.i}</span>
            </div>
          ))}
        </DrawerSection>
        <DrawerSection label="Technical details">
          {[{l:"Source quality",s:81},{l:"Expert validation",s:60},{l:"Coverage",s:75},{l:"Freshness",s:68},{l:"Consistency",s:84}].map((row,i)=>{
            const c=confColor(row.s);
            return (<div key={i} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:7 }}>
              <span style={{ fontSize:12, color:N.textSec, fontFamily:FONT, width:130 }}>{row.l}</span>
              <div style={{ flex:1, height:3, background:N.border, borderRadius:999, overflow:"hidden" }}><div style={{ width:`${row.s}%`, height:"100%", background:c.color, borderRadius:999 }} /></div>
              <span style={{ fontSize:11, fontWeight:700, color:c.color, fontFamily:MONO, width:28, textAlign:"right" }}>{row.s}%</span>
            </div>);
          })}
        </DrawerSection>
      </Drawer>
    </div>
  );
}

// ─── WORK PLAN V6.1 ───────────────────────────────────────────────────────────
// Each phase: outcome + status + remaining + main blocker + probability

function WorkPlanTab() {
  const phases = [
    { name:"Research and sources",   outcome:"All data assembled and contradiction-free",                 status:"complete" as const, prob:98, remaining:"0 h",  blocker:null as string|null, actions:[{l:"Load Q3 financial model",d:true},{l:"Infrastructure report reviewed",d:true},{l:"CRM export requested",d:true}] },
    { name:"Analysis and synthesis", outcome:"3 options ranked with risk and financial impact",           status:"complete" as const, prob:94, remaining:"0 h",  blocker:null, actions:[{l:"Q3 performance synthesized",d:true},{l:"Investment case developed",d:true},{l:"Sarah Chen financial review",d:true}] },
    { name:"Draft and review",       outcome:"Board-ready draft approved by all reviewers",               status:"active" as const,   prob:81, remaining:"~6 h", blocker:"3 comments unresolved · CRM source missing", actions:[{l:"Slide draft v1 generated",d:true},{l:"Resolve 3 open comments",d:false},{l:"CFO pre-review",d:false}] },
    { name:"Finalize and deliver",   outcome:"Approved presentation delivered to board",                  status:"future" as const,   prob:74, remaining:"~4 h", blocker:"CFO approval not yet secured", actions:[{l:"Final approval",d:false},{l:"Board delivery",d:false}] },
  ];
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
      {phases.map((p,i)=>(
        <Card key={i} style={{ padding:"18px 22px" }} accent={p.status==="complete"?N.success:p.status==="active"?N.action:undefined}>
          <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
            <div style={{ width:24, height:24, borderRadius:7, background:p.status==="complete"?N.successBg:p.status==="active"?N.actionBg:N.subtle, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
              {p.status==="complete"?<CheckCircle size={12} color={N.success} strokeWidth={2} />:p.status==="active"?<RefreshCw size={11} color={N.action} strokeWidth={2.5} />:<Circle size={12} color={N.textDis} strokeWidth={2} />}
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              {/* outcome first — the why */}
              <div style={{ fontSize:14, fontWeight:600, color:N.text, fontFamily:FONT, marginBottom:3 }}>{p.outcome}</div>
              <div style={{ fontSize:12, color:N.textSec, fontFamily:FONT, marginBottom:p.blocker?5:10 }}>
                {p.name} · <span style={{ fontWeight:600, color:confColor(p.prob).color }}>{p.prob}% probability</span> · Remaining: {p.remaining}
              </div>
              {p.blocker && <div style={{ fontSize:11, color:N.warn, marginBottom:10, fontFamily:FONT, display:"flex", gap:4 }}><AlertTriangle size={9} style={{ flexShrink:0, marginTop:2 }} strokeWidth={2} />{p.blocker}</div>}
              <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
                {p.actions.map((a,j)=>(
                  <div key={j} style={{ display:"flex", alignItems:"center", gap:7, fontSize:12, color:a.d?N.textDis:N.text, fontFamily:FONT }}>
                    <div style={{ width:14, height:14, borderRadius:"50%", border:`1.5px solid ${a.d?N.success:N.borderMd}`, background:a.d?N.success:"transparent", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                      {a.d && <Check size={7} color="#fff" strokeWidth={3} />}
                    </div>
                    <span style={{ textDecoration:a.d?"line-through":"none" }}>{a.l}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

// ─── WORK ACTIVITY V6.1 — Narrative: what changed + why + confidence delta ───

function WorkActivityTab() {
  const [filter, setFilter] = useState("all");
  const [comment, setComment] = useState("");
  const filters = ["all","human","ai","critical","sources"];
  const filtered = filter==="all" ? ACTIVITY_FEED : ACTIVITY_FEED.filter(ev=>ev.tags.includes(filter));
  return (
    <div style={{ maxWidth:640 }}>
      <div style={{ display:"flex", gap:6, marginBottom:20, flexWrap:"wrap" }}>
        {filters.map(f=>(
          <button key={f} onClick={()=>setFilter(f)}
            style={{ padding:"4px 11px", background:filter===f?N.text:"transparent", border:`1px solid ${filter===f?N.text:N.border}`, borderRadius:999, fontSize:12, color:filter===f?"#fff":N.textSec, cursor:"pointer", fontFamily:FONT, fontWeight:filter===f?600:400, transition:T.fast, textTransform:"capitalize" }}>
            {f==="ai"?"AI":f}
          </button>
        ))}
      </div>
      <div style={{ display:"flex", flexDirection:"column" }}>
        {filtered.map((ev,i)=>(
          <div key={ev.id} style={{ display:"flex", gap:11, paddingBottom:18 }}>
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center" }}>
              <div style={{ width:28, height:28, borderRadius:"50%", background:ev.actorType==="ai"?N.innoBg:N.subtle, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, border:`1px solid ${ev.actorType==="ai"?N.innoBrd:N.border}` }}>
                {ev.actorType==="ai"?<Sparkles size={11} color={N.inno} strokeWidth={2.5} />:<User size={11} color={N.textSec} strokeWidth={2} />}
              </div>
              {i<filtered.length-1 && <div style={{ width:1, flex:1, background:N.border, margin:"3px 0", minHeight:14 }} />}
            </div>
            <div style={{ flex:1, paddingTop:3 }}>
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4, flexWrap:"wrap" }}>
                <span style={{ fontSize:13, fontWeight:600, color:N.text, fontFamily:FONT }}>{ev.actor}</span>
                {ev.actorType==="ai" && <NOVALabel />}
                {/* V6.1: only critical badge — max 1 on timeline */}
                {ev.tags.includes("critical") && (
                  <span style={{ fontSize:11, fontWeight:600, color:N.crit, background:N.critBg, border:`1px solid #FECACA`, borderRadius:999, padding:"1px 8px", fontFamily:FONT, display:"flex", alignItems:"center", gap:3 }}>
                    <AlertTriangle size={8} strokeWidth={2.5} /> Critical
                  </span>
                )}
                <span style={{ fontSize:11, color:N.textDis, fontFamily:FONT, marginLeft:"auto" }}>{ev.time}</span>
              </div>
              {/* V6.1 narrative: what changed (primary) */}
              <div style={{ fontSize:13, fontWeight:500, color:N.text, fontFamily:FONT, marginBottom:ev.actorType==="ai"?6:0 }}>{ev.change}</div>
              {ev.actorType==="ai" && (
                <div style={{ background:N.innoBg, borderRadius:8, border:`1px solid ${N.innoBrd}`, padding:"10px 12px" }}>
                  {/* impact + confidence delta — the narrative key */}
                  <div style={{ fontSize:13, fontWeight:500, color:ev.confDelta?(ev.confDelta.to>ev.confDelta.from?N.success:N.crit):N.textSec, fontFamily:FONT, marginBottom:ev.why?6:0 }}>
                    {ev.impact}
                    {ev.confDelta && (
                      <span style={{ fontFamily:MONO, fontWeight:700, marginLeft:4 }}>({ev.confDelta.from}% → {ev.confDelta.to}%)</span>
                    )}
                  </div>
                  {ev.why && <div style={{ fontSize:12, color:N.textDis, fontFamily:FONT, lineHeight:1.45 }}>{ev.why}</div>}
                  {ev.sources.length>0 && (
                    <div style={{ display:"flex", gap:5, marginTop:6, flexWrap:"wrap" }}>
                      {ev.sources.map((s,j)=>(
                        <span key={j} style={{ fontSize:10, color:N.inno, background:"rgba(109,40,217,.08)", border:`1px solid ${N.innoBrd}`, borderRadius:4, padding:"1px 6px", fontFamily:FONT }}>{s}</span>
                      ))}
                    </div>
                  )}
                </div>
              )}
              {ev.actorType==="human" && ev.why && (
                <div style={{ padding:"8px 11px", background:N.subtle, borderRadius:7, fontSize:12, color:N.textSec, border:`1px solid ${N.border}`, fontFamily:FONT, lineHeight:1.5, marginTop:4 }}>"{ev.why}"</div>
              )}
            </div>
          </div>
        ))}
      </div>
      <div style={{ background:N.surface, border:`1.5px solid ${comment?N.action:N.border}`, borderRadius:11, overflow:"hidden", transition:T.std }}>
        <textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Add a comment…"
          style={{ width:"100%", border:"none", outline:"none", padding:"13px 15px", fontSize:13, color:N.text, fontFamily:FONT, resize:"none", minHeight:64, background:"transparent", lineHeight:1.6, boxSizing:"border-box" }} />
        {comment && <div style={{ padding:"7px 13px", borderTop:`1px solid ${N.border}`, display:"flex", justifyContent:"flex-end" }}><Btn variant="primary" size="sm"><Send size={11} strokeWidth={2.5} /> Post</Btn></div>}
      </div>
    </div>
  );
}

// ─── WORK PEOPLE V6.1 — Who can unblock the work now? ───────────────────────

function WorkPeopleTab() {
  const [drawer, setDrawer] = useState<typeof PEOPLE_DATA[0]|null>(null);
  return (
    <div>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
        <h2 style={{ fontSize:17, fontWeight:650, color:N.text, margin:0, fontFamily:FONT }}>People &amp; experts</h2>
        <Btn variant="secondary" size="sm"><Plus size={12} strokeWidth={2.5} /> Invite</Btn>
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {PEOPLE_DATA.map(p=>(
          <Card key={p.id} style={{ padding:"16px 20px" }}>
            <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
              <div style={{ width:36, height:36, borderRadius:"50%", background:p.type==="ai"?N.innoBg:N.subtle, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, border:`1px solid ${p.type==="ai"?N.innoBrd:N.border}` }}>
                {p.type==="ai"?<Sparkles size={14} color={N.inno} strokeWidth={2.5} />:<User size={14} color={N.textSec} strokeWidth={2} />}
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                {/* V6.1: no badge pile — status as dot + text */}
                <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:3 }}>
                  <span style={{ fontSize:14, fontWeight:600, color:N.text, fontFamily:FONT }}>{p.name}</span>
                  {p.type==="ai" && <NOVALabel />}
                  <StatusDot ok={p.status==="active"||p.status==="working"} />
                </div>
                <div style={{ fontSize:12, color:N.textSec, fontFamily:FONT, marginBottom:6 }}>{p.role} · {p.availability}</div>
                {/* V6.1: contribution = who can unblock now */}
                <div style={{ fontSize:13, color:p.pendingRequests>0?N.warn:N.textSec, fontFamily:FONT, marginBottom:p.novaState?8:0 }}>{p.contribution}</div>
                {/* NOVA: single visible line */}
                {p.novaState && (
                  <div style={{ padding:"9px 11px", background:N.innoBg, borderRadius:7, border:`1px solid ${N.innoBrd}` }}>
                    <div style={{ display:"flex", alignItems:"center", gap:5, marginBottom:4 }}>
                      <div style={{ width:5, height:5, borderRadius:"50%", background:N.inno, animation:"pulse 2s ease-in-out infinite" }} />
                      <span style={{ fontSize:10, fontWeight:600, color:N.inno, textTransform:"uppercase", letterSpacing:"0.05em", fontFamily:FONT }}>Current reasoning</span>
                    </div>
                    <p style={{ fontSize:12, color:N.inno, margin:0, lineHeight:1.5, fontFamily:FONT }}>{p.novaState}</p>
                  </div>
                )}
              </div>
              <button onClick={()=>setDrawer(p)} style={{ fontSize:11, color:N.textSec, background:"none", border:`1px solid ${N.border}`, borderRadius:6, padding:"3px 9px", cursor:"pointer", fontFamily:FONT, flexShrink:0 }}>Details</button>
            </div>
          </Card>
        ))}
      </div>

      {/* People drawer — narrative order */}
      <Drawer open={!!drawer} onClose={()=>setDrawer(null)} title={drawer?.name??""}>
        {drawer && (
          <>
            <DrawerSection label="Summary">
              <p style={{ fontSize:13, color:N.text, fontFamily:FONT, lineHeight:1.65, margin:0 }}>{drawer.contribution}. {drawer.type==="ai"?"NOVA is working continuously on this project and cannot be reassigned.":`${drawer.pendingRequests>0?`${drawer.pendingRequests} pending request${drawer.pendingRequests!==1?"s":""} awaiting input.`:""} Response time: ${drawer.responseTime}.`}</p>
            </DrawerSection>
            <DrawerSection label="Why it matters">
              <p style={{ fontSize:13, color:N.textSec, fontFamily:FONT, lineHeight:1.55, margin:0 }}>
                {drawer.type==="ai" ? "NOVA is the primary source of cross-source validation. Its output determines which assumptions are safe to include in the final deliverable." : `${drawer.name} has reviewed ${drawer.docsReviewed} documents and validated ${drawer.validationCount} sections. Their sign-off is required before CFO review can begin.`}
              </p>
            </DrawerSection>
            {drawer.novaState && <DrawerSection label="Current reasoning"><p style={{ fontSize:13, color:N.inno, fontFamily:FONT, lineHeight:1.55, margin:0 }}>{drawer.novaState}</p></DrawerSection>}
            <DrawerSection label="Key evidence">
              <DrawerRow label="Availability"     value={drawer.availability} />
              <DrawerRow label="Workload"          value={`${drawer.workload}%`} color={drawer.workload>85?N.crit:drawer.workload>65?"#B45309":N.success} />
              <DrawerRow label="Response time"     value={drawer.responseTime} />
              <DrawerRow label="Docs reviewed"     value={drawer.docsReviewed} />
              <DrawerRow label="Validations"       value={drawer.validationCount} />
              {drawer.trustScore>0 && <DrawerRow label="Trust score" value={`${drawer.trustScore}%`} color={confColor(drawer.trustScore).color} />}
            </DrawerSection>
            <DrawerSection label="Technical details">
              <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
                {drawer.expertise.map((e,i)=><span key={i} style={{ fontSize:12, color:N.textSec, background:N.subtle, border:`1px solid ${N.border}`, borderRadius:999, padding:"2px 10px", fontFamily:FONT }}>{e}</span>)}
              </div>
            </DrawerSection>
          </>
        )}
      </Drawer>
    </div>
  );
}

// ─── WORK SOURCES V6.1 ───────────────────────────────────────────────────────
// Each source: name + status + freshness + usage + NOVA comment + action

function WorkSourcesTab() {
  const [drawer, setDrawer] = useState<typeof SOURCES_DATA[0]|null>(null);
  const st: Record<string,{label:string;color:string;bg:string;brd:string}> = {
    available:{ label:"Available", color:N.success, bg:N.successBg, brd:"#BBF7D0" },
    stale:    { label:"Stale",     color:N.warn,    bg:N.warnBg,    brd:"#FDE68A" },
    missing:  { label:"Missing",   color:N.crit,    bg:N.critBg,    brd:"#FECACA" },
  };
  const sorted = [...SOURCES_DATA].sort((a,b)=>{ const o={missing:0,stale:1,available:2}; return (o[a.status]??3)-(o[b.status]??3); });
  return (
    <div>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:18 }}>
        <h2 style={{ fontSize:17, fontWeight:650, color:N.text, margin:0, fontFamily:FONT }}>Sources</h2>
        <div style={{ display:"flex", gap:8, alignItems:"center" }}>
          <span style={{ fontSize:12, color:N.inno, fontFamily:FONT, display:"flex", alignItems:"center", gap:4 }}><div style={{ width:5, height:5, borderRadius:"50%", background:N.inno, animation:"pulse 2s ease-in-out infinite" }} />Validating…</span>
          <Btn variant="secondary" size="sm"><Plus size={12} strokeWidth={2.5} /> Add</Btn>
        </div>
      </div>
      {/* V6.1: reduced counter — inline text summary, not 4-box grid */}
      <div style={{ padding:"10px 16px", background:N.surface, borderRadius:9, border:`1px solid ${N.border}`, marginBottom:16, display:"flex", gap:16, flexWrap:"wrap" }}>
        {[{l:"2 available",c:N.success},{l:"1 outdated",c:N.warn},{l:"1 missing",c:N.crit},{l:"1 conflict",c:N.crit}].map((item,i)=>(
          <span key={i} style={{ fontSize:13, fontWeight:600, color:item.c, fontFamily:FONT }}>{item.l}</span>
        ))}
        <span style={{ fontSize:13, color:N.textSec, fontFamily:FONT, marginLeft:"auto" }}>Overall coverage: 75%</span>
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {sorted.map(s=>{
          const state = st[s.status];
          return (
            <Card key={s.id} style={{ padding:"15px 20px" }} accent={s.status==="missing"?N.crit:s.status==="stale"?"#D97706":undefined}>
              <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
                <div style={{ flex:1, minWidth:0 }}>
                  {/* V6.1: name + 1 status badge only */}
                  <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:5 }}>
                    <span style={{ fontSize:14, fontWeight:600, color:N.text, fontFamily:FONT }}>{s.name}</span>
                    <span style={{ fontSize:11, fontWeight:600, color:state.color, background:state.bg, border:`1px solid ${state.brd}`, borderRadius:999, padding:"1px 8px", fontFamily:FONT }}>{state.label}</span>
                  </div>
                  <div style={{ fontSize:12, color:N.textDis, fontFamily:FONT, marginBottom:7 }}>
                    {s.type} · Freshness: {s.freshness}
                    {s.uses>0?` · ${s.uses} sections`:" · Unused"}
                    {s.conflicts>0&&<span style={{ color:N.crit }}> · ⚠ {s.conflicts} conflict</span>}
                  </div>
                  <div style={{ fontSize:12, color:N.inno, fontFamily:FONT, display:"flex", gap:5 }}>
                    <Sparkles size={10} strokeWidth={2.5} style={{ flexShrink:0, marginTop:2 }} />{s.aiComment}
                  </div>
                </div>
                <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
                  {s.status==="missing" && <Btn variant="secondary" size="sm"><Upload size={10} strokeWidth={2} /> Add</Btn>}
                  {s.status==="stale"   && <Btn variant="secondary" size="sm"><RefreshCw size={10} strokeWidth={2} /> Refresh</Btn>}
                  <button onClick={()=>setDrawer(s)} style={{ fontSize:11, color:N.textSec, background:"none", border:`1px solid ${N.border}`, borderRadius:6, padding:"3px 9px", cursor:"pointer", fontFamily:FONT }}>Details</button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Source drawer — narrative order */}
      <Drawer open={!!drawer} onClose={()=>setDrawer(null)} title={drawer?.name??""}>
        {drawer && (
          <>
            <DrawerSection label="Summary">
              <p style={{ fontSize:13, color:N.text, fontFamily:FONT, lineHeight:1.65, margin:0 }}>{drawer.aiComment}</p>
            </DrawerSection>
            <DrawerSection label="Why it matters">
              {drawer.decisionsImpacted.length>0 && <p style={{ fontSize:13, color:N.textSec, fontFamily:FONT, lineHeight:1.6, margin:"0 0 8px" }}>Supports: <strong style={{ color:N.text }}>{drawer.decisionsImpacted.join(", ")}</strong></p>}
              {drawer.referencedBy.length>0 && <p style={{ fontSize:13, color:N.textSec, fontFamily:FONT, lineHeight:1.6, margin:0 }}>Used in: <strong style={{ color:N.text }}>{drawer.referencedBy.join(", ")}</strong></p>}
              {drawer.decisionsImpacted.length===0&&drawer.referencedBy.length===0 && <p style={{ fontSize:13, color:N.textSec, fontFamily:FONT, lineHeight:1.6, margin:0 }}>Not yet referenced by any deliverable or decision.</p>}
            </DrawerSection>
            <DrawerSection label="Key evidence">
              <DrawerRow label="Type"           value={drawer.type} />
              <DrawerRow label="Quality score"  value={drawer.qualityScore>0?`${drawer.qualityScore}%`:"—"} color={drawer.qualityScore>0?confColor(drawer.qualityScore).color:N.textDis} />
              <DrawerRow label="Reliability"    value={drawer.reliability>0?`${drawer.reliability}%`:"—"}   color={drawer.reliability>0?confColor(drawer.reliability).color:N.textDis} />
              <DrawerRow label="Evidence score" value={drawer.evidenceScore>0?`${drawer.evidenceScore}%`:"—"} color={drawer.evidenceScore>0?confColor(drawer.evidenceScore).color:N.textDis} />
              <DrawerRow label="Conflicts"      value={drawer.conflicts>0?`${drawer.conflicts}`:"None"} color={drawer.conflicts>0?N.crit:undefined} />
            </DrawerSection>
            <DrawerSection label="History">
              <DrawerRow label="Last verified" value={drawer.lastVerified} />
              <DrawerRow label="Freshness"     value={drawer.freshness} />
              <DrawerRow label="Usage"         value={drawer.uses>0?`${drawer.uses} sections`:"Unused"} />
            </DrawerSection>
          </>
        )}
      </Drawer>
    </div>
  );
}

// ─── WORK DECISIONS V6.1 ─────────────────────────────────────────────────────
// Card: decision + recommendation + if approved/rejected + confidence + one CTA

function WorkDecisionsTab({ setActiveDecision, setView, workId }:{ setActiveDecision:(id:string)=>void; setView:(v:View)=>void; workId:string }) {
  const decisions = DECISIONS_DATA.filter(d=>d.workId===workId);
  return (
    <div>
      <h2 style={{ fontSize:17, fontWeight:650, color:N.text, margin:"0 0 20px", fontFamily:FONT }}>Decisions</h2>
      <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {decisions.map(d=>(
          <Card key={d.id} accent={d.status==="pending"?N.crit:undefined} style={{ padding:"20px 24px" }}>
            {/* V6.1: exactly 2 badges */}
            <div style={{ display:"flex", gap:8, marginBottom:10 }}>
              {d.deadlineDays>0 && <DeadlineBadge days={d.deadlineDays} />}
              {d.confidence>0 && <ConfChip pct={d.confidence} afterAction={d.confAfterAction} reasons={d.confReasons} positive={d.confPositive} missing={d.confMissing} />}
            </div>
            <div style={{ fontSize:15, fontWeight:700, color:N.text, marginBottom:8, fontFamily:FONT, lineHeight:1.4 }}>{d.statement}</div>
            {d.recommendation && (
              <div style={{ fontSize:13, color:N.inno, fontFamily:FONT, marginBottom:12, display:"flex", gap:5 }}>
                <Sparkles size={11} strokeWidth={2.5} style={{ flexShrink:0, marginTop:2 }} /> {d.recommendation}
              </div>
            )}
            {/* V6.1: if approved / rejected consequence visible on card */}
            {d.ifApproved && (
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:14 }}>
                <div style={{ padding:"10px 12px", background:N.successBg, borderRadius:8, border:`1px solid #BBF7D0` }}>
                  <div style={{ fontSize:10, fontWeight:700, color:N.success, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4, fontFamily:FONT }}>If approved</div>
                  <div style={{ fontSize:12, color:N.success, fontFamily:FONT, lineHeight:1.45 }}>{d.ifApproved}</div>
                </div>
                <div style={{ padding:"10px 12px", background:N.critBg, borderRadius:8, border:`1px solid #FECACA` }}>
                  <div style={{ fontSize:10, fontWeight:700, color:N.crit, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4, fontFamily:FONT }}>If rejected</div>
                  <div style={{ fontSize:12, color:N.crit, fontFamily:FONT, lineHeight:1.45 }}>{d.ifRejected}</div>
                </div>
              </div>
            )}
            <div style={{ display:"flex", gap:10, alignItems:"center" }}>
              <Btn variant="primary" size="sm" onClick={()=>{ setActiveDecision(d.id); setView("decision-package"); }}>
                Review &amp; decide <ArrowRight size={12} strokeWidth={2.5} />
              </Btn>
              {d.rationale && <WhyInline>{d.rationale}</WhyInline>}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ─── WORK DELIVERABLES V6.1 ───────────────────────────────────────────────────
// Card: name + readiness % + main blocker + next action. Drawer carries complexity.

function WorkDeliverablesTab() {
  const [drawer, setDrawer] = useState<typeof DELIVERABLES_DATA[0]|null>(null);
  return (
    <div>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
        <h2 style={{ fontSize:17, fontWeight:650, color:N.text, margin:0, fontFamily:FONT }}>Deliverables</h2>
        <Btn variant="secondary" size="sm"><Plus size={12} strokeWidth={2.5} /> Create</Btn>
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {DELIVERABLES_DATA.map(d=>{
          const pubColor = d.publicationScore>=70?N.success:d.publicationScore>=45?"#B45309":N.crit;
          return (
            <Card key={d.id} style={{ padding:"18px 22px" }} accent={d.blockerMain?N.warn:undefined}>
              <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
                <div style={{ flex:1, minWidth:0 }}>
                  {/* V6.1: name + confidence only — 1 badge */}
                  <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
                    <span style={{ fontSize:14, fontWeight:600, color:N.text, fontFamily:FONT }}>{d.name}</span>
                    <ConfChip pct={d.confidence} afterAction={d.confAfterAction} reasons={[`Evidence: ${d.evidenceCoverage}%`,d.blockerMain]} positive={[]} missing={d.missingInfo[0]} />
                  </div>
                  {/* Readiness bar */}
                  <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
                    <span style={{ fontSize:12, color:N.textSec, fontFamily:FONT, flexShrink:0 }}>Ready for publication</span>
                    <div style={{ flex:1, height:3, background:N.border, borderRadius:999, overflow:"hidden" }}>
                      <div style={{ width:`${d.publicationScore}%`, height:"100%", background:pubColor, borderRadius:999 }} />
                    </div>
                    <span style={{ fontSize:12, fontWeight:700, color:pubColor, fontFamily:MONO }}>{d.publicationScore}%</span>
                  </div>
                  {/* Main blocker */}
                  {d.blockerMain && (
                    <div style={{ fontSize:12, color:N.warn, fontFamily:FONT, marginBottom:5, display:"flex", gap:5 }}>
                      <AlertTriangle size={10} strokeWidth={2} style={{ flexShrink:0, marginTop:2 }} />{d.blockerMain}
                    </div>
                  )}
                  <div style={{ fontSize:12, color:N.textSec, fontFamily:FONT }}>{d.nextAction}</div>
                </div>
                <div style={{ display:"flex", flexDirection:"column", gap:5, flexShrink:0 }}>
                  <Btn variant="quiet" size="sm"><Eye size={11} strokeWidth={2} /></Btn>
                  <button onClick={()=>setDrawer(d)} style={{ fontSize:11, color:N.textSec, background:"none", border:`1px solid ${N.border}`, borderRadius:6, padding:"3px 9px", cursor:"pointer", fontFamily:FONT }}>Details</button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Deliverable drawer — narrative order */}
      <Drawer open={!!drawer} onClose={()=>setDrawer(null)} title={drawer?.name??""}>
        {drawer && (
          <>
            <DrawerSection label="Summary">
              <p style={{ fontSize:13, color:N.text, fontFamily:FONT, lineHeight:1.65, margin:0 }}>{drawer.aiSummary}</p>
            </DrawerSection>
            <DrawerSection label="Why it matters">
              <p style={{ fontSize:13, color:N.textSec, fontFamily:FONT, lineHeight:1.6, margin:0 }}>
                This deliverable is required for {drawer.audience}. Publication score is {drawer.publicationScore}% — {drawer.publicationScore>=70?"ready for distribution":"not yet ready for distribution"}.
              </p>
            </DrawerSection>
            <DrawerSection label="What is blocking">
              {drawer.missingInfo.map((m,i)=>(
                <div key={i} style={{ display:"flex", gap:7, fontSize:13, color:N.crit, marginBottom:5, fontFamily:FONT }}>
                  <AlertTriangle size={11} style={{ flexShrink:0, marginTop:2 }} strokeWidth={2} />{m}
                </div>
              ))}
            </DrawerSection>
            <DrawerSection label="Key evidence">
              <DrawerRow label="Evidence coverage"  value={`${drawer.evidenceCoverage}%`} color={confColor(drawer.evidenceCoverage).color} />
              <DrawerRow label="Completeness"        value={`${drawer.completeness}%`}     color={confColor(drawer.completeness).color} />
              <DrawerRow label="Publication score"   value={`${drawer.publicationScore}%`} color={confColor(drawer.publicationScore).color} />
              <DrawerRow label="Pending comments"    value={drawer.pendingComments} color={drawer.pendingComments>0?N.warn:undefined} />
              <DrawerRow label="Outstanding reviews" value={drawer.outstandingReviews} color={drawer.outstandingReviews>0?N.warn:undefined} />
            </DrawerSection>
            <DrawerSection label="History">
              {drawer.versionHistory.map((v,i)=>(
                <div key={i} style={{ display:"flex", gap:10, padding:"7px 0", borderBottom:`1px solid ${N.border}`, fontSize:12, fontFamily:FONT }}>
                  <span style={{ fontFamily:MONO, color:N.action, fontWeight:600, width:36, flexShrink:0 }}>{v.v}</span>
                  <span style={{ color:N.textDis, width:44, flexShrink:0 }}>{v.date}</span>
                  <span style={{ color:N.textSec }}>{v.note}</span>
                </div>
              ))}
            </DrawerSection>
            <DrawerSection label="Technical details">
              <DrawerRow label="Generated by" value={drawer.generatedBy} />
              <DrawerRow label="Reviewed by"  value={drawer.reviewedBy??"Pending"} />
              <DrawerRow label="Validated by" value={drawer.validatedBy??"Not yet"} />
              <DrawerRow label="Format"        value={drawer.format} />
              <DrawerRow label="Audience"      value={drawer.audience} />
            </DrawerSection>
          </>
        )}
      </Drawer>
    </div>
  );
}

// ─── GLOBAL DECISIONS ────────────────────────────────────────────────────────

function GlobalDecisionsView({ setActiveDecision, setView }:{ setActiveDecision:(id:string)=>void; setView:(v:View)=>void }) {
  const [filter, setFilter] = useState<DecStatus|"all">("all");
  const tabs = [{ id:"all" as const, label:"All", count:3 },{ id:"pending" as const, label:"Needs my decision", count:1 },{ id:"waiting" as const, label:"Waiting", count:1 },{ id:"decided" as const, label:"History", count:1 }];
  const filtered = filter==="all"?DECISIONS_DATA:DECISIONS_DATA.filter(d=>d.status===filter);
  return (
    <div style={{ maxWidth:760, margin:"0 auto", padding:"52px 52px 100px" }}>
      <h1 style={{ fontSize:26, fontWeight:650, color:N.text, margin:"0 0 4px", letterSpacing:"-0.03em", fontFamily:FONT }}>Decisions</h1>
      <p style={{ fontSize:14, color:N.textDis, margin:"0 0 28px", fontFamily:FONT }}>1 decision requires your authority · due in 4 days</p>
      <div style={{ display:"flex", gap:0, borderBottom:`1px solid ${N.border}`, marginBottom:20 }}>
        {tabs.map(t=>(
          <button key={t.id} onClick={()=>setFilter(t.id)}
            style={{ padding:"9px 13px", background:"none", border:"none", borderBottom:`2px solid ${filter===t.id?N.action:"transparent"}`, color:filter===t.id?N.action:N.textSec, fontSize:13, fontWeight:filter===t.id?600:400, cursor:"pointer", fontFamily:FONT, transition:T.std, display:"flex", gap:5 }}>
            {t.label} <span style={{ fontSize:11, background:t.id==="pending"?N.critBg:N.subtle, color:t.id==="pending"?N.crit:N.textDis, borderRadius:999, padding:"1px 6px" }}>{t.count}</span>
          </button>
        ))}
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {filtered.map(d=>(
          <Card key={d.id} onClick={()=>d.status!=="decided"?(setActiveDecision(d.id),setView("decision-package")):undefined}
            accent={d.status==="pending"?N.crit:d.status==="waiting"?"#D97706":N.success} style={{ padding:"18px 22px" }}>
            {d.heroSentence && <p style={{ fontSize:14, fontWeight:600, color:N.text, margin:"0 0 10px", lineHeight:1.5, fontFamily:FONT }}>{d.heroSentence}</p>}
            {/* V6.1: exactly 2 badges */}
            <div style={{ display:"flex", gap:8, marginBottom:8 }}>
              {d.deadlineDays>0 && <DeadlineBadge days={d.deadlineDays} />}
              {d.confidence>0 && <ConfChip pct={d.confidence} afterAction={d.confAfterAction} reasons={d.confReasons} positive={d.confPositive} missing={d.confMissing} />}
            </div>
            <div style={{ fontSize:14, fontWeight:500, color:N.text, fontFamily:FONT }}>{d.statement}</div>
            {d.outcome && <div style={{ fontSize:13, color:N.success, marginTop:6, fontFamily:FONT, display:"flex", gap:4 }}><CheckCircle size={11} strokeWidth={2.5} style={{ marginTop:1 }} /> {d.outcome}</div>}
          </Card>
        ))}
      </div>
    </div>
  );
}

// ─── GLOBAL DELIVERABLES ─────────────────────────────────────────────────────

function GlobalDeliverablesView() {
  const all = [
    ...DELIVERABLES_DATA,
    { id:"del3", name:"Annual Supplier Review — Final", format:"Report", status:"published" as const, version:"v2.0", audience:"Procurement team", updated:"2 days ago", publicationScore:97, confidence:93, confAfterAction:93, blockerMain:"", nextAction:"", aiSummary:"Fully validated and published.", generatedBy:"NOVA", reviewedBy:"Legal team", validatedBy:"CPO" as string|null, evidenceCoverage:94, completeness:100, pendingComments:0, outstandingReviews:0, missingInfo:[] as string[], versionHistory:[] as {v:string;date:string;note:string}[] },
  ];
  const [filter, setFilter] = useState<"all"|"draft"|"review"|"published">("all");
  const filtered = filter==="all" ? all : all.filter(d=>d.status===filter);
  return (
    <div style={{ maxWidth:760, margin:"0 auto", padding:"52px 52px 100px" }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:4 }}>
        <h1 style={{ fontSize:26, fontWeight:650, color:N.text, margin:0, letterSpacing:"-0.03em", fontFamily:FONT }}>Deliverables</h1>
        <Btn variant="primary" size="md"><Plus size={13} strokeWidth={2.5} /> Create</Btn>
      </div>
      <p style={{ fontSize:14, color:N.textDis, margin:"0 0 28px", fontFamily:FONT }}>All outputs across your work.</p>
      <div style={{ display:"flex", gap:0, borderBottom:`1px solid ${N.border}`, marginBottom:20 }}>
        {(["all","draft","review","published"] as const).map(f=>(
          <button key={f} onClick={()=>setFilter(f)}
            style={{ padding:"9px 13px", background:"none", border:"none", borderBottom:`2px solid ${filter===f?N.action:"transparent"}`, color:filter===f?N.action:N.textSec, fontSize:13, fontWeight:filter===f?600:400, cursor:"pointer", fontFamily:FONT, transition:T.std, display:"flex", gap:5 }}>
            {f==="all"?"All":f==="draft"?"Drafts":f==="review"?"In review":"Published"}
            <span style={{ fontSize:11, background:N.subtle, color:N.textDis, borderRadius:999, padding:"1px 6px" }}>{all.filter(d=>f==="all"||d.status===f).length}</span>
          </button>
        ))}
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:7 }}>
        {filtered.map(d=>(
          <div key={d.id} style={{ display:"flex", alignItems:"center", gap:14, padding:"14px 20px", background:N.surface, borderRadius:10, border:`1px solid ${N.border}`, boxShadow:SH.card }}>
            <FileText size={13} color={N.textSec} strokeWidth={2} style={{ flexShrink:0 }} />
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:13, fontWeight:600, color:N.text, fontFamily:FONT }}>{d.name}</div>
              <div style={{ fontSize:12, color:N.textSec, fontFamily:FONT }}>{d.format} · {d.audience} · {d.updated}</div>
            </div>
            <ConfChip pct={d.confidence} afterAction={d.confAfterAction} reasons={[`Evidence: ${d.evidenceCoverage}%`]} positive={[]} missing="" />
            <div style={{ display:"flex", gap:5 }}>
              <Btn variant="quiet" size="sm"><Eye size={11} strokeWidth={2} /></Btn>
              {d.status==="published" && <Btn variant="secondary" size="sm"><Download size={11} strokeWidth={2} /></Btn>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── DECISION PACKAGE V6.1 ───────────────────────────────────────────────────
// Hero + if approved/rejected + options + dissent + one CTA. All evidence in drawer.

function DecisionPackageView({ decisionId, setView }:{ decisionId:string; setView:(v:View)=>void }) {
  const d = DECISIONS_DATA.find(x=>x.id===decisionId)??DECISIONS_DATA[0];
  const [sel, setSel] = useState<string|null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  return (
    <div style={{ maxWidth:780, margin:"0 auto", padding:"52px 52px 100px" }}>
      <button onClick={()=>setView("work")} style={{ fontSize:13, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, marginBottom:28, display:"flex", gap:4, alignItems:"center" }}>
        <ChevronLeft size={13} strokeWidth={2.5} /> Back to work
      </button>

      {/* ── HERO ── */}
      <div style={{ padding:"26px 30px", background:`linear-gradient(135deg,${N.critBg},#FFF7F0)`, borderRadius:16, border:`1px solid #FECACA`, boxShadow:SH.hero, marginBottom:24 }}>
        <div style={{ display:"flex", gap:8, marginBottom:12 }}>
          <DeadlineBadge days={d.deadlineDays} />
          <ConfChip pct={d.confidence} afterAction={d.confAfterAction} reasons={d.confReasons} positive={d.confPositive} missing={d.confMissing} />
        </div>
        <p style={{ fontSize:18, fontWeight:700, color:N.text, margin:"0 0 6px", lineHeight:1.55, letterSpacing:"-0.02em", fontFamily:FONT }}>{d.statement}</p>
        {d.heroSentence && <p style={{ fontSize:14, color:N.crit, margin:"0 0 18px", fontFamily:FONT }}>{d.heroSentence}</p>}
        {d.recommendation && (
          <div style={{ fontSize:13, color:N.inno, fontFamily:FONT, display:"flex", gap:6, marginBottom:18 }}>
            <Sparkles size={11} strokeWidth={2.5} style={{ flexShrink:0, marginTop:2 }} />
            NOVA recommends: {d.recommendation}
          </div>
        )}
        <div style={{ display:"flex", gap:10, alignItems:"center" }}>
          <Btn variant="primary" size="md" onClick={()=>setView("decision-pause")}>Review and decide <ArrowRight size={14} strokeWidth={2.5} /></Btn>
          {d.rationale && <WhyInline>{d.rationale}{d.uncertainty?` Note: ${d.uncertainty}`:""}</WhyInline>}
          <button onClick={()=>setDetailOpen(true)} style={{ fontSize:12, color:N.textDis, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, marginLeft:"auto", display:"flex", gap:3 }}>Full package <ChevronRight size={11} strokeWidth={2} /></button>
        </div>
      </div>

      {/* If approved / rejected — visible consequence on main card */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:24 }}>
        <div style={{ padding:"14px 16px", background:N.successBg, borderRadius:11, border:`1px solid #BBF7D0` }}>
          <div style={{ fontSize:10, fontWeight:700, color:N.success, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:5, fontFamily:FONT }}>If approved</div>
          <div style={{ fontSize:13, color:N.success, fontFamily:FONT, lineHeight:1.5 }}>{d.ifApproved}</div>
        </div>
        <div style={{ padding:"14px 16px", background:N.critBg, borderRadius:11, border:`1px solid #FECACA` }}>
          <div style={{ fontSize:10, fontWeight:700, color:N.crit, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:5, fontFamily:FONT }}>If rejected</div>
          <div style={{ fontSize:13, color:N.crit, fontFamily:FONT, lineHeight:1.5 }}>{d.ifRejected}</div>
        </div>
      </div>

      {/* Options */}
      <div style={{ fontSize:10, fontWeight:700, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:10, fontFamily:FONT }}>Options</div>
      <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:20 }}>
        {d.options.map(opt=>(
          <button key={opt.id} onClick={()=>setSel(opt.id===sel?null:opt.id)}
            style={{ padding:"16px 18px", background:sel===opt.id?N.actionBg:N.surface, border:`1.5px solid ${sel===opt.id?N.action:N.border}`, borderRadius:11, cursor:"pointer", textAlign:"left", fontFamily:FONT, transition:T.std, boxShadow:SH.card }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <div style={{ width:18, height:18, borderRadius:"50%", border:`2px solid ${sel===opt.id?N.action:N.borderMd}`, background:sel===opt.id?N.action:"transparent", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, transition:T.std }}>
                {sel===opt.id && <Check size={8} color="#fff" strokeWidth={3} />}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ display:"flex", gap:8, alignItems:"center", marginBottom:4 }}>
                  <span style={{ fontSize:14, fontWeight:600, color:N.text, fontFamily:FONT }}>{opt.label}</span>
                  {opt.recommended && <span style={{ fontSize:10, color:N.inno, background:N.innoBg, border:`1px solid ${N.innoBrd}`, borderRadius:999, padding:"1px 7px", fontFamily:FONT, display:"flex", gap:3, alignItems:"center" }}><Sparkles size={8} strokeWidth={2.5} /> NOVA</span>}
                  <span style={{ fontSize:11, color:opt.risk==="Low"?N.success:opt.risk==="Medium"?"#B45309":N.crit, fontFamily:FONT }}>{opt.risk} risk</span>
                </div>
                <div style={{ fontSize:12, color:N.textSec, fontFamily:FONT }}>{opt.consequence}</div>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Dissent */}
      {d.dissent && (
        <div style={{ padding:"12px 16px", background:N.subtle, borderRadius:9, border:`1px solid ${N.border}`, marginBottom:24, display:"flex", gap:8 }}>
          <MessageSquare size={11} color={N.textSec} strokeWidth={2} style={{ flexShrink:0, marginTop:2 }} />
          <div style={{ fontSize:12, color:N.textSec, fontFamily:FONT, fontStyle:"italic" }}>"{d.dissent}"</div>
        </div>
      )}

      <Btn variant="primary" size="lg" onClick={()=>setView("decision-pause")}>Review and decide <ArrowRight size={14} strokeWidth={2.5} /></Btn>

      {/* Full package drawer — narrative order */}
      <Drawer open={detailOpen} onClose={()=>setDetailOpen(false)} title="Decision package">
        <DrawerSection label="Summary">
          <p style={{ fontSize:13, color:N.text, fontFamily:FONT, lineHeight:1.65, margin:0 }}>{d.recommendation} {d.rationale}</p>
        </DrawerSection>
        <DrawerSection label="Why it matters">
          <p style={{ fontSize:13, color:N.textSec, fontFamily:FONT, lineHeight:1.6, margin:0 }}>{d.businessImpact}</p>
        </DrawerSection>
        <DrawerSection label="What is blocking">
          {d.uncertainty && <div style={{ fontSize:13, color:N.warn, fontFamily:FONT, marginBottom:5 }}>{d.uncertainty}</div>}
          {d.dissent && <div style={{ fontSize:13, color:N.textSec, fontFamily:FONT, fontStyle:"italic" }}>"{d.dissent}"</div>}
        </DrawerSection>
        <DrawerSection label="Key evidence">
          <DrawerRow label="Financial impact" value={d.financialImpact} />
          <DrawerRow label="Risk impact"      value={d.riskImpact} />
          {d.sources.map((s,i)=><div key={i} style={{ fontSize:13, color:N.action, fontFamily:FONT, marginTop:6 }}>{s}</div>)}
        </DrawerSection>
        {d.expertsConsulted.length>0 && <DrawerSection label="Technical details">
          {d.expertsConsulted.map((e,i)=><div key={i} style={{ fontSize:13, color:N.textSec, fontFamily:FONT, marginBottom:4 }}>{e}</div>)}
        </DrawerSection>}
      </Drawer>
    </div>
  );
}

// ─── DECISION PAUSE V6.1 ─────────────────────────────────────────────────────

function DecisionPauseView({ decisionId, setView }:{ decisionId:string; setView:(v:View)=>void }) {
  const d = DECISIONS_DATA.find(x=>x.id===decisionId)??DECISIONS_DATA[0];
  const [step, setStep] = useState<"review"|"decide">("review");
  const [choice, setChoice] = useState<string|null>(null);
  const [rationale, setRationale] = useState("");
  const [loading, setLoading] = useState(false);
  const choices = [
    { id:"approve",  label:"Approve",        color:N.success, bg:N.successBg, brd:"#BBF7D0" },
    { id:"changes",  label:"Request changes", color:N.warn,    bg:N.warnBg,    brd:"#FDE68A" },
    { id:"reject",   label:"Reject",          color:N.crit,    bg:N.critBg,    brd:"#FECACA" },
    { id:"defer",    label:"Defer",           color:N.textSec, bg:N.subtle,    brd:N.border  },
  ];
  return (
    <div style={{ minHeight:"100vh", background:N.canvas, display:"flex", alignItems:"flex-start", justifyContent:"center", padding:"48px 24px 80px" }}>
      <div style={{ width:"100%", maxWidth:520 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:36 }}>
          <div style={{ width:26, height:26, borderRadius:7, background:N.action, display:"flex", alignItems:"center", justifyContent:"center" }}><Lock size={11} color="#fff" strokeWidth={2.5} /></div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, fontWeight:600, color:N.textSec, fontFamily:FONT }}>Decision · {d.authority}</div>
            <div style={{ fontSize:11, color:N.textDis, fontFamily:FONT }}>Permanent and immutable record</div>
          </div>
          <button onClick={()=>setView("decision-package")} style={{ fontSize:13, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT }}>← Back</button>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:36 }}>
          {[{id:"review",label:"Review"},{id:"decide",label:"Decide"}].map((s,i)=>(
            <div key={s.id} style={{ display:"flex", alignItems:"center", gap:8 }}>
              <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                <div style={{ width:18, height:18, borderRadius:"50%", background:step===s.id?N.action:(i===0&&step==="decide")?N.success:N.border, display:"flex", alignItems:"center", justifyContent:"center", transition:T.std }}>
                  {i===0&&step==="decide"?<Check size={9} color="#fff" strokeWidth={3} />:<span style={{ fontSize:9, fontWeight:700, color:step===s.id?"#fff":N.textDis, fontFamily:FONT }}>{i+1}</span>}
                </div>
                <span style={{ fontSize:13, fontWeight:step===s.id?600:400, color:step===s.id?N.text:N.textSec, fontFamily:FONT }}>{s.label}</span>
              </div>
              {i===0 && <div style={{ width:36, height:1, background:N.border, margin:"0 4px" }} />}
            </div>
          ))}
        </div>
        {step==="review" && (
          <>
            <h1 style={{ fontSize:20, fontWeight:650, color:N.text, margin:"0 0 5px", letterSpacing:"-0.02em", fontFamily:FONT }}>Review the decision</h1>
            <p style={{ fontSize:13, color:N.textSec, margin:"0 0 24px", lineHeight:1.6, fontFamily:FONT }}>Confirm you have reviewed the key elements before proceeding.</p>
            <div style={{ display:"flex", flexDirection:"column", gap:7, marginBottom:28 }}>
              {[
                { label:"Decision",   value:d.statement },
                { label:"Recommended",value:d.options[0]?.label, sub:d.options[0]?.consequence },
                { label:"If approved",value:d.ifApproved, ok:true },
                { label:"If rejected",value:d.ifRejected, danger:true },
                { label:"Uncertainty",value:d.uncertainty, warn:true },
              ].filter(row=>row.value).map((row,i)=>(
                <div key={i} style={{ padding:"11px 14px", background:row.warn?N.warnBg:row.ok?N.successBg:row.danger?N.critBg:N.surface, borderRadius:10, border:`1px solid ${row.warn?"#FDE68A":row.ok?"#BBF7D0":row.danger?"#FECACA":N.border}`, boxShadow:SH.card }}>
                  <div style={{ fontSize:10, fontWeight:600, color:row.warn?N.warn:row.ok?N.success:row.danger?N.crit:N.textDis, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4, fontFamily:FONT }}>{row.label}</div>
                  <div style={{ fontSize:13, fontWeight:500, color:row.warn?N.warn:row.ok?N.success:row.danger?N.crit:N.text, fontFamily:FONT, lineHeight:1.5 }}>{row.value}</div>
                  {row.sub && <div style={{ fontSize:11, color:N.textSec, marginTop:3, fontFamily:FONT }}>{row.sub}</div>}
                </div>
              ))}
            </div>
            <Btn variant="primary" size="lg" full onClick={()=>setStep("decide")}>I have reviewed — continue <ArrowRight size={14} strokeWidth={2.5} /></Btn>
            <div style={{ textAlign:"center", marginTop:10 }}><button onClick={()=>setView("decision-package")} style={{ fontSize:13, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT }}>Cancel</button></div>
          </>
        )}
        {step==="decide" && (
          <>
            <h1 style={{ fontSize:20, fontWeight:650, color:N.text, margin:"0 0 5px", letterSpacing:"-0.02em", fontFamily:FONT }}>Record your decision</h1>
            <p style={{ fontSize:13, color:N.textSec, margin:"0 0 20px", lineHeight:1.6, fontFamily:FONT }}>No option is preselected. Choose deliberately.</p>
            <div style={{ display:"flex", flexDirection:"column", gap:6, marginBottom:20 }}>
              {choices.map(c=>(
                <button key={c.id} onClick={()=>setChoice(c.id===choice?null:c.id)}
                  style={{ padding:"11px 14px", background:choice===c.id?c.bg:N.surface, border:`1.5px solid ${choice===c.id?c.color:N.border}`, borderRadius:9, cursor:"pointer", textAlign:"left", fontFamily:FONT, transition:T.std, display:"flex", alignItems:"center", gap:10 }}>
                  <div style={{ width:16, height:16, borderRadius:"50%", border:`2px solid ${choice===c.id?c.color:N.borderMd}`, background:choice===c.id?c.color:"transparent", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, transition:T.std }}>
                    {choice===c.id && <Check size={8} color="#fff" strokeWidth={3} />}
                  </div>
                  <span style={{ fontSize:13, fontWeight:600, color:choice===c.id?c.color:N.text, fontFamily:FONT }}>{c.label}</span>
                </button>
              ))}
            </div>
            <div style={{ marginBottom:24 }}>
              <label style={{ display:"block", fontSize:13, fontWeight:600, color:N.text, marginBottom:6, fontFamily:FONT }}>Your rationale <span style={{ color:N.crit, fontWeight:400 }}>*</span></label>
              <textarea value={rationale} onChange={e=>setRationale(e.target.value)} placeholder="Required — retained as an immutable record."
                style={{ width:"100%", minHeight:88, border:`1.5px solid ${rationale?N.action:N.border}`, borderRadius:10, padding:"11px 13px", fontSize:13, color:N.text, fontFamily:FONT, resize:"vertical", outline:"none", lineHeight:1.6, boxSizing:"border-box", transition:T.std }} />
            </div>
            <Btn variant="primary" size="lg" full disabled={!choice||!rationale.trim()||loading} onClick={()=>{ setLoading(true); setTimeout(()=>{ setLoading(false); setView("decision-receipt"); },700); }}>
              {loading?<><RefreshCw size={13} strokeWidth={2.5} style={{ animation:"spin 1s linear infinite" }} /> Recording…</>:<>Record — {choices.find(c=>c.id===choice)?.label??"choose above"}</>}
            </Btn>
            <div style={{ textAlign:"center", marginTop:10 }}><button onClick={()=>setStep("review")} style={{ fontSize:13, color:N.textSec, background:"none", border:"none", cursor:"pointer", fontFamily:FONT }}>← Back</button></div>
          </>
        )}
      </div>
    </div>
  );
}

// ─── DECISION RECEIPT ─────────────────────────────────────────────────────────

function DecisionReceiptView({ decisionId, setView }:{ decisionId:string; setView:(v:View)=>void }) {
  const d = DECISIONS_DATA.find(x=>x.id===decisionId)??DECISIONS_DATA[0];
  return (
    <div style={{ minHeight:"100vh", background:N.canvas, display:"flex", alignItems:"flex-start", justifyContent:"center", padding:"52px 24px 80px" }}>
      <div style={{ width:"100%", maxWidth:520 }}>
        <div style={{ textAlign:"center", marginBottom:40 }}>
          <div style={{ width:44, height:44, borderRadius:"50%", background:N.successBg, border:`1px solid #BBF7D0`, display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 14px" }}><CheckCircle size={20} color={N.success} strokeWidth={2} /></div>
          <h1 style={{ fontSize:22, fontWeight:650, color:N.text, margin:"0 0 5px", letterSpacing:"-0.025em", fontFamily:FONT }}>Decision recorded</h1>
          <p style={{ fontSize:13, color:N.textSec, margin:0, fontFamily:FONT }}>Permanent and immutable record.</p>
        </div>
        <Card style={{ padding:"22px 26px", marginBottom:14 }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:16, paddingBottom:12, borderBottom:`1px solid ${N.border}` }}>
            <div>
              <div style={{ fontSize:10, fontWeight:600, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4, fontFamily:FONT }}>Reference</div>
              <code style={{ fontSize:11, fontFamily:MONO, color:N.text, background:N.subtle, padding:"2px 8px", borderRadius:5, border:`1px solid ${N.border}` }}>DEC-2025-{d.id.toUpperCase()}-Q3</code>
            </div>
            <button style={{ fontSize:12, color:N.action, background:"none", border:"none", cursor:"pointer", fontFamily:FONT, display:"flex", gap:3, alignItems:"center" }}><Download size={11} strokeWidth={2} /> Export</button>
          </div>
          {[{l:"Outcome",v:"Approved",c:N.success},{l:"Decision",v:d.statement},{l:"Approved option",v:d.options[0]?.label??""},{l:"Authority",v:"Sarah Chen"},{l:"Recorded",v:`${new Date().toLocaleDateString("en-GB",{day:"numeric",month:"long",year:"numeric"})} ${new Date().toLocaleTimeString("en-GB",{hour:"2-digit",minute:"2-digit"})}`}].map((row,i)=>(
            <div key={i} style={{ display:"flex", alignItems:"flex-start", gap:16, padding:"9px 0", borderBottom:i<4?`1px solid ${N.border}`:"none" }}>
              <span style={{ width:96, fontSize:12, fontWeight:500, color:N.textSec, flexShrink:0, fontFamily:FONT }}>{row.l}</span>
              <span style={{ fontSize:13, color:row.c??N.text, lineHeight:1.5, fontFamily:FONT }}>{row.v}</span>
            </div>
          ))}
        </Card>
        <Card style={{ padding:"16px 20px", marginBottom:24 }}>
          <div style={{ fontSize:10, fontWeight:700, color:N.textDis, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:10, fontFamily:FONT }}>Resulting actions</div>
          {["Infrastructure procurement — Thomas Vidal · 20 Jul","Update Q3 budget model — Sarah Chen · 16 Jul","Notify board of approval in presentation · 18 Jul"].map((a,i)=>(
            <div key={i} style={{ display:"flex", gap:7, padding:"7px 0", borderBottom:i<2?`1px solid ${N.border}`:"none" }}>
              <ArrowRight size={10} color={N.action} strokeWidth={2.5} style={{ flexShrink:0, marginTop:3 }} /><span style={{ fontSize:13, color:N.text, fontFamily:FONT }}>{a}</span>
            </div>
          ))}
        </Card>
        <div style={{ display:"flex", gap:10 }}>
          <Btn variant="primary" size="md" onClick={()=>setView("work")}>Return to work <ArrowRight size={13} strokeWidth={2.5} /></Btn>
          <Btn variant="secondary" size="md">Share receipt</Btn>
        </div>
      </div>
    </div>
  );
}

// ─── SEARCH ───────────────────────────────────────────────────────────────────

function SearchOverlay({ onClose, setView, setActiveWork, setActiveDecision }:{ onClose:()=>void; setView:(v:View)=>void; setActiveWork:(id:string)=>void; setActiveDecision:(id:string)=>void }) {
  const [q, setQ] = useState("");
  const ref = useRef<HTMLInputElement>(null);
  useEffect(()=>{ ref.current?.focus(); }, []);
  const RECENT = [
    { label:"Q3 budget review presentation",         sub:"76% confidence · Due 18 Jul", act:()=>{ setActiveWork("w1"); setView("work"); onClose(); } },
    { label:"Approve €420k infrastructure",           sub:"82% confidence · Due 15 Jul", act:()=>{ setActiveDecision("d1"); setView("decision-package"); onClose(); } },
    { label:"Customer churn analysis",                sub:"41% confidence · Due 22 Jul", act:()=>{ setActiveWork("w2"); setView("work"); onClose(); } },
  ];
  const filtered = q.length>1 ? [
    ...WORK_ITEMS.filter(w=>w.outcome.toLowerCase().includes(q.toLowerCase())).map(w=>({ label:w.outcome, sub:`${w.confidence}% · ${w.deadline}`, act:()=>{ setActiveWork(w.id); setView("work"); onClose(); } })),
    ...DECISIONS_DATA.filter(d=>d.statement.toLowerCase().includes(q.toLowerCase())).map(d=>({ label:d.statement, sub:`${d.confidence>0?d.confidence+"%":""} · ${d.authority}`, act:()=>{ setActiveDecision(d.id); setView("decision-package"); onClose(); } })),
  ] : [];
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(15,23,42,.35)", backdropFilter:"blur(3px)", display:"flex", alignItems:"flex-start", justifyContent:"center", padding:"72px 24px", zIndex:100 }}
      onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{ width:"100%", maxWidth:520, background:N.surface, borderRadius:13, boxShadow:SH.overlay, overflow:"hidden", border:`1px solid ${N.border}` }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, padding:"13px 16px", borderBottom:`1px solid ${N.border}` }}>
          <Search size={14} color={N.textDis} strokeWidth={2} />
          <input ref={ref} value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Escape"&&onClose()}
            placeholder="Search work, decisions, deliverables…"
            style={{ flex:1, border:"none", outline:"none", fontSize:14, color:N.text, fontFamily:FONT, background:"transparent" }} />
          <kbd style={{ fontSize:10, color:N.textDis, background:N.subtle, border:`1px solid ${N.border}`, borderRadius:4, padding:"1px 5px", fontFamily:MONO }}>Esc</kbd>
        </div>
        <div style={{ maxHeight:360, overflowY:"auto", padding:"8px 0 4px" }}>
          {(q.length<2?RECENT:filtered).map((item,i)=>(
            <button key={i} onClick={item.act}
              style={{ width:"100%", padding:"9px 16px", background:"transparent", border:"none", display:"flex", alignItems:"center", gap:10, cursor:"pointer", fontFamily:FONT, textAlign:"left" }}
              onMouseEnter={e=>e.currentTarget.style.background=N.subtle} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:13, color:N.text, fontFamily:FONT, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{item.label}</div>
                <div style={{ fontSize:11, color:N.textDis, fontFamily:FONT }}>{item.sub}</div>
              </div>
            </button>
          ))}
          {q.length>1 && filtered.length===0 && <div style={{ padding:"32px 16px", textAlign:"center", fontSize:13, color:N.textDis, fontFamily:FONT }}>No results for "{q}"</div>}
        </div>
      </div>
    </div>
  );
}

// ─── APP ROOT ─────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState<View>("home");
  const [activeWork, setActiveWork] = useState("w1");
  const [activeDecision, setActiveDecision] = useState("d1");
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(()=>{
    function onKey(e:KeyboardEvent) {
      if ((e.metaKey||e.ctrlKey)&&e.key==="k"){ e.preventDefault(); setSearchOpen(true); }
      if (e.key==="Escape") setSearchOpen(false);
    }
    window.addEventListener("keydown", onKey);
    return ()=>window.removeEventListener("keydown", onKey);
  }, []);

  const fullscreen = view==="decision-pause"||view==="decision-receipt";

  return (
    <div style={{ display:"flex", height:"100vh", fontFamily:FONT, background:N.canvas, color:N.text, overflow:"hidden" }}>
      {!fullscreen && <NavRail view={view} setView={setView} onSearch={()=>setSearchOpen(true)} />}
      <main style={{ flex:1, overflow:"hidden", display:"flex", flexDirection:"column" }}>
        {view==="home"                && <div style={{ flex:1, overflowY:"auto" }}><HomeView setView={setView} setActiveWork={setActiveWork} setActiveDecision={setActiveDecision} /></div>}
        {view==="clarify"             && <div style={{ flex:1, overflowY:"auto" }}><ClarifyView setView={setView} /></div>}
        {view==="canvas"              && <div style={{ flex:1, overflowY:"auto" }}><CanvasView setView={setView} /></div>}
        {view==="plan"                && <div style={{ flex:1, overflowY:"auto" }}><PlanView setView={setView} /></div>}
        {view==="confirm"             && <div style={{ flex:1, overflowY:"auto" }}><ConfirmView setView={setView} setActiveWork={setActiveWork} /></div>}
        {view==="work"                && <WorkView workId={activeWork} setView={setView} setActiveDecision={setActiveDecision} />}
        {view==="global-decisions"    && <div style={{ flex:1, overflowY:"auto" }}><GlobalDecisionsView setActiveDecision={setActiveDecision} setView={setView} /></div>}
        {view==="global-deliverables" && <div style={{ flex:1, overflowY:"auto" }}><GlobalDeliverablesView /></div>}
        {view==="decision-package"    && <div style={{ flex:1, overflowY:"auto" }}><DecisionPackageView decisionId={activeDecision} setView={setView} /></div>}
        {view==="decision-pause"      && <DecisionPauseView decisionId={activeDecision} setView={setView} />}
        {view==="decision-receipt"    && <DecisionReceiptView decisionId={activeDecision} setView={setView} />}
      </main>
      {searchOpen && <SearchOverlay onClose={()=>setSearchOpen(false)} setView={setView} setActiveWork={setActiveWork} setActiveDecision={setActiveDecision} />}
      <style>{`
        * { box-sizing:border-box; }
        @keyframes spin { to { transform:rotate(360deg); } }
        @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.4;transform:scale(.7)} }
        body { margin:0; }
        ::-webkit-scrollbar { width:4px; }
        ::-webkit-scrollbar-track { background:transparent; }
        ::-webkit-scrollbar-thumb { background:#CBD5E1; border-radius:3px; }
        ::-webkit-scrollbar-thumb:hover { background:#94A3B8; }
        details summary::-webkit-details-marker { display:none; }
      `}</style>
    </div>
  );
}
