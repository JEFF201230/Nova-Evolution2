MISSION

Tu es un Senior Staff Design System Engineer, Frontend Architect et UX Engineer.

Ta mission est de produire la documentation technique complète permettant une implémentation STRICTEMENT IDENTIQUE du module NOVA.

Aucune synthèse.
Aucune simplification.
Aucune omission.

Je veux une spécification exhaustive.

L'objectif est qu'une équipe React/TypeScript puisse reconstruire le module sans jamais ouvrir Figma une seconde fois.

====================================================================
LIVRABLES OBLIGATOIRES
====================================================================

Analyse absolument TOUT.

Pour CHAQUE écran.

Pour CHAQUE composant.

Pour CHAQUE variante.

Pour CHAQUE interaction.

Pour CHAQUE état.

Pour CHAQUE propriété.

Ne rien oublier.

====================================================================
1. INVENTAIRE COMPLET
====================================================================

Lister tous les écrans.

Hiérarchie.

Navigation.

Arborescence.

Relations entre les pages.

Workflow utilisateur.

Workflow IA.

Workflow décisionnel.

Workflow documentaire.

Workflow des preuves.

Workflow des validations.

Workflow des collaborateurs.

====================================================================
2. USER FLOW
====================================================================

Créer le parcours utilisateur complet.

Décrire :

entrée

actions

sorties

conditions

retours

navigation

cas d'erreur

cas annulés

cas validés

cas bloqués

points de retour

états transitoires

====================================================================
3. INFORMATION ARCHITECTURE
====================================================================

Décrire :

containers

layout

sections

cards

drawers

tabs

header

footer

toolbar

sidebar

floating actions

navigation

breadcrumb

modales

popover

tooltips

====================================================================
4. DESIGN TOKENS
====================================================================

Extraire :

Spacing

Grid

Columns

Rows

Container Width

Padding

Margins

Gap

Radius

Elevation

Opacity

Stroke

Border

Blur

Shadow

Typography

Letter spacing

Line Height

Weight

Font

Font Size

Z-index

====================================================================
5. COULEURS
====================================================================

Extraire :

HEX

RGB

RGBA

Opacity

Variables

Tokens

Semantic Colors

Light Mode

Dark Mode si existant

Hover

Pressed

Focus

Disabled

Selected

====================================================================
6. TYPOGRAPHIE
====================================================================

Pour chaque texte :

Font

Weight

Size

Height

Letter spacing

Token

Couleur

Alignement

Transformation

====================================================================
7. ICONES
====================================================================

Lister :

nom

taille

padding

position

couleur

état

interaction

bibliothèque utilisée

====================================================================
8. COMPOSANTS
====================================================================

Pour chaque composant :

Nom

Description

Type

Responsabilité

Propriétés

Props

Variants

Slots

Children

Parent

Events

Accessibility

Responsive

Breakpoints

Etat initial

Etat hover

Etat focus

Etat disabled

Etat loading

Etat error

Etat warning

Etat success

Etat selected

Etat active

Etat pending

Etat hidden

Etat visible

Etat collapsed

Etat expanded

Etat drawer

Etat modal

Etat overlay

Etat sticky

====================================================================
9. DIMENSIONS PIXEL PERFECT
====================================================================

Pour CHAQUE composant :

Width

Height

Min Width

Max Width

Min Height

Max Height

Padding

Margin

Gap

Border Radius

Border Width

Stroke

Shadow

Position

Absolute

Relative

Constraints

Auto Layout

Frame

Alignment

Anchor

Offset

Rotation

Scale

====================================================================
10. AUTO LAYOUT
====================================================================

Pour chaque Frame :

Direction

Spacing

Padding

Distribution

Alignment

Resize

Fill

Hug

Fixed

Constraints

====================================================================
11. RESPONSIVE
====================================================================

Desktop

Laptop

Tablet

Mobile

Breakpoints

Behaviour

Collapse

Wrapping

Hidden

Priority

====================================================================
12. CSS
====================================================================

Générer :

CSS complet

Variables

Custom Properties

Tailwind équivalent

SCSS

CSS Modules

Flex

Grid

Absolute

Position

Overflow

Transitions

Animations

====================================================================
13. JSX
====================================================================

Produire :

Arborescence JSX complète

Nom des composants

Hiérarchie

Composition

Props

Children

Fragments

Conditions

Mapping

====================================================================
14. REACT
====================================================================

Définir :

Component Tree

Shared Components

Hooks

State

Props

Memo

Context

Composition

Containers

Presentational Components

====================================================================
15. ACCESSIBILITÉ
====================================================================

ARIA

Keyboard Navigation

Focus Order

Roles

Labels

Contrast

Screen Reader

Tab Index

====================================================================
16. INTERACTIONS
====================================================================

Pour chaque élément :

Click

Hover

Drag

Drop

Animation

Transition

Drawer

Popover

Tooltip

Navigation

Shortcut

Keyboard

====================================================================
17. DRAWERS
====================================================================

Pour chaque Drawer :

Largeur

Animation

Overlay

Stack

Close Behaviour

Scroll

Header

Body

Footer

Actions

====================================================================
18. TABS
====================================================================

Décrire :

Navigation

Etat

Animation

Lazy Loading

Transitions

====================================================================
19. ETATS
====================================================================

Tous les états possibles.

Tous les états impossibles.

Toutes les transitions.

Toutes les conditions.

====================================================================
20. DEPENDANCES
====================================================================

Pour chaque écran :

Composants dépendants

Composants partagés

Variables

Tokens

Styles

Interactions

====================================================================
21. MATRICE COMPLETE
====================================================================

Créer une matrice :

Ecran

↓

Section

↓

Composant

↓

Sous composant

↓

Variant

↓

Etat

↓

Interaction

↓

Navigation

↓

CSS

↓

JSX

↓

Accessibilité

↓

Responsive

====================================================================
22. EXPORT
====================================================================

Produire les documents suivants :

01_SCREEN_INVENTORY.md

02_USER_FLOW.md

03_INFORMATION_ARCHITECTURE.md

04_COMPONENT_LIBRARY.md

05_DESIGN_TOKENS.md

06_COLOR_SYSTEM.md

07_TYPOGRAPHY.md

08_LAYOUT_SYSTEM.md

09_COMPONENT_SPECIFICATIONS.md

10_DRAWER_SPECIFICATIONS.md

11_INTERACTION_SPECIFICATIONS.md

12_RESPONSIVE_SPECIFICATIONS.md

13_ACCESSIBILITY.md

14_CSS_REFERENCE.md

15_JSX_REFERENCE.md

16_REACT_COMPONENT_TREE.md

17_DEPENDENCY_GRAPH.md

18_IMPLEMENTATION_GUIDE.md

19_PIXEL_PERFECT_CHECKLIST.md

20_IMPLEMENTATION_MATRIX.md

====================================================================
REGLE ABSOLUE
====================================================================

Ne résume jamais.

Ne simplifie jamais.

Ne saute aucun composant.

Ne saute aucune variante.

Ne saute aucun état.

Chaque valeur doit être extraite directement de Figma.

Toutes les dimensions doivent être données en pixels.

Toutes les couleurs doivent être données en HEX et RGBA.

Toutes les typographies doivent être détaillées.

Toutes les contraintes Auto Layout doivent être documentées.

Toutes les interactions doivent être décrites.

L'objectif est de permettre une implémentation React + TypeScript pixel-perfect sans rouvrir Figma.

Ce prompt est orienté reverse-engineering exhaustif : il vise à transformer le fichier Figma en une documentation d'implémentation complète couvrant la structure, les composants, les styles, les dimensions, les interactions, les dépendances et les parcours utilisateurs.