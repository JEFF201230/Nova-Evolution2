ORCHESTRATOR — UX ITERATION V6
Mission Studio

La V5 constitue désormais la base officielle.

Ne repars pas de zéro.

Conserve :

- le Design System STAR
- la palette STAR
- les composants actuels
- la hiérarchie générale
- le Mission Control
- le Pilotage opérationnel

L'objectif n'est plus une évolution graphique.

L'objectif est de transformer ORCHESTRATOR en véritable système d'orchestration d'agents IA.

──────────────────────────────────────

PROBLÈME ACTUEL

Le Prompt Center reste un simple formulaire.

Il ressemble à une zone de texte.

Or l'utilisateur ne rédige pas un prompt.

Il construit une mission confiée à une équipe d'agents IA.

Le Prompt Center doit donc évoluer vers un véritable espace de travail.

──────────────────────────────────────

OBJECTIF

Transformer le Prompt Center en

MISSION STUDIO

Mission Control explique la situation.

Mission Studio permet d'agir.

Pilotage Opérationnel permet de suivre l'exécution.

Ces trois espaces doivent former un parcours naturel.

──────────────────────────────────────

RENOMMER

Prompt Center

↓

Mission Studio

Sous-titre :

"Construisez une mission. ORCHESTRATOR sélectionne, coordonne et supervise les agents IA."

──────────────────────────────────────

COMPORTEMENT ADAPTATIF

Etat 1

Mission Studio compact.

Disposition actuelle conservée.

Mission Control reste prioritaire.

Etat 2

Lorsque l'utilisateur clique dans Mission Studio :

Animation fluide.

Mission Studio devient l'espace principal.

Largeur :

70 à 80 % de l'écran.

Le cockpit ne disparaît jamais.

Il devient une colonne latérale.

Le tableau de bord reste visible mais secondaire.

L'utilisateur ne change jamais de page.

──────────────────────────────────────

NOUVELLE DISPOSITION

┌──────────────────────────────────────────────────────────────┬──────────────────────┐
│                                                              │                      │
│                                                              │ Contexte actif       │
│                                                              │                      │
│               MISSION STUDIO                                │ Décision            │
│                                                              │ Programme           │
│               Conversation                                  │ Risques             │
│                                                              │ Missions            │
│               Documents                                     │ KPI                 │
│                                                              │                      │
│               Réponses IA                                   │                      │
│                                                              │                      │
│                                                              │                      │
└──────────────────────────────────────────────────────────────┴──────────────────────┘

Le cockpit devient un contexte permanent.

──────────────────────────────────────

MISSION STUDIO

Le textarea disparaît.

Mission Studio devient un véritable éditeur.

Structure proposée :

OBJECTIF

Que souhaitez-vous accomplir ?

────────────────────

CONTEXTE

Programme

Mission

Risque

Budget

Document

Architecture

Réunion

Tous les éléments peuvent être ajoutés.

────────────────────

MISSION

Grand éditeur.

Support du Markdown.

Support des longues instructions.

Support du copier/coller.

Support du drag & drop.

Support des pièces jointes.

Hauteur confortable.

L'utilisateur peut écrire plusieurs milliers de caractères.

────────────────────

AGENTS

Architecture

Planning

Finance

Risk

Legal

QA

Document

Classification

Ou

Sélection automatique.

────────────────────

LANCEMENT

Le bouton ne doit plus s'appeler

"Lancer"

mais

"Exécuter la mission"

──────────────────────────────────────

CONVERSATION

Une fois la mission lancée,

Mission Studio devient conversationnel.

ORCHESTRATOR répond directement dans cet espace.

Exemple :

Vous

Analyse l'impact du retard API.

────────────────

ORCHESTRATOR

Analyse terminée.

2 risques critiques détectés.

1 partenaire bloque le planning.

Coût estimé :

42 k€

Je recommande :

• créer une revue exceptionnelle

• notifier Marc Leroy

• préparer un plan B

Actions proposées :

[Créer les missions]

[Notifier]

[Préparer le rapport]

[Créer la décision]

La conversation reste visible.

──────────────────────────────────────

AGENTS EN ACTIVITÉ

Mission Studio doit montrer que plusieurs agents travaillent réellement.

Exemple :

Architecture Agent

█████████░

72 %

Analyse des dépendances.

──────────────

Risk Agent

███████░░

58 %

Evaluation des impacts.

──────────────

Planning Agent

██████████

Terminé.

Conflits détectés.

──────────────

Finance Agent

████████░░

81 %

Projection budgétaire.

Le système doit donner l'impression d'orchestrer une équipe.

──────────────────────────────────────

HISTORIQUE

Sous la conversation,

Ajouter

"Missions récentes"

Aujourd'hui

Analyse Architecture

09:14

Audit Budget

09:32

Préparation COPIL

10:11

Comparaison scénarios

11:42

Toutes les missions restent consultables.

──────────────────────────────────────

COLONNE CONTEXTE

Pendant l'édition,

la carte "Action prioritaire"

ne doit plus occuper autant d'espace.

Elle devient un résumé compact.

Programme

VEEDDA

Décision active

Architecture multi-agents

Impact

45 k€

3 personnes bloquées

Documents liés

Risques liés

Missions liées

Ce panneau reste visible pendant toute la rédaction.

──────────────────────────────────────

DESIGN

Conserver strictement

STAR.

Très peu de couleurs.

Pas d'effets décoratifs.

Grandes respirations.

Hiérarchie très forte.

Le regard doit immédiatement comprendre :

• où écrire

• ce que les agents font

• ce que l'utilisateur peut décider.

──────────────────────────────────────

VISION

ORCHESTRATOR ne doit plus ressembler à ChatGPT.

Il ne doit plus ressembler à Jira.

Il ne doit plus ressembler à ClickUp.

Il doit ressembler au poste de commandement d'une organisation où un décideur pilote une équipe d'agents IA spécialisés.

Mission Control informe.

Mission Studio orchestre.

Pilotage Opérationnel exécute.

Le résultat doit donner l'impression d'utiliser un véritable système d'orchestration intelligent plutôt qu'un simple logiciel SaaS.