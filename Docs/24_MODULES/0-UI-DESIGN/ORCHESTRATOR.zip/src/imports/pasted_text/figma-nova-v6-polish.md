PROMPT FIGMA — NOVA V6.1 FINAL POLISH
MISSION UNIQUE : RÉDUIRE LE BRUIT, RENFORCER LA DÉCISION

Tu interviens sur la V6 existante de NOVA.

Tu ne repars pas de zéro.

Tu ne crées pas une nouvelle direction artistique.

Tu ne modifies pas l’architecture produit.

Tu ne crées pas de nouvelle page.

Tu ne rajoutes pas de nouveaux blocs métier.

Tu dois uniquement améliorer la V6 existante par une série de mini-chantiers strictement limités.

L’objectif est simple :

rendre NOVA plus évident, plus calme et plus utile en moins de 10 secondes.

La V6 doit rester immédiatement reconnaissable après modification.

RÈGLE ABSOLUE

Chaque écran doit répondre à une seule question principale.

Chaque page doit avoir :

un seul point focal ;
une seule action prioritaire ;
un seul message principal ;
des informations secondaires accessibles uniquement à la demande.

Toute information visible qui ne soutient pas directement la décision principale doit être :

déplacée dans un drawer ;
déplacée dans un détail ;
rendue secondaire ;
ou supprimée de la vue principale.
MINI-CHANTIER 1 — HIÉRARCHIE VISUELLE GLOBALE
Objectif

Créer une hiérarchie visuelle claire entre :

information critique ;
action prioritaire ;
contenu secondaire ;
arrière-plan.
À faire

Sur chaque écran :

identifier le point focal principal ;
renforcer légèrement son contraste ou son contour ;
réduire visuellement les composants secondaires ;
éviter que plusieurs cartes aient la même importance ;
réduire le nombre de bordures colorées concurrentes ;
garder les espaces blancs existants ;
conserver les proportions générales.
Résultat obligatoire

En moins de deux secondes, l’utilisateur doit savoir où regarder.

Interdictions
aucun nouveau widget ;
aucun nouveau panneau ;
aucune nouvelle couleur principale ;
aucune réduction des espaces blancs ;
aucune densification.
MINI-CHANTIER 2 — SIMPLIFICATION DES BADGES
Objectif

Réduire le bruit visuel provoqué par l’accumulation de statuts.

Règle

Sur une même carte principale, ne jamais afficher plus de deux badges visibles par défaut.

Badges autorisés

Uniquement :

urgence ou échéance ;
confiance NOVA.
À déplacer en information secondaire
High ;
Medium ;
Working ;
Attention ;
Active ;
Available ;
Invited ;
Draft ;
In review ;
autres statuts redondants.

Ces informations doivent rester accessibles dans le drawer, le détail ou le texte secondaire.

Exemple attendu

Avant :

Attention · 76% · Medium · Working · Due in 4 days

Après :

Due in 4 days · 76% confidence

Résultat obligatoire

L’œil doit lire une phrase, pas une série de pastilles.

MINI-CHANTIER 3 — HOME
Question unique de la page

Que dois-je faire maintenant ?

À conserver
champ d’objectif ;
message de situation ;
décision urgente ;
active work ;
bloc de travail en arrière-plan.
À faire

Faire du bloc suivant le point focal absolu :

Your presentation is blocked by 3 open comments and a missing CRM source. Resolve them today and NOVA estimates validation probability rises from 76% to 92%.

Le bloc doit contenir :

une phrase de situation ;
une phrase de gain ;
un seul bouton principal ;
un lien secondaire “Why?” ;
un lien discret vers le détail complet.
Action principale

Remplacer les formulations purement opérationnelles par une formulation orientée bénéfice.

Exemple :

Spend 15 minutes resolving 3 comments to increase validation probability from 76% to 92%.

À réduire
les autres cartes ne doivent pas concurrencer le bloc principal ;
active work devient plus sobre ;
les informations de fond restent lisibles mais visuellement secondaires.
Résultat obligatoire

En moins de 10 secondes, l’utilisateur doit comprendre :

ce qui bloque ;
ce qu’il doit faire ;
ce qu’il gagne s’il agit.
MINI-CHANTIER 4 — WORK OVERVIEW
Question unique de la page

Quelle est la meilleure prochaine action pour faire avancer ce travail ?

À conserver
résumé NOVA ;
next best action ;
décision en attente ;
progression ;
livrables ;
personnes ;
statut NOVA.
À faire

Le bloc Next Best Action doit devenir le point focal principal.

Il doit afficher uniquement :

action ;
gain ;
durée estimée ;
impact sur la confiance ;
bouton principal.
Exemple attendu

Review Sarah Chen’s 3 comments
15 min estimated
Unblocks CFO review
Confidence: 76% → 92%

À déplacer dans le drawer ou le détail
explications longues ;
métriques secondaires ;
détails de progression ;
historiques ;
informations redondantes.
Résultat obligatoire

Une seule action doit dominer l’écran.

MINI-CHANTIER 5 — DECISIONS
Question unique de la page

Quelle décision dois-je prendre et quelle en est la conséquence ?

À conserver
recommandation NOVA ;
options ;
confiance ;
échéance ;
impacts ;
workflow Review → Decide.
À faire

La carte principale doit contenir :

décision ;
recommandation ;
conséquence en cas d’approbation ;
conséquence en cas de rejet ;
confiance ;
un seul bouton “Review and decide” ;
un lien “Why?”.
À réduire

Les détails suivants ne doivent pas apparaître tous simultanément :

evidence ;
alternatives ;
risk ;
business impact ;
financial impact ;
reasoning ;
expert review ;
full package.

Ils doivent être regroupés dans le drawer ou le package de décision.

Workflow obligatoire

Conserver exactement :

Review ;
Decide.

L’utilisateur doit relire les éléments critiques avant de pouvoir enregistrer sa décision.

Résultat obligatoire

La décision doit sembler importante, claire, traçable et irréversible sans paraître complexe.

MINI-CHANTIER 6 — DELIVERABLES
Question unique de la page

Ce livrable est-il prêt à être utilisé ou publié ?

À conserver
statut ;
readiness ;
confiance ;
blocages ;
détail ;
version history.
À faire

Chaque carte doit afficher uniquement :

nom du livrable ;
niveau de préparation ;
blocage principal ;
prochaine action ;
bouton Details.
Exemple attendu

Board Presentation
64% ready
Blocked by 3 unresolved comments
Resolve comments to reach publication readiness

Dans le drawer

Conserver :

evidence coverage ;
completeness ;
generated by ;
reviewed by ;
validated by ;
missing information ;
version history.
Résultat obligatoire

La liste reste légère.

Le drawer porte la complexité.

MINI-CHANTIER 7 — SOURCES
Question unique de la page

Quelles sources sont fiables, manquantes ou périmées ?

À conserver
cartes sources ;
statut ;
commentaire NOVA ;
détail ;
drawer source.
À faire

Réduire l’importance visuelle des compteurs globaux.

Afficher en priorité :

sources fiables ;
sources périmées ;
sources manquantes ;
sources en conflit.

Chaque source doit présenter uniquement :

nom ;
statut ;
fraîcheur ;
usage ;
commentaire NOVA ;
action si nécessaire.
Dans le drawer

Conserver :

qualité ;
fiabilité ;
evidence score ;
historique ;
livrables concernés ;
décisions impactées ;
commentaire complet.
Résultat obligatoire

L’utilisateur doit comprendre immédiatement quelle source demande une action.

MINI-CHANTIER 8 — PEOPLE & EXPERTS
Question unique de la page

Qui peut débloquer le travail maintenant ?

À conserver
personnes ;
NOVA ;
disponibilité ;
charge ;
confiance ;
drawer détail.
À faire

Réduire l’apparence CRM.

Afficher en priorité :

rôle ;
disponibilité ;
blocage ou contribution actuelle ;
demande en attente ;
temps de réponse estimé.
Pour NOVA

Conserver un seul message visible :

Current reasoning

Le reste doit être dans le drawer.

Exemple attendu

Sarah Chen
Available now
2 pending requests
Can unblock financial review

Résultat obligatoire

La page doit expliquer qui est utile maintenant, pas seulement qui appartient au projet.

MINI-CHANTIER 9 — ACTIVITY
Question unique de la page

Qu’est-ce qui a changé et pourquoi est-ce important ?

À conserver
timeline ;
événements humains ;
événements NOVA ;
filtres ;
confiance.
À faire

Transformer les événements en récit d’évolution.

Chaque événement NOVA doit afficher :

ce qui a changé ;
pourquoi ;
impact ;
évolution de confiance si pertinente.
Exemple attendu

NOVA detected a missing CRM source
Revenue section confidence decreased from 82% to 76%

À réduire
supprimer les formulations génériques ;
éviter les cartes trop détaillées ;
ne pas afficher toutes les métadonnées simultanément.
Résultat obligatoire

La timeline doit raconter la progression du travail, pas seulement enregistrer des actions.

MINI-CHANTIER 10 — PLAN
Question unique de la page

Quelle étape est en cours et qu’est-ce qui peut empêcher la suite ?

À conserver
phases ;
statut ;
tâches ;
probabilités ;
blocages ;
temps restant.
À faire

Pour chaque phase, afficher uniquement :

résultat attendu ;
statut ;
reste à faire ;
blocage principal ;
probabilité d’achèvement.
À réduire
contribution humaine et IA détaillée en vue principale ;
métriques secondaires ;
répétitions de statut.

Ces informations doivent être accessibles dans le détail.

Résultat obligatoire

L’utilisateur doit comprendre le chemin critique sans lire toute la phase.

MINI-CHANTIER 11 — DRAWERS
Objectif

Transformer les drawers en espaces d’explication, pas en fiches administratives.

Structure obligatoire

Chaque drawer doit suivre cet ordre :

Summary ;
Why it matters ;
What is blocking ;
Key evidence ;
History ;
Technical details.
À éviter
listes brutes de métriques ;
tableaux sans hiérarchie ;
répétition des informations déjà visibles ;
jargon technique en premier niveau.
Résultat obligatoire

Le drawer doit raconter une histoire utile.

MINI-CHANTIER 12 — SYSTÈME DE CONFIANCE
Règle

Ne jamais afficher un pourcentage seul.

Chaque score doit toujours pouvoir être expliqué par “Why?”.

Vue principale

Afficher seulement :

76% confidence

Dans le détail

Afficher :

principaux facteurs positifs ;
principaux facteurs négatifs ;
élément manquant ;
amélioration attendue après action.
Exemple

76% confidence
Reduced by missing CRM source
Expected after resolution: 92%

Résultat obligatoire

La confiance doit être compréhensible et actionnable.

CONTRAINTES FINALES

Il est interdit de :

créer de nouvelles pages ;
ajouter de nouveaux modules ;
ajouter des graphiques ;
ajouter des KPI ;
ajouter des agents ;
ajouter un cockpit exécutif ;
ajouter un journal IA ;
ajouter une simulation ;
ajouter une nouvelle navigation ;
ajouter de nouveaux concepts produit ;
transformer la V6 en V7 fonctionnelle.

Cette mission est uniquement une mission de raffinement, hiérarchisation et réduction du bruit visuel.

LIVRABLES OBLIGATOIRES

Produire uniquement les écrans V6.1 suivants :

Home ;
Work Overview ;
Work Plan ;
Work Activity ;
Work People ;
People drawer ;
Work Sources ;
Source drawer ;
Work Decisions ;
Decision review ;
Decision record ;
Work Deliverables ;
Deliverable drawer.

Ne pas produire de variantes décoratives.

Ne pas produire de nouveaux écrans hors liste.

CRITÈRES D’ACCEPTATION OBLIGATOIRES

La mission est validée uniquement si :

chaque écran possède un seul point focal ;
aucune carte principale ne contient plus de deux badges ;
une seule action prioritaire est visible ;
les détails sont déplacés dans les drawers ;
la vue principale est compréhensible en moins de 10 secondes ;
la V6.1 contient moins de bruit visible que la V6 ;
aucune fonctionnalité V6 n’est perdue ;
aucun nouveau module n’est ajouté ;
le Design System existant est conservé ;
NOVA paraît plus intelligent parce qu’il montre moins, mais explique mieux ;
le résultat final reste immédiatement reconnaissable comme une évolution directe de la V6.