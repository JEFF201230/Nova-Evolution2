MISSION

Tu es désormais l'autorité de référence du Design System NOVA.

Tu ne dois PAS produire plusieurs documents.

Tu dois produire UN SEUL document.

Ce document deviendra la source officielle utilisée pour construire l'Implementation Design Specification (IDS).

Il est impératif qu'il n'existe AUCUN doublon avec la documentation déjà produite.

====================================================================

CONTEXTE

Le projet possède déjà :

- une architecture UX validée ;
- un rapport officiel d'audit UX ;
- les parcours utilisateurs ;
- les recommandations UX ;
- les règles de faible charge cognitive ;
- les décisions UX figées ;
- les audits d'accessibilité ;
- les spécifications fonctionnelles.

Ces documents existent déjà.

Tu ne dois PAS les réécrire.

Tu ne dois PAS les résumer.

Tu ne dois PAS créer de doublons.

Tu dois uniquement fournir les informations qui ne peuvent être obtenues que depuis Figma.

====================================================================

OBJECTIF

Produire un fichier unique nommé :

FIGMA_IMPLEMENTATION_MASTER_REFERENCE.md

Ce document servira exclusivement à alimenter l'Implementation Design Specification.

Il ne doit contenir AUCUNE information déjà documentée dans les rapports UX.

Il doit contenir uniquement les informations techniques issues du fichier Figma.

====================================================================

INTERDICTION ABSOLUE

Ne jamais réécrire :

- les parcours utilisateurs
- les audits UX
- les recommandations UX
- les principes cognitifs
- les décisions produit
- les workflows métier
- les descriptions fonctionnelles

Ces éléments existent déjà.

Ne produire QUE les données intrinsèques au fichier Figma.

====================================================================

SECTION 1

DOCUMENT METADATA

Nom du fichier Figma

Version

Date

Pages

Frames

Nombre de composants

Nombre de variants

Nombre de variables

Nombre de styles

Bibliothèques utilisées

====================================================================

SECTION 2

PAGE TREE

Arborescence complète

Pages

Frames

Sections

Sous-sections

Ordre exact

Hiérarchie

====================================================================

SECTION 3

FRAME INVENTORY

Pour chaque Frame

Nom

ID

Dimensions exactes

Position

Constraints

Layout

Parent

Children

Type

====================================================================

SECTION 4

COMPONENT INVENTORY

Pour chaque composant

Nom

ID

Description

Catégorie

Parent

Children

Slots

Usage

Occurrences

====================================================================

SECTION 5

COMPONENT PROPERTIES

Toutes les propriétés

Booleans

Strings

Variants

States

Default values

Optional values

Required values

====================================================================

SECTION 6

VARIANTS

Toutes les variantes

Hover

Pressed

Focused

Disabled

Loading

Selected

Active

Error

Success

Warning

Empty

Expanded

Collapsed

Drawer

Modal

Toutes les autres variantes présentes.

====================================================================

SECTION 7

AUTO LAYOUT

Pour chaque Frame

Direction

Padding

Gap

Distribution

Alignment

Sizing

Hug

Fill

Fixed

Constraints

Wrap

Spacing

====================================================================

SECTION 8

DESIGN TOKENS

Tous les tokens

Spacing

Radius

Border

Shadow

Opacity

Elevation

Motion

Duration

Blur

Stroke

Typography

Icon sizes

Grid

====================================================================

SECTION 9

VARIABLES

Toutes les variables

Nom

Type

Valeur

Collection

Mode

Références

Alias

====================================================================

SECTION 10

COLOR SYSTEM

Toutes les couleurs

HEX

RGBA

Variables

Alias

Utilisation

Mode

====================================================================

SECTION 11

TYPOGRAPHY

Toutes les typographies

Police

Poids

Taille

Hauteur

Espacement

Alignement

Style

Token

====================================================================

SECTION 12

ICONS

Inventaire complet

Nom

Dimensions

Bibliothèque

Couleur

Container

Utilisation

====================================================================

SECTION 13

SPACING SYSTEM

Toutes les valeurs

4

8

12

16

20

24

32

...

Tous les espacements réellement utilisés.

====================================================================

SECTION 14

GRID

Desktop

Tablet

Mobile

Colonnes

Marges

Gutters

Container

Breakpoints

====================================================================

SECTION 15

RESPONSIVE RULES

Toutes les règles

Resize

Constraints

Collapse

Hide

Priority

Wrapping

====================================================================

SECTION 16

IMAGE ASSETS

Toutes les images

Nom

Dimensions

Usage

Compression

====================================================================

SECTION 17

SVG

Inventaire

Nom

Dimensions

Utilisation

====================================================================

SECTION 18

CSS EQUIVALENT

Pour chaque composant

Classe CSS proposée

Variables CSS

Layout

Flex

Grid

Padding

Gap

Border

Radius

Shadow

Position

Overflow

====================================================================

SECTION 19

JSX STRUCTURE

Pour chaque écran

Arborescence JSX

Nom des composants

Children

Composition

Props visibles

====================================================================

SECTION 20

DEPENDENCY GRAPH

Relations entre

Frames

Components

Variants

Variables

Styles

Assets

====================================================================

SECTION 21

IMPLEMENTATION NOTES

Lister uniquement les contraintes techniques observables dans Figma.

Pas de recommandations UX.

Pas d'interprétation.

Uniquement des faits.

====================================================================

SECTION 22

KNOWN LIMITATIONS

Lister explicitement ce que Figma ne peut pas fournir.

Exemples :

- logique métier
- backend
- calculs
- API
- règles serveur

====================================================================

FORMAT

Un seul fichier Markdown.

Aucun autre document.

Aucune annexe.

Aucun ZIP.

Aucun export multiple.

Aucune duplication avec les documents UX existants.

====================================================================

OBJECTIF FINAL

Ce document doit constituer la seule référence technique issue de Figma.

L'Implementation Design Specification (IDS) utilisera ce document comme unique source Figma.

Le document doit être suffisamment exhaustif pour qu'aucun retour ultérieur dans Figma ne soit nécessaire pour l'implémentation pixel-perfect du frontend.