# 08 — LAYOUT SYSTEM
## NOVA V6.1 — Grid, Spacing, Containers

---

## ROOT LAYOUT

```
App root (position: fixed, inset: 0, display: flex, flex-direction: row)
├── NavRail: 56px wide, 100% height, flex-shrink: 0
└── Main area: flex: 1, min-width: 0, display: flex, flex-direction: column, overflow: hidden
    └── Screen: flex: 1, overflow-y: auto
```

**Viewport assumption:** Desktop browser, minimum width ~900px. No responsive breakpoints — fixed-width desktop layout only.

---

## SPACING SCALE

Base unit: 4px. All spacing values are multiples.

| Token | Value | Usage |
|---|---|---|
| sp-1 | 4px | Icon-to-text gap, dense metadata |
| sp-2 | 8px | Default gap in flex rows, small padding |
| sp-3 | 12px | Medium gap, compact list spacing |
| sp-4 | 16px | Card padding (compact), section gap |
| sp-5 | 20px | Drawer padding, card gap |
| sp-6 | 24px | Standard page section spacing |
| sp-7 | 28px | Page outer padding top |
| sp-8 | 32px | Page outer padding left/right |
| sp-10 | 40px | Large section spacing |
| sp-12 | 48px | Centered view vertical padding (clarify, confirm, pause) |
| sp-16 | 64px | — |
| sp-24 | 96px | — |

---

## PAGE CONTAINERS

### Full-width pages (home, work, decisions list, deliverables list)
```css
padding: 28px 32px;
/* No max-width — fills available space after nav rail */
```

### Centered narrow pages (clarify, confirm, decision-pause, decision-receipt)
```css
max-width: 560px;
margin: 0 auto;
padding: 48px 24px;
```

### Medium centered (canvas, plan)
```css
/* No explicit max-width — content fills column */
padding: 28px 32px;
```

### Decision package
```css
max-width: 800px;
margin: 0 auto;
padding: 28px 32px;
```

---

## GRID LAYOUTS

### Work Overview — 2-column grid
```css
display: grid;
grid-template-columns: 2fr 1fr;
gap: 20px;
align-items: start;
```
- Left column: main content (hero + focal card + disclosure + decisions)
- Right column: sidebar (progress + analysis link)

### Canvas Cards — 3-column grid
```css
display: grid;
grid-template-columns: repeat(3, 1fr);
gap: 16px;
margin-bottom: 24px;
```

### Decision Option Impact — 2-column grid (inside option button)
```css
display: grid;
grid-template-columns: 1fr 1fr;
gap: 8px;
margin-top: 8px;
```
Labels: "If approved" / "If rejected"

### Decision Pause Consequences — 2-column grid
```css
display: grid;
grid-template-columns: 1fr 1fr;
gap: 12px;
margin-bottom: 20px;
```

### Decision Receipt Consequences — 2-column grid (same structure)

### People AI/Human Contributions (expanded phase) — 2-column grid
```css
display: grid;
grid-template-columns: 1fr 1fr;
gap: 12px;
margin-top: 12px;
```

### Confirm Autonomy Levels — Horizontal row
```css
display: flex;
gap: 8px;
/* 4 buttons equal width each: flex: 1 */
```

### Source counter strip — Inline flex
```css
display: flex;
gap: 12px;
align-items: center;
padding: 10px 0;
border-bottom: 1px solid N.border;
margin-bottom: 12px;
font-size: 12px;
color: N.textSec;
```
Separator dots: `·` character in N.textDis

---

## NAV RAIL LAYOUT

```css
width: 56px;
height: 100%;
display: flex;
flex-direction: column;
padding: 12px 0;
overflow: hidden;
```

Logo block:
```css
display: flex;
justify-content: center;
padding: 8px 0 12px;
```

Logo circle:
```css
width: 32px; height: 32px;
border-radius: 9px;
background: linear-gradient(135deg, #1D4ED8, #6D28D9);
display: flex; align-items: center; justify-content: center;
```

Nav group:
```css
display: flex;
flex-direction: column;
gap: 2px;
padding: 0 8px;
```

NavItem:
```css
width: 100%;
display: flex;
flex-direction: column;
align-items: center;
gap: 3px;
padding: 7px 4px;
border-radius: 8px;
border-left: 2px solid transparent; /* → N.action when active */
```

Bottom section:
```css
margin-top: auto;
display: flex;
flex-direction: column;
gap: 2px;
padding: 0 8px;
```

User profile row:
```css
display: flex;
flex-direction: column;
align-items: center;
gap: 3px;
padding: 8px 4px;
border-radius: 8px;
margin-top: 4px;
border-top: 1px solid N.border;
```

---

## CARD LAYOUTS

### Standard Card
```css
background: N.surface;
border: 1px solid N.border;
border-radius: 12px;
box-shadow: SH.card;
padding: 16px;
```

### Hero Card (Home situation block)
```css
background: linear-gradient(135deg, #EFF6FF, #F5F3FF);
border: 1px solid N.innoBrd;
border-radius: 16px;
box-shadow: SH.hero;
padding: 22px 24px;
```

### Next Best Action Focal Card
```css
border: 2px solid N.action;
box-shadow: 0 0 0 4px rgba(29,78,216,.06), /* ring */ SH.card;
border-radius: 14px;
padding: 22px 26px;
background: N.surface;
```

### NOVA Box (inside cards / events)
```css
background: N.innoBg;
border: 1px solid N.innoBrd;
border-radius: 8px;
padding: 10px 12px;
margin-top: 8px;
```

### Work Overview Situation Card (inside work)
```css
background: linear-gradient(135deg, #EFF6FF, #F5F3FF);
border: 1px solid N.innoBrd;
border-radius: 14px;
padding: 20px;
```

### Decision Package Hero Block
```css
background: linear-gradient(135deg, #FEF2F2, #FFF7F0);
border: 1px solid #FECACA;
border-radius: 14px;
padding: 22px 24px;
margin-bottom: 20px;
```

### Autonomy Button (selected)
```css
border: 2px solid N.action;
background: N.actionBg;
border-radius: 10px;
padding: 14px 16px;
flex: 1;
cursor: pointer;
text-align: left;
```

---

## WORK SCREEN LAYOUT

### Breadcrumb
```css
position: sticky;
top: 0;
z-index: 10;
background: N.surface;
border-bottom: 1px solid N.border;
height: 42px;
display: flex;
align-items: center;
padding: 0 24px;
gap: 6px;
```

### Work Header
```css
padding: 20px 24px 0;
border-bottom: 1px solid N.border;
```

Header top row:
```css
display: flex;
justify-content: space-between;
align-items: flex-start;
margin-bottom: 14px;
```

Progress bar container:
```css
height: 3px;
background: N.border;
border-radius: 999px;
margin-bottom: 12px;
```

Phase meta row:
```css
display: flex;
align-items: center;
gap: 12px;
padding-bottom: 14px;
font-size: 11px;
color: N.textSec;
```

### Tab Strip
```css
display: flex;
background: N.surface;
border-bottom: 1px solid N.border;
padding: 0 24px;
```

Tab button:
```css
padding: 10px 16px;
border: none;
background: none;
border-bottom: 2px solid transparent; /* → N.action when active */
cursor: pointer;
white-space: nowrap;
```

### Tab Content Areas

All tab content areas:
```css
padding: 20px 24px;
flex: 1;
overflow-y: auto;
```

Exception — WorkOverviewTab:
```css
/* Uses 2-col grid, defined above */
padding: 20px 24px;
display: grid;
grid-template-columns: 2fr 1fr;
gap: 20px;
align-items: start;
```

---

## DRAWER LAYOUT

```css
/* Backdrop */
position: fixed;
inset: 0;
z-index: 50;
background: rgba(15,23,42,.20);
backdrop-filter: blur(2px);

/* Panel */
position: fixed;
top: 0; right: 0;
width: 460px;
height: 100%;
background: N.surface;
box-shadow: SH.overlay;
display: flex;
flex-direction: column;
z-index: 51;
```

Header:
```css
padding: 18px 20px;
border-bottom: 1px solid N.border;
display: flex;
justify-content: space-between;
align-items: center;
flex-shrink: 0;
```

Body:
```css
flex: 1;
overflow-y: auto;
padding: 20px;
```

DrawerSection spacing:
```css
margin-bottom: 24px;
```

---

## SEARCH OVERLAY LAYOUT

Backdrop:
```css
position: fixed;
inset: 0;
z-index: 100;
background: rgba(15,23,42,.35);
backdrop-filter: blur(2px);
display: flex;
align-items: flex-start;
justify-content: center;
padding-top: 120px;
```

Panel:
```css
width: 560px;
background: N.surface;
border-radius: 16px;
box-shadow: SH.overlay;
overflow: hidden;
```

Input row:
```css
display: flex;
align-items: center;
gap: 12px;
padding: 14px 16px;
```

Results:
```css
max-height: 320px;
overflow-y: auto;
```

Result item:
```css
width: 100%;
display: flex;
align-items: center;
gap: 12px;
padding: 12px 16px;
border: none;
background: transparent;
cursor: pointer;
text-align: left;
```

---

## CLARIFY LAYOUT

```css
max-width: 640px;
margin: 0 auto;
padding: 48px 24px;
```

Progress indicator:
```css
display: flex;
gap: 4px;
margin-bottom: 32px;
/* Each dot: width 6px, height 6px, border-radius 50% */
/* Active dot: width 20px, border-radius 999px, background N.action */
/* Inactive dot: background N.border */
```

Suggestions:
```css
display: flex;
flex-direction: column;
gap: 8px;
margin-bottom: 16px;
```

Suggestion button:
```css
text-align: left;
padding: 12px 16px;
border-radius: 10px;
border: 1.5px solid N.border; /* → N.action when selected */
background: N.surface; /* → N.actionBg when selected */
cursor: pointer;
```

OR divider:
```css
display: flex;
align-items: center;
gap: 12px;
margin: 16px 0;
/* Lines: flex: 1, height: 1px, background: N.border */
/* Text: 11px N.textDis */
```

Action row:
```css
display: flex;
justify-content: flex-end;
gap: 8px;
margin-top: 24px;
```

---

## ACTIVITY LAYOUT

Filter row:
```css
display: flex;
gap: 6px;
margin-bottom: 16px;
flex-wrap: wrap;
```

Filter pill:
```css
padding: 4px 12px;
border-radius: 999px;
font-size: 11px;
font-weight: 500;
border: 1px solid N.border;
background: transparent; /* → N.text when selected */
color: N.textSec; /* → #FFFFFF when selected */
cursor: pointer;
```

Event card:
```css
background: N.surface;
border: 1px solid N.border;
border-radius: 10px;
padding: 14px;
```

Event header:
```css
display: flex;
justify-content: space-between;
align-items: flex-start;
margin-bottom: 8px;
```

NOVA box in event:
```css
background: N.innoBg;
border: 1px solid N.innoBrd;
border-radius: 8px;
padding: 10px 12px;
margin-top: 8px;
```

---

## PEOPLE TAB LAYOUT

Person card:
```css
background: N.surface;
border: 1px solid N.border;
border-radius: 10px;
padding: 14px 16px;
display: flex;
align-items: flex-start;
gap: 12px;
```

Avatar circle:
```css
width: 38px; height: 38px;
border-radius: 50%;
flex-shrink: 0;
display: flex; align-items: center; justify-content: center;
```
Human avatar bg: N.subtle + N.textSec icon
AI avatar bg: N.innoBg + N.inno icon (Sparkles)

Card body:
```css
flex: 1;
min-width: 0;
```

Card footer:
```css
display: flex;
align-items: center;
justify-content: space-between;
margin-top: 8px;
```

---

## PHASE LAYOUT (Plan + Work Plan tab)

Phase row:
```css
border: 1px solid N.border;
border-radius: 10px;
overflow: hidden;
background: N.surface;
```

Phase icon container:
```css
width: 28px; height: 28px;
border-radius: 8px;
display: flex; align-items: center; justify-content: center;
```

Phase toggle button:
```css
width: 100%;
display: flex;
align-items: center;
gap: 12px;
padding: 14px 16px;
background: none;
border: none;
cursor: pointer;
text-align: left;
```

Phase expanded area:
```css
padding: 0 16px 14px;
border-top: 1px solid N.border;
```

---

## DECISION PACKAGE LAYOUT

Options section:
```css
margin-bottom: 24px;
display: flex;
flex-direction: column;
gap: 10px;
```

Option button:
```css
width: 100%;
text-align: left;
padding: 16px;
border-radius: 10px;
border: 1.5px solid N.border; /* → N.action when selected */
background: N.surface; /* → N.actionBg when selected */
cursor: pointer;
```

Radio circle:
```css
width: 16px; height: 16px;
border-radius: 50%;
border: 2px solid N.borderMd; /* → N.action when selected */
/* If selected: filled with Check icon */
```

Dissent block:
```css
background: N.warnBg;
border: 1px solid #FDE68A;
border-radius: 8px;
padding: 12px 14px;
margin-bottom: 20px;
```

---

## DECISION PAUSE LAYOUT

Checkpoint card:
```css
background: N.surface;
border: 1px solid N.border;
border-radius: 12px;
padding: 20px;
margin-bottom: 20px;
box-shadow: SH.card;
```

Steps indicator:
```css
display: flex;
align-items: center;
gap: 8px;
margin-bottom: 28px;
```

Step circle:
```css
width: 24px; height: 24px;
border-radius: 50%;
/* active: N.action bg, white text */
/* complete: success bg, success icon */
/* future: N.border bg, N.textDis text */
```

Checklist item:
```css
display: flex;
align-items: flex-start;
gap: 10px;
padding: 10px 0;
border-bottom: 1px solid N.border;
font-size: 13px;
color: N.text;
```

Checkbox:
```css
width: 16px; height: 16px;
border-radius: 4px;
border: 1.5px solid N.borderMd;
background: N.surface;
flex-shrink: 0;
margin-top: 1px;
```

---

## DECISION RECEIPT LAYOUT

Success icon header:
```css
display: flex;
flex-direction: column;
align-items: center;
margin-bottom: 28px;
```

Icon circle:
```css
width: 64px; height: 64px;
background: N.successBg;
border-radius: 50%;
display: flex; align-items: center; justify-content: center;
margin-bottom: 12px;
```

Receipt card:
```css
background: N.surface;
border: 1px solid N.border;
border-radius: 12px;
padding: 20px;
margin-bottom: 20px;
box-shadow: SH.card;
```

Action buttons:
```css
display: flex;
gap: 10px;
margin-top: 28px;
```
