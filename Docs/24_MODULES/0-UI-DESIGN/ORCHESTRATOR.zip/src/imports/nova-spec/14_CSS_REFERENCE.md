# 14 — CSS REFERENCE
## NOVA V6.1 — All Style Declarations

---

## IMPLEMENTATION NOTE

NOVA V6.1 uses **inline styles exclusively** via React's `style` prop. No CSS classes, no Tailwind utilities in JSX, no external stylesheets beyond fonts. All style values are JS objects.

The only CSS present in the project is:
- `src/styles/fonts.css` — Google Fonts import
- `src/styles/theme.css` — Tailwind design tokens (used by Tailwind infrastructure, NOT by NOVA components)
- `src/styles/index.css` — Tailwind base layer (reset + theme mapping)

---

## GLOBAL CSS (index.css pattern)

```css
/* Tailwind base reset is included — do not add additional resets */
/* Custom scrollbar styles (for drawer and search) */
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: #94A3B8; }

/* Spin animation for loading spinner */
@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
```

---

## TRANSITION SYSTEM

```typescript
const ease = "cubic-bezier(.2,0,0,1)";
const T = {
  fast: `all 120ms ${ease}`,   // hover states, quick toggles
  std:  `all 200ms ${ease}`,   // standard interactions, accordion
};
```

**Usage rule:**
- T.fast: button hover, card hover, nav item hover, suggestion pill hover
- T.std: accordion toggle (ChevronDown rotate), autonomy selection

---

## ROOT LAYOUT STYLES

```javascript
// App container
{
  display: "flex",
  height: "100vh",
  width: "100vw",
  background: N.canvas,
  fontFamily: FONT,
  overflow: "hidden",
}

// Main area
{
  flex: 1,
  minWidth: 0,
  display: "flex",
  flexDirection: "column",
  overflow: "hidden",
}
```

---

## NAV RAIL STYLES

```javascript
// Container
{
  width: 56, flexShrink: 0,
  height: "100%",
  background: N.surface,
  borderRight: `1px solid ${N.border}`,
  display: "flex", flexDirection: "column",
  padding: "12px 0",
  overflow: "hidden",
}

// Logo block
{
  display: "flex", justifyContent: "center",
  padding: "8px 0 12px",
}

// Logo circle
{
  width: 32, height: 32, borderRadius: 9,
  background: "linear-gradient(135deg, #1D4ED8, #6D28D9)",
  display: "flex", alignItems: "center", justifyContent: "center",
}

// Nav group
{ display: "flex", flexDirection: "column", gap: 2, padding: "0 8px" }

// NavItem (base)
{
  width: "100%", display: "flex", flexDirection: "column",
  alignItems: "center", gap: 3, padding: "7px 4px",
  borderRadius: 8, cursor: "pointer", transition: T.fast,
  borderLeft: "2px solid transparent",
  background: "transparent", color: N.textSec,
  border: "none",
}

// NavItem (active override)
{
  borderLeft: `2px solid ${N.action}`,
  background: N.actionBg, color: N.action,
}

// NavItem label
{ fontSize: 9, fontWeight: 600, letterSpacing: "0.02em", fontFamily: FONT }

// User profile row
{
  display: "flex", flexDirection: "column",
  alignItems: "center", gap: 3,
  padding: "8px 4px", borderRadius: 8,
  cursor: "pointer", transition: T.fast,
  marginTop: 4, borderTop: `1px solid ${N.border}`,
}

// User avatar circle
{
  width: 28, height: 28, borderRadius: "50%",
  background: "linear-gradient(135deg, #2563EB, #7C3AED)",
  display: "flex", alignItems: "center", justifyContent: "center",
}
```

---

## CARD STYLES

```javascript
// Base Card
{
  background: N.surface,
  border: `1px solid ${N.border}`,
  borderRadius: 12,
  boxShadow: SH.card,
  padding: 16,
  cursor: onClick ? "pointer" : "default",
  transition: T.fast,
}

// Card hover (applied inline on mouseEnter/Leave)
{ borderColor: N.borderMd, boxShadow: SH.cardHv }

// Hero gradient card
{
  background: "linear-gradient(135deg, #EFF6FF 0%, #F5F3FF 100%)",
  border: `1px solid ${N.innoBrd}`,
  borderRadius: 16,
  boxShadow: SH.hero,
  padding: "22px 24px",
}

// Next Best Action focal card
{
  border: `2px solid ${N.action}`,
  boxShadow: `0 0 0 4px rgba(29,78,216,.06), ${SH.card}`,
  borderRadius: 14,
  padding: "22px 26px",
  background: N.surface,
}

// NOVA box (inside cards)
{
  background: N.innoBg,
  border: `1px solid ${N.innoBrd}`,
  borderRadius: 8,
  padding: "10px 12px",
  marginTop: 8,
}

// Decision package hero
{
  background: "linear-gradient(135deg, #FEF2F2, #FFF7F0)",
  border: "1px solid #FECACA",
  borderRadius: 14,
  padding: "22px 24px",
  marginBottom: 20,
}
```

---

## BUTTON STYLES

```javascript
// Primary button (base)
{
  background: N.action, color: "#fff",
  border: "none", borderRadius: 8,
  padding: size === "sm" ? "6px 14px" : "9px 20px",
  fontSize: size === "sm" ? 12 : 13,
  fontWeight: 600, cursor: "pointer",
  display: "inline-flex", alignItems: "center", gap: 6,
  transition: T.fast, fontFamily: FONT,
  opacity: disabled ? 0.4 : 1,
}

// Primary hover
{
  background: N.actionHv,
  boxShadow: "0 2px 8px rgba(29,78,216,.24)",
  transform: "translateY(-1px)",
}

// Secondary button (base)
{
  background: N.surface, color: N.text,
  border: `1px solid ${N.borderMd}`,
  boxShadow: SH.card, borderRadius: 8,
  padding: same as primary,
  fontWeight: 600, cursor: "pointer",
  transition: T.fast,
}

// Secondary hover
{ background: N.subtle, borderColor: N.borderSt }

// Quiet button (base)
{
  background: "transparent", color: N.textSec,
  border: "none", borderRadius: 6,
  padding: size === "sm" ? "4px 10px" : "6px 14px",
  fontSize: 12, cursor: "pointer",
  transition: T.fast,
}

// Quiet hover
{ background: N.subtle, color: N.text }
```

---

## BADGE / CHIP STYLES

```javascript
// NOVALabel sm
{
  display: "inline-flex", alignItems: "center", gap: 4,
  background: N.innoBg, color: N.inno,
  border: `1px solid ${N.innoBrd}`,
  borderRadius: 999, padding: "2px 8px",
  fontSize: 10, fontWeight: 700,
  letterSpacing: "0.04em", fontFamily: FONT,
}

// NOVALabel xs
{ ...sm, gap: 3, padding: "1px 6px", fontSize: 9 }

// DeadlineBadge
{
  display: "inline-flex", alignItems: "center", gap: 3,
  background: bg, color: color,
  border: `1px solid ${brd}`,
  borderRadius: 999, padding: "2px 8px",
  fontSize: 11, fontWeight: 600,
}

// ConfChip trigger
{
  display: "inline-flex", alignItems: "center", gap: 4,
  background: confColor(pct).bg, color: confColor(pct).color,
  borderRadius: 999, padding: "2px 8px",
  fontSize: 11, fontWeight: 600,
  cursor: "pointer", border: "none",
  fontFamily: FONT,
}

// Source status badge (inline)
{
  fontSize: 10, fontWeight: 600,
  padding: "2px 7px", borderRadius: 999,
  border: `1px solid ${brd}`,
  background: bg, color: color,
}

// Activity event type dot
{
  width: 6, height: 6, borderRadius: "50%",
  background: typeColor, flexShrink: 0, marginTop: 4,
}

// Phase probability badge
{
  fontSize: 10, fontWeight: 700,
  fontFamily: MONO, letterSpacing: "0.02em",
  color: confColor(prob).color,
}

// Autonomy badge (inside autonomy button, selected)
{
  fontSize: 10, fontWeight: 700,
  fontFamily: MONO, letterSpacing: "0.02em",
  color: N.action, background: "rgba(29,78,216,.12)",
  borderRadius: 4, padding: "1px 5px",
}
```

---

## INPUT / TEXTAREA STYLES

```javascript
// Composer textarea
{
  width: "100%",
  border: "none", outline: "none",
  resize: "none",
  background: "transparent",
  fontSize: 14, color: N.text, fontFamily: FONT,
  lineHeight: 1.6,
}

// Clarify textarea
{
  width: "100%",
  border: `1.5px solid ${borderColor}`,
  borderRadius: 10,
  padding: "12px 14px",
  fontSize: 14, color: N.text, fontFamily: FONT,
  lineHeight: 1.6,
  outline: "none", resize: "none",
  background: N.surface,
}

// Activity comment textarea
{
  width: "100%",
  border: `1px solid ${comment ? N.action : N.border}`,
  borderRadius: 8,
  padding: "10px 12px",
  fontSize: 13, fontFamily: FONT, color: N.text,
  resize: "none", outline: "none",
}

// Decision rationale textarea (pause step 2)
{
  width: "100%",
  border: `1px solid ${rationale ? N.action : N.border}`,
  borderRadius: 8, padding: "10px 12px",
  fontSize: 13, fontFamily: FONT, color: N.text,
  resize: "none", outline: "none",
}

// Search overlay input
{
  flex: 1, border: "none", outline: "none",
  fontSize: 15, fontFamily: FONT, color: N.text,
  background: "transparent",
}
```

---

## PROGRESS BAR STYLES

```javascript
// Bar track
{
  flex: 1, height: 3,
  background: N.border,
  borderRadius: 999,
  overflow: "hidden",
}

// Bar fill
{
  width: `${score}%`,
  height: "100%",
  background: confColor(score).color,
  borderRadius: 999,
}

// Work header progress bar
{
  height: 3,
  background: N.border,
  borderRadius: 999,
  marginBottom: 12,
  overflow: "hidden",
}

// Work header progress fill
{
  width: `${item.progress}%`,
  height: "100%",
  background: progressColor, // based on health
  borderRadius: 999,
}

// Deliverable readiness bar track
{
  flex: 1, height: 6,
  background: N.border, borderRadius: 999,
  overflow: "hidden",
}

// Deliverable readiness bar fill
{
  width: `${deliverable.readiness}%`,
  height: "100%",
  background: confColor(deliverable.readiness).color,
  borderRadius: 999,
}
```

---

## OVERLAY STYLES

```javascript
// Drawer backdrop
{
  position: "fixed", inset: 0, zIndex: 50,
  background: "rgba(15,23,42,.20)",
  backdropFilter: "blur(2px)",
}

// Drawer panel
{
  position: "fixed", top: 0, right: 0, zIndex: 51,
  width: 460, height: "100%",
  background: N.surface,
  boxShadow: SH.overlay,
  display: "flex", flexDirection: "column",
}

// Search backdrop
{
  position: "fixed", inset: 0, zIndex: 100,
  background: "rgba(15,23,42,.35)",
  backdropFilter: "blur(2px)",
  display: "flex", alignItems: "flex-start",
  justifyContent: "center",
  paddingTop: 120,
}

// Search panel
{
  width: 560, background: N.surface,
  borderRadius: 16, boxShadow: SH.overlay,
  overflow: "hidden",
}

// ConfChip popover
{
  position: "absolute", top: -8, left: 0,
  zIndex: 20, width: 260,
  background: N.surface,
  border: `1px solid ${N.border}`,
  borderRadius: 12, boxShadow: SH.overlay,
  padding: 14,
}
```

---

## WORK SCREEN STYLES

```javascript
// Breadcrumb
{
  position: "sticky", top: 0, zIndex: 10,
  background: N.surface,
  borderBottom: `1px solid ${N.border}`,
  padding: "0 24px",
  display: "flex", alignItems: "center",
  gap: 6, height: 42, flexShrink: 0,
}

// Work header
{
  padding: "20px 24px 0",
  borderBottom: `1px solid ${N.border}`,
  flexShrink: 0,
}

// Tab strip
{
  display: "flex",
  background: N.surface,
  borderBottom: `1px solid ${N.border}`,
  padding: "0 24px",
  flexShrink: 0,
}

// Tab button (base)
{
  padding: "10px 16px",
  border: "none", background: "none",
  borderBottom: `2px solid transparent`,
  fontSize: 13, cursor: "pointer",
  fontWeight: 400, color: N.textSec,
  transition: T.fast, fontFamily: FONT,
}

// Tab button (active override)
{
  color: N.action, fontWeight: 600,
  borderBottomColor: N.action,
}

// Tab content wrapper
{
  flex: 1, overflow: "auto",
  padding: "20px 24px",
}
```

---

## TYPOGRAPHY STYLES (pattern summary)

```javascript
// Page title / hero heading
{ fontSize: 19, fontWeight: 700, letterSpacing: "-0.022em", color: N.text, fontFamily: FONT }

// Section heading
{ fontSize: 15, fontWeight: 700, color: N.text, fontFamily: FONT }

// Card title / decision statement
{ fontSize: 15, fontWeight: 700, color: N.text, lineHeight: 1.35 }

// Primary paragraph
{ fontSize: 14, color: N.text, lineHeight: 1.65, fontFamily: FONT }

// Secondary paragraph
{ fontSize: 13, color: N.textSec, lineHeight: 1.6, fontFamily: FONT }

// Label / section header
{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: N.textDis }

// Metadata inline
{ fontSize: 11, color: N.textSec, fontFamily: FONT }

// Timestamp
{ fontSize: 11, color: N.textDis, fontFamily: FONT }

// Monospace (confidence delta, autonomy badge, phase prob)
{ fontFamily: MONO, fontSize: 11, fontWeight: 700, letterSpacing: "0.02em" }

// NOVA box primary text
{ fontSize: 13, color: N.inno, fontFamily: FONT }

// NOVA box secondary text
{ fontSize: 12, color: N.textDis, fontFamily: FONT }
```
