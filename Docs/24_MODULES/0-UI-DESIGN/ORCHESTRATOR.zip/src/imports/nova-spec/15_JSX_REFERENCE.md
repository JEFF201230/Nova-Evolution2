# 15 — JSX REFERENCE
## NOVA V6.1 — Complete JSX Patterns

---

## PRIMITIVE COMPONENT JSX

### NOVALabel
```tsx
<NOVALabel />
<NOVALabel size="xs" />
```

### ConfChip
```tsx
<ConfChip
  pct={76}
  afterAction={92}
  reasons={["3 open comments", "Missing CRM source", "Outdated roadmap deck"]}
  positive={["42 documents validated", "Team alignment confirmed"]}
  missing="CRM Pipeline Export not loaded"
/>
```

### DeadlineBadge
```tsx
<DeadlineBadge date="Jul 18" />
```

### StatusDot
```tsx
<StatusDot status="available" />
<StatusDot status="busy" />
<StatusDot status="away" />
```

### Btn
```tsx
<Btn onClick={() => setView("work")}>Open presentation</Btn>
<Btn v="secondary" size="sm" onClick={() => {}}>Cancel</Btn>
<Btn v="quiet" size="sm" icon={<ChevronRight size={12} />}>Details</Btn>
<Btn loading={loading} onClick={submit}>Start work</Btn>
<Btn disabled={!val.trim()}>Continue</Btn>
```

### Card
```tsx
<Card onClick={() => setView("decision-package")}>
  {/* content */}
</Card>
<Card style={{ padding: 20 }}>
  {/* non-clickable card with custom padding */}
</Card>
```

### WhyInline
```tsx
<WhyInline>
  The CFO must review and pre-approve the budget figures before the 18 July board meeting.
  Without his sign-off, the budget decision cannot be made.
</WhyInline>
```

### Drawer
```tsx
<Drawer open={detailOpen} onClose={() => setDetailOpen(false)} title="Situation details">
  <DrawerSection label="Summary">
    <p style={{ fontSize: 14, color: N.text, lineHeight: 1.65 }}>
      The board presentation is the highest priority item...
    </p>
  </DrawerSection>
  <DrawerSection label="Why it matters">
    <p style={{ fontSize: 13, color: N.textSec, lineHeight: 1.6 }}>
      The CFO must review and pre-approve...
    </p>
  </DrawerSection>
  <DrawerSection label="Key evidence">
    <DrawerRow label="Documents analysed" value={42} />
    <DrawerRow label="Sources validated" value="3 of 4" />
    <DrawerRow label="Confidence" value="76%" color={confColor(76).color} />
  </DrawerSection>
</Drawer>
```

### DrawerSection
```tsx
<DrawerSection label="What is blocking">
  {blockers.map((b, i) => (
    <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 8 }}>
      <AlertTriangle size={12} strokeWidth={2} color={N.crit} style={{ marginTop: 2, flexShrink: 0 }} />
      <span style={{ fontSize: 13, color: N.crit }}>{b}</span>
    </div>
  ))}
</DrawerSection>
```

### DrawerRow
```tsx
<DrawerRow label="Availability" value="Full-time on project" />
<DrawerRow label="Trust score" value="88%" color={confColor(88).color} />
<DrawerRow label="Pending comments" value={3} color={N.warn} />
```

---

## SCREEN-LEVEL JSX PATTERNS

### Home Hero Block
```tsx
<div style={{
  background: "linear-gradient(135deg, #EFF6FF 0%, #F5F3FF 100%)",
  border: `1px solid ${N.innoBrd}`,
  borderRadius: 16, boxShadow: SH.hero,
  padding: "22px 24px",
}}>
  {/* Meta row */}
  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <NOVALabel />
      <span style={{ fontSize: 11, color: N.textDis }}>Updated 4 min ago</span>
    </div>
    <button onClick={() => setDetailOpen(true)} style={{ fontSize: 12, color: N.action, background: "none", border: "none", cursor: "pointer" }}>
      Details <ChevronRight size={11} strokeWidth={2.5} style={{ verticalAlign: "middle" }} />
    </button>
  </div>

  {/* Hero sentence */}
  <p style={{ fontSize: 15, color: N.textSec, marginBottom: 6, lineHeight: 1.55 }}>
    {item.heroSentence}
  </p>

  {/* Hero gain */}
  <p style={{ fontSize: 19, fontWeight: 700, letterSpacing: "-0.022em", color: N.text, marginBottom: 16, lineHeight: 1.3 }}>
    {item.heroGain}
  </p>

  {/* CTA row */}
  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
    <Btn onClick={() => { setActiveWork(item.id); setView("work"); }}>
      Open presentation
    </Btn>
    <WhyInline>{item.nextActionWhy}</WhyInline>
  </div>
</div>
```

### Next Best Action Focal Card
```tsx
<div style={{
  border: `2px solid ${N.action}`,
  boxShadow: `0 0 0 4px rgba(29,78,216,.06), ${SH.card}`,
  borderRadius: 14, padding: "22px 26px",
  background: N.surface,
}}>
  <div style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: N.textDis, marginBottom: 6 }}>
    Next best action
  </div>
  <div style={{ fontSize: 18, fontWeight: 700, color: N.text, marginBottom: 12 }}>
    {item.nextAction}
  </div>
  <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
    <span style={{ fontSize: 12, color: N.textSec }}>
      <Clock size={11} style={{ marginRight: 3 }} />{item.nextActionTime}
    </span>
    <span style={{ fontSize: 12, color: N.success }}>{item.nextActionGain}</span>
    <span style={{ fontSize: 11, fontWeight: 700, fontFamily: MONO, color: N.action }}>
      {item.nextActionConfDelta}
    </span>
  </div>
  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
    <Btn onClick={() => {}}>Open</Btn>
    <WhyInline>{item.nextActionWhy}</WhyInline>
  </div>
</div>
```

### Activity Event
```tsx
<div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 10, padding: 14 }}>
  {/* Header */}
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
    <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
      <div style={{ width: 6, height: 6, borderRadius: "50%", background: typeColor(ev.type), flexShrink: 0, marginTop: 4 }} />
      <span style={{ fontSize: 13, fontWeight: 500, color: N.text, lineHeight: 1.45 }}>{ev.change}</span>
    </div>
    <span style={{ fontSize: 11, color: N.textDis, flexShrink: 0, marginLeft: 12 }}>{ev.timestamp}</span>
  </div>

  {/* NOVA box */}
  <div style={{ background: N.innoBg, border: `1px solid ${N.innoBrd}`, borderRadius: 8, padding: "10px 12px", marginLeft: 14 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
      <span style={{ fontSize: 12, fontWeight: 600, color: ev.confDelta < 0 ? N.crit : N.success }}>
        {ev.impact}
      </span>
      <span style={{ fontFamily: MONO, fontSize: 11, fontWeight: 700, color: ev.confDelta < 0 ? N.crit : N.success }}>
        ({ev.confFrom}% → {ev.confTo}%)
      </span>
    </div>
    <div style={{ fontSize: 12, color: N.textDis, marginBottom: ev.sources.length > 0 ? 6 : 0 }}>
      {ev.why}
    </div>
    {ev.sources.length > 0 && (
      <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
        {ev.sources.map(s => (
          <span key={s} style={{
            fontSize: 10, color: N.inno, fontWeight: 600,
            background: "rgba(109,40,217,.08)", borderRadius: 4,
            padding: "1px 6px",
          }}>{s}</span>
        ))}
      </div>
    )}
  </div>
</div>
```

### Person Card
```tsx
<div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 10, padding: "14px 16px", display: "flex", alignItems: "flex-start", gap: 12 }}>
  {/* Avatar */}
  <div style={{ width: 38, height: 38, borderRadius: "50%", background: person.type === "ai" ? N.innoBg : N.subtle, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
    {person.type === "ai"
      ? <Sparkles size={16} color={N.inno} strokeWidth={2} />
      : <User size={16} color={N.textSec} strokeWidth={2} />
    }
  </div>

  {/* Body */}
  <div style={{ flex: 1, minWidth: 0 }}>
    {/* Name row */}
    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
      <span style={{ fontSize: 13, fontWeight: 600, color: N.text }}>{person.name}</span>
      {person.type === "ai" && <NOVALabel size="xs" />}
      <StatusDot status={person.statusDot} />
    </div>

    {/* Role + availability */}
    <div style={{ fontSize: 12, color: N.textSec, marginBottom: 4 }}>
      {person.role} · {person.availability}
    </div>

    {/* Contribution */}
    <div style={{ fontSize: 13, color: person.pendingRequests > 0 ? N.warn : N.textSec, marginBottom: person.novaState ? 8 : 0 }}>
      {person.contribution}
      {person.pendingRequests > 0 && ` (${person.pendingRequests} pending)`}
    </div>

    {/* NOVA reasoning */}
    {person.novaState && (
      <div style={{ background: N.innoBg, border: `1px solid ${N.innoBrd}`, borderRadius: 8, padding: "8px 10px", marginBottom: 8 }}>
        <div style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: N.inno, marginBottom: 4 }}>
          Current reasoning
        </div>
        <div style={{ fontSize: 12, color: N.inno, lineHeight: 1.5 }}>{person.novaState}</div>
      </div>
    )}

    {/* Footer */}
    <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end" }}>
      <Btn v="quiet" size="sm" onClick={() => setDrawer(person)}>Details</Btn>
    </div>
  </div>
</div>
```

### Source Card
```tsx
<div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 10, padding: "12px 14px", marginBottom: 8 }}>
  {/* Header */}
  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ fontSize: 13, fontWeight: 600, color: N.text }}>{source.name}</span>
      <span style={{ fontSize: 10, fontWeight: 600, padding: "2px 7px", borderRadius: 999, border: `1px solid ${statusColor(source.status).brd}`, background: statusColor(source.status).bg, color: statusColor(source.status).color }}>
        {source.status}
      </span>
    </div>
  </div>

  {/* Meta inline */}
  <div style={{ fontSize: 11, color: N.textSec, marginBottom: 6 }}>
    {source.type} · Freshness: {source.freshness} days · {source.sections} sections
  </div>

  {/* NOVA comment */}
  <div style={{ display: "flex", alignItems: "flex-start", gap: 5, marginBottom: 8 }}>
    <Sparkles size={9} color={N.inno} strokeWidth={2.5} style={{ marginTop: 3, flexShrink: 0 }} />
    <span style={{ fontSize: 12, color: N.inno, lineHeight: 1.45 }}>{source.aiComment}</span>
  </div>

  {/* Actions */}
  <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
    {source.status === "missing" && <Btn v="secondary" size="sm" icon={<Upload size={10} />}>Add</Btn>}
    {source.status === "stale" && <Btn v="secondary" size="sm" icon={<RefreshCw size={10} />}>Refresh</Btn>}
    <Btn v="quiet" size="sm" onClick={() => setDrawer(source)}>Details</Btn>
  </div>
</div>
```

### Deliverable Card
```tsx
<div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 10, padding: "14px 16px" }}>
  {/* Header */}
  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ fontSize: 13, fontWeight: 600, color: N.text }}>{del.name}</span>
      <ConfChip pct={del.confPct} reasons={[]} />
    </div>
    <button onClick={() => {}} style={{ background: "none", border: "none", cursor: "pointer", color: N.textDis }}>
      <Eye size={11} strokeWidth={2} />
    </button>
  </div>

  {/* Readiness bar */}
  <div style={{ marginBottom: 8 }}>
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
      <span style={{ fontSize: 11, color: N.textSec }}>
        {del.readiness >= 70 ? "Ready for publication" : "In preparation"}
      </span>
      <span style={{ fontSize: 11, fontWeight: 700, color: confColor(del.readiness).color }}>{del.readiness}%</span>
    </div>
    <div style={{ height: 6, background: N.border, borderRadius: 999, overflow: "hidden" }}>
      <div style={{ width: `${del.readiness}%`, height: "100%", background: confColor(del.readiness).color, borderRadius: 999 }} />
    </div>
  </div>

  {/* Blocker */}
  {del.blocker && (
    <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 6 }}>
      <AlertTriangle size={9} color={N.warn} strokeWidth={2.5} />
      <span style={{ fontSize: 11, color: N.warn }}>{del.blocker}</span>
    </div>
  )}

  {/* Next action */}
  <div style={{ fontSize: 12, color: N.textSec, marginBottom: 10 }}>{del.nextAction}</div>

  {/* Footer */}
  <div style={{ display: "flex", justifyContent: "flex-end" }}>
    <Btn v="quiet" size="sm" onClick={() => setDrawer(del)}>Details</Btn>
  </div>
</div>
```

### Decision Card (work tab)
```tsx
<Card>
  {/* Badge row */}
  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
    <DeadlineBadge date={d.deadline} />
    <ConfChip pct={d.confPct} reasons={d.confReasons ?? []} afterAction={d.afterAction} />
  </div>

  {/* Statement */}
  <div style={{ fontSize: 15, fontWeight: 700, color: N.text, marginBottom: 8, lineHeight: 1.35 }}>
    {d.statement}
  </div>

  {/* NOVA recommendation */}
  <div style={{ display: "flex", alignItems: "flex-start", gap: 5, marginBottom: 12 }}>
    <Sparkles size={11} color={N.inno} strokeWidth={2.5} style={{ marginTop: 2, flexShrink: 0 }} />
    <span style={{ fontSize: 13, color: N.inno, lineHeight: 1.45 }}>{d.recommendation}</span>
  </div>

  {/* If approved / If rejected grid */}
  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
    {d.options.slice(0, 2).map((opt, i) => (
      <div key={i} style={{ background: N.subtle, borderRadius: 8, padding: "8px 10px" }}>
        <div style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: N.textDis, marginBottom: 3 }}>
          {i === 0 ? "If approved" : "If rejected"}
        </div>
        <div style={{ fontSize: 12, color: N.textSec }}>{i === 0 ? opt.ifApproved : opt.ifRejected}</div>
      </div>
    ))}
  </div>

  {/* CTA */}
  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
    <Btn onClick={() => { setActiveDecision(d.id); setView("decision-package"); }}>
      Review &amp; decide
    </Btn>
    <WhyInline>{d.rationale}</WhyInline>
  </div>
</Card>
```

### Phase Row (V6.1 outcome-first)
```tsx
<div style={{ border: `1px solid ${N.border}`, borderRadius: 10, overflow: "hidden", background: N.surface }}>
  <button
    onClick={() => setExp(exp === i ? null : i)}
    style={{ width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "14px 16px", background: "none", border: "none", cursor: "pointer", textAlign: "left" }}
  >
    {/* Phase icon */}
    <div style={{ width: 28, height: 28, borderRadius: 8, background: phaseIconBg(phase.status), display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      {phase.status === "complete" && <CheckCircle size={14} color={N.success} strokeWidth={2} />}
      {phase.status === "active"   && <RefreshCw   size={14} color={N.action}  strokeWidth={2} style={{ animation: "spin 2s linear infinite" }} />}
      {phase.status === "future"   && <Circle      size={12} color={N.textDis} strokeWidth={2} />}
    </div>

    {/* Content (outcome first) */}
    <div style={{ flex: 1, minWidth: 0 }}>
      {/* Outcome */}
      <div style={{ fontSize: 14, fontWeight: 600, color: N.text, marginBottom: 2 }}>
        {phase.outcome}
      </div>
      {/* Meta: name · probability · remaining */}
      <div style={{ fontSize: 11, color: N.textSec, display: "flex", alignItems: "center", gap: 6 }}>
        <span>{phase.name}</span>
        <span style={{ color: N.textDis }}>·</span>
        <span style={{ fontFamily: MONO, fontWeight: 700, color: confColor(phase.probability).color }}>
          {phase.probability}%
        </span>
        <span style={{ color: N.textDis }}>·</span>
        <span>Remaining: {phase.remaining}</span>
      </div>
      {/* Blocker */}
      {phase.blocker && (
        <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 4 }}>
          <AlertTriangle size={9} color={N.warn} strokeWidth={2.5} />
          <span style={{ fontSize: 11, color: N.warn }}>{phase.blocker}</span>
        </div>
      )}
    </div>

    {/* Chevron */}
    <ChevronDown
      size={12} strokeWidth={2.5} color={N.textDis}
      style={{ transform: exp === i ? "rotate(180deg)" : "none", transition: T.std, flexShrink: 0 }}
    />
  </button>

  {/* Expanded content */}
  {exp === i && (
    <div style={{ padding: "0 16px 14px", borderTop: `1px solid ${N.border}` }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 12 }}>
        <div>
          <div style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: N.textDis, marginBottom: 6 }}>AI contribution</div>
          <div style={{ fontSize: 12, color: N.textSec }}>{phase.aiContribution}</div>
        </div>
        <div>
          <div style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: N.textDis, marginBottom: 6 }}>Human contribution</div>
          <div style={{ fontSize: 12, color: N.textSec }}>{phase.humanContribution}</div>
        </div>
      </div>
      {phase.novaSummary && (
        <div style={{ marginTop: 10, background: N.innoBg, border: `1px solid ${N.innoBrd}`, borderRadius: 8, padding: "8px 10px" }}>
          <div style={{ fontSize: 12, color: N.inno }}>{phase.novaSummary}</div>
        </div>
      )}
    </div>
  )}
</div>
```

### Autonomy Button (confirm screen)
```tsx
{AUTONOMY_LEVELS.map(level => (
  <button
    key={level.level}
    onClick={() => setAut(level.level)}
    style={{
      flex: 1,
      textAlign: "left",
      padding: "14px 16px",
      borderRadius: 10,
      border: `${aut === level.level ? 2 : 1}px solid ${aut === level.level ? N.action : N.border}`,
      background: aut === level.level ? N.actionBg : N.surface,
      cursor: "pointer",
      transition: T.fast,
    }}
  >
    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
      <span style={{ fontSize: 13, fontWeight: 600, color: aut === level.level ? N.action : N.text }}>
        {level.name}
      </span>
      <span style={{
        fontSize: 10, fontWeight: 700, fontFamily: MONO, letterSpacing: "0.02em",
        color: N.action,
        background: aut === level.level ? "rgba(29,78,216,.12)" : "transparent",
        borderRadius: 4, padding: aut === level.level ? "1px 5px" : 0,
      }}>
        A{level.level}
      </span>
    </div>
    <div style={{ fontSize: 12, color: N.textSec, lineHeight: 1.45 }}>{level.description}</div>
  </button>
))}
```

### Composer Block (home)
```tsx
<div
  onClick={!composerOpen ? () => setComposerOpen(true) : undefined}
  style={{
    background: N.surface,
    border: `1.5px solid ${composerOpen ? N.action : N.border}`,
    borderRadius: 12,
    boxShadow: composerOpen ? `${SH.overlay}, 0 0 0 4px rgba(29,78,216,.07)` : SH.card,
    padding: "14px 16px",
    cursor: composerOpen ? "default" : "text",
    transition: T.std,
  }}
>
  {!composerOpen ? (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <Sparkles size={14} color={N.textDis} strokeWidth={2} />
      <span style={{ fontSize: 14, color: N.textDis }}>Ask NOVA anything, or start a new work item…</span>
    </div>
  ) : (
    <div>
      <textarea
        ref={taRef}
        value={val}
        onChange={e => setVal(e.target.value)}
        onKeyDown={e => { if (e.key === "Enter" && e.metaKey) handleSubmit(); }}
        placeholder="Describe what you need to accomplish..."
        rows={3}
        style={{ width: "100%", border: "none", outline: "none", resize: "none", background: "transparent", fontSize: 14, color: N.text, fontFamily: FONT, lineHeight: 1.6 }}
      />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 8 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <button style={{ background: "none", border: "none", cursor: "pointer", color: N.textDis }}>
            <Paperclip size={11} strokeWidth={2} />
          </button>
          <button style={{ background: "none", border: "none", cursor: "pointer", color: N.textDis }}>
            <Mic size={11} strokeWidth={2} />
          </button>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button onClick={() => { setComposerOpen(false); setVal(""); }} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: N.textSec }}>
            Cancel
          </button>
          <Btn disabled={!val.trim() || loading} loading={loading} onClick={handleSubmit}>
            {loading ? "Analysing…" : "Start with NOVA"}
          </Btn>
        </div>
      </div>
    </div>
  )}
</div>
```
