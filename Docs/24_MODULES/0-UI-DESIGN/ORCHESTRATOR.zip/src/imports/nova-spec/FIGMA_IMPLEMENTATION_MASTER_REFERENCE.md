# FIGMA_IMPLEMENTATION_MASTER_REFERENCE
## NOVA Design System — Figma Technical Reference
**Version:** V6.1  
**Role:** Unique Figma-sourced technical reference for the IDS  
**Scope:** Only data intrinsic to the Figma file. Does not duplicate UX flows, accessibility audits, functional specifications, or cognitive load rules already documented elsewhere.

---

## SECTION 1 — DOCUMENT METADATA

| Field | Value |
|---|---|
| Figma file name | NOVA — Design System V6.1 |
| Version | 6.1 (V6 + Polish pass) |
| Date | 2026-07-12 |
| Pages | 1 (single-page application canvas) |
| Top-level frames | 11 |
| Total components | 16 |
| Total variant sets | 8 |
| Component properties | 41 (across all components) |
| Color variables | 21 primitive + 12 semantic |
| Spacing variables | 14 |
| Shadow styles | 4 |
| Typography styles | 12 |
| Icon library | lucide-react (external, not local Figma library) |
| Prototype connections | 34 |

---

## SECTION 2 — PAGE TREE

```
NOVA V6.1
└── [Page] Application Canvas
    ├── [Section] Primitives
    │   ├── NOVALabel / xs
    │   ├── NOVALabel / sm
    │   ├── ConfChip / default
    │   ├── ConfChip / open
    │   ├── DeadlineBadge / urgent
    │   ├── DeadlineBadge / warning
    │   ├── DeadlineBadge / normal
    │   ├── StatusDot / available
    │   ├── StatusDot / busy
    │   ├── StatusDot / away
    │   ├── Btn / primary / sm
    │   ├── Btn / primary / md
    │   ├── Btn / primary / loading
    │   ├── Btn / primary / disabled
    │   ├── Btn / secondary / sm
    │   ├── Btn / secondary / md
    │   ├── Btn / quiet / sm
    │   ├── Btn / quiet / md
    │   ├── Card / default
    │   ├── Card / hover
    │   ├── WhyInline / collapsed
    │   └── WhyInline / expanded
    │
    ├── [Section] Layout Atoms
    │   ├── DrawerRow
    │   ├── DrawerSection
    │   ├── Drawer / closed
    │   ├── Drawer / open
    │   ├── NavItem / default
    │   ├── NavItem / hover
    │   ├── NavItem / active
    │   └── SearchOverlay
    │
    ├── [Section] Screens
    │   ├── [Frame] home
    │   ├── [Frame] clarify
    │   ├── [Frame] canvas
    │   ├── [Frame] plan
    │   ├── [Frame] confirm
    │   ├── [Frame] work — overview
    │   ├── [Frame] work — activity
    │   ├── [Frame] work — people
    │   ├── [Frame] work — sources
    │   ├── [Frame] work — decisions
    │   ├── [Frame] work — deliverables
    │   ├── [Frame] decision-package
    │   ├── [Frame] decision-pause — step 1
    │   ├── [Frame] decision-pause — step 2
    │   ├── [Frame] decision-receipt
    │   ├── [Frame] global-decisions
    │   └── [Frame] global-deliverables
    │
    └── [Section] Overlays
        ├── Drawer (open state, 460px)
        ├── SearchOverlay (560px panel)
        └── ConfChip popover (260px)
```

---

## SECTION 3 — FRAME INVENTORY

All screens use the same base viewport: **1280 × 800px**. NavRail occupies the leftmost 56px. Main area = 1224px.

| Frame name | Width | Height | X | Y | Layout | Clip content |
|---|---|---|---|---|---|---|
| home | 1280 | 800 | 0 | 0 | Vertical Auto Layout | true |
| clarify | 1280 | 800 | 1380 | 0 | Vertical Auto Layout | true |
| canvas | 1280 | 800 | 2760 | 0 | Vertical Auto Layout | true |
| plan | 1280 | 800 | 4140 | 0 | Vertical Auto Layout | true |
| confirm | 1280 | 800 | 5520 | 0 | Vertical Auto Layout | true |
| work — overview | 1280 | 800 | 6900 | 0 | Vertical Auto Layout | true |
| work — activity | 1280 | 800 | 8280 | 0 | Vertical Auto Layout | true |
| work — people | 1280 | 800 | 9660 | 0 | Vertical Auto Layout | true |
| work — sources | 1280 | 800 | 11040 | 0 | Vertical Auto Layout | true |
| work — decisions | 1280 | 800 | 12420 | 0 | Vertical Auto Layout | true |
| work — deliverables | 1280 | 800 | 13800 | 0 | Vertical Auto Layout | true |
| decision-package | 1280 | 800 | 15180 | 0 | Vertical Auto Layout | true |
| decision-pause / step 1 | 1280 | 800 | 16560 | 0 | Vertical Auto Layout | true |
| decision-pause / step 2 | 1280 | 800 | 17940 | 0 | Vertical Auto Layout | true |
| decision-receipt | 1280 | 800 | 19320 | 0 | Vertical Auto Layout | true |
| global-decisions | 1280 | 800 | 20700 | 0 | Vertical Auto Layout | true |
| global-deliverables | 1280 | 800 | 22080 | 0 | Vertical Auto Layout | true |

**Frame structure (all screens):**
```
[Frame: screen-name] 1280 × 800
└── [Auto Layout Row, fill container]
    ├── [Component: NavRail] 56 × 800, fixed width, fill height
    └── [Frame: main-area] fill, 800, clip content
```

**Constraints (all screen frames):**
- Horizontal: Scale
- Vertical: Scale
- Min width: 960px
- Min height: 600px

---

## SECTION 4 — COMPONENT INVENTORY

| Component name | Category | Slots | Occurrences (across all screens) |
|---|---|---|---|
| NOVALabel | Badge | icon (Sparkles), label text | 12 |
| ConfChip | Badge | trigger, popover | 18 |
| DeadlineBadge | Badge | icon (Clock), date text | 9 |
| StatusDot | Indicator | — | 4 |
| Btn | Action | icon (optional), label | 47 |
| Card | Container | default slot (children) | 22 |
| WhyInline | Disclosure | trigger text, expansion content | 8 |
| DrawerRow | Data display | label, value | 34 |
| DrawerSection | Layout | section header, default slot | 21 |
| Drawer | Overlay | header (title, close), body | 9 |
| NavItem | Navigation | icon, label, badge (optional) | 8 (per screen) |
| NavRail | Navigation | logo, primary items, bottom items, user | 17 (all screens) |
| SearchOverlay | Overlay | input, results list | 1 (global) |
| WorkView | Screen shell | breadcrumb, header, tab strip, tab content | 7 |
| ConfChip Popover | Overlay sub | header, delta row, reason lists, missing | 18 |
| PhaseRow | Data display | icon, outcome, meta, expanded content | max 4 per screen |

---

## SECTION 5 — COMPONENT PROPERTIES

### NOVALabel
| Property | Type | Values | Default |
|---|---|---|---|
| size | Variant | sm, xs | sm |

### ConfChip
| Property | Type | Values | Default |
|---|---|---|---|
| pct | Number | 0–100 | 76 |
| afterAction | Number (optional) | 0–100 | undefined |
| open | Boolean (instance) | true, false | false |
| hasAfterAction | Boolean | true, false | false |
| hasPositive | Boolean | true, false | false |
| hasMissing | Boolean | true, false | false |

### DeadlineBadge
| Property | Type | Values | Default |
|---|---|---|---|
| date | String | any | "Jul 18" |
| urgency | Variant (derived) | urgent, warning, normal | normal |

### StatusDot
| Property | Type | Values | Default |
|---|---|---|---|
| status | Variant | available, busy, away | available |

### Btn
| Property | Type | Values | Default |
|---|---|---|---|
| variant | Variant | primary, secondary, quiet | primary |
| size | Variant | sm, md | md |
| state | Variant | default, hover, loading, disabled | default |
| hasIcon | Boolean | true, false | false |
| iconPosition | Variant | leading, trailing | leading |
| label | String | any | "Button" |

### Card
| Property | Type | Values | Default |
|---|---|---|---|
| state | Variant | default, hover | default |
| clickable | Boolean | true, false | false |

### WhyInline
| Property | Type | Values | Default |
|---|---|---|---|
| state | Variant | collapsed, expanded | collapsed |
| triggerLabel | String | any | "Why?" |

### DrawerRow
| Property | Type | Values | Default |
|---|---|---|---|
| label | String | any | "Label" |
| value | String | any | "Value" |
| hasColor | Boolean | true, false | false |
| valueColor | Variant | success, warning, critical, default | default |

### DrawerSection
| Property | Type | Values | Default |
|---|---|---|---|
| label | String | any | "Section" |

### Drawer
| Property | Type | Values | Default |
|---|---|---|---|
| state | Variant | closed, open | closed |
| title | String | any | "Details" |
| width | Number (fixed) | 460 | 460 |

### NavItem
| Property | Type | Values | Default |
|---|---|---|---|
| state | Variant | default, hover, active | default |
| label | String | any | "Home" |
| hasBadge | Boolean | true, false | false |
| badgeCount | Number | 0–99 | 0 |

### PhaseRow
| Property | Type | Values | Default |
|---|---|---|---|
| status | Variant | complete, active, future | future |
| state | Variant | collapsed, expanded | collapsed |
| hasBlocker | Boolean | true, false | false |

---

## SECTION 6 — VARIANTS

### Btn variants
```
primary / md / default
primary / md / hover       → bg #1E40AF + shadow 0 2px 8px rgba(29,78,216,.24) + translateY(-1px)
primary / md / loading     → RefreshCw spinning + "…" label
primary / md / disabled    → opacity 0.4, cursor not-allowed
primary / sm / default
primary / sm / hover
secondary / md / default
secondary / md / hover     → bg #F1F5F9 + border #94A3B8
secondary / sm / default
quiet / sm / default
quiet / sm / hover         → bg #F1F5F9 + color #0F172A
quiet / md / default
quiet / md / hover
```

### Card variants
```
default    → border #E2E8F0, shadow SH.card
hover      → border #CBD5E1, shadow SH.cardHv
```

### NavItem variants
```
default    → bg transparent, color #475569, border-left transparent
hover      → bg rgba(15,23,42,.04), color #0F172A
active     → bg #EFF6FF, color #1D4ED8, border-left 2px solid #1D4ED8
```

### ConfChip variants
```
high       → bg #F0FDF4, color #166534     (pct ≥ 80)
medium     → bg #FFFBEB, color #B45309     (pct 55–79)
low        → bg #FEF2F2, color #991B1B     (pct < 55)
```
Each confidence level × {closed, open popover} = 6 variant combinations.

### DeadlineBadge variants
```
urgent     → bg #FEF2F2, color #991B1B, border #FECACA   (≤ 4 days)
warning    → bg #FFFBEB, color #92400E, border #FDE68A   (≤ 10 days)
normal     → bg #F1F5F9, color #94A3B8, border #E2E8F0   (> 10 days)
```

### StatusDot variants
```
available  → #166534
busy       → #991B1B
away       → #B45309
```

### WhyInline variants
```
collapsed  → ChevronDown 0°, no expansion box
expanded   → ChevronDown 180°, expansion box visible
```

### PhaseRow variants
```
complete / collapsed
complete / expanded
active / collapsed
active / expanded     → RefreshCw spinning
future / collapsed
future / expanded
```

### Drawer variants
```
closed     → not rendered
open       → fixed right 0, width 460px, backdrop visible
```

---

## SECTION 7 — AUTO LAYOUT

### Screen frame root
```
Direction:    Horizontal (Row)
Gap:          0
Padding:      0
Distribution: Space between
Align items:  Stretch
Sizing:       Fixed 1280 × 800
```

### NavRail
```
Direction:    Vertical (Column)
Gap:          0
Padding:      12 0 12 0
Align items:  Center
Sizing:       Fixed 56, Fill height
Clip:         true
```

### NavRail — nav group
```
Direction:    Vertical
Gap:          2
Padding:      0 8 0 8
Sizing:       Fill width, Hug height
```

### NavItem
```
Direction:    Vertical
Gap:          3
Padding:      7 4 7 4
Align items:  Center
Sizing:       Fill width, Hug height
```

### Main area (all screens)
```
Direction:    Vertical
Gap:          0
Padding:      0
Sizing:       Fill, Fill
Clip:         true
```

### Page content area (home, global views)
```
Direction:    Vertical
Gap:          24
Padding:      28 32 28 32
Sizing:       Fill, Hug (scroll overflow)
```

### Centered narrow views (clarify, confirm, pause, receipt)
```
Direction:    Vertical
Gap:          24
Padding:      48 24 48 24
Max width:    560 (constraint, not Auto Layout)
Align:        Center horizontal
Sizing:       Hug width (centered in fill parent)
```

### Card (base)
```
Direction:    Vertical
Gap:          0 (children define own spacing via margins)
Padding:      16
Sizing:       Fill width, Hug height
```

### Hero card (home + work overview)
```
Direction:    Vertical
Gap:          0
Padding:      22 24 22 24
Sizing:       Fill width, Hug height
```

### Next Best Action focal card
```
Direction:    Vertical
Gap:          0
Padding:      22 26 22 26
Sizing:       Fill width, Hug height
Stroke:       Inner, 2px #1D4ED8
```

### Work overview grid (2-col)
```
Direction:    Horizontal
Gap:          20
Padding:      20 24 20 24
Align items:  Start
Sizing:       Fill width
Left column:  2/3 fill (flex: 2)
Right column: 1/3 fill (flex: 1)
```

### Canvas grid (3-col)
```
Direction:    Horizontal (wrap)
Gap:          16
Padding:      0
Sizing:       Fill width
Per cell:     1/3 fill
```

### Decision option impact grid (2-col inside option)
```
Direction:    Horizontal
Gap:          8
Padding:      0
Sizing:       Fill width
Per cell:     1/2 fill
```

### Btn (md)
```
Direction:    Horizontal
Gap:          6
Padding:      9 20 9 20
Align items:  Center
Sizing:       Hug width, Hug height
```

### Btn (sm)
```
Padding:      6 14 6 14
Gap:          5
```

### Badge row (ConfChip + DeadlineBadge)
```
Direction:    Horizontal
Gap:          6
Sizing:       Hug width, Hug height
Align items:  Center
```

### DrawerSection
```
Direction:    Vertical
Gap:          10 (between header and content)
Margin bottom: 24 (between sections)
Sizing:       Fill width, Hug height
```

### DrawerRow
```
Direction:    Horizontal
Gap:          0
Padding:      8 0 8 0
Distribution: Space between
Align items:  Center
Border bottom: 1px solid #E2E8F0
Sizing:       Fill width, Fixed 34 height
```

### NOVA box (inside cards)
```
Direction:    Vertical
Gap:          4
Padding:      10 12 10 12
Sizing:       Fill width, Hug height
```

### Activity NOVA box header (impact + delta)
```
Direction:    Horizontal
Gap:          6
Align items:  Center
Sizing:       Fill width, Hug height
```

### Source counter strip
```
Direction:    Horizontal
Gap:          12
Align items:  Center
Padding:      10 0 10 0
Border bottom: 1px solid #E2E8F0
Sizing:       Fill width, Fixed height 36
```

### Clarify suggestions list
```
Direction:    Vertical
Gap:          8
Sizing:       Fill width, Hug height
```

### Clarify OR divider
```
Direction:    Horizontal
Gap:          12
Align items:  Center
Sizing:       Fill width, Fixed height 16
```

### Work tab strip
```
Direction:    Horizontal
Gap:          0
Padding:      0 24 0 24
Align items:  End
Border bottom: 1px solid #E2E8F0
Sizing:       Fill width, Fixed 42 height
```

### Work tab button
```
Direction:    Horizontal
Gap:          0
Padding:      10 16 10 16
Align items:  Center
Sizing:       Hug width, Fill height
```

### Decision package option button
```
Direction:    Vertical
Gap:          8
Padding:      16
Sizing:       Fill width, Hug height
```

### Decision option header row (radio + label + risk)
```
Direction:    Horizontal
Gap:          8
Align items:  Center
Sizing:       Fill width, Hug height
```

### Confirm autonomy row
```
Direction:    Horizontal
Gap:          8
Sizing:       Fill width, Hug height
Per button:   Fill width (flex: 1)
```

### Phase row header (toggle)
```
Direction:    Horizontal
Gap:          12
Padding:      14 16 14 16
Align items:  Center
Sizing:       Fill width, Hug height
```

### Phase icon container
```
Width:        28
Height:       28
Border radius: 8
Align:        Center Center
Sizing:       Fixed
```

### Person card
```
Direction:    Horizontal
Gap:          12
Padding:      14 16 14 16
Align items:  Start
Sizing:       Fill width, Hug height
```

### Person avatar
```
Width:        38
Height:       38
Border radius: 50% (999)
Align:        Center Center
Sizing:       Fixed
```

### Breadcrumb
```
Direction:    Horizontal
Gap:          6
Padding:      0 24 0 24
Align items:  Center
Sizing:       Fill width, Fixed 42 height
```

### Drawer header
```
Direction:    Horizontal
Gap:          0
Padding:      18 20 18 20
Distribution: Space between
Align items:  Center
Border bottom: 1px solid #E2E8F0
Sizing:       Fill width, Hug height
```

### Search overlay panel
```
Direction:    Vertical
Gap:          0
Sizing:       Fixed 560, Hug height
Max height:   480
Clip:         true
```

### Search input row
```
Direction:    Horizontal
Gap:          12
Padding:      14 16 14 16
Align items:  Center
Sizing:       Fill width, Fixed 52 height
```

### ConfChip trigger
```
Direction:    Horizontal
Gap:          4
Padding:      2 8 2 8
Align items:  Center
Sizing:       Hug width, Hug height
Border radius: 999
```

### ConfChip popover
```
Direction:    Vertical
Gap:          10
Padding:      14
Sizing:       Fixed 260, Hug height
```

### Clarify progress indicator
```
Direction:    Horizontal
Gap:          4
Align items:  Center
Sizing:       Hug width, Fixed 6 height
```

---

## SECTION 8 — DESIGN TOKENS

### Spacing tokens (used values only)
| Token | Value | Primary usage |
|---|---|---|
| space-1 | 2px | Icon stroke width base |
| space-2 | 4px | Micro gap (icon-to-text, tight rows) |
| space-3 | 6px | Badge padding, tight list gap |
| space-4 | 8px | Default row padding, small component gap |
| space-5 | 10px | NOVA box padding vertical |
| space-6 | 12px | Drawer body row padding, source card padding |
| space-7 | 14px | Btn padding vertical (md), tab padding, breadcrumb gap |
| space-8 | 16px | Card default padding, option button padding |
| space-9 | 18px | Drawer header padding |
| space-10 | 20px | Tab content padding, hero block padding vertical |
| space-11 | 22px | Focal card / hero card padding top-bottom |
| space-12 | 24px | Section gap, drawer section margin, hero card padding horizontal |
| space-13 | 26px | Focal card padding horizontal |
| space-14 | 28px | Page outer padding top |
| space-15 | 32px | Page outer padding horizontal |
| space-16 | 36px | Work header section padding |
| space-17 | 48px | Centered view vertical padding |

### Border radius tokens
| Token | Value | Usage |
|---|---|---|
| radius-xs | 4px | Source tag, expertise tag, monospace badge |
| radius-sm | 6px | Quiet button |
| radius-md | 8px | Card default (inner), NOVA box, input, activity event |
| radius-lg | 10px | Source card, person card, phase row, option button, suggestion button |
| radius-xl | 12px | Card (standard), DrawerSection context, ConfChip popover |
| radius-2xl | 14px | Work overview focal card, decision hero block, work hero card |
| radius-3xl | 16px | Home hero card, Search overlay panel |
| radius-full | 999px | All pill badges (NOVALabel, ConfChip, DeadlineBadge), filter pills, status dots, progress bars, Btn (not used), clarify active dot |
| radius-circle | 50% | Avatars (person, user), StatusDot, step circles, success icon circle |

### Shadow tokens
| Token | CSS value |
|---|---|
| SH.card | `0 1px 3px rgba(15,23,42,.06), 0 1px 2px rgba(15,23,42,.04)` |
| SH.cardHv | `0 4px 12px rgba(15,23,42,.08), 0 2px 4px rgba(15,23,42,.04)` |
| SH.overlay | `0 20px 48px rgba(15,23,42,.16), 0 4px 8px rgba(15,23,42,.08)` |
| SH.hero | `0 2px 20px rgba(29,78,216,.10), 0 1px 4px rgba(29,78,216,.06)` |

Shadow additional (derived, not named):
| Usage | CSS value |
|---|---|
| Btn primary hover | `0 2px 8px rgba(29,78,216,.24)` |
| Focal card ring | `0 0 0 4px rgba(29,78,216,.06)` |
| Composer active ring | `0 0 0 4px rgba(29,78,216,.07)` |

### Opacity tokens
| Token | Value | Usage |
|---|---|---|
| opacity-disabled | 0.4 | Btn disabled |
| opacity-backdrop-drawer | 0.20 | Drawer backdrop |
| opacity-backdrop-search | 0.35 | Search backdrop |
| opacity-nav-hover | 0.04 | NavItem hover bg (on #0F172A) |
| opacity-inno-tag | 0.08 | NOVA activity source tag bg (on #6D28D9) |
| opacity-autonomy-badge | 0.12 | Autonomy badge bg (on #1D4ED8) |

### Motion tokens
| Token | Value | Usage |
|---|---|---|
| ease-default | cubic-bezier(.2,0,0,1) | All transitions |
| duration-fast | 120ms | Hover states, badge toggles |
| duration-std | 200ms | Accordion, chevron rotate |
| duration-loading | 500ms | Home composer load simulation |
| duration-record | 700ms | Decision pause record simulation |
| animation-spin | 1s linear infinite | Loading spinner, active phase icon |

### Blur tokens
| Token | Value | Usage |
|---|---|---|
| blur-drawer | 2px | Drawer backdrop |
| blur-search | 2px | Search backdrop |

### Border/stroke tokens
| Token | Value | Usage |
|---|---|---|
| stroke-default | 1px solid #E2E8F0 | Default borders |
| stroke-medium | 1px solid #CBD5E1 | Button secondary default |
| stroke-strong | 1px solid #94A3B8 | Button secondary hover |
| stroke-action | 1.5px solid #1D4ED8 | Active input, selected suggestion |
| stroke-focal | 2px solid #1D4ED8 | Focal card, selected option button |
| stroke-innoBrd | 1px solid #DDD6FE | NOVA boxes, hero card, AI elements |
| stroke-success | 1px solid #BBF7D0 | Success badge border |
| stroke-warn | 1px solid #FDE68A | Warning badge border |
| stroke-crit | 1px solid #FECACA | Critical badge border |
| stroke-none | none | NavRail active border-left override |

### Elevation system (z-index)
| Token | Value | Usage |
|---|---|---|
| z-base | 0 | All cards, standard content |
| z-breadcrumb | 10 | Work breadcrumb (sticky) |
| z-popover | 20 | ConfChip popover |
| z-drawer | 50 | Drawer backdrop |
| z-drawer-panel | 51 | Drawer panel |
| z-search | 100 | Search overlay |

### Typography tokens
| Token | Font | Weight | Size | Line height | Letter spacing | Usage |
|---|---|---|---|---|---|---|
| type-hero | Inter | 700 | 19px | 1.30 | -0.022em | Home hero gain, work overview gain |
| type-h2 | Inter | 700 | 18px | 1.30 | -0.015em | Focal card action title |
| type-h3 | Inter | 700 | 15px | 1.35 | 0 | Card title, decision statement, section heading |
| type-body-lg | Inter | 400 | 15px | 1.55 | 0 | Hero sentence |
| type-body | Inter | 400 | 14px | 1.65 | 0 | Primary paragraph, composer input |
| type-body-sec | Inter | 400 | 13px | 1.60 | 0 | Secondary paragraph, card metadata |
| type-body-med | Inter | 500 | 13px | 1.45 | 0 | Activity change text (primary) |
| type-body-strong | Inter | 600 | 13px | 1.45 | 0 | Deliverable name, person name |
| type-label | Inter | 600 | 12px | 1.40 | 0 | Secondary labels, card subtitles |
| type-meta | Inter | 400 | 12px | 1.40 | 0 | Timestamps (secondary), version rows |
| type-micro | Inter | 400 | 11px | 1.30 | 0 | Timestamps, disabled text, badge meta |
| type-micro-strong | Inter | 600 | 11px | 1.30 | 0 | Confidence chip, deadline badge |
| type-overline | Inter | 700 | 10px | 1.20 | 0.06em | DrawerSection label, card category label, NOVA box "Current reasoning" |
| type-overline-sm | Inter | 700 | 9px | 1.20 | 0.04em | NOVALabel text, NavItem label |
| type-mono | Roboto Mono | 700 | 11px | 1.20 | 0.02em | Confidence delta, autonomy badge, phase probability |

### Icon size tokens
| Token | Size | Stroke | Usage |
|---|---|---|---|
| icon-xs | 7px | 2.5 | NOVALabel Sparkles (xs) |
| icon-sm | 8px | 2.5 | NOVALabel Sparkles (sm) |
| icon-base | 9–10px | 2–2.5 | Badge icons (Clock, AlertTriangle small) |
| icon-md | 11–12px | 2–2.5 | Most inline icons |
| icon-lg | 13–14px | 2–2.5 | Search input icon, nav arrow |
| icon-nav | 16px | 2 | NavRail items |
| icon-person-avatar | 16px | 2 | Person card avatar |
| icon-receipt | 20px | 2.5 | Decision receipt success |

### Grid tokens
| Token | Value |
|---|---|
| grid-columns | 12 (conceptual) |
| grid-gutter | 20px |
| grid-margin-h | 32px |
| content-max-narrow | 560px |
| content-max-medium | 640px |
| content-max-decision | 800px |
| nav-rail-width | 56px |
| drawer-width | 460px |
| search-panel-width | 560px |
| confchip-popover-width | 260px |

---

## SECTION 9 — VARIABLES

### Collection: Primitives

| Name | Type | Value | Mode |
|---|---|---|---|
| color/canvas | Color | #F8FAFC | Default |
| color/surface | Color | #FFFFFF | Default |
| color/subtle | Color | #F1F5F9 | Default |
| color/text | Color | #0F172A | Default |
| color/text-sec | Color | #475569 | Default |
| color/text-dis | Color | #94A3B8 | Default |
| color/border | Color | #E2E8F0 | Default |
| color/border-md | Color | #CBD5E1 | Default |
| color/border-st | Color | #94A3B8 | Default |
| color/action | Color | #1D4ED8 | Default |
| color/action-hv | Color | #1E40AF | Default |
| color/action-bg | Color | #EFF6FF | Default |
| color/success-bg | Color | #F0FDF4 | Default |
| color/success | Color | #166534 | Default |
| color/warn-bg | Color | #FFFBEB | Default |
| color/warn | Color | #92400E | Default |
| color/crit-bg | Color | #FEF2F2 | Default |
| color/crit | Color | #991B1B | Default |
| color/inno-bg | Color | #F5F3FF | Default |
| color/inno | Color | #6D28D9 | Default |
| color/inno-brd | Color | #DDD6FE | Default |

### Collection: Derived (not in Figma primitives, present as hardcoded values)

| Name | Value | Usage |
|---|---|---|
| color/amber-700 | #B45309 | ConfChip medium, phase probability medium |
| color/amber-600 | #D97706 | Work header progress bar (attention) |
| color/success-brd | #BBF7D0 | Success badge border |
| color/warn-brd | #FDE68A | Warning badge border |
| color/crit-brd | #FECACA | Critical badge border |
| gradient/hero | linear-gradient(135deg, #EFF6FF 0%, #F5F3FF 100%) | Home + work hero |
| gradient/decision | linear-gradient(135deg, #FEF2F2, #FFF7F0) | Decision package hero |
| gradient/logo | linear-gradient(135deg, #1D4ED8 0%, #6D28D9 100%) | NavRail logo + user avatar |

### Collection: Spacing

| Name | Value |
|---|---|
| space/4 | 4px |
| space/6 | 6px |
| space/8 | 8px |
| space/10 | 10px |
| space/12 | 12px |
| space/14 | 14px |
| space/16 | 16px |
| space/18 | 18px |
| space/20 | 20px |
| space/22 | 22px |
| space/24 | 24px |
| space/26 | 26px |
| space/28 | 28px |
| space/32 | 32px |
| space/48 | 48px |

### Collection: Motion

| Name | Value |
|---|---|
| ease/default | cubic-bezier(.2,0,0,1) |
| duration/fast | 120ms |
| duration/std | 200ms |

---

## SECTION 10 — COLOR SYSTEM

*(Full palette, semantic mapping, interactive states, badge colors, confidence function, source status colors, phase status colors, and health → progress bar color are fully documented in `06_COLOR_SYSTEM.md`. This section lists only Figma-file-specific details not covered there.)*

### Gradient definitions (Figma format)
```
gradient/hero:
  Type: Linear
  Angle: 135°
  Stop 0: #EFF6FF (opacity 100%)
  Stop 1: #F5F3FF (opacity 100%)

gradient/decision:
  Type: Linear
  Angle: 135°
  Stop 0: #FEF2F2 (opacity 100%)
  Stop 1: #FFF7F0 (opacity 100%)

gradient/logo:
  Type: Linear
  Angle: 135°
  Stop 0: #1D4ED8 (opacity 100%)
  Stop 1: #6D28D9 (opacity 100%)
```

### Color roles not previously documented
| Role | HEX | Context |
|---|---|---|
| Decision package hero border | #FECACA | Matches crit-brd |
| Decision hero bg end | #FFF7F0 | Only in decision gradient |
| Dissent block border | #FDE68A | Matches warn-brd |
| Step circle future bg | #E2E8F0 | Matches border token |
| Step circle future color | #94A3B8 | Matches text-dis |
| Checklist checkbox border | #CBD5E1 | Matches border-md |
| NavRail logo bg | gradient/logo | Not a flat color |
| User avatar bg | gradient/logo | Same gradient as logo |

---

## SECTION 11 — TYPOGRAPHY

*(Complete per-element font inventory for every screen is documented in `07_TYPOGRAPHY.md`. This section documents only the Figma text style definitions.)*

### Figma text styles (named styles in Figma)

| Style name | Font | Weight | Size | Line height | Letter spacing |
|---|---|---|---|---|---|
| Hero/Gain | Inter | 700 | 19 | 130% | -2.2% |
| Heading/Action | Inter | 700 | 18 | 130% | -1.5% |
| Heading/Card | Inter | 700 | 15 | 135% | 0% |
| Body/Large | Inter | 400 | 15 | 155% | 0% |
| Body/Default | Inter | 400 | 14 | 165% | 0% |
| Body/Secondary | Inter | 400 | 13 | 160% | 0% |
| Body/Medium | Inter | 500 | 13 | 145% | 0% |
| Body/Strong | Inter | 600 | 13 | 145% | 0% |
| Label/Default | Inter | 600 | 12 | 140% | 0% |
| Meta/Default | Inter | 400 | 11 | 130% | 0% |
| Meta/Strong | Inter | 600 | 11 | 130% | 0% |
| Overline/Default | Inter | 700 | 10 | 120% | 6% |
| Overline/Small | Inter | 700 | 9 | 120% | 4% |
| Mono/Default | Roboto Mono | 700 | 11 | 120% | 2% |

---

## SECTION 12 — ICONS

All icons are from the **lucide-react** external library. No local icon components exist in the Figma file.

### Icon inventory

| Icon name (lucide) | Sizes used | Stroke widths | Colors in use |
|---|---|---|---|
| Sparkles | 7, 8, 9, 11, 13, 14, 15 | 2, 2.5 | #6D28D9, #FFFFFF |
| Home | 16 | 2 | #475569, #1D4ED8 |
| Briefcase | 16 | 2 | #475569, #1D4ED8 |
| Scale | 14, 15, 16 | 2 | #475569, #1D4ED8 |
| FileText | 11, 13, 16 | 2 | #475569, #1D4ED8, #94A3B8 |
| Search | 14, 16 | 2 | #475569, #94A3B8, #1D4ED8 |
| Bell | 16 | 2 | #475569 |
| HelpCircle | 16 | 2 | #475569 |
| Settings | 16 | 2 | #475569 |
| ChevronRight | 11, 12, 13 | 2, 2.5 | #94A3B8, #1D4ED8 |
| ChevronDown | 9, 12 | 2, 2.5 | #94A3B8, #475569, #1D4ED8 |
| ChevronLeft | 13 | 2.5 | #0F172A, #475569 |
| Plus | 12, 13 | 2.5 | #FFFFFF, #475569 |
| Check | 7, 9, 10 | 3 | #166534, #FFFFFF, #1D4ED8 |
| AlertTriangle | 9, 10, 11, 12 | 2, 2.5 | #991B1B, #92400E, #B45309 |
| Clock | 9, 11 | 2, 2.5 | #991B1B, #92400E, #94A3B8 |
| ArrowRight | 12, 13, 14 | 2, 2.5 | #FFFFFF, #1D4ED8, #475569 |
| MoreHorizontal | 12 | 2 | #94A3B8 |
| Edit2 | 9 | 2 | #1D4ED8 |
| Eye | 11 | 2 | #94A3B8 |
| Paperclip | 11 | 2 | #94A3B8 |
| Mic | 11 | 2 | #94A3B8 |
| MessageSquare | 11 | 2 | #6D28D9 |
| Download | 11 | 2 | #475569, #1D4ED8 |
| Upload | 10 | 2 | #475569 |
| Info | 11 | 2 | #94A3B8 |
| CheckCircle | 11, 14, 20 | 2, 2.5 | #166534, #1D4ED8 |
| RefreshCw | 10, 12, 13, 14 | 2, 2.5 | #FFFFFF, #1D4ED8, #94A3B8 |
| Lock | 11 | 2.5 | #475569 |
| StopCircle | 11, 13 | 2 | #94A3B8, #991B1B |
| Send | 11 | 2.5 | #1D4ED8 |
| Circle | 12 | 2 | #94A3B8 |
| User | 9, 14, 16 | 2 | #475569, #FFFFFF |
| X | 12, 13, 15 | 2 | #94A3B8 |

### Icon containers (non-standard)

| Context | Container | Size | Bg | Radius |
|---|---|---|---|---|
| NavRail logo | Square | 32×32 | gradient/logo | 9px |
| Phase icon (complete) | Square | 28×28 | #F0FDF4 | 8px |
| Phase icon (active) | Square | 28×28 | #EFF6FF | 8px |
| Phase icon (future) | Square | 28×28 | #F1F5F9 | 8px |
| Person avatar (human) | Circle | 38×38 | #F1F5F9 | 50% |
| Person avatar (AI) | Circle | 38×38 | #F5F3FF | 50% |
| User avatar (nav) | Circle | 28×28 | gradient/logo | 50% |
| Decision receipt icon | Circle | 64×64 | #F0FDF4 | 50% |
| Step circle (active) | Circle | 24×24 | #1D4ED8 | 50% |
| Step circle (complete) | Circle | 24×24 | #F0FDF4 | 50% |
| Step circle (future) | Circle | 24×24 | #E2E8F0 | 50% |
| Clarify progress dot (active) | Pill | 20×6 | #1D4ED8 | 999px |
| Clarify progress dot (inactive) | Circle | 6×6 | #E2E8F0 | 50% |
| Radio circle (unselected) | Circle | 16×16 | transparent | 50% |
| Radio circle (selected) | Circle | 16×16 | #1D4ED8 | 50% |
| Checkbox | Square | 16×16 | #FFFFFF | 4px |

---

## SECTION 13 — SPACING SYSTEM

All spacing values present in the Figma file, with frequency of usage:

| Value | Token | Frequency | Primary contexts |
|---|---|---|---|
| 2px | space/2 | 3× | Badge gap (NOVALabel xs), clarify progress dot gap |
| 3px | — | 8× | Badge icon gap (DeadlineBadge, StatusDot-to-name), NavItem gap |
| 4px | space/4 | 12× | Tight icon-to-text gaps, filter pill vertical padding |
| 5px | — | 6× | WhyInline expansion box gap, Btn sm gap |
| 6px | space/6 | 18× | Badge padding horizontal (left), badge row gap, source tag padding |
| 7px | — | 4× | DrawerRow vertical padding, clarify progress gap |
| 8px | space/8 | 24× | Primary row gap, small component padding, drawer row gap |
| 9px | — | 2× | NOVALabel sm padding vertical |
| 10px | space/10 | 9× | NOVA box padding, search input padding, checklist item padding |
| 12px | space/12 | 14× | Person card gap, source card padding, drawer body row gap |
| 14px | space/14 | 11× | Btn padding v (md), tab button padding, composer input padding |
| 16px | space/16 | 19× | Card padding (default), option button padding, phase header padding |
| 18px | space/18 | 6× | Drawer header padding |
| 20px | space/20 | 8× | Tab content padding, hero card padding v, grid gap |
| 22px | space/22 | 4× | Hero card / focal card padding top-bottom |
| 24px | space/24 | 11× | Section gaps, focal card padding horizontal, section margin-bottom |
| 26px | space/26 | 2× | Focal card padding horizontal |
| 28px | space/28 | 4× | Page outer padding top |
| 32px | space/32 | 4× | Page outer padding horizontal |
| 48px | space/48 | 6× | Centered view vertical padding |
| 64px | — | 1× | Decision receipt icon circle |
| 120px | — | 1× | Search overlay backdrop padding-top |

---

## SECTION 14 — GRID

### Application grid (Figma layout grid)

NOVA V6.1 uses a structural split layout, not a traditional 12-column grid.

| Layer | Value |
|---|---|
| Layout type | Fixed split: NavRail + Main |
| NavRail width | 56px (fixed) |
| Main area | Remaining viewport (fill) |
| Content padding H | 32px (left and right) |
| Content padding V | 28px top |
| Work screen padding H | 24px (tabs + content) |
| Narrow centered max-width | 560px |
| Medium centered max-width | 640px |
| Decision package max-width | 800px |

### Internal grids (component-level)

| Grid | Columns | Gap | Usage |
|---|---|---|---|
| Canvas cards | 3 | 16px | Canvas synthesis screen |
| Work overview | 2 (2fr 1fr) | 20px | Overview tab main+sidebar |
| Option impact | 2 (1fr 1fr) | 8px | Decision option if/if-rejected |
| Decision pause consequences | 2 (1fr 1fr) | 12px | Pause step 1 |
| Decision receipt consequences | 2 (1fr 1fr) | 12px | Receipt screen |
| Phase expanded AI/Human | 2 (1fr 1fr) | 12px | Phase accordion expanded |
| Autonomy buttons | 4 (equal) | 8px | Confirm screen |

### Breakpoints

NOVA V6.1 is desktop-only. No responsive breakpoints defined in Figma.

| Breakpoint | Status |
|---|---|
| Mobile | Not defined |
| Tablet | Not defined |
| Desktop (default) | 1280px design target |
| Desktop min | 960px (minimum functional) |

---

## SECTION 15 — RESPONSIVE RULES

### Figma constraints per layer type

| Layer | Horizontal constraint | Vertical constraint |
|---|---|---|
| NavRail | Left, fixed width | Top + Bottom (stretch) |
| Main area | Left + Right (stretch) | Top + Bottom (stretch) |
| Page content | Left + Right (fill) | Top (hug, scroll) |
| NavItem | Left + Right (fill) | Top (hug) |
| Card | Left + Right (fill) | Top (hug) |
| Work 2-col grid | Left + Right (fill) | Top (hug) |
| Drawer | Right (fixed), full height | Top + Bottom |
| Search panel | Center horizontal | Top (fixed offset 120px) |
| Breadcrumb | Left + Right (fill) | Top (fixed height 42px) |
| Tab strip | Left + Right (fill) | Top (fixed height 42px) |
| Badges (NOVALabel, ConfChip) | Hug | Hug |
| Progress bars | Left + Right (fill) | Fixed height |

### Resize behaviour (what happens when viewport narrows)

| Element | Behaviour below min-width |
|---|---|
| NavRail | Stays 56px (labels may clip) |
| Main content | Compresses (no reflow) |
| 3-col canvas grid | Columns compress |
| 2-col work grid | Columns compress |
| Drawer | Overlaps main (overlay — correct) |
| Centered views | Remain centered, shrink horizontally |

### Hide/show rules

No conditional hide/show rules defined in Figma for responsive states (desktop-only design).

---

## SECTION 16 — IMAGE ASSETS

No raster image assets (PNG, JPG, WebP) are used in NOVA V6.1.

All visual content is:
- CSS gradients (hero blocks, logo, avatars)
- Lucide icon SVGs (rendered inline)
- Text content
- CSS-drawn shapes (circles, pills, progress bars)

---

## SECTION 17 — SVG

### Lucide icons (external library, not embedded SVG)

All icons are rendered via `lucide-react` JSX components — not embedded `<svg>` literals in the code. The Figma file references them as external library components.

### CSS-drawn shapes (no SVG required)

| Shape | Technique | Usage |
|---|---|---|
| StatusDot | `border-radius: 50%`, fixed 7×7px | Availability indicator |
| ConfChip | `border-radius: 999px` pill | Confidence badge |
| Progress bar | `border-radius: 999px`, fill width % | All progress bars |
| Clarify dot | `border-radius: 50%` or `border-radius: 999px` pill | Step indicator |
| Avatar | `border-radius: 50%` | Person / user circles |
| Step circle | `border-radius: 50%` | Decision pause steps |
| Radio circle | `border-radius: 50%` | Decision option selection |

---

## SECTION 18 — CSS EQUIVALENT

### NOVALabel (sm)
```css
.nova-label {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #F5F3FF;
  color: #6D28D9;
  border: 1px solid #DDD6FE;
  border-radius: 999px;
  padding: 2px 8px;
  font-family: 'Inter', system-ui, sans-serif;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.04em;
}
.nova-label--xs {
  gap: 3px;
  padding: 1px 6px;
  font-size: 9px;
}
```

### ConfChip
```css
.conf-chip {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  border-radius: 999px;
  padding: 2px 8px;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  border: none;
  font-family: 'Inter', system-ui, sans-serif;
  transition: all 120ms cubic-bezier(.2,0,0,1);
}
.conf-chip--high { background: #F0FDF4; color: #166534; }
.conf-chip--medium { background: #FFFBEB; color: #B45309; }
.conf-chip--low { background: #FEF2F2; color: #991B1B; }

.conf-chip__popover {
  position: absolute;
  top: -8px;
  left: 0;
  z-index: 20;
  width: 260px;
  background: #FFFFFF;
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  box-shadow: 0 20px 48px rgba(15,23,42,.16), 0 4px 8px rgba(15,23,42,.08);
  padding: 14px;
}
```

### DeadlineBadge
```css
.deadline-badge {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  border-radius: 999px;
  padding: 2px 8px;
  font-size: 11px;
  font-weight: 600;
  border: 1px solid;
}
.deadline-badge--urgent { background: #FEF2F2; color: #991B1B; border-color: #FECACA; }
.deadline-badge--warning { background: #FFFBEB; color: #92400E; border-color: #FDE68A; }
.deadline-badge--normal { background: #F1F5F9; color: #94A3B8; border-color: #E2E8F0; }
```

### StatusDot
```css
.status-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  flex-shrink: 0;
}
.status-dot--available { background: #166534; }
.status-dot--busy { background: #991B1B; }
.status-dot--away { background: #B45309; }
```

### Btn
```css
.btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border-radius: 8px;
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 600;
  cursor: pointer;
  transition: all 120ms cubic-bezier(.2,0,0,1);
}
.btn--primary {
  background: #1D4ED8;
  color: #FFFFFF;
  border: none;
  padding: 9px 20px;
  font-size: 13px;
}
.btn--primary:hover {
  background: #1E40AF;
  box-shadow: 0 2px 8px rgba(29,78,216,.24);
  transform: translateY(-1px);
}
.btn--primary:disabled { opacity: 0.4; }
.btn--primary.btn--sm { padding: 6px 14px; font-size: 12px; }

.btn--secondary {
  background: #FFFFFF;
  color: #0F172A;
  border: 1px solid #CBD5E1;
  box-shadow: 0 1px 3px rgba(15,23,42,.06), 0 1px 2px rgba(15,23,42,.04);
  padding: 9px 20px;
  font-size: 13px;
}
.btn--secondary:hover { background: #F1F5F9; border-color: #94A3B8; }
.btn--secondary.btn--sm { padding: 6px 14px; font-size: 12px; }

.btn--quiet {
  background: transparent;
  color: #475569;
  border: none;
  padding: 6px 14px;
  font-size: 12px;
  border-radius: 6px;
}
.btn--quiet:hover { background: #F1F5F9; color: #0F172A; }
.btn--quiet.btn--sm { padding: 4px 10px; }
```

### Card
```css
.card {
  background: #FFFFFF;
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(15,23,42,.06), 0 1px 2px rgba(15,23,42,.04);
  padding: 16px;
  transition: all 120ms cubic-bezier(.2,0,0,1);
}
.card--clickable { cursor: pointer; }
.card--clickable:hover {
  border-color: #CBD5E1;
  box-shadow: 0 4px 12px rgba(15,23,42,.08), 0 2px 4px rgba(15,23,42,.04);
}
```

### NavRail
```css
.nav-rail {
  width: 56px;
  flex-shrink: 0;
  height: 100%;
  background: #FFFFFF;
  border-right: 1px solid #E2E8F0;
  display: flex;
  flex-direction: column;
  padding: 12px 0;
  overflow: hidden;
}
.nav-item {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  padding: 7px 4px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 120ms cubic-bezier(.2,0,0,1);
  border-left: 2px solid transparent;
  background: transparent;
  color: #475569;
  border: none;
}
.nav-item:hover { background: rgba(15,23,42,.04); color: #0F172A; }
.nav-item--active {
  border-left: 2px solid #1D4ED8;
  background: #EFF6FF;
  color: #1D4ED8;
}
```

### Drawer
```css
.drawer-backdrop {
  position: fixed;
  inset: 0;
  z-index: 50;
  background: rgba(15,23,42,.20);
  backdrop-filter: blur(2px);
}
.drawer-panel {
  position: fixed;
  top: 0;
  right: 0;
  z-index: 51;
  width: 460px;
  height: 100%;
  background: #FFFFFF;
  box-shadow: 0 20px 48px rgba(15,23,42,.16), 0 4px 8px rgba(15,23,42,.08);
  display: flex;
  flex-direction: column;
}
.drawer-header {
  padding: 18px 20px;
  border-bottom: 1px solid #E2E8F0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-shrink: 0;
}
.drawer-body {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}
.drawer-section { margin-bottom: 24px; }
.drawer-section__label {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: #94A3B8;
  margin-bottom: 10px;
  font-family: 'Inter', system-ui, sans-serif;
}
.drawer-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  border-bottom: 1px solid #E2E8F0;
  font-family: 'Inter', system-ui, sans-serif;
}
.drawer-row__label { font-size: 12px; color: #475569; }
.drawer-row__value { font-size: 12px; font-weight: 600; color: #0F172A; }
```

### WhyInline
```css
.why-inline__trigger {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  color: #475569;
  font-size: 12px;
  text-decoration: underline;
  text-decoration-style: dotted;
  text-decoration-color: #94A3B8;
  cursor: pointer;
}
.why-inline__expansion {
  display: block;
  margin-top: 6px;
  background: #F5F3FF;
  border: 1px solid #DDD6FE;
  border-radius: 8px;
  padding: 10px 12px;
  font-size: 12px;
  color: #475569;
  line-height: 1.55;
}
```

### Hero block
```css
.hero-block {
  background: linear-gradient(135deg, #EFF6FF 0%, #F5F3FF 100%);
  border: 1px solid #DDD6FE;
  border-radius: 16px;
  box-shadow: 0 2px 20px rgba(29,78,216,.10), 0 1px 4px rgba(29,78,216,.06);
  padding: 22px 24px;
}
```

### Focal card (Next Best Action)
```css
.focal-card {
  border: 2px solid #1D4ED8;
  box-shadow: 0 0 0 4px rgba(29,78,216,.06),
              0 1px 3px rgba(15,23,42,.06),
              0 1px 2px rgba(15,23,42,.04);
  border-radius: 14px;
  padding: 22px 26px;
  background: #FFFFFF;
}
```

### NOVA box
```css
.nova-box {
  background: #F5F3FF;
  border: 1px solid #DDD6FE;
  border-radius: 8px;
  padding: 10px 12px;
  margin-top: 8px;
}
```

### Work tab strip
```css
.work-tabs {
  display: flex;
  background: #FFFFFF;
  border-bottom: 1px solid #E2E8F0;
  padding: 0 24px;
}
.work-tab {
  padding: 10px 16px;
  border: none;
  background: none;
  border-bottom: 2px solid transparent;
  font-size: 13px;
  cursor: pointer;
  font-weight: 400;
  color: #475569;
  transition: all 120ms cubic-bezier(.2,0,0,1);
  font-family: 'Inter', system-ui, sans-serif;
}
.work-tab--active {
  color: #1D4ED8;
  font-weight: 600;
  border-bottom-color: #1D4ED8;
}
```

### Progress bar
```css
.progress-bar-track {
  height: 3px;
  background: #E2E8F0;
  border-radius: 999px;
  overflow: hidden;
}
.progress-bar-fill {
  height: 100%;
  border-radius: 999px;
  /* color set dynamically via inline style based on health */
}
/* Readiness bar (deliverables) */
.readiness-bar-track { height: 6px; }
```

### Search overlay
```css
.search-backdrop {
  position: fixed;
  inset: 0;
  z-index: 100;
  background: rgba(15,23,42,.35);
  backdrop-filter: blur(2px);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding-top: 120px;
}
.search-panel {
  width: 560px;
  background: #FFFFFF;
  border-radius: 16px;
  box-shadow: 0 20px 48px rgba(15,23,42,.16), 0 4px 8px rgba(15,23,42,.08);
  overflow: hidden;
}
```

### Custom scrollbar
```css
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: #94A3B8; }
```

### Spin animation
```css
@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
.spin { animation: spin 1s linear infinite; }
```

---

## SECTION 19 — JSX STRUCTURE

*(Complete JSX patterns for every screen and component are documented in `15_JSX_REFERENCE.md` and `16_REACT_COMPONENT_TREE.md`. This section documents only the Figma-layer-to-JSX naming mapping.)*

### Figma layer name → JSX component mapping

| Figma layer name | JSX component / element |
|---|---|
| NavRail | `<NavRail>` |
| NavItem/active | `<NavItem state="active">` |
| Logo / mark | `<div>` with gradient + `<Sparkles>` |
| Hero / situation | `<div style={heroBlock}>` |
| Composer / collapsed | `<div onClick={open}>` |
| Composer / expanded | `<div>` + `<textarea>` |
| Card / default | `<Card>` |
| Card / clickable | `<Card onClick={...}>` |
| NOVALabel / sm | `<NOVALabel>` |
| NOVALabel / xs | `<NOVALabel size="xs">` |
| ConfChip / closed | `<ConfChip>` (open=false) |
| ConfChip / popover | `<ConfChip>` with internal popover rendered |
| DeadlineBadge | `<DeadlineBadge date="...">` |
| StatusDot / available | `<StatusDot status="available">` |
| Btn / primary / md | `<Btn>` |
| Btn / quiet / sm | `<Btn v="quiet" size="sm">` |
| WhyInline | `<WhyInline>` |
| DrawerRow | `<DrawerRow label="..." value="...">` |
| DrawerSection | `<DrawerSection label="...">` |
| Drawer / open | `<Drawer open={true}>` |
| PhaseRow / active / collapsed | phase `<button>` with active status |
| PhaseRow / expanded | phase `<button>` + expanded `<div>` |
| NOVA box | `<div style={novaBox}>` |
| Source counter strip | `<div style={counterStrip}>` text |
| Activity event | `<div>` card with NOVA box |
| Person card | `<div>` flex with avatar + body |
| Source card | `<div>` with status badge + NOVA comment |
| Deliverable card | `<div>` with readiness bar |
| Decision card | `<Card>` with badges + statement + grid |
| Next Best Action | `<div style={focalCard}>` |
| Decision hero | `<div style={decisionHero}>` |
| Dissent block | `<div style={dissentBlock}>` |
| Step indicator | `<div>` flex of step circles |
| Search overlay | `<SearchOverlay>` |
| Breadcrumb | sticky `<div>` flex |

---

## SECTION 20 — DEPENDENCY GRAPH

*(Full React component dependency graph is documented in `17_DEPENDENCY_GRAPH.md`. This section covers Figma-specific dependencies.)*

### Component → style token dependencies

```
NOVALabel → color/inno, color/inno-bg, color/inno-brd
ConfChip → confColor() function → color/success, color/warn, color/crit (and bg/brd variants), color/amber-700
DeadlineBadge → color/crit, color/crit-brd, color/crit-bg, color/warn, color/warn-brd, color/warn-bg, color/text-dis, color/border, color/subtle
StatusDot → color/success, color/crit, color/amber-700
Btn/primary → color/action, color/action-hv
Btn/secondary → color/surface, color/text, color/border-md, color/border-st
Btn/quiet → color/text-sec, color/subtle, color/text
Card → color/surface, color/border, color/border-md, SH.card, SH.cardHv
Drawer → color/surface, color/border, SH.overlay, opacity/backdrop-drawer
WhyInline → color/text-sec, color/text-dis, color/inno-bg, color/inno-brd
NavItem/active → color/action-bg, color/action
HeroBlock → gradient/hero, color/inno-brd, SH.hero
FocalCard → color/action, color/surface, SH.card
NOVAbox → color/inno-bg, color/inno-brd
```

### Screen → component dependencies

```
home → NavRail, HeroBlock, Composer, NOVALabel, Btn, WhyInline, Card, DeadlineBadge, ConfChip, Drawer, DrawerSection, DrawerRow
clarify → NavRail, Btn
canvas → NavRail, Btn
plan → NavRail, PhaseRow, Btn
confirm → NavRail, ConfChip, Btn
work/* → NavRail, Breadcrumb, WorkHeader, TabStrip + per-tab components
decision-package → NavRail, Breadcrumb, DeadlineBadge, ConfChip, NOVALabel, WhyInline, Btn, Drawer, DrawerSection, DrawerRow
decision-pause → NavRail, Breadcrumb, Btn
decision-receipt → NavRail, Breadcrumb, Btn
global-decisions → NavRail, Card, DeadlineBadge, ConfChip, Btn
global-deliverables → NavRail, ConfChip, Btn
```

---

## SECTION 21 — IMPLEMENTATION NOTES

These are technical constraints observable directly in the Figma file, with no UX interpretation.

1. **NavRail overflow hidden:** The nav rail has `overflow: hidden`. If the label font renders wider than 56px, it will clip silently.

2. **Border-left on NavItem:** The active state uses `border-left: 2px solid #1D4ED8`. This requires the button element to have `border` shorthand reset and then `border-left` override, or the element loses its flex layout due to unexpected border dimensions. Use explicit `borderLeft` in inline styles.

3. **ConfChip popover anchoring:** The popover is `position: absolute` with `top: -8px, left: 0` relative to the ConfChip trigger. If the ConfChip appears near the left edge of the screen, the popover (260px) extends rightward — no left-flip logic is defined in Figma.

4. **Drawer z-stacking:** Backdrop is z-index 50, panel is z-index 51. The Breadcrumb is z-index 10. The SearchOverlay is z-index 100. These values must be honoured exactly to prevent stacking conflicts.

5. **Focal card shadow composition:** The Next Best Action card uses a composite shadow: outer ring `0 0 0 4px rgba(29,78,216,.06)` + standard `SH.card`. These must be defined in a single `box-shadow` declaration separated by a comma.

6. **Progress bar heights:** Two distinct heights exist in the system — 3px (work header, health bars in drawer) and 6px (deliverable readiness bar). These are not interchangeable.

7. **ChevronDown rotation:** The rotate transform is `rotate(180deg)` when expanded. The transition is `all 200ms` (T.std), not T.fast. This applies to: phase accordion chevron, ConfChip chevron, WhyInline chevron.

8. **RefreshCw loading spinner:** Uses CSS `animation: spin 1s linear infinite`. This is the only animation that uses keyframes; all other motion is CSS transition-based.

9. **Active phase icon animation:** PhaseRow with status="active" renders RefreshCw with the same `spin` animation. This shares the same `@keyframes spin` definition.

10. **Gradient direction:** All gradients in the system use `135deg`. None use `to right`, `to bottom`, or other angle values.

11. **Mono font scope:** Roboto Mono is used exclusively for: confidence deltas in activity (N% → N%), autonomy level badges (A0–A3), and phase probability values. It is not used elsewhere, including timestamps.

12. **Drawer backdrop: blur(2px) exact:** Both drawer and search overlay use the same blur value. Do not increase or approximate.

13. **Overline letter-spacing:** DrawerSection labels use `letter-spacing: 0.06em`. NOVALabel and activity source tags use `0.04em`. These are distinct and must not be unified.

14. **Card border-radius split:** Standard cards = 12px. Hero/focal cards = 14–16px. Option buttons = 10px. These must be rendered as-specified, not unified.

15. **No CSS reset beyond Tailwind base:** The project relies on Tailwind's base reset. Adding a second `* { margin: 0; padding: 0 }` unlayered reset will override utility classes.

---

## SECTION 22 — KNOWN LIMITATIONS

What Figma cannot provide for this project:

| Category | Limitation |
|---|---|
| **Business logic** | Confidence score calculation, probability computation, risk assessment algorithms |
| **Backend / API** | NOVA AI inference endpoints, document analysis API, source validation service |
| **State persistence** | Decision recording, work item progress, user session, autonomy level memory |
| **Real-time data** | Activity stream, live confidence updates, source freshness polling |
| **Authentication** | User identity, permissions, session management |
| **Navigation routing** | URL structure, browser history, deep linking — Figma only shows screen states |
| **Animation choreography** | Figma prototype transitions do not specify the exact easing/duration for view-to-view navigation |
| **Scroll state** | Figma does not capture initial scroll position per tab |
| **Focus management** | Figma does not specify which element receives focus after state changes |
| **Keyboard interactions** | Only Cmd+K is captured in prototype; all other keyboard interactions are inferred |
| **Error states** | No error screens defined (network failure, load timeout, AI unavailable) |
| **Empty states** | No empty list states defined (no active work, no decisions, no sources) |
| **Loading states** | Only the composer and decision record have loading states; others are undefined |
| **Accessibility tree** | ARIA roles, labels, and landmarks not specifiable in Figma |
| **Data validation** | Required fields, field limits, format constraints — not in Figma |
| **Placeholder content** | 10 stub interactions listed in the implementation as no-ops (see doc 20) |
| **Internationalisation** | All copy is English-only; text overflow for longer languages not handled |
| **Font loading fallback** | Figma assumes Inter is always available; web fallback (`system-ui, -apple-system, sans-serif`) behaviour not designed |
| **Print rendering** | No print stylesheet defined |
| **Dark mode** | Not designed; no dark mode variables or variant states exist in Figma |
