# HOME_PIXEL_PERFECT_SPEC
## NOVA V6.1 — Page HOME — Référence unique d'intégration pixel-perfect

**Source:** Extrait directement de `src/app/App.tsx` — `HomeView`  
**Périmètre:** Page HOME uniquement. NavRail documenté à part (partagé avec toutes les vues).  
**Règle:** Ce document est autosuffisant. Aucun autre fichier n'est nécessaire pour intégrer la HOME.

---

## 1. VIEWPORT & CONTENEUR RACINE

```
App root
├── NavRail            → width: 220px, height: 100vh, position: sticky, top: 0
└── HomeView container → flex: 1, overflow-y: auto, background: #F8FAFC
```

### HomeView — conteneur scrollable
```css
max-width: 880px;
margin: 0 auto;
padding: 52px 52px 100px;
```

**Fond de page:** `#F8FAFC` (N.canvas) — posé sur le `<body>` / App root, pas sur le conteneur HOME.

---

## 2. STRUCTURE DOM COMPLÈTE

```
HomeView (div, max-width 880px, centré, padding 52px 52px 100px)
│
├── [A] Header block (div, marginBottom 32px)
│   ├── h1 — "Good afternoon, Sarah."
│   └── p  — "1 decision due in 4 days · 2 active work items"
│
├── [B] Composer block (div, marginBottom 44px)
│   ├── Composer card (div, border 1.5px, borderRadius 14px, overflow hidden)
│   │   ├── État collapsed → button (placeholder text + icône Sparkles)
│   │   └── État expanded  → label + textarea + footer (Attach / Voice / Cancel / CTA)
│   └── Suggestion pills row (div, display flex, gap 8px, marginTop 10px, flexWrap wrap)
│       ├── "Try:" label
│       └── pill × 3
│
├── [C] Hero block — FOCAL POINT (div, padding 28px 32px, marginBottom 24px)
│   ├── Meta row   → NOVALabel + "Situation · now"
│   ├── heroSentence → p (15px)
│   ├── heroGain     → p (19px 700)
│   └── CTA row    → Btn "Open presentation" + WhyInline + "Details" link
│
├── [D] Decision card (div, marginBottom 24px)
│   └── Card (accent crit, padding 18px 24px, clickable)
│       ├── Icon container (36×36 critBg)
│       ├── Body
│       │   ├── Badge row → DeadlineBadge + ConfChip
│       │   ├── Statement (14px 600)
│       │   └── urgency text (13px N.crit)
│       └── ArrowRight icon
│
├── [E] Active work section (div, marginBottom 20px)
│   ├── Section label — "ACTIVE WORK" (11px 600 uppercase)
│   └── Work rows list (flex column, gap 6px)
│       └── WorkRow × 3 (div, clickable)
│           ├── StatusDot
│           ├── Body (flex 1) → outcome + nextAction
│           ├── ConfChip
│           └── Deadline date
│
├── [F] NOVA background strip (div, padding 12px 18px)
│   ├── NOVALabel
│   ├── Text NOVA status
│   └── "Details" link
│
└── [G] Drawer (fixed, z-index 50, conditionnellement rendu)
    └── 5 DrawerSections
```

---

## 3. BLOC A — HEADER

### Conteneur
```css
margin-bottom: 32px;
```

### h1 — Titre de salutation
```css
font-family: 'Inter', system-ui, -apple-system, sans-serif;
font-size: 27px;
font-weight: 650;
color: #0F172A;
margin: 0 0 4px 0;
letter-spacing: -0.03em;
```
**Contenu:** `"Good afternoon, Sarah."`

### p — Sous-titre contextuel
```css
font-family: 'Inter', system-ui, -apple-system, sans-serif;
font-size: 14px;
color: #94A3B8;
margin: 0;
```
**Contenu:** `"1 decision due in 4 days · 2 active work items"`

---

## 4. BLOC B — COMPOSER

### Conteneur externe
```css
margin-bottom: 44px;
```

### Carte composer (état collapsed)
```css
background: #FFFFFF;
border-radius: 14px;
border: 1.5px solid #CBD5E1;           /* N.borderMd — collapsed */
box-shadow: 0 4px 12px rgba(15,23,42,.08), 0 2px 4px rgba(15,23,42,.04);  /* SH.cardHv */
transition: all 280ms cubic-bezier(.2,0,0,1);
overflow: hidden;
```

### Carte composer (état expanded)
```css
border: 1.5px solid #1D4ED8;           /* N.action */
box-shadow: 0 20px 48px rgba(15,23,42,.16), 0 4px 8px rgba(15,23,42,.08),
            0 0 0 4px rgba(29,78,216,.07);   /* SH.overlay + ring */
```

---

### 4.1 Collapsed — bouton trigger

```css
width: 100%;
padding: 20px 24px;
background: none;
border: none;
text-align: left;
cursor: text;
display: flex;
align-items: center;
gap: 14px;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```

**Icône container:**
```css
width: 36px;
height: 36px;
border-radius: 10px;
background: #EFF6FF;     /* N.actionBg */
display: flex;
align-items: center;
justify-content: center;
flex-shrink: 0;
```
Icône: `<Sparkles size={15} color="#1D4ED8" strokeWidth={2} />`

**Texte principal:**
```css
font-size: 15px;
color: #94A3B8;   /* N.textDis */
```
Contenu: `"What would you like to achieve?"`

**Texte secondaire:**
```css
font-size: 12px;
color: #94A3B8;
margin-top: 3px;
opacity: 0.65;
```
Contenu: `"Describe your objective. NOVA builds the work, coordinates contributors, validates evidence and prepares the final deliverables."`

---

### 4.2 Expanded — label + textarea

**Label:**
```css
display: block;
font-size: 13px;
font-weight: 600;
color: #475569;    /* N.textSec */
margin-bottom: 8px;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Contenu: `"What would you like to achieve?"`

**Textarea:**
```css
width: 100%;
border: none;
outline: none;
font-size: 15px;
color: #0F172A;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
resize: none;
line-height: 1.65;
background: transparent;
min-height: 80px;
box-sizing: border-box;
```
Placeholder: `"Describe your goal. NOVA will ask only what's needed."`

Wrapper textarea: `padding: 20px 24px 0`

---

### 4.3 Expanded — footer actions

```css
padding: 10px 22px 16px;
border-top: 1px solid #E2E8F0;
display: flex;
align-items: center;
gap: 8px;
margin-top: 4px;
```

**Bouton Attach:**
```css
display: flex;
align-items: center;
gap: 4px;
padding: 5px 10px;
background: none;
border: 1px solid #E2E8F0;
border-radius: 7px;
font-size: 12px;
color: #475569;
cursor: pointer;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Icône: `<Paperclip size={11} strokeWidth={2} />`

**Bouton Voice:** Identique à Attach.
Icône: `<Mic size={11} strokeWidth={2} />`

**Spacer:** `flex: 1`

**Bouton Cancel:**
```css
padding: 5px 12px;
background: none;
border: none;
font-size: 13px;
color: #475569;
cursor: pointer;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```

**CTA "Continue":** `<Btn variant="primary" size="sm">`
```css
/* Btn sm primary */
height: 32px;
padding: 0 12px;
font-size: 13px;
background: #1D4ED8;
color: #FFFFFF;
border-radius: 9px;
font-weight: 600;
letter-spacing: -0.01em;
border: none;
```
Contenu: `Continue` + `<ArrowRight size={13} strokeWidth={2.5} />`  
État loading: `<RefreshCw size={12} strokeWidth={2.5} style={{ animation: "spin 1s linear infinite" }} />` + `"Working…"`  
Disabled: `opacity: 0.4`

---

### 4.4 Suggestion pills (sous la carte, état collapsed)

**Conteneur:**
```css
display: flex;
gap: 8px;
margin-top: 10px;
flex-wrap: wrap;
align-items: center;
```

**"Try:" label:**
```css
font-size: 12px;
color: #94A3B8;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```

**Pill (état default):**
```css
padding: 3px 11px;
background: transparent;
border: 1px solid #E2E8F0;
border-radius: 999px;
font-size: 12px;
color: #475569;
cursor: pointer;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
transition: all 120ms cubic-bezier(.2,0,0,1);
```

**Pill (état hover):**
```css
border-color: #1D4ED8;
color: #1D4ED8;
background: #EFF6FF;
```

**Contenu des pills:**
1. `"Prepare a board presentation on Q3 results"`
2. `"Analyse reasons for the drop in NPS"`
3. `"Draft a proposal for a new supplier partnership"`

---

## 5. BLOC C — HERO BLOCK (FOCAL POINT)

```css
padding: 28px 32px;
background: linear-gradient(135deg, #EFF6FF 0%, #F5F3FF 100%);
border-radius: 16px;
border: 1px solid #DDD6FE;   /* N.innoBrd */
box-shadow: 0 2px 20px rgba(29,78,216,.10), 0 1px 4px rgba(29,78,216,.06);  /* SH.hero */
margin-bottom: 24px;
```

### 5.1 Meta row
```css
display: flex;
align-items: center;
gap: 8px;
margin-bottom: 14px;
```

**NOVALabel:**
```css
display: inline-flex;
align-items: center;
gap: 4px;
font-size: 11px;
font-weight: 650;
color: #6D28D9;
background: #F5F3FF;
border: 1px solid #DDD6FE;
border-radius: 6px;
padding: 2px 7px;
letter-spacing: -0.01em;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Icône: `<Sparkles size={9} strokeWidth={2.5} color="#6D28D9" />` + `"NOVA"`

**Timestamp:**
```css
font-size: 12px;
color: #94A3B8;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Contenu: `"Situation · now"`

### 5.2 heroSentence — paragraphe situation
```css
font-size: 15px;
font-weight: 400;
color: #475569;    /* N.textSec */
margin: 0 0 8px 0;
line-height: 1.6;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Contenu: `"Your board presentation is blocked by 3 open comments and a missing CRM source."`

### 5.3 heroGain — titre focal (texte le plus grand de la page)
```css
font-size: 19px;
font-weight: 700;
color: #0F172A;    /* N.text */
margin: 0 0 22px 0;
line-height: 1.5;
letter-spacing: -0.022em;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Contenu: `"Spend 15 minutes resolving the comments today and validation probability rises from 76% to 92%."`

### 5.4 CTA row
```css
display: flex;
align-items: center;
gap: 12px;
flex-wrap: wrap;
```

**CTA "Open presentation":** `<Btn variant="primary" size="md">`
```css
height: 40px;
padding: 0 16px;
font-size: 14px;
background: #1D4ED8;
color: #FFFFFF;
border-radius: 9px;
font-weight: 600;
letter-spacing: -0.01em;
border: none;
box-shadow: none;
transition: all 200ms cubic-bezier(.2,0,0,1);
```
Hover:
```css
background: #1E40AF;
box-shadow: 0 2px 8px rgba(29,78,216,.24);
transform: translateY(-1px);
```
Icône trailing: `<ArrowRight size={14} strokeWidth={2.5} />`

**WhyInline — bouton trigger:**
```css
font-size: 12px;
color: #475569;
background: none;
border: none;
cursor: pointer;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
padding: 0;
text-decoration: underline;
text-decoration-style: dotted;
text-underline-offset: 3px;
display: inline-flex;
align-items: center;
gap: 3px;
```
Contenu: `"Why?"` + `<ChevronDown size={9} strokeWidth={2.5} />`

**WhyInline — contenu expandé:**
```css
margin-top: 10px;
padding: 12px 14px;
background: #F5F3FF;
border-radius: 9px;
border: 1px solid #DDD6FE;
font-size: 12px;
color: #6D28D9;
line-height: 1.6;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Contenu: `"These 3 comments block the CFO pre-review, which is required before the 18 July board deadline. The CRM export is separately missing — NOVA estimates 1–2 days to obtain it from IT."`

**"Details" link:**
```css
font-size: 12px;
color: #94A3B8;
background: none;
border: none;
cursor: pointer;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
margin-left: auto;
display: flex;
align-items: center;
gap: 3px;
```
Contenu: `"Details"` + `<ChevronRight size={11} strokeWidth={2} />`

---

## 6. BLOC D — DECISION CARD

### Conteneur
```css
margin-bottom: 24px;
```

### Card (clickable, accent crit)
```css
background: #FFFFFF;
border-radius: 12px;
border: 1px solid #E2E8F0;        /* default — devient #CBD5E1 au hover */
border-left: 3px solid #991B1B;   /* accent N.crit */
box-shadow: 0 1px 3px rgba(15,23,42,.06), 0 1px 2px rgba(15,23,42,.04);  /* SH.card */
transition: all 200ms cubic-bezier(.2,0,0,1);
cursor: pointer;
padding: 18px 24px;
```
Hover:
```css
border-color: #CBD5E1;   /* N.borderMd */
box-shadow: 0 4px 12px rgba(15,23,42,.08), 0 2px 4px rgba(15,23,42,.04);  /* SH.cardHv */
```

### Layout interne
```css
display: flex;
align-items: center;
gap: 12px;
```

### Icône container
```css
width: 36px;
height: 36px;
border-radius: 10px;
background: #FEF2F2;    /* N.critBg */
display: flex;
align-items: center;
justify-content: center;
flex-shrink: 0;
```
Icône: `<Scale size={15} color="#991B1B" strokeWidth={2} />`

### Body (flex 1, min-width 0)

**Badge row:**
```css
display: flex;
align-items: center;
gap: 8px;
margin-bottom: 6px;
```

**DeadlineBadge (4 jours → urgent):**
```css
display: inline-flex;
align-items: center;
gap: 4px;
font-size: 11px;
font-weight: 600;
color: #991B1B;        /* N.crit — urgence ≤4 jours */
background: #FEF2F2;   /* N.critBg */
border: 1px solid #FECACA;
border-radius: 999px;
padding: 2px 9px;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
white-space: nowrap;
```
Icône: `<Clock size={9} strokeWidth={2.5} color="#991B1B" />` + `"Due in 4 days"`

**ConfChip (82% — high ≥80):**
```css
/* Trigger */
display: inline-flex;
align-items: center;
gap: 4px;
font-size: 12px;
font-weight: 700;
color: #166534;        /* success — pct ≥ 80 */
background: transparent;
border: none;
cursor: pointer;
font-family: 'Roboto Mono', monospace;
padding: 0;
line-height: 1;
```
Contenu trigger: `"82%"` + `<span style="font-size:10px; font-family:Inter; font-weight:500; opacity:.7">confidence</span>` + `<ChevronDown size={9} strokeWidth={2.5} opacity=.5 />`

**ConfChip Popover (état ouvert, 82%):**
```css
position: absolute;
top: calc(100% + 8px);
left: 0;
z-index: 30;
background: #FFFFFF;
border: 1px solid #E2E8F0;
border-radius: 12px;
box-shadow: 0 20px 48px rgba(15,23,42,.16), 0 4px 8px rgba(15,23,42,.08);
padding: 16px 18px;
min-width: 240px;
width: max-content;
max-width: 300px;
```

Header popover:
```css
display: flex;
align-items: center;
justify-content: space-between;
margin-bottom: 12px;
```
— `"Why 82%"`: 11px, 700, uppercase, #94A3B8, letter-spacing 0.05em  
— Delta `"82% → 92% after action"`: 11px, 700, #166534, Roboto Mono

Raisons négatives (points N.crit):
```
• "Revenue projection provisional — CRM pending"
• "CFO pre-review not started"
```
Chaque ligne: `display:flex; gap:7px; font-size:12px; color:#991B1B; margin-bottom:5px; line-height:1.4`  
Dot: `width:4px; height:4px; border-radius:50%; background:#991B1B; flex-shrink:0; margin-top:5px`

Séparateur: `height:1px; background:#E2E8F0; margin: 10px 0 8px`

Raisons positives (points N.success):
```
• "3 options fully evaluated"
• "Infrastructure capacity validated"
```
Chaque ligne: `font-size:12px; color:#166534`

Missing block:
```css
margin-top: 8px;
padding: 8px 10px;
background: #FFFBEB;
border-radius: 7px;
border: 1px solid #FDE68A;
font-size: 11px;
color: #92400E;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Contenu: `"Missing: CRM export — revenue section provisional"`

Bouton close (X):
```css
position: absolute;
top: 10px;
right: 10px;
background: none;
border: none;
cursor: pointer;
color: #94A3B8;
```
Icône: `<X size={12} strokeWidth={2} />`

**Statement:**
```css
font-size: 14px;
font-weight: 600;
color: #0F172A;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
line-height: 1.4;
```
Contenu: `"Approve Q3 budget increase of €420k for cloud infrastructure"`

**Urgency text:**
```css
font-size: 13px;
color: #991B1B;   /* N.crit */
margin-top: 3px;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Contenu: `"Without this decision by 15 July, the Q3 product launch is cancelled."`

### ArrowRight trailing
```css
flex-shrink: 0;
```
Icône: `<ArrowRight size={15} color="#94A3B8" strokeWidth={2} />`

---

## 7. BLOC E — ACTIVE WORK

### Conteneur
```css
margin-bottom: 20px;
```

### Label de section
```css
font-size: 11px;
font-weight: 600;
color: #94A3B8;
letter-spacing: 0.04em;
text-transform: uppercase;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
margin-bottom: 10px;
```
Contenu: `"Active work"`

### Liste des lignes
```css
display: flex;
flex-direction: column;
gap: 6px;
```

### WorkRow (par ligne, ×3)
```css
display: flex;
align-items: center;
gap: 14px;
padding: 13px 18px;
background: #FFFFFF;
border-radius: 10px;
border: 1px solid #E2E8F0;
cursor: pointer;
transition: all 200ms cubic-bezier(.2,0,0,1);
box-shadow: 0 1px 3px rgba(15,23,42,.06), 0 1px 2px rgba(15,23,42,.04);
```
Hover:
```css
border-color: #CBD5E1;
box-shadow: 0 4px 12px rgba(15,23,42,.08), 0 2px 4px rgba(15,23,42,.04);
```

**StatusDot:**
```css
width: 7px;
height: 7px;
border-radius: 50%;
flex-shrink: 0;
background: #166534;   /* ok=true (health active|complete) → N.success */
             #E2E8F0;  /* ok=false (health attention|blocked) → N.border */
```

**Body (flex: 1, min-width: 0):**

Outcome:
```css
font-size: 13px;
font-weight: 500;
color: #0F172A;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
overflow: hidden;
text-overflow: ellipsis;
white-space: nowrap;
```

nextAction:
```css
font-size: 12px;
color: #475569;         /* N.textSec — health normal */
       #991B1B;         /* N.crit — health === "blocked" */
margin-top: 2px;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```

**ConfChip (inline, par ligne):**  
Rendu identique au ConfChip de la decision card mais avec les données de chaque work item.

| Work item | pct | afterAction | StatusDot |
|---|---|---|---|
| w1 — Q3 budget presentation | 76% | 92% | grey (#E2E8F0) — attention |
| w2 — Customer churn analysis | 41% | 68% | grey (#E2E8F0) — active → vert |
| w3 — Supply chain partner | 22% | 45% | grey (#E2E8F0) — blocked |

Note: StatusDot `ok = health === "active" || health === "complete"`. `w2.health = "active"` → vert. `w1.health = "attention"` et `w3.health = "blocked"` → gris.

**Deadline date:**
```css
font-size: 12px;
color: #94A3B8;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
flex-shrink: 0;
```
Valeurs: `"18 Jul"` / `"22 Jul"` / `"31 Jul"`

---

## 8. BLOC F — NOVA BACKGROUND STRIP

```css
padding: 12px 18px;
background: #F5F3FF;    /* N.innoBg */
border-radius: 10px;
border: 1px solid #DDD6FE;  /* N.innoBrd */
display: flex;
align-items: center;
gap: 10px;
```

**NOVALabel:** Identique au hero block (cf. §5.1)

**Texte statut:**
```css
font-size: 13px;
color: #6D28D9;    /* N.inno */
font-family: 'Inter', system-ui, -apple-system, sans-serif;
flex: 1;
```
Contenu: `"Working in background · You save approximately "` + `<strong>6 hours of review</strong>` + `" this week · 1 conflict detected"`

`<strong>` hérite de la couleur parente (#6D28D9), poids 700.

**"Details" link:**
```css
font-size: 12px;
color: #6D28D9;
background: none;
border: none;
cursor: pointer;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
display: flex;
align-items: center;
gap: 3px;
```
Contenu: `"Details"` + `<ChevronRight size={11} strokeWidth={2} color="#6D28D9" />`

---

## 9. BLOC G — DRAWER "Situation details"

Rendu uniquement quand `detailOpen === true`.

### Backdrop
```css
position: fixed;
inset: 0;
z-index: 50;
```

**Fond backdrop (inner div):**
```css
position: absolute;
inset: 0;
background: rgba(15,23,42,0.2);
backdrop-filter: blur(2px);
```
Click → `setDetailOpen(false)`

### Panneau
```css
position: absolute;
top: 0;
right: 0;
bottom: 0;
width: 460px;
background: #FFFFFF;
box-shadow: 0 20px 48px rgba(15,23,42,.16), 0 4px 8px rgba(15,23,42,.08);
display: flex;
flex-direction: column;
```

### Header du drawer
```css
display: flex;
align-items: center;
justify-content: space-between;
padding: 20px 24px;
border-bottom: 1px solid #E2E8F0;
flex-shrink: 0;
```

Titre:
```css
font-size: 15px;
font-weight: 650;
color: #0F172A;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
letter-spacing: -0.015em;
```
Contenu: `"Situation details"`

Bouton close:
```css
background: none;
border: none;
cursor: pointer;
color: #94A3B8;
padding: 4px;
```
Icône: `<X size={15} strokeWidth={2} />`

### Corps du drawer
```css
flex: 1;
overflow-y: auto;
padding: 24px;
```

### 9.1 DrawerSection — header commun à toutes les sections
```css
margin-bottom: 24px;
```
Label:
```css
font-size: 10px;
font-weight: 700;
color: #94A3B8;
text-transform: uppercase;
letter-spacing: 0.06em;
margin-bottom: 10px;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```

---

### 9.2 Section "Summary"
Paragraphe:
```css
font-size: 14px;
color: #0F172A;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
line-height: 1.65;
margin: 0;
```
Contenu: `"The board presentation is the highest priority item. It is 72% complete and blocked by 3 open comments and 1 missing source. Resolving these raises confidence from 76% to 92% and unblocks the CFO review."`

### 9.3 Section "Why it matters"
Paragraphe:
```css
font-size: 13px;
color: #475569;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
line-height: 1.6;
margin: 0;
```
Contenu: `"The CFO must review and pre-approve the budget figures before the 18 July board meeting. Without his sign-off, the budget decision cannot be made at the meeting."`

### 9.4 Section "What is blocking"
3 items:
```css
display: flex;
gap: 8px;
font-size: 13px;
color: #991B1B;
margin-bottom: 5px;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
```
Icône: `<AlertTriangle size={11} style={{ flexShrink:0, marginTop:2 }} strokeWidth={2} color="#991B1B" />`

Contenu:
1. `"3 open comments in revenue section — Sarah Chen"`
2. `"CRM Pipeline Export not loaded — revenue projection provisional"`
3. `"Product Roadmap deck outdated by 6 days"`

### 9.5 Section "Later actions"
Items (depuis `WORK_ITEMS.flatMap(w => [...w.laterActions, ...w.backgroundActions])`):
```css
font-size: 13px;
color: #475569;
font-family: 'Inter', system-ui, -apple-system, sans-serif;
padding: 8px 0;
border-bottom: 1px solid #E2E8F0;
```
Contenu (6 items):
1. `"Refresh the Product Roadmap deck (6 days old)"`
2. `"Request CRM export from IT"`
3. `"NOVA final consistency check before publication"`
4. `"Approve CRM export access with IT"`
5. `"NOVA preparing recommendation draft"`
6. `"Chase vendor NDA"`
7. `"Schedule partner kickoff once legal clears"`

### 9.6 Section "Technical details"
DrawerRow ×4:
```css
/* DrawerRow */
display: flex;
justify-content: space-between;
align-items: flex-start;
padding: 9px 0;
border-bottom: 1px solid #E2E8F0;
```
Label: `font-size: 13px; color: #475569; font-family: Inter`  
Value: `font-size: 13px; font-weight: 600; color: #0F172A; font-family: Inter; text-align: right; max-width: 220px`

| Label | Value |
|---|---|
| Documents analysed | 42 |
| Sources validated | 3 of 4 |
| Time saved | ~6 h |
| Conflicts detected | 1 |

---

## 10. DONNÉES (WORK_ITEMS pour la HOME)

### w1 — Affiché dans le hero + work rows + decision card
```
outcome:         "Prepare Q3 budget review presentation for the board"
heroSentence:    "Your board presentation is blocked by 3 open comments and a missing CRM source."
heroGain:        "Spend 15 minutes resolving the comments today and validation probability rises from 76% to 92%."
nextAction:      "Review Sarah Chen's 3 comments in the revenue section"
nextActionTime:  "~15 min"
nextActionGain:  "Unblocks CFO review"
nextActionConfDelta: "76% → 92%"
nextActionWhy:   "These 3 comments block the CFO pre-review, which is required before the 18 July board deadline. The CRM export is separately missing — NOVA estimates 1–2 days to obtain it from IT."
deadline:        "18 Jul"
health:          "attention"
confidence:      76
confAfterAction: 92
confReasons:     ["3 comments unresolved in revenue section", "Product Roadmap source outdated", "CFO review not started"]
confPositive:    ["Financial model cross-checked — capex section clear", "Sarah Chen validated financial assumptions"]
confMissing:     "CRM export — revenue section provisional until loaded"
```

### w2
```
outcome:         "Analyze reasons for customer churn increase in June"
nextAction:      "Review NOVA synthesis draft"
deadline:        "22 Jul"
health:          "active"
confidence:      41 → StatusDot vert car health==="active"
confAfterAction: 68
```

### w3
```
outcome:         "Onboard new supply chain partner for EU operations"
nextAction:      "Assign an owner to the overdue legal review"
deadline:        "31 Jul"
health:          "blocked"
confidence:      22
confAfterAction: 45
```

---

## 11. INTERACTIONS

| Élément | Trigger | Action |
|---|---|---|
| Composer (collapsed) | onClick | `setComposerOpen(true)` + `setTimeout(() => ref.current?.focus(), 50)` |
| Suggestion pill | onClick | `setComposerOpen(true)` + `setVal(ex)` + focus |
| Textarea | Cmd+Enter | `setLoading(true)` → 500ms → `setView("clarify")` |
| CTA "Continue" | onClick | `setLoading(true)` → 500ms → `setView("clarify")` (guard: `!val.trim()` → disabled) |
| Cancel composer | onClick | `setComposerOpen(false)` + `setVal("")` |
| Hero "Open presentation" | onClick | `setActiveWork("w1")` + `setView("work")` |
| WhyInline trigger | onClick | `setOpen(!open)` (toggle expansion) |
| "Details" link (hero) | onClick | `setDetailOpen(true)` |
| Decision Card | onClick | `setActiveDecision("d1")` + `setView("decision-package")` |
| WorkRow | onClick | `setActiveWork(w.id)` + `setView("work")` |
| WorkRow hover | onMouseEnter/Leave | `borderColor` → `#CBD5E1` + `boxShadow` → SH.cardHv / reset |
| "Details" link (NOVA strip) | onClick | `setDetailOpen(true)` |
| ConfChip | onClick | `setOpen(!open)` |
| ConfChip close (X) | onClick | `setOpen(false)` |
| ConfChip popover | onClick | `e.stopPropagation()` |
| Drawer backdrop | onClick | `setDetailOpen(false)` |
| Drawer X | onClick | `setDetailOpen(false)` |

---

## 12. STATE LOCAL (HomeView)

| Variable | Type | Init | Rôle |
|---|---|---|---|
| `val` | string | `""` | Valeur textarea composer |
| `composerOpen` | boolean | `false` | Affiche état expanded/collapsed du composer |
| `loading` | boolean | `false` | État de chargement (CTA + spinner) |
| `detailOpen` | boolean | `false` | Ouvre le drawer "Situation details" |
| `ref` | `RefObject<HTMLTextAreaElement>` | `useRef` | Focus programmatique sur textarea |

---

## 13. ORDRE VISUEL (Z)

| Élément | Z-index | Notes |
|---|---|---|
| Page content | 0 | Tous les blocs A–F |
| ConfChip popover | 30 | Au-dessus des cards |
| Drawer backdrop | 50 | Recouvre toute la page |
| Drawer panneau | (au-dessus du backdrop via positionnement absolu dans le même z-50 stacking context) |

---

## 14. ANIMATION

| Élément | Propriété animée | Durée | Easing |
|---|---|---|---|
| Composer card (open/close) | border, boxShadow | 280ms | cubic-bezier(.2,0,0,1) |
| Btn hover | background, boxShadow, transform | 200ms | cubic-bezier(.2,0,0,1) |
| WorkRow hover | borderColor, boxShadow | 200ms | cubic-bezier(.2,0,0,1) |
| Suggestion pill hover | borderColor, color, background | 120ms | cubic-bezier(.2,0,0,1) |
| WhyInline ChevronDown | rotate(180deg) | 200ms | cubic-bezier(.2,0,0,1) |
| ConfChip ChevronDown | rotate(180deg) | 200ms | cubic-bezier(.2,0,0,1) |
| CTA loading spinner | spin 1s linear infinite | ∞ | linear |

```css
@keyframes spin {
  from { transform: rotate(0deg); }
  to   { transform: rotate(360deg); }
}
```

---

## 15. CHECKLIST PIXEL-PERFECT — HOME UNIQUEMENT

- [ ] Canvas background `#F8FAFC` (pas blanc, pas gray-100)
- [ ] Header: 27px 650 weight -0.03em letter-spacing
- [ ] Composer collapsed: border 1.5px `#CBD5E1`, shadow SH.cardHv
- [ ] Composer expanded: border 1.5px `#1D4ED8` + ring `rgba(29,78,216,.07)`
- [ ] Composer transition: 280ms (plus lent que le standard 200ms)
- [ ] Icône Sparkles composer: 36×36 container `#EFF6FF`, Sparkles 15px `#1D4ED8`
- [ ] Suggestion pills: border-radius 999px, transition 120ms
- [ ] Hero: gradient `135deg #EFF6FF→#F5F3FF`, border `#DDD6FE`, shadow SH.hero
- [ ] Hero padding: `28px 32px`
- [ ] heroGain: 19px 700 -0.022em — texte le plus grand de la HOME
- [ ] heroSentence: 15px 400, couleur `#475569`
- [ ] heroGain marginBottom: 22px (avant la CTA row)
- [ ] CTA "Open presentation": Btn md primary + ArrowRight 14px
- [ ] WhyInline: text-decoration underline dotted, text-underline-offset 3px
- [ ] "Details" link: marginLeft auto (aligné à droite dans la CTA flex row)
- [ ] Decision card: accent border-left `3px solid #991B1B`
- [ ] Decision card icône: Scale 15px `#991B1B` dans container 36×36 `#FEF2F2`
- [ ] DeadlineBadge: Clock 9px + "Due in 4 days", border-radius 999px, padding 2px 9px
- [ ] ConfChip: Roboto Mono pour le pourcentage, Inter pour "confidence"
- [ ] Section label "Active work": 11px 600 uppercase 0.04em letter-spacing
- [ ] WorkRow: padding 13px 18px, border-radius 10px, gap 14px
- [ ] StatusDot: 7px circle — vert seulement si `health === "active" || "complete"`
- [ ] w2 (churn): StatusDot VERT car `health="active"`, malgré confidence 41% (rouge)
- [ ] NOVA strip: background `#F5F3FF`, border `#DDD6FE`, border-radius 10px, padding 12px 18px
- [ ] NOVA strip text: `#6D28D9`, `<strong>` hérite la couleur
- [ ] Drawer width: exactement 460px
- [ ] Drawer backdrop: `rgba(15,23,42,0.2)` + `blur(2px)`
- [ ] DrawerSection header: 10px 700 uppercase letter-spacing 0.06em `#94A3B8`
- [ ] DrawerRow: padding 9px 0 (pas 8px), border-bottom `#E2E8F0`
- [ ] DrawerRow label: 13px (pas 12px) `#475569`
- [ ] DrawerRow value: 13px 600, max-width 220px, text-align right
