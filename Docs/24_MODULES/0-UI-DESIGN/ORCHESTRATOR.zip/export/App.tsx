import { useState, useRef, useEffect } from "react";
import {
  ChevronRight, X, Bot, Calendar, Shield, BarChart2,
  Bell, List, Brain, AlertTriangle, CheckCircle, Clock,
  Zap, FileText, Send, Sparkles, ChevronDown,
  Bold, Italic, AlignLeft, Paperclip, Plus,
} from "lucide-react";

// ─── STAR DESIGN SYSTEM ───────────────────────────────────────────────────────
const S = {
  teal:         "#0F5962",
  tealDark:     "#0d4a52",
  tealLight:    "#e8f4f6",
  teal20:       "rgba(15,89,98,0.10)",
  cyan:         "#6CB4C7",
  coral:        "#FF9076",
  success:      "#10b981",
  successLight: "#d1fae5",
  warning:      "#f59e0b",
  warningLight: "#fef3c7",
  error:        "#ef4444",
  errorLight:   "#fee2e2",
  g50:  "#f9fafb", g100: "#f3f4f6", g200: "#e5e7eb", g300: "#d1d5db",
  g400: "#9ca3af", g500: "#6b7280", g600: "#4b5563", g700: "#374151", g900: "#111827",
  white: "#ffffff",
};
const shadow = {
  kpi: "0 2px 8px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04)",
  md:  "0 4px 12px rgba(0,0,0,0.08), 0 2px 4px rgba(0,0,0,0.05)",
  lg:  "0 10px 24px rgba(0,0,0,0.10), 0 4px 6px rgba(0,0,0,0.05)",
  xl:  "0 20px 40px rgba(0,0,0,0.14), 0 8px 12px rgba(0,0,0,0.06)",
};
const ease = "cubic-bezier(0.4,0,0.2,1)";
const T = `all 250ms ${ease}`;
const FONT = "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif";

// ─── DATA ─────────────────────────────────────────────────────────────────────
const PROGRAMS = [
  { id: "veedda", name: "VEEDDA", tagline: "Plateforme IA de traitement documentaire", health: 78, status: "attention" as const, phase: "Phase 2 / 4", budgetUsed: 82, missionsActive: 5, missionsCritical: 2, nextMilestone: { label: "Revue de phase", date: "4 juil.", daysLeft: 3 }, riskCount: 2, owner: "Sophie Martin", tags: ["IA Générative", "Documentaire"], team: 8, startDate: "Jan 2026", endDate: "Déc 2026", description: "Plateforme IA de traitement et classification documentaire pour les organismes publics." },
  { id: "orchestrator", name: "ORCHESTRATOR", tagline: "Cockpit de pilotage des programmes IA", health: 91, status: "nominal" as const, phase: "Phase 1 / 3", budgetUsed: 61, missionsActive: 3, missionsCritical: 0, nextMilestone: { label: "Sprint Review", date: "7 juil.", daysLeft: 6 }, riskCount: 0, owner: "Jeff Dupont", tags: ["Pilotage", "Multi-agents"], team: 4, startDate: "Avr 2026", endDate: "Déc 2026", description: "Cockpit de pilotage stratégique et opérationnel des programmes IA." },
];
const DECISIONS = [
  { id: "d1", title: "Valider l'architecture multi-agents VEEDDA", priority: "critique" as const, program: "VEEDDA", waitingDays: 5, deadline: "3 juil. 2026", impact: "Bloque 3 personnes. Sprint 8 à l'arrêt. €45k en attente.", context: "L'équipe technique attend votre validation pour démarrer le sprint 8. L'architecture proposée permet le traitement parallèle de 6 flux documentaires avec une résilience améliorée de 40%. Trois développeurs sont mobilisés sans pouvoir avancer depuis 5 jours.", recommendation: "Valider l'architecture proposée", options: [{ label: "Valider l'architecture proposée", type: "primary" as const }, { label: "Demander une révision mineure", type: "secondary" as const }, { label: "Reporter à la revue de phase", type: "secondary" as const }], agent: "Decision Assistant peut analyser les impacts" },
  { id: "d2", title: "Approuver le budget infrastructure cloud (+€12k)", priority: "haute" as const, program: "VEEDDA", waitingDays: 2, deadline: "7 juil. 2026", impact: "Risque de coupure de service. SLA non respecté.", context: "Les coûts d'infrastructure ont dépassé les prévisions de 23%. Une enveloppe de €12k est nécessaire avant le 7 juillet pour maintenir le SLA.", recommendation: "Approuver €12k supplémentaires", options: [{ label: "Approuver €12k supplémentaires", type: "primary" as const }, { label: "Approuver €8k et revoir l'architecture", type: "secondary" as const }, { label: "Escalader au sponsor", type: "secondary" as const }], agent: "Risk Monitor a analysé l'impact" },
  { id: "d3", title: "Choisir le partenaire d'intégration ORCHESTRATOR", priority: "normale" as const, program: "ORCHESTRATOR", waitingDays: 1, deadline: "10 juil. 2026", impact: "Démarre semaine 28. 3 candidats évalués.", context: "DataSync Pro obtient 87/100. L'équipe recommande ce choix.", recommendation: "Choisir DataSync Pro", options: [{ label: "Choisir DataSync Pro (87/100)", type: "primary" as const }, { label: "Choisir TechBridge (74/100)", type: "secondary" as const }, { label: "Relancer un appel d'offres", type: "secondary" as const }], agent: "Decision Assistant a synthétisé l'évaluation" },
  { id: "d4", title: "Valider la communication revue de phase VEEDDA", priority: "normale" as const, program: "VEEDDA", waitingDays: 0, deadline: "4 juil. 2026", impact: "12 parties prenantes. Revue dans 3 jours.", context: "Le document est prêt et validé par Sophie Martin.", recommendation: "Approuver et envoyer", options: [{ label: "Approuver et envoyer", type: "primary" as const }, { label: "Réviser avant envoi", type: "secondary" as const }, { label: "Déléguer à Sophie Martin", type: "secondary" as const }], agent: null },
];
type MilestoneStep = { label: string; done: boolean; active?: boolean; blocked?: boolean };
const MISSIONS: Array<{ id: string; name: string; program: string; status: "critique"|"retard"|"bloqué"|"en cours"|"planifié"; progress: number; deadline: string; daysLeft: number; owner: string; description: string; blockers: string[]; milestones: MilestoneStep[]; }> = [
  { id: "m1", name: "Intégration API Partenaires", program: "VEEDDA", status: "critique", progress: 34, deadline: "5 juil.", daysLeft: 4, owner: "Marc Leroy", description: "Connexion des 6 API partenaires prioritaires.", blockers: ["Accès sandbox non reçu de PartenairePlus", "Spec API v2 non finalisée"], milestones: [{ label: "Spécifications validées", done: true }, { label: "Développement", done: false, active: true }, { label: "Tests d'intégration", done: false }, { label: "Go-live", done: false }] },
  { id: "m2", name: "Module de classification IA", program: "VEEDDA", status: "retard", progress: 61, deadline: "12 juil.", daysLeft: 11, owner: "Amina Diallo", description: "Entraînement et déploiement du modèle de classification.", blockers: ["Dataset incomplet — 2 300 documents manquants"], milestones: [{ label: "Dataset préparé", done: true }, { label: "Modèle v1 entraîné", done: true }, { label: "Validation métier", done: false, active: true }, { label: "Déploiement prod", done: false }] },
  { id: "m3", name: "Architecture multi-agents", program: "VEEDDA", status: "bloqué", progress: 20, deadline: "18 juil.", daysLeft: 17, owner: "Pierre Nguyen", description: "Système d'orchestration multi-agents pour le traitement parallèle.", blockers: ["En attente de validation architecturale (Décision #1)"], milestones: [{ label: "POC validé", done: true }, { label: "Validation architecture", done: false, active: true, blocked: true }, { label: "Développement", done: false }, { label: "Tests de charge", done: false }] },
  { id: "m4", name: "Interface utilisateur v2", program: "VEEDDA", status: "en cours", progress: 74, deadline: "25 juil.", daysLeft: 24, owner: "Léa Fontaine", description: "Refonte de l'interface selon les nouveaux standards.", blockers: [], milestones: [{ label: "Maquettes validées", done: true }, { label: "Développement composants", done: true }, { label: "Intégration API", done: false, active: true }, { label: "Tests utilisateurs", done: false }] },
  { id: "m5", name: "Cockpit Mission Control", program: "ORCHESTRATOR", status: "en cours", progress: 88, deadline: "7 juil.", daysLeft: 6, owner: "Jeff Dupont", description: "Page principale du cockpit.", blockers: [], milestones: [{ label: "Spécifications", done: true }, { label: "Design", done: true }, { label: "Développement", done: true }, { label: "Finalisation", done: false, active: true }] },
  { id: "m6", name: "Module mémoire programme", program: "ORCHESTRATOR", status: "planifié", progress: 0, deadline: "31 juil.", daysLeft: 30, owner: "Thomas Bernard", description: "Système de mémoire persistante.", blockers: [], milestones: [{ label: "Spécifications", done: false, active: true }, { label: "Architecture", done: false }, { label: "Développement", done: false }, { label: "Tests", done: false }] },
];
const RISKS = [
  { id: "r1", title: "Retard livraison partenaire critique", level: "critique" as const, program: "VEEDDA", probability: "Élevée", impact: "Bloque la mise en production du module API", mitigation: "Identifier un partenaire alternatif avant le 5 juillet", owner: "Sophie Martin", updatedAt: "Aujourd'hui 09:14" },
  { id: "r2", title: "Dépassement budgétaire infrastructure", level: "critique" as const, program: "VEEDDA", probability: "Certaine", impact: "€12k supplémentaires, SLA à risque", mitigation: "Décision budgétaire requise avant le 7 juillet", owner: "Jeff Dupont", updatedAt: "Hier 16:30" },
  { id: "r3", title: "Dépendance modèle tiers non contractualisée", level: "moyen" as const, program: "ORCHESTRATOR", probability: "Modérée", impact: "Blocage potentiel en phase 2", mitigation: "Contrat en cours — signature semaine 28", owner: "Thomas Bernard", updatedAt: "29 juin" },
  { id: "r4", title: "Compétences ML insuffisantes", level: "moyen" as const, program: "VEEDDA", probability: "Modérée", impact: "Qualité du modèle dégradée", mitigation: "Formation planifiée semaine 29", owner: "Amina Diallo", updatedAt: "28 juin" },
];
const AGENTS_DATA = [
  { id: "a1", name: "VEEDDA Analyst", role: "Analyse documentaire & reporting", status: "actif" as const, program: "VEEDDA", currentTask: "Génération rapport hebdomadaire — 78%", progress: 78 as number|null, tasksCompleted: 47, lastActivity: "Il y a 2 min", memory: "12 sessions · 340 actions · 8 rapports générés" },
  { id: "a2", name: "Risk Monitor", role: "Surveillance des risques en temps réel", status: "actif" as const, program: "Multi-programmes", currentTask: "Surveillance continue — 4 risques trackés", progress: null as number|null, tasksCompleted: 128, lastActivity: "Il y a 8 min", memory: "31 sessions · 1 240 évaluations · 12 alertes émises" },
  { id: "a3", name: "Decision Assistant", role: "Synthèse et aide à la décision", status: "idle" as const, program: "Multi-programmes", currentTask: "En veille — prêt à analyser", progress: null as number|null, tasksCompleted: 23, lastActivity: "Hier 17:45", memory: "8 sessions · 23 décisions analysées" },
];
const UPCOMING_MILESTONES = [
  { date: "4 juil.", label: "Revue de phase VEEDDA", program: "VEEDDA", daysLeft: 3 },
  { date: "5 juil.", label: "Deadline API Partenaires", program: "VEEDDA", daysLeft: 4 },
  { date: "7 juil.", label: "Sprint Review ORCHESTRATOR", program: "ORCHESTRATOR", daysLeft: 6 },
  { date: "10 juil.", label: "Choix partenaire d'intégration", program: "ORCHESTRATOR", daysLeft: 9 },
];

// ─── V6 CONSTANTS ─────────────────────────────────────────────────────────────
const SPECIALIST_AGENTS = [
  { id: "architecture", name: "Architecture", icon: "⬡", color: S.teal, desc: "Analyse et conception système" },
  { id: "planning",     name: "Planning",     icon: "◷", color: S.cyan, desc: "Jalons, dépendances, délais" },
  { id: "finance",      name: "Finance",      icon: "◈", color: S.success, desc: "Projection budgétaire" },
  { id: "risk",         name: "Risk",         icon: "▲", color: S.error, desc: "Identification et mitigation" },
  { id: "legal",        name: "Legal",        icon: "⚖", color: S.g600, desc: "Conformité et contrats" },
  { id: "qa",           name: "QA",           icon: "✓", color: S.success, desc: "Qualité et validation" },
  { id: "document",     name: "Document",     icon: "□", color: S.g500, desc: "Synthèse et rédaction" },
  { id: "classification", name: "Classification", icon: "⊞", color: S.warning, desc: "Catégorisation IA" },
];
const CONTEXT_TYPES = [
  { id: "programme", label: "Programme", icon: "●", options: ["VEEDDA", "ORCHESTRATOR"] },
  { id: "mission",   label: "Mission",   icon: "◆", options: MISSIONS.slice(0, 3).map(m => m.name) },
  { id: "risque",    label: "Risque",    icon: "▲", options: RISKS.slice(0, 2).map(r => r.title) },
  { id: "budget",    label: "Budget",    icon: "◈", options: ["Budget Phase 2 — VEEDDA", "Budget Q3 — ORCHESTRATOR"] },
  { id: "document",  label: "Document",  icon: "□", options: ["Cahier des charges VEEDDA v2", "Architecture STAR"] },
  { id: "architecture", label: "Architecture", icon: "⬡", options: ["Multi-agents v2", "API Gateway v2"] },
  { id: "reunion",   label: "Réunion",   icon: "◉", options: ["COPIL Phase 2 — 4 juil.", "Sprint Review — 7 juil."] },
];
const RECENT_MISSIONS = [
  { time: "09:14", name: "Analyse Architecture VEEDDA", agents: ["architecture", "risk"], status: "completed" },
  { time: "09:32", name: "Audit Budget Infrastructure", agents: ["finance"], status: "completed" },
  { time: "10:11", name: "Préparation COPIL Phase 2", agents: ["planning", "document"], status: "completed" },
  { time: "11:42", name: "Comparaison scénarios runtime", agents: ["architecture", "qa"], status: "completed" },
];
const AGENT_PHASES: Record<string, { tasks: string[]; target: number }> = {
  architecture:    { tasks: ["Analyse du système...", "Cartographie des dépendances...", "Évaluation des impacts..."], target: 72 },
  planning:        { tasks: ["Lecture des jalons...", "Détection des conflits...", "Terminé — 2 conflits détectés"], target: 100 },
  finance:         { tasks: ["Lecture du budget...", "Projection des coûts...", "Estimation : +€42k"], target: 81 },
  risk:            { tasks: ["Scan des risques...", "Évaluation des probabilités...", "2 risques critiques identifiés"], target: 58 },
  legal:           { tasks: ["Vérification contrats...", "Analyse conformité..."], target: 45 },
  qa:              { tasks: ["Revue qualité...", "Tests de régression..."], target: 67 },
  document:        { tasks: ["Lecture documents...", "Synthèse en cours..."], target: 55 },
  classification:  { tasks: ["Classification des éléments...", "Catégorisation IA..."], target: 80 },
};

// ─── MISSION STUDIO V7 CONSTANTS ──────────────────────────────────────────────
const MISSION_TEMPLATES = [
  { id: "audit-arch", icon: "⬡", label: "Audit Architecture", objective: "Auditer l'architecture technique du programme VEEDDA", text: "Analyse l'architecture multi-agents VEEDDA et identifie les points de fragilité, les risques techniques et les optimisations possibles. Évalue la conformité avec les standards STAR et propose des recommandations priorisées avec plan d'action." },
  { id: "copil", icon: "◷", label: "Préparer un COPIL", objective: "Préparer le comité de pilotage Phase 2 VEEDDA — 4 juillet", text: "Prépare un dossier complet pour le COPIL Phase 2 VEEDDA. Inclure : bilan d'avancement, risques actifs, décisions en attente, planning phase 3 et recommandations stratégiques. Format exécutif, max 2 pages." },
  { id: "risk-analysis", icon: "▲", label: "Analyse de risque", objective: "Analyser les risques critiques du programme VEEDDA", text: "Identifie, analyse et priorise les risques actifs sur VEEDDA. Pour chaque risque : probabilité, impact, coût estimé, plan de mitigation et responsable. Focus sur les risques bloquants à traiter cette semaine." },
  { id: "audit-qa", icon: "✓", label: "Audit qualité", objective: "Auditer la qualité des livrables VEEDDA Phase 2", text: "Évalue la qualité des livrables de la phase 2 VEEDDA : conformité aux standards, dette technique, couverture de tests, documentation. Produit un rapport de qualité avec plan d'action correctif priorisé." },
  { id: "finance", icon: "◈", label: "Analyse financière", objective: "Analyser la situation budgétaire des programmes", text: "Analyse les dépassements budgétaires VEEDDA (+23% infrastructure). Compare prévisions vs réalisé. Identifie les causes de dépassement, projette la fin de phase et propose des options de réajustement budgétaire." },
  { id: "doc", icon: "□", label: "Documentation", objective: "Générer la documentation technique du programme", text: "Produis une documentation complète du programme VEEDDA : architecture, APIs, processus, décisions prises et leur rationale. Format compatible avec les standards de l'écosystème STAR." },
  { id: "compte-rendu", icon: "◉", label: "Compte-rendu", objective: "Rédiger un compte-rendu de la session de pilotage", text: "Rédige un compte-rendu structuré de la session de pilotage. Inclure : points abordés, décisions prises, actions à suivre, responsables et échéances. Format exécutif, max 2 pages." },
  { id: "roadmap", icon: "⊞", label: "Roadmap Phase 3", objective: "Construire la roadmap de la phase 3 VEEDDA", text: "Génère une roadmap détaillée pour la phase 3 VEEDDA basée sur les livrables de la phase 2. Inclure : jalons, dépendances, ressources, risques anticipés et critères de succès." },
];
const DELIVERABLES = ["Rapport", "Synthèse", "Roadmap", "Plan d'action", "Décisions", "Tickets", "Documentation", "Diagrammes"];
const ANALYSIS_STEPS = [
  { text: "Programme VEEDDA analysé — Phase 2 / 4", state: "done" },
  { text: "Décision active identifiée — Architecture multi-agents (critique)", state: "done" },
  { text: "Documents liés en lecture...", state: "active" },
  { text: "Risques actifs en évaluation — 2 critiques", state: "active" },
  { text: "Agents spécialisés en sélection...", state: "pending" },
  { text: "Plan d'exécution en préparation...", state: "pending" },
];
const AGENT_PRE_STATES: Record<string, Array<{ text: string; phase: "ready"|"active"|"done" }>> = {
  architecture: [{ text: "Disponible", phase: "ready" }, { text: "Lecture du contexte...", phase: "active" }, { text: "Analyse des dépendances...", phase: "active" }, { text: "Prêt", phase: "done" }],
  planning:     [{ text: "Disponible", phase: "ready" }, { text: "Scan des jalons...", phase: "active" }, { text: "Vérification des délais...", phase: "active" }, { text: "Prêt", phase: "done" }],
  finance:      [{ text: "Disponible", phase: "ready" }, { text: "Lecture du budget...", phase: "active" }, { text: "Prêt", phase: "done" }],
  risk:         [{ text: "Disponible", phase: "ready" }, { text: "Détection des risques...", phase: "active" }, { text: "2 risques identifiés", phase: "done" }],
};

// ─── TYPES ────────────────────────────────────────────────────────────────────
type Page = "mission-control" | "commandement" | "pilotage";
type OpTab = "missions" | "agents" | "risques" | "roadmap" | "memoire";
type StudioState = "idle" | "editing" | "running";
interface ChatMessage { id: string; role: "user"|"assistant"; content: string; time: string; typing?: boolean; actions?: string[]; }
type DrawerItem =
  | { type: "decision"; data: (typeof DECISIONS)[number] }
  | { type: "program";  data: (typeof PROGRAMS)[number] }
  | { type: "mission";  data: (typeof MISSIONS)[number] }
  | { type: "risk";     data: (typeof RISKS)[number] }
  | { type: "agent";    data: (typeof AGENTS_DATA)[number] };

// ─── AI MOCK V6 ───────────────────────────────────────────────────────────────
const INITIAL_ACTIVITY = [
  { id: "e1", time: "11:42", agent: "Architecture Agent", icon: "⬡", action: "a produit une recommandation architecturale", program: "ORCHESTRATOR", color: "#0F5962" },
  { id: "e2", time: "11:38", agent: "Finance Agent", icon: "◈", action: "a terminé l'estimation budgétaire — +€42k", program: "VEEDDA", color: "#10b981" },
  { id: "e3", time: "11:31", agent: "Planning Agent", icon: "◷", action: "a recalculé les jalons — 2 conflits détectés", program: "VEEDDA", color: "#6CB4C7" },
  { id: "e4", time: "11:24", agent: "Risk Monitor", icon: "▲", action: "a détecté un nouveau risque critique", program: "VEEDDA", color: "#ef4444" },
  { id: "e5", time: "11:15", agent: "VEEDDA Analyst", icon: "◉", action: "a généré le rapport hebdomadaire (78%)", program: "VEEDDA", color: "#0F5962" },
  { id: "e6", time: "11:08", agent: "Decision Assistant", icon: "◆", action: "a synthétisé 2 options de décision", program: "ORCHESTRATOR", color: "#0F5962" },
];
const ACTIVITY_POOL = [
  { agent: "Risk Monitor", icon: "▲", action: "a détecté un signal d'alerte sur le retard API", program: "VEEDDA", color: "#ef4444" },
  { agent: "Planning Agent", icon: "◷", action: "a recalculé les jalons — 1 conflit résolu", program: "VEEDDA", color: "#6CB4C7" },
  { agent: "Finance Agent", icon: "◈", action: "a mis à jour la projection budgétaire", program: "VEEDDA", color: "#10b981" },
  { agent: "Architecture Agent", icon: "⬡", action: "a produit une nouvelle recommandation", program: "ORCHESTRATOR", color: "#0F5962" },
  { agent: "VEEDDA Analyst", icon: "◉", action: "a analysé 47 nouveaux documents", program: "VEEDDA", color: "#0F5962" },
  { agent: "Risk Monitor", icon: "▲", action: "a évalué 3 nouvelles dépendances critiques", program: "VEEDDA", color: "#ef4444" },
  { agent: "ORCHESTRATOR", icon: "⚡", action: "a créé une nouvelle décision à valider", program: "Système", color: "#0F5962" },
];
const KNOWLEDGE_BASE = [
  { id: "k1", insight: "Pattern multi-agents validé pour traitement parallèle", agent: "Architecture", usages: 5, confidence: 89, missions: 3, docs: 2 },
  { id: "k2", insight: "API Gateway — vulnérabilité TLS v1.1 identifiée", agent: "Risk", usages: 3, confidence: 95, missions: 1, docs: 1 },
  { id: "k3", insight: "Dataset VEEDDA — 2 300 docs incomplets (Lot B manquant)", agent: "VEEDDA Analyst", usages: 2, confidence: 100, missions: 1, docs: 1 },
  { id: "k4", insight: "Budget infrastructure : +23% de dépassement sur instances GPU", agent: "Finance", usages: 4, confidence: 87, missions: 2, docs: 2 },
  { id: "k5", insight: "Partenaire PartenairePlus : délais de réponse > 48h en moyenne", agent: "Risk", usages: 2, confidence: 78, missions: 1, docs: 0 },
  { id: "k6", insight: "Modèle v1 VEEDDA : accuracy 89% — meilleur résultat de la phase", agent: "VEEDDA Analyst", usages: 3, confidence: 100, missions: 2, docs: 1 },
];
const AGENT_PROFILES: Record<string, { specialty: string; expertise: string[]; recentWork: Array<{ label: string; time: string }>; metrics: { missionsRealized: number; confidence: number; timeConsumed: string; documents: number }; memory: string[] }> = {
  architecture: { specialty: "Analyse et conception système", expertise: ["Architecture distribuée", "API & intégrations", "Dépendances techniques", "Performance"], recentWork: [{ label: "Recommandation architecturale VEEDDA", time: "Il y a 2h" }, { label: "Analyse API Partenaires", time: "Il y a 4h" }, { label: "Cartographie des dépendances", time: "Il y a 6h" }], metrics: { missionsRealized: 12, confidence: 94, timeConsumed: "48h", documents: 8 }, memory: ["Pattern multi-agents validé", "API Gateway — vulnérabilité TLS v1.1", "Dépendance circulaire micro-services"] },
  planning: { specialty: "Jalons, dépendances et délais", expertise: ["Planification agile", "Gestion des conflits", "Dépendances inter-missions", "Prévision"], recentWork: [{ label: "Recalcul jalons VEEDDA — 2 conflits", time: "Il y a 31 min" }, { label: "Mise à jour roadmap Phase 3", time: "Il y a 3h" }], metrics: { missionsRealized: 8, confidence: 88, timeConsumed: "22h", documents: 4 }, memory: ["Conflit planning semaine 28 — résolu", "Jalons Phase 3 dépendent du budget"] },
  finance: { specialty: "Projection budgétaire et audit financier", expertise: ["Analyse des coûts", "Projection budgétaire", "Audit de dépassements", "ROI IA"], recentWork: [{ label: "Estimation budgétaire +€42k", time: "Il y a 38 min" }, { label: "Audit infrastructure cloud", time: "Il y a 5h" }], metrics: { missionsRealized: 6, confidence: 91, timeConsumed: "18h", documents: 5 }, memory: ["Dépassement infra +23%", "Coût IA estimé : €9k/jour de retard"] },
  risk: { specialty: "Identification et mitigation des risques", expertise: ["Risk assessment", "Impact analysis", "Dépendances critiques", "Alertes préventives"], recentWork: [{ label: "Alerte risque partenaire critique", time: "Il y a 24 min" }, { label: "Évaluation 3 dépendances", time: "Il y a 2h" }], metrics: { missionsRealized: 15, confidence: 96, timeConsumed: "61h", documents: 12 }, memory: ["Partenaire PartenairePlus : délais > 48h", "Budget infra : seuil critique dépassé"] },
};

function generateResponse(objective: string): { content: string; actions: string[] } {
  const p = (objective || "").toLowerCase();
  if (p.includes("risque") || p.includes("impact") || p.includes("retard") || p.includes("api")) {
    return {
      content: `**Analyse terminée en 3.8 secondes.**\n\nRésultats de l'analyse multi-agents :\n\n• **2 risques critiques** dans la chaîne de livraison API — partenaire sans accès sandbox depuis 5 jours\n• **1 conflit planning** détecté — la deadline du 5 juillet est incompatible avec l'état actuel (34%)\n• **Coût estimé si non résolu : 42 k€** (€9k/jour × J-5 de retard cumulé)\n\nJe recommande :\n• Créer une revue exceptionnelle avec Marc Leroy avant le 3 juillet\n• Notifier les parties prenantes du risque partenaire\n• Préparer un plan B avec un partenaire alternatif`,
      actions: ["Créer les missions", "Notifier Marc Leroy", "Préparer le rapport", "Créer la décision"],
    };
  }
  if (p.includes("revue") || p.includes("phase") || p.includes("copil")) {
    return {
      content: `**Dossier de revue préparé en 2.1 secondes.**\n\nPoints clés identifiés pour la revue du 4 juillet :\n\n• **Points positifs** : Interface v2 à 74%, modèle IA accuracy 89%\n• **Points d'attention** : API Partenaires à 34% seulement, 2 blocages actifs\n• **Décisions requises** : Validation architecture (urgente), budget infrastructure\n\nStructure recommandée :\n1. Bilan Phase 2 — 10 min\n2. Risques actifs — 15 min\n3. Décisions en attente — 20 min\n4. Planning Phase 3 — 10 min`,
      actions: ["Créer le support", "Programmer la revue", "Notifier les parties prenantes", "Exporter le dossier"],
    };
  }
  if (p.includes("architecture") || p.includes("multi-agent") || p.includes("bloqu")) {
    return {
      content: `**Analyse architecturale terminée en 4.2 secondes.**\n\n**Option A — Valider immédiatement (recommandée)**\nDébloque 3 développeurs dès demain. Coût de l'attente : €9k/jour.\nRisque technique : faible — architecture validée par Pierre Nguyen.\n\n**Option B — Révision partielle (+3 jours)**\nAjustement tolérance aux pannes. Repousse sprint 8 au 8 juillet.\n\n**Verdict Architecture Agent** : L'architecture est solide. Le risque du retard dépasse largement le risque technique. Recommande la validation immédiate.`,
      actions: ["Valider l'architecture", "Créer la décision", "Notifier l'équipe", "Générer la note technique"],
    };
  }
  return {
    content: `**Analyse terminée en 3.2 secondes.**\n\nJ'ai analysé le contexte de vos programmes VEEDDA et ORCHESTRATOR.\n\n**Priorités identifiées :**\n\n• **Décision urgente** — L'architecture multi-agents bloque 3 personnes depuis 5 jours. Coût : €9k/jour. Priorité absolue.\n• **Revue de phase** — Dans 3 jours. Les décisions #1, #2 et #4 doivent être traitées avant.\n• **Budget infrastructure** — €12k nécessaires avant le 7 juillet pour maintenir le SLA.\n\n**Recommandation immédiate** : Traitez la décision #1 maintenant. Impact maximal, risque minimal.`,
    actions: ["Créer les missions", "Planifier les actions", "Générer le rapport", "Créer la décision"],
  };
}

function renderMD(text: string) {
  return text.split("\n").map((line, i) => {
    const parts = line.split(/(\*\*[^*]+\*\*)/g);
    const content = parts.map((part, j) =>
      part.startsWith("**") && part.endsWith("**")
        ? <strong key={j} style={{ fontWeight: 600, color: S.g900 }}>{part.slice(2, -2)}</strong>
        : <span key={j}>{part}</span>
    );
    return <div key={i} style={{ minHeight: line === "" ? 8 : undefined, lineHeight: 1.65 }}>{content}</div>;
  });
}

// ─── STAR BADGE ───────────────────────────────────────────────────────────────
function STARBadge({ variant, label }: { variant: "error"|"warning"|"success"|"primary"|"neutral"; label: string; }) {
  const s = { error: { bg: S.errorLight, color: "#b91c1c", dot: S.error }, warning: { bg: S.warningLight, color: "#92400e", dot: S.warning }, success: { bg: S.successLight, color: "#065f46", dot: S.success }, primary: { bg: S.tealLight, color: S.teal, dot: S.teal }, neutral: { bg: S.g100, color: S.g600, dot: S.g400 } }[variant];
  return <span style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "2px 8px", borderRadius: 9999, fontSize: 11, fontWeight: 500, background: s.bg, color: s.color }}><span style={{ width: 6, height: 6, borderRadius: "50%", background: s.dot, flexShrink: 0 }} />{label}</span>;
}

// ─── TOP BAR ──────────────────────────────────────────────────────────────────
function TopBar({ page, setPage }: { page: Page; setPage: (p: Page) => void }) {
  return (
    <header style={{ height: 54, background: S.teal, display: "flex", alignItems: "center", padding: "0 28px", gap: 24, flexShrink: 0, zIndex: 30 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, width: 200, flexShrink: 0 }}>
        <div style={{ width: 28, height: 28, background: "rgba(255,255,255,0.15)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid rgba(255,255,255,0.2)" }}><Zap size={14} color={S.white} /></div>
        <span style={{ fontSize: 13, fontWeight: 700, color: S.white, letterSpacing: "-0.2px" }}>ORCHESTRATOR</span>
      </div>
      <nav style={{ flex: 1, display: "flex", justifyContent: "center", gap: 2 }}>
        {([
          { id: "mission-control" as Page, label: "Mission Control" },
          { id: "commandement" as Page, label: "Centre de commandement" },
          { id: "pilotage" as Page, label: "Pilotage opérationnel" },
        ]).map(tab => (
          <button key={tab.id} onClick={() => setPage(tab.id)} style={{ padding: "6px 16px", borderRadius: 20, fontSize: 13, fontWeight: 500, border: "none", cursor: "pointer", transition: T, background: page === tab.id ? "rgba(255,255,255,0.18)" : "transparent", color: page === tab.id ? S.white : "rgba(255,255,255,0.6)" }}
            onMouseEnter={e => { if (page !== tab.id) e.currentTarget.style.background = "rgba(255,255,255,0.09)"; }}
            onMouseLeave={e => { if (page !== tab.id) e.currentTarget.style.background = "transparent"; }}
          >{tab.label}</button>
        ))}
      </nav>
      <div style={{ display: "flex", alignItems: "center", gap: 14, width: 200, justifyContent: "flex-end", flexShrink: 0 }}>
        <div style={{ position: "relative" }}><Bell size={16} color="rgba(255,255,255,0.7)" style={{ cursor: "pointer" }} /><span style={{ position: "absolute", top: -3, right: -3, width: 7, height: 7, background: S.coral, borderRadius: "50%", border: `1.5px solid ${S.teal}` }} /></div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 28, height: 28, borderRadius: "50%", background: "rgba(255,255,255,0.18)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: S.white, border: "1px solid rgba(255,255,255,0.25)" }}>JD</div>
          <span style={{ fontSize: 13, fontWeight: 500, color: S.white }}>Jeff</span>
        </div>
      </div>
    </header>
  );
}

// ─── PRIORITY ACTION CARD ─────────────────────────────────────────────────────
function PriorityActionCard({ decision, totalDecisions, compact, onContext, onViewAll }: {
  decision: (typeof DECISIONS)[number]; totalDecisions: number; compact?: boolean;
  onContext: () => void; onViewAll: () => void;
}) {
  const [actionTaken, setActionTaken] = useState<string | null>(null);
  const [hovered, setHovered] = useState(false);
  const barColor = decision.priority === "critique" ? S.error : S.warning;

  if (compact) {
    return (
      <div>
        <div style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: 10 }}>Action prioritaire</div>
        <button onClick={onContext} style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "14px 14px 14px 18px", textAlign: "left", cursor: "pointer", transition: T, position: "relative", overflow: "hidden", width: "100%", display: "block" }}
          onMouseEnter={e => (e.currentTarget.style.boxShadow = shadow.md)}
          onMouseLeave={e => (e.currentTarget.style.boxShadow = shadow.kpi)}
        >
          <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 4, background: barColor, borderRadius: "12px 0 0 12px" }} />
          <STARBadge variant={decision.priority === "critique" ? "error" : "warning"} label={decision.priority === "critique" ? "Critique" : "Haute"} />
          <div style={{ fontSize: 13, fontWeight: 600, color: S.g900, lineHeight: 1.4, marginTop: 8, marginBottom: 8, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{decision.title}</div>
          <div style={{ fontSize: 12, color: S.teal, display: "flex", alignItems: "center", gap: 3 }}>Voir la décision <ChevronRight size={11} /></div>
          {totalDecisions > 1 && <div style={{ fontSize: 11, color: S.g400, marginTop: 6 }}>+ {totalDecisions - 1} autre{totalDecisions - 1 > 1 ? "s" : ""}</div>}
        </button>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: 10 }}>Action prioritaire</div>
      <div onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
        style={{ flex: 1, background: S.white, borderRadius: 14, border: `1px solid ${S.g200}`, boxShadow: hovered ? shadow.md : shadow.kpi, transition: T, position: "relative", overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 5, background: barColor, borderRadius: "14px 0 0 14px" }} />
        <div style={{ padding: "22px 22px 20px 27px", flex: 1, display: "flex", flexDirection: "column" }}>
          {actionTaken ? (
            <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <div style={{ textAlign: "center" }}>
                <div style={{ width: 40, height: 40, borderRadius: "50%", background: S.successLight, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px" }}><CheckCircle size={20} color={S.success} /></div>
                <div style={{ fontSize: 14, fontWeight: 600, color: S.g900 }}>Action enregistrée</div>
                <div style={{ fontSize: 13, color: S.g500, marginTop: 4 }}>{actionTaken}</div>
              </div>
            </div>
          ) : (
            <>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
                <STARBadge variant={decision.priority === "critique" ? "error" : "warning"} label={decision.priority === "critique" ? "Critique" : "Haute priorité"} />
                <span style={{ fontSize: 12, color: S.g500 }}>{decision.program} · {decision.waitingDays === 0 ? "Aujourd'hui" : `Depuis ${decision.waitingDays}j`}</span>
              </div>
              <h3 style={{ fontSize: 17, fontWeight: 700, color: S.g900, lineHeight: 1.35, margin: "0 0 14px" }}>{decision.title}</h3>
              <div style={{ padding: "10px 14px", borderRadius: 8, background: decision.priority === "critique" ? S.errorLight : S.warningLight, border: `1px solid ${decision.priority === "critique" ? S.error + "33" : S.warning + "44"}`, marginBottom: 14 }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: decision.priority === "critique" ? "#b91c1c" : "#92400e", display: "block", marginBottom: 3 }}>↳ Impact</span>
                <span style={{ fontSize: 13, color: decision.priority === "critique" ? "#7f1d1d" : "#78350f" }}>{decision.impact}</span>
              </div>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 8, marginBottom: 18, padding: "8px 12px", background: S.teal20, borderRadius: 8 }}>
                <Sparkles size={13} color={S.teal} style={{ marginTop: 1, flexShrink: 0 }} />
                <span style={{ fontSize: 13, color: S.teal, fontWeight: 500 }}>Recommandé : {decision.recommendation}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                <button onClick={() => setActionTaken(decision.recommendation)} style={{ padding: "8px 16px", background: S.teal, color: S.white, border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer", transition: T }}
                  onMouseEnter={e => (e.currentTarget.style.background = S.tealDark)}
                  onMouseLeave={e => (e.currentTarget.style.background = S.teal)}
                >{decision.recommendation}</button>
                <button onClick={() => setActionTaken("Reportée")} style={{ padding: "8px 14px", background: "transparent", color: S.g700, border: `1px solid ${S.g300}`, borderRadius: 8, fontSize: 13, fontWeight: 500, cursor: "pointer", transition: T }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = S.teal; e.currentTarget.style.color = S.teal; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = S.g300; e.currentTarget.style.color = S.g700; }}
                >Reporter</button>
                <button onClick={onContext} style={{ padding: "8px 12px", background: "none", border: "none", color: S.teal, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, borderRadius: 6, transition: T }}
                  onMouseEnter={e => (e.currentTarget.style.background = S.tealLight)}
                  onMouseLeave={e => (e.currentTarget.style.background = "none")}
                >Contexte <ChevronRight size={12} /></button>
              </div>
            </>
          )}
        </div>
        {totalDecisions > 1 && (
          <button onClick={onViewAll} style={{ padding: "10px 27px", background: "none", border: "none", borderTop: `1px solid ${S.g100}`, display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", width: "100%", transition: T }}
            onMouseEnter={e => (e.currentTarget.style.background = S.g50)}
            onMouseLeave={e => (e.currentTarget.style.background = "none")}
          >
            <span style={{ fontSize: 12, color: S.g500 }}>{totalDecisions - 1} autre{totalDecisions - 1 > 1 ? "s" : ""} décision{totalDecisions - 1 > 1 ? "s" : ""} en attente</span>
            <span style={{ fontSize: 12, color: S.teal, fontWeight: 500, display: "flex", alignItems: "center", gap: 3 }}>Tout voir <ChevronRight size={12} /></span>
          </button>
        )}
      </div>
    </div>
  );
}

// ─── SECONDARY SYNTHESIS ──────────────────────────────────────────────────────
function SecondarySynthesis({ openDrawer, onNavigateToPilotage }: { openDrawer: (d: DrawerItem) => void; onNavigateToPilotage: () => void; }) {
  const blocked = MISSIONS.filter(m => ["critique","bloqué","retard"].includes(m.status)).slice(0, 4);
  const PH = ({ label }: { label: string }) => (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
      <span style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px" }}>{label}</span>
      <button onClick={onNavigateToPilotage} style={{ fontSize: 11, color: S.teal, background: "none", border: "none", cursor: "pointer", padding: "1px 4px", borderRadius: 4, transition: T }}
        onMouseEnter={e => (e.currentTarget.style.background = S.tealLight)}
        onMouseLeave={e => (e.currentTarget.style.background = "none")}
      >Voir tout →</button>
    </div>
  );
  const card: React.CSSProperties = { background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, overflow: "hidden" };
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginTop: 28 }}>
      <div><PH label="Programmes" />
        <div style={card}>{PROGRAMS.map((p, i) => { const hc = p.health >= 85 ? S.success : p.health >= 70 ? S.warning : S.error; return (
          <button key={p.id} onClick={() => openDrawer({ type: "program", data: p })} style={{ width: "100%", padding: "12px 16px", background: "none", border: "none", borderBottom: i < PROGRAMS.length - 1 ? `1px solid ${S.g100}` : "none", display: "flex", alignItems: "center", gap: 12, cursor: "pointer", textAlign: "left", transition: T }} onMouseEnter={e => (e.currentTarget.style.background = S.g50)} onMouseLeave={e => (e.currentTarget.style.background = "none")}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: p.status === "nominal" ? S.successLight : S.warningLight, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><span style={{ fontSize: 10, fontWeight: 800, color: p.status === "nominal" ? S.success : S.warning }}>{p.name.slice(0,2)}</span></div>
            <div style={{ flex: 1 }}><div style={{ fontSize: 13, fontWeight: 600, color: S.g900 }}>{p.name}</div><div style={{ height: 3, background: S.g100, borderRadius: 9999, marginTop: 5, overflow: "hidden" }}><div style={{ height: "100%", width: `${p.health}%`, background: hc }} /></div></div>
            <div style={{ fontSize: 14, fontWeight: 700, color: hc, fontVariantNumeric: "tabular-nums", flexShrink: 0 }}>{p.health}%</div>
          </button>
        );})}
        </div>
      </div>
      <div><PH label="Missions sous attention" />
        <div style={card}>{blocked.map((m, i) => (
          <button key={m.id} onClick={() => openDrawer({ type: "mission", data: m })} style={{ width: "100%", padding: "11px 16px", background: "none", border: "none", borderBottom: i < blocked.length - 1 ? `1px solid ${S.g100}` : "none", display: "flex", alignItems: "center", gap: 10, cursor: "pointer", textAlign: "left", transition: T }} onMouseEnter={e => (e.currentTarget.style.background = S.g50)} onMouseLeave={e => (e.currentTarget.style.background = "none")}>
            <span style={{ width: 7, height: 7, borderRadius: "50%", background: m.status === "retard" ? S.warning : S.error, flexShrink: 0 }} />
            <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontSize: 13, fontWeight: 500, color: S.g900, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{m.name}</div><div style={{ fontSize: 11, color: S.g500 }}>{m.program}</div></div>
            <div style={{ fontSize: 11, fontWeight: 500, color: m.status === "retard" ? S.warning : S.error, flexShrink: 0 }}>{{ critique: "Critique", bloqué: "Bloqué", retard: "En retard" }[m.status as string]}</div>
          </button>
        ))}</div>
      </div>
      <div><PH label="Prochains jalons" />
        <div style={card}>{UPCOMING_MILESTONES.map((m, i) => (
          <div key={i} style={{ padding: "11px 16px", borderBottom: i < UPCOMING_MILESTONES.length - 1 ? `1px solid ${S.g100}` : "none", display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 36, textAlign: "center", flexShrink: 0 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: m.daysLeft <= 3 ? S.error : m.daysLeft <= 6 ? S.warning : S.g500, fontVariantNumeric: "tabular-nums" }}>J-{m.daysLeft}</div>
              <div style={{ fontSize: 10, color: S.g400 }}>{m.date}</div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontSize: 13, fontWeight: 500, color: S.g900, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{m.label}</div><div style={{ fontSize: 11, color: S.g500 }}>{m.program}</div></div>
          </div>
        ))}</div>
      </div>
    </div>
  );
}

// ─── COCKPIT CONTENT (mode idle) ──────────────────────────────────────────────
function CockpitContent({ openDrawer, onNavigateToPilotage, onOpenStudio }: {
  openDrawer: (d: DrawerItem) => void;
  onNavigateToPilotage: () => void;
  onOpenStudio: () => void;
}) {
  return (
    <div style={{ maxWidth: 1100, margin: "0 auto", padding: "32px 32px 56px" }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 12, fontWeight: 500, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 8 }}>Mardi 1 juillet 2026</div>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: S.g900, margin: "0 0 10px", lineHeight: 1.2 }}>Bonjour, Jeff</h1>
        <p style={{ fontSize: 15, color: S.g700, margin: "0 0 16px", lineHeight: 1.65, maxWidth: 660 }}>
          <span style={{ color: S.error, fontWeight: 600 }}>1 décision critique bloque votre équipe VEEDDA depuis 5 jours.</span>
          {" "}2 risques actifs nécessitent votre arbitrage. La revue de phase est attendue dans 3 jours.
        </p>
        {/* Pendant votre absence — system worked while you were away */}
        <div style={{ display: "inline-flex", alignItems: "center", gap: 10, padding: "8px 14px", background: S.white, border: `1px solid ${S.g200}`, borderRadius: 10, boxShadow: shadow.kpi }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ width: 7, height: 7, borderRadius: "50%", background: S.success, animation: "stPulse 2s ease infinite" }} />
            <span style={{ fontSize: 11, fontWeight: 700, color: S.g700 }}>Pendant votre absence</span>
          </div>
          <span style={{ color: S.g300 }}>·</span>
          {[
            { icon: "⬡", text: "4 analyses complétées", color: S.teal },
            { icon: "▲", text: "1 nouveau risque détecté", color: S.error },
            { icon: "◷", text: "Planning recalculé", color: S.cyan },
            { icon: "◈", text: "Projection budgétaire mise à jour", color: S.success },
          ].map((item, i) => (
            <span key={i} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: S.g600 }}>
              <span style={{ fontSize: 10, color: item.color }}>{item.icon}</span>{item.text}
              {i < 3 && <span style={{ color: S.g300, marginLeft: 2 }}>·</span>}
            </span>
          ))}
          <button style={{ fontSize: 11, color: S.teal, background: "none", border: "none", cursor: "pointer", marginLeft: 4, padding: "0 4px", borderRadius: 4, transition: T }}
            onMouseEnter={e => (e.currentTarget.style.background = S.tealLight)}
            onMouseLeave={e => (e.currentTarget.style.background = "none")}
          >Voir l'activité →</button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 0 }}>
        <PriorityActionCard
          decision={DECISIONS[0]} totalDecisions={DECISIONS.length} compact={false}
          onContext={() => openDrawer({ type: "decision", data: DECISIONS[0] })}
          onViewAll={onNavigateToPilotage}
        />

        {/* Mission Studio trigger card */}
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: 10 }}>Mission Studio</div>
          <button onClick={onOpenStudio}
            style={{ flex: 1, background: S.white, borderRadius: 14, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "22px 24px", textAlign: "left", cursor: "pointer", transition: T, display: "flex", flexDirection: "column" }}
            onMouseEnter={e => (e.currentTarget.style.boxShadow = shadow.md)}
            onMouseLeave={e => (e.currentTarget.style.boxShadow = shadow.kpi)}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 10, background: S.teal20, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Zap size={15} color={S.teal} />
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: S.g900 }}>Construisez une mission IA</div>
                <div style={{ fontSize: 12, color: S.g500, marginTop: 1 }}>Orchestrez une équipe d'agents spécialisés</div>
              </div>
            </div>
            <p style={{ fontSize: 13, color: S.g600, lineHeight: 1.55, margin: "0 0 18px" }}>
              Décrivez votre objectif. ORCHESTRATOR sélectionne, coordonne et supervise les agents IA adaptés.
            </p>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 20 }}>
              {[{ icon: "⚡", label: "Analyser les risques" }, { icon: "📋", label: "Préparer une revue" }, { icon: "🔧", label: "Débloquer un projet" }, { icon: "📊", label: "Rapport d'avancement" }].map((s, i) => (
                <span key={i} style={{ padding: "4px 10px", background: S.g50, border: `1px solid ${S.g200}`, borderRadius: 6, fontSize: 12, color: S.g600, display: "flex", alignItems: "center", gap: 5 }}>
                  <span>{s.icon}</span>{s.label}
                </span>
              ))}
            </div>
            <div style={{ marginTop: "auto", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ display: "flex", gap: 4 }}>
                {SPECIALIST_AGENTS.slice(0, 5).map(a => (
                  <span key={a.id} style={{ width: 22, height: 22, borderRadius: "50%", background: S.g100, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: S.g500, border: `1.5px solid ${S.white}` }}>{a.icon}</span>
                ))}
                <span style={{ width: 22, height: 22, borderRadius: "50%", background: S.g100, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: S.g500, border: `1.5px solid ${S.white}` }}>+3</span>
              </div>
              <span style={{ fontSize: 13, color: S.teal, fontWeight: 600, display: "flex", alignItems: "center", gap: 4 }}>Ouvrir le Studio <ChevronRight size={13} /></span>
            </div>
          </button>
        </div>
      </div>

      <SecondarySynthesis openDrawer={openDrawer} onNavigateToPilotage={onNavigateToPilotage} />
      <ActivityFeed />
    </div>
  );
}

// ─── CONTEXT SIDEBAR ──────────────────────────────────────────────────────────
function ContextSidebar({ openDrawer }: { openDrawer: (d: DrawerItem) => void }) {
  const d = DECISIONS[0];
  const sep = <div style={{ height: 1, background: S.g100, margin: "12px 0" }} />;
  const sL = (label: string) => <div style={{ fontSize: 10, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 7 }}>{label}</div>;
  const rowBtn = (children: React.ReactNode, onClick: () => void, bg = S.g50, hoverBg = S.tealLight) => (
    <button onClick={onClick} style={{ width: "100%", background: bg, border: `1px solid ${S.g200}`, borderRadius: 7, padding: "7px 10px", textAlign: "left", cursor: "pointer", transition: T, display: "block" }}
      onMouseEnter={e => (e.currentTarget.style.background = hoverBg)}
      onMouseLeave={e => (e.currentTarget.style.background = bg)}
    >{children}</button>
  );

  return (
    <div style={{ width: 300, padding: "18px 18px", overflowY: "auto", height: "100%" }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: 14 }}>Contexte actif</div>

      {sL("Programme")}
      {rowBtn(
        <><div style={{ display: "flex", alignItems: "center", gap: 7 }}>
          <span style={{ width: 7, height: 7, borderRadius: "50%", background: S.warning, flexShrink: 0 }} />
          <span style={{ fontSize: 13, fontWeight: 600, color: S.g900 }}>VEEDDA</span>
          <span style={{ fontSize: 11, color: S.warning, fontWeight: 500, marginLeft: "auto" }}>78%</span>
        </div><div style={{ fontSize: 11, color: S.g500, marginTop: 3 }}>Phase 2 / 4 · Revue dans 3j</div></>,
        () => openDrawer({ type: "program", data: PROGRAMS[0] })
      )}

      {sep}
      {sL("Décision active")}
      {rowBtn(
        <><div style={{ fontSize: 11, fontWeight: 600, color: S.error, marginBottom: 3 }}>CRITIQUE · depuis 5j</div>
        <div style={{ fontSize: 12, fontWeight: 600, color: S.g900, lineHeight: 1.3 }}>Validation architecture multi-agents</div>
        <div style={{ fontSize: 11, color: "#b91c1c", marginTop: 5 }}>€45k · 3 personnes bloquées</div></>,
        () => openDrawer({ type: "decision", data: d }), S.errorLight, "#fecaca"
      )}

      {sep}
      {sL("Documents liés")}
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {["Cahier des charges VEEDDA v2", "Architecture STAR — v3.1", "Revue de phase — template", "Rapport Phase 1 — v2"].map((doc, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 7, padding: "6px 8px", borderRadius: 6, background: S.g50, border: `1px solid ${S.g200}`, cursor: "pointer", transition: T, fontSize: 12, color: S.g700 }}
            onMouseEnter={e => (e.currentTarget.style.background = S.tealLight)}
            onMouseLeave={e => (e.currentTarget.style.background = S.g50)}
          >
            <span style={{ color: S.g400, fontSize: 10, flexShrink: 0 }}>□</span>
            <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1 }}>{doc}</span>
          </div>
        ))}
      </div>

      {sep}
      {sL("Risques liés")}
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {RISKS.filter(r => r.level === "critique").map(r => (
          <button key={r.id} onClick={() => openDrawer({ type: "risk", data: r })}
            style={{ width: "100%", display: "flex", alignItems: "flex-start", gap: 7, padding: "6px 8px", borderRadius: 6, background: S.errorLight, border: `1px solid ${S.error}22`, cursor: "pointer", transition: T, textAlign: "left" }}
            onMouseEnter={e => (e.currentTarget.style.background = "#fecaca")}
            onMouseLeave={e => (e.currentTarget.style.background = S.errorLight)}
          >
            <span style={{ color: S.error, fontSize: 9, marginTop: 2, flexShrink: 0 }}>▲</span>
            <span style={{ fontSize: 12, color: "#b91c1c", lineHeight: 1.35 }}>{r.title}</span>
          </button>
        ))}
      </div>

      {sep}
      {sL("Missions liées")}
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {MISSIONS.filter(m => ["critique", "bloqué"].includes(m.status)).slice(0, 3).map(m => (
          <button key={m.id} onClick={() => openDrawer({ type: "mission", data: m })}
            style={{ width: "100%", display: "flex", alignItems: "flex-start", gap: 7, padding: "6px 8px", borderRadius: 6, background: S.g50, border: `1px solid ${S.g200}`, cursor: "pointer", transition: T, textAlign: "left" }}
            onMouseEnter={e => (e.currentTarget.style.background = S.tealLight)}
            onMouseLeave={e => (e.currentTarget.style.background = S.g50)}
          >
            <span style={{ color: S.g400, fontSize: 9, marginTop: 2, flexShrink: 0 }}>◆</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, color: S.g700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.name}</div>
              <div style={{ fontSize: 10, color: m.status === "bloqué" ? S.error : S.warning, fontWeight: 500, marginTop: 2 }}>{{ critique: "Critique", bloqué: "Bloqué" }[m.status as string]} · {m.progress}%</div>
            </div>
          </button>
        ))}
      </div>

      {sep}
      {sL("Conversations récentes")}
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {[{ time: "09:14", label: "Analyse risques API Partenaires" }, { time: "09:32", label: "Budget infrastructure +€12k" }, { time: "10:11", label: "Revue de phase — préparation" }].map((c, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 7, padding: "6px 8px", borderRadius: 6, background: S.g50, border: `1px solid ${S.g200}`, cursor: "pointer", transition: T }}
            onMouseEnter={e => (e.currentTarget.style.background = S.tealLight)}
            onMouseLeave={e => (e.currentTarget.style.background = S.g50)}
          >
            <span style={{ fontSize: 10, color: S.g400, flexShrink: 0, fontVariantNumeric: "tabular-nums", width: 32 }}>{c.time}</span>
            <span style={{ fontSize: 12, color: S.g700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.label}</span>
          </div>
        ))}
      </div>

      {sep}
      {sL("Prompts utilisés")}
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {["Analyse l'impact du retard API sur la release VEEDDA...", "Prépare le dossier pour la revue de phase du 4 juillet...", "Identifie les options pour débloquer l'architecture..."].map((prompt, i) => (
          <div key={i} style={{ padding: "6px 8px", borderRadius: 6, background: S.g50, border: `1px solid ${S.g200}`, cursor: "pointer", fontSize: 11, color: S.g500, lineHeight: 1.4, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" as const, transition: T }}
            onMouseEnter={e => (e.currentTarget.style.background = S.tealLight)}
            onMouseLeave={e => (e.currentTarget.style.background = S.g50)}
          >"{prompt}"</div>
        ))}
      </div>
    </div>
  );
}

// ─── MISSION STUDIO ───────────────────────────────────────────────────────────
function MissionStudio({ studioState, onStateChange, onClose }: {
  studioState: "editing" | "running";
  onStateChange: (s: "editing" | "running") => void;
  onClose: () => void;
}) {
  const [studioMode, setStudioMode] = useState("analyse");
  const [objective, setObjective] = useState("");
  const [contexts, setContexts] = useState<Array<{ type: string; value: string }>>([]);
  const [missionText, setMissionText] = useState("");
  const [autoAgents, setAutoAgents] = useState(true);
  const [selectedAgentIds, setSelectedAgentIds] = useState<string[]>([]);
  const [showContextMenu, setShowContextMenu] = useState<string | null>(null);
  const [agentProgress, setAgentProgress] = useState<Record<string, number>>({});

  const STUDIO_MODES = [
    { id: "analyse",       label: "Analyse",        icon: "⬡" },
    { id: "audit",         label: "Audit",           icon: "✓" },
    { id: "simulation",    label: "Simulation",      icon: "⊞" },
    { id: "architecture",  label: "Architecture",    icon: "⬡" },
    { id: "roadmap",       label: "Roadmap",         icon: "◷" },
    { id: "documentation", label: "Documentation",   icon: "□" },
    { id: "decision",      label: "Décision",        icon: "◆" },
    { id: "copil",         label: "COPIL / COMEX",   icon: "◉" },
    { id: "securite",      label: "Sécurité",        icon: "▲" },
    { id: "conformite",    label: "Conformité",      icon: "✓" },
  ];
  const [agentTasks, setAgentTasks] = useState<Record<string, string>>({});
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [attachments, setAttachments] = useState<string[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [followUp, setFollowUp] = useState("");
  // V7 state
  const [analysisStarted, setAnalysisStarted] = useState(false);
  const [analysisStep, setAnalysisStep] = useState(0);
  const [agentLiveStates, setAgentLiveStates] = useState<Record<string, { text: string; phase: "ready"|"active"|"done" }>>({});
  const [selectedDeliverables, setSelectedDeliverables] = useState<string[]>([]);
  const convRef = useRef<HTMLDivElement>(null);

  const activeAgents = autoAgents
    ? SPECIALIST_AGENTS.filter(a => ["architecture","planning","finance","risk"].includes(a.id))
    : SPECIALIST_AGENTS.filter(a => selectedAgentIds.includes(a.id));

  const agentCount = autoAgents ? 4 : selectedAgentIds.length;
  const wordCount = missionText.trim() ? missionText.trim().split(/\s+/).length : 0;
  const tokenEst = Math.ceil((objective.length + missionText.length) / 4);
  const complexity = tokenEst < 100 ? "Simple" : tokenEst < 400 ? "Standard" : "Complexe";
  const timeEst = Math.max(1, Math.ceil(tokenEst / 150) + agentCount);
  const canLaunch = objective.trim().length > 0 || missionText.trim().length > 0;

  // Pre-analysis feed — triggers once when user starts typing
  useEffect(() => {
    if (!objective || analysisStarted) return;
    setAnalysisStarted(true);
    let i = 0;
    const t = setInterval(() => { i++; setAnalysisStep(i); if (i >= ANALYSIS_STEPS.length) clearInterval(t); }, 420);
    return () => clearInterval(t);
  }, [objective]);

  // Agent live states — cycle pre-launch activity when objective is set
  useEffect(() => {
    if (!objective || !autoAgents) return;
    const timers: ReturnType<typeof setTimeout>[] = [];
    const AUTO = ["architecture", "planning", "finance", "risk"];
    AUTO.forEach(id => {
      const seq = AGENT_PRE_STATES[id] || [];
      seq.forEach((s, i) => {
        const t = setTimeout(() => setAgentLiveStates(prev => ({ ...prev, [id]: s })), 400 + i * 1000 + Math.random() * 300);
        timers.push(t);
      });
    });
    return () => timers.forEach(clearTimeout);
  }, [!!objective, autoAgents]);

  // Progress simulation
  useEffect(() => {
    if (studioState !== "running") return;
    const init: Record<string, number> = {};
    const tasks: Record<string, string> = {};
    activeAgents.forEach(a => { init[a.id] = 0; tasks[a.id] = AGENT_PHASES[a.id]?.tasks[0] || "Initialisation..."; });
    setAgentProgress(init);
    setAgentTasks(tasks);
    let elapsed = 0;
    const timer = setInterval(() => {
      elapsed += 120;
      setAgentProgress(prev => {
        const next = { ...prev };
        let anyMoving = false;
        activeAgents.forEach(a => {
          const target = AGENT_PHASES[a.id]?.target || 80;
          if ((next[a.id] || 0) < target) {
            next[a.id] = Math.min(target, (next[a.id] || 0) + 2 + Math.random() * 8);
            anyMoving = true;
            const phases = AGENT_PHASES[a.id]?.tasks || [];
            const idx = Math.min(Math.floor((next[a.id] / 100) * phases.length), phases.length - 1);
            setAgentTasks(t => ({ ...t, [a.id]: phases[idx] }));
          }
        });
        if (!anyMoving) {
          clearInterval(timer);
          setTimeout(() => {
            const resp = generateResponse(objective);
            setMessages([{
              id: "ai1", role: "assistant",
              content: resp.content,
              time: new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
              actions: resp.actions,
            }]);
            setTimeout(() => convRef.current?.scrollTo({ top: 9999, behavior: "smooth" }), 50);
          }, 600);
        }
        return next;
      });
    }, 120);
    return () => clearInterval(timer);
  }, [studioState]);

  function handleLaunch() {
    if (!objective.trim() && !missionText.trim()) return;
    onStateChange("running");
  }

  function handleFollowUp() {
    if (!followUp.trim()) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: "user", content: followUp, time: new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) };
    const typingMsg: ChatMessage = { id: "typing", role: "assistant", content: "", time: "", typing: true };
    setMessages(prev => [...prev, userMsg, typingMsg]);
    const captured = followUp;
    setFollowUp("");
    setTimeout(() => {
      const resp = generateResponse(captured);
      setMessages(prev => [...prev.filter(m => !m.typing), { id: Date.now().toString(), role: "assistant", content: resp.content, time: new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), actions: resp.actions }]);
      setTimeout(() => convRef.current?.scrollTo({ top: 9999, behavior: "smooth" }), 50);
    }, 1800);
  }

  function addContext(typeId: string, value: string) {
    setContexts(prev => [...prev.filter(c => !(c.type === typeId && c.value === value)), { type: typeId, value }]);
    setShowContextMenu(null);
  }

  const sectionLabel = (label: string) => (
    <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: 10 }}>{label}</div>
  );

  // ── RUNNING STATE ──
  if (studioState === "running") {
    return (
      <div style={{ padding: "28px 36px 40px", maxWidth: 860 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
          <div>
            <h2 style={{ fontSize: 17, fontWeight: 700, color: S.g900, margin: 0 }}>Mission en cours</h2>
            {objective && <div style={{ fontSize: 13, color: S.g500, marginTop: 3 }}>{objective}</div>}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => { onStateChange("editing"); setAgentProgress({}); setMessages([]); }}
              style={{ padding: "6px 12px", background: S.g100, border: `1px solid ${S.g200}`, borderRadius: 7, fontSize: 12, color: S.g600, cursor: "pointer", transition: T }}
              onMouseEnter={e => (e.currentTarget.style.background = S.g200)}
              onMouseLeave={e => (e.currentTarget.style.background = S.g100)}
            >+ Nouvelle mission</button>
            <button onClick={onClose} style={{ padding: "6px 12px", background: "transparent", border: `1px solid ${S.g200}`, borderRadius: 7, fontSize: 12, color: S.g600, cursor: "pointer", transition: T }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = S.g300; e.currentTarget.style.color = S.g700; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = S.g200; e.currentTarget.style.color = S.g600; }}
            >↑ Réduire</button>
          </div>
        </div>

        {/* Agents en activité */}
        <div style={{ background: S.white, borderRadius: 14, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "20px 24px", marginBottom: 20 }}>
          {sectionLabel("Agents en activité")}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            {activeAgents.map(agent => {
              const progress = agentProgress[agent.id] || 0;
              const target = AGENT_PHASES[agent.id]?.target || 80;
              const isDone = progress >= target;
              return (
                <div key={agent.id} style={{ padding: "12px 14px", borderRadius: 10, background: isDone ? S.successLight : S.g50, border: `1px solid ${isDone ? S.success + "44" : S.g200}`, transition: T }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 13, color: agent.color }}>{agent.icon}</span>
                      <span style={{ fontSize: 13, fontWeight: 600, color: S.g900 }}>{agent.name} Agent</span>
                    </div>
                    <span style={{ fontSize: 12, fontWeight: 700, color: isDone ? S.success : S.g700, fontVariantNumeric: "tabular-nums" }}>
                      {isDone ? "✓" : `${Math.round(progress)}%`}
                    </span>
                  </div>
                  <div style={{ height: 4, background: S.g200, borderRadius: 9999, overflow: "hidden", marginBottom: 7 }}>
                    <div style={{ height: "100%", width: `${(progress / target) * 100}%`, background: isDone ? S.success : agent.color, borderRadius: 9999, transition: "width 200ms ease" }} />
                  </div>
                  <div style={{ fontSize: 11, color: isDone ? "#065f46" : S.g500 }}>{agentTasks[agent.id] || "Initialisation..."}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Conversation */}
        {messages.length > 0 && (
          <div style={{ background: S.white, borderRadius: 14, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, marginBottom: 20, overflow: "hidden" }}>
            <div ref={convRef} style={{ maxHeight: 420, overflowY: "auto", padding: "20px 24px 0", display: "flex", flexDirection: "column", gap: 16 }}>
              {messages.map(msg => (
                <div key={msg.id}>
                  <div style={{ display: "flex", flexDirection: msg.role === "user" ? "row-reverse" : "row", gap: 10, alignItems: "flex-start" }}>
                    {msg.role === "assistant" && (
                      <div style={{ width: 28, height: 28, borderRadius: "50%", background: S.teal, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 2 }}><Zap size={12} color={S.white} /></div>
                    )}
                    {msg.typing ? (
                      <div style={{ padding: "10px 14px", background: S.g100, borderRadius: 12, borderBottomLeftRadius: 4 }}>
                        <div style={{ display: "flex", gap: 4 }}>{[0,1,2].map(i => <span key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: S.g400, display: "inline-block", animation: `stBounce 1.2s ease ${i * 0.18}s infinite` }} />)}</div>
                      </div>
                    ) : (
                      <div style={{ maxWidth: "86%", padding: "12px 16px", background: msg.role === "user" ? S.teal20 : S.g50, borderRadius: 12, borderBottomRightRadius: msg.role === "user" ? 4 : 12, borderBottomLeftRadius: msg.role === "assistant" ? 4 : 12, fontSize: 13, color: S.g700, lineHeight: 1.6 }}>
                        {msg.role === "assistant" ? renderMD(msg.content) : <span>{msg.content}</span>}
                        <div style={{ fontSize: 10, color: S.g400, marginTop: 6 }}>{msg.time}</div>
                      </div>
                    )}
                  </div>
                  {/* Action buttons */}
                  {msg.actions && msg.actions.length > 0 && (
                    <div style={{ display: "flex", gap: 8, marginTop: 10, marginLeft: 38, flexWrap: "wrap" }}>
                      {msg.actions.map((action, i) => (
                        <button key={i} style={{ padding: "6px 14px", background: i === 0 ? S.teal : S.white, color: i === 0 ? S.white : S.teal, border: `1px solid ${S.teal}`, borderRadius: 7, fontSize: 12, fontWeight: 500, cursor: "pointer", transition: T }}
                          onMouseEnter={e => { e.currentTarget.style.background = i === 0 ? S.tealDark : S.tealLight; }}
                          onMouseLeave={e => { e.currentTarget.style.background = i === 0 ? S.teal : S.white; }}
                        >{action}</button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <div style={{ height: 4 }} />
            </div>
            {/* Follow-up input */}
            <div style={{ padding: "14px 24px", borderTop: `1px solid ${S.g100}`, display: "flex", gap: 10 }}>
              <input
                value={followUp}
                onChange={e => setFollowUp(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") handleFollowUp(); }}
                placeholder="Continuez la conversation..."
                style={{ flex: 1, border: `1.5px solid ${S.g200}`, borderRadius: 8, padding: "8px 12px", fontSize: 13, color: S.g900, background: S.g50, outline: "none", fontFamily: FONT, transition: T }}
                onFocus={e => (e.currentTarget.style.borderColor = S.teal + "99")}
                onBlur={e => (e.currentTarget.style.borderColor = S.g200)}
              />
              <button onClick={handleFollowUp} disabled={!followUp.trim()} style={{ padding: "8px 16px", background: followUp.trim() ? S.teal : S.g200, color: followUp.trim() ? S.white : S.g400, border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: followUp.trim() ? "pointer" : "default", display: "flex", alignItems: "center", gap: 6, transition: T }}
            onMouseEnter={e => { if (followUp.trim()) e.currentTarget.style.background = S.tealDark; }}
            onMouseLeave={e => { if (followUp.trim()) e.currentTarget.style.background = S.teal; }}
              ><Send size={13} />Envoyer</button>
            </div>
          </div>
        )}

        {/* Missions récentes */}
        <div style={{ background: S.white, borderRadius: 14, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, overflow: "hidden" }}>
          <div style={{ padding: "14px 20px", borderBottom: `1px solid ${S.g100}` }}>
            <span style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px" }}>Missions récentes — Aujourd'hui</span>
          </div>
          {RECENT_MISSIONS.map((m, i) => (
            <div key={i} style={{ padding: "11px 20px", borderBottom: i < RECENT_MISSIONS.length - 1 ? `1px solid ${S.g100}` : "none", display: "flex", alignItems: "center", gap: 14, cursor: "pointer", transition: T }}
              onMouseEnter={e => (e.currentTarget.style.background = S.g50)}
              onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
            >
              <span style={{ fontSize: 11, color: S.g400, fontVariantNumeric: "tabular-nums", width: 34, flexShrink: 0 }}>{m.time}</span>
              <span style={{ flex: 1, fontSize: 13, color: S.g700, fontWeight: 500 }}>{m.name}</span>
              <div style={{ display: "flex", gap: 4 }}>
                {m.agents.map(id => {
                  const a = SPECIALIST_AGENTS.find(sa => sa.id === id);
                  return a ? <span key={id} style={{ fontSize: 11, color: a.color, background: S.g50, border: `1px solid ${S.g200}`, borderRadius: 4, padding: "1px 5px" }}>{a.icon} {a.name}</span> : null;
                })}
              </div>
              <CheckCircle size={13} color={S.success} />
            </div>
          ))}
        </div>

        <style>{`@keyframes stBounce { 0%,60%,100%{transform:translateY(0)} 30%{transform:translateY(-5px)} }`}</style>
      </div>
    );
  }

  // ── EDITING STATE — 2-column command center ──
  const slabel = (t: string) => <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: 8 }}>{t}</div>;

  return (
    <div style={{ padding: "22px 28px 32px", height: "100%", overflowY: "auto" }}
      onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={e => { e.preventDefault(); setIsDragging(false); const files = Array.from(e.dataTransfer.files); setAttachments(prev => [...prev, ...files.map(f => f.name)]); }}
    >
      {/* Mode selector */}
      <div style={{ marginBottom: 18 }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.7px", marginBottom: 8 }}>Mode AI Studio</div>
        <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
          {STUDIO_MODES.map(m => (
            <button key={m.id} onClick={() => setStudioMode(m.id)}
              style={{ padding: "5px 11px", background: studioMode === m.id ? S.teal : S.white, color: studioMode === m.id ? S.white : S.g600, border: `1px solid ${studioMode === m.id ? S.teal : S.g200}`, borderRadius: 7, fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, transition: T, fontWeight: studioMode === m.id ? 600 : 400 }}
              onMouseEnter={e => { if (studioMode !== m.id) { e.currentTarget.style.borderColor = S.teal; e.currentTarget.style.color = S.teal; } }}
              onMouseLeave={e => { if (studioMode !== m.id) { e.currentTarget.style.borderColor = S.g200; e.currentTarget.style.color = S.g600; } }}
            >
              <span style={{ fontSize: 10, color: studioMode === m.id ? "rgba(255,255,255,0.7)" : S.teal }}>{m.icon}</span>{m.label}
            </button>
          ))}
        </div>
        {studioMode !== "analyse" && (
          <div style={{ marginTop: 8, padding: "6px 10px", background: S.teal20, border: `1px solid ${S.teal}22`, borderRadius: 7, fontSize: 12, color: S.teal }}>
            Mode <strong>{STUDIO_MODES.find(m => m.id === studioMode)?.label}</strong> — agents et templates adaptés automatiquement par ORCHESTRATOR.
          </div>
        )}
      </div>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 20 }}>
        <div>
          <h2 style={{ fontSize: 19, fontWeight: 700, color: S.g900, margin: 0 }}>Mission Studio</h2>
          <p style={{ fontSize: 12, color: S.g500, margin: "4px 0 0", lineHeight: 1.5 }}>Construisez une mission. ORCHESTRATOR sélectionne, coordonne et supervise les agents IA.</p>
        </div>
        <button onClick={onClose} style={{ padding: "5px 11px", background: S.g100, border: `1px solid ${S.g200}`, borderRadius: 7, fontSize: 12, color: S.g600, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, transition: T, flexShrink: 0, marginLeft: 16 }}
          onMouseEnter={e => { e.currentTarget.style.background = S.g200; e.currentTarget.style.color = S.g900; }}
          onMouseLeave={e => { e.currentTarget.style.background = S.g100; e.currentTarget.style.color = S.g600; }}
        >↑ Réduire</button>
      </div>

      {/* 2-column grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 20, alignItems: "start" }}>

        {/* ── LEFT: Mission editor ── */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

          {/* Objective */}
          <div>
            {slabel("Objectif")}
            <input value={objective} onChange={e => setObjective(e.target.value)}
              placeholder="Que souhaitez-vous accomplir ?"
              style={{ width: "100%", border: `1.5px solid ${objective ? S.teal + "66" : S.g200}`, borderRadius: 10, padding: "11px 14px", fontSize: 15, fontWeight: 500, color: S.g900, background: S.white, outline: "none", fontFamily: FONT, boxSizing: "border-box", transition: T }}
              onFocus={e => (e.currentTarget.style.borderColor = S.teal + "99")}
              onBlur={e => (e.currentTarget.style.borderColor = objective ? S.teal + "66" : S.g200)}
            />
          </div>

          {/* Context chips */}
          <div>
            {slabel("Contexte")}
            <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
              {CONTEXT_TYPES.map(ct => {
                const isAdded = contexts.some(c => c.type === ct.id);
                return (
                  <div key={ct.id} style={{ position: "relative" }}>
                    <button onClick={() => setShowContextMenu(showContextMenu === ct.id ? null : ct.id)}
                      style={{ padding: "4px 10px", background: isAdded ? S.teal20 : S.g100, border: `1px solid ${isAdded ? S.teal + "44" : S.g200}`, borderRadius: 7, fontSize: 12, color: isAdded ? S.teal : S.g600, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, transition: T }}
                      onMouseEnter={e => { if (!isAdded) e.currentTarget.style.borderColor = S.g300; }}
                      onMouseLeave={e => { if (!isAdded) e.currentTarget.style.borderColor = S.g200; }}
                    ><span style={{ fontSize: 9 }}>{ct.icon}</span>{isAdded ? ct.label : `+ ${ct.label}`}{!isAdded && <ChevronDown size={9} />}</button>
                    {showContextMenu === ct.id && (
                      <div style={{ position: "absolute", top: "calc(100% + 4px)", left: 0, background: S.white, border: `1px solid ${S.g200}`, borderRadius: 8, boxShadow: shadow.md, minWidth: 180, zIndex: 100, overflow: "hidden" }}>
                        {ct.options.map((opt, i) => (
                          <button key={i} onClick={() => addContext(ct.id, opt)}
                            style={{ width: "100%", padding: "8px 14px", background: "transparent", border: "none", fontSize: 13, color: S.g700, cursor: "pointer", textAlign: "left", transition: T }}
                            onMouseEnter={e => (e.currentTarget.style.background = S.g50)}
                            onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
                          >{opt}</button>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            {contexts.length > 0 && (
              <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 8 }}>
                {contexts.map((c, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 4, padding: "3px 9px", background: S.tealLight, border: `1px solid ${S.teal}33`, borderRadius: 6, fontSize: 12, color: S.teal }}>
                    {c.value}
                    <button onClick={() => setContexts(prev => prev.filter((_, j) => j !== i))} style={{ background: "none", border: "none", color: S.teal, cursor: "pointer", fontSize: 13, lineHeight: 1, padding: "0 1px" }}>×</button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Mission editor */}
          <div>
            {slabel("Mission")}
            <div style={{ background: S.white, borderRadius: 12, border: `1.5px solid ${missionText ? S.teal + "55" : S.g200}`, overflow: "hidden", transition: T, position: "relative" }}>
              {/* Toolbar */}
              <div style={{ padding: "7px 12px", borderBottom: `1px solid ${S.g100}`, display: "flex", gap: 2, alignItems: "center" }}>
                {[{ icon: <Bold size={12} /> }, { icon: <Italic size={12} /> }, { icon: <AlignLeft size={12} /> }].map((item, i) => (
                  <button key={i} style={{ width: 26, height: 26, display: "flex", alignItems: "center", justifyContent: "center", background: "none", border: "none", borderRadius: 5, color: S.g500, cursor: "pointer", transition: T }}
                    onMouseEnter={e => { e.currentTarget.style.background = S.g100; e.currentTarget.style.color = S.g900; }}
                    onMouseLeave={e => { e.currentTarget.style.background = "none"; e.currentTarget.style.color = S.g500; }}
                  >{item.icon}</button>
                ))}
                <div style={{ width: 1, height: 14, background: S.g200, margin: "0 4px" }} />
                <button style={{ padding: "2px 7px", background: "none", border: "none", borderRadius: 5, fontSize: 12, color: S.teal, cursor: "pointer", transition: T }}
                  onMouseEnter={e => (e.currentTarget.style.background = S.tealLight)}
                  onMouseLeave={e => (e.currentTarget.style.background = "none")}
                >@ Référence</button>
                <label style={{ padding: "2px 7px", borderRadius: 5, fontSize: 12, color: S.g500, cursor: "pointer", display: "flex", alignItems: "center", gap: 3, transition: T }}
                  onMouseEnter={e => { e.currentTarget.style.background = S.g100; e.currentTarget.style.color = S.g700; }}
                  onMouseLeave={e => { e.currentTarget.style.background = "none"; e.currentTarget.style.color = S.g500; }}
                >
                  <input type="file" multiple style={{ display: "none" }} onChange={e => { const files = Array.from(e.target.files || []); setAttachments(prev => [...prev, ...files.map(f => f.name)]); e.target.value = ""; }} />
                  <Paperclip size={11} /> Joindre
                </label>
              </div>
              <div style={{ position: "relative" }}>
                <textarea value={missionText} onChange={e => setMissionText(e.target.value)}
                  placeholder="Décrivez votre mission en détail. Markdown supporté. Utilisez @ pour référencer des programmes, missions ou documents..."
                  style={{ width: "100%", resize: "none", border: "none", padding: "13px 15px", fontSize: 14, color: S.g900, background: "transparent", outline: "none", fontFamily: FONT, lineHeight: 1.65, boxSizing: "border-box", minHeight: 240 }}
                />
                {isDragging && (
                  <div style={{ position: "absolute", inset: 0, border: `2px dashed ${S.teal}`, borderRadius: 10, background: S.tealLight, display: "flex", alignItems: "center", justifyContent: "center", pointerEvents: "none" }}>
                    <span style={{ fontSize: 13, color: S.teal, fontWeight: 500 }}>Déposez vos documents ici</span>
                  </div>
                )}
              </div>
              {/* Metadata strip */}
              <div style={{ padding: "7px 14px", borderTop: `1px solid ${S.g100}`, display: "flex", gap: 14, flexWrap: "wrap" }}>
                {[
                  { label: "~" + tokenEst + " tokens" },
                  { label: complexity, color: complexity === "Complexe" ? S.warning : complexity === "Standard" ? S.teal : S.g500 },
                  { label: `~${timeEst} min` },
                  { label: `${agentCount} agents` },
                  wordCount > 0 ? { label: wordCount + " mots" } : null,
                ].filter(Boolean).map((item, i) => item && (
                  <span key={i} style={{ fontSize: 11, color: item.color || S.g400, fontVariantNumeric: "tabular-nums" }}>{item.label}</span>
                ))}
                {attachments.length > 0 && (
                  <span style={{ fontSize: 11, color: S.teal }}>{attachments.length} fichier{attachments.length > 1 ? "s" : ""} joint{attachments.length > 1 ? "s" : ""}</span>
                )}
              </div>
              {attachments.length > 0 && (
                <div style={{ padding: "6px 12px 10px", display: "flex", gap: 5, flexWrap: "wrap", borderTop: `1px solid ${S.g100}` }}>
                  {attachments.map((name, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 4, padding: "3px 8px", background: S.tealLight, border: `1px solid ${S.teal}33`, borderRadius: 5, fontSize: 11, color: S.teal }}>
                      📎 {name.length > 20 ? name.slice(0, 18) + "…" : name}
                      <button onClick={() => setAttachments(prev => prev.filter((_, j) => j !== i))} style={{ background: "none", border: "none", color: S.teal, cursor: "pointer", fontSize: 13, lineHeight: 1, padding: 0 }}>×</button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Pre-analysis zone — appears progressively as user types */}
          {analysisStarted && analysisStep > 0 && (
            <div style={{ background: S.teal20, border: `1px solid ${S.teal}33`, borderRadius: 12, padding: "14px 18px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 11 }}>
                <Zap size={12} color={S.teal} />
                <span style={{ fontSize: 11, fontWeight: 600, color: S.teal, textTransform: "uppercase", letterSpacing: "0.6px" }}>ORCHESTRATOR analyse déjà</span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {ANALYSIS_STEPS.slice(0, analysisStep).map((step, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: step.state === "done" ? "#065f46" : step.state === "active" ? S.teal : S.g500 }}>
                    <span style={{ fontSize: 11, flexShrink: 0, width: 14, textAlign: "center", animation: step.state === "active" ? "stSpin 2s linear infinite" : undefined }}>
                      {step.state === "done" ? "✓" : step.state === "active" ? "◌" : "·"}
                    </span>
                    {step.text}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Deliverable selector */}
          <div>
            {slabel("Résultat attendu")}
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {DELIVERABLES.map(d => {
                const sel = selectedDeliverables.includes(d);
                return (
                  <button key={d} onClick={() => setSelectedDeliverables(prev => sel ? prev.filter(x => x !== d) : [...prev, d])}
                    style={{ padding: "5px 12px", background: sel ? S.teal20 : S.white, border: `1px solid ${sel ? S.teal + "55" : S.g200}`, borderRadius: 7, fontSize: 12, color: sel ? S.teal : S.g600, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, transition: T, fontWeight: sel ? 500 : 400 }}
                    onMouseEnter={e => { if (!sel) e.currentTarget.style.borderColor = S.g300; }}
                    onMouseLeave={e => { if (!sel) e.currentTarget.style.borderColor = S.g200; }}
                  >
                    {sel && <span style={{ fontSize: 9, color: S.teal }}>✓</span>}
                    {d}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Pre-launch summary + CTA */}
          <div>
            {canLaunch && (
              <div style={{ padding: "11px 16px", background: S.g50, border: `1px solid ${S.g200}`, borderRadius: 10, marginBottom: 12, display: "flex", gap: 16, flexWrap: "wrap" }}>
                {[
                  `${agentCount} agent${agentCount > 1 ? "s" : ""} mobilisé${agentCount > 1 ? "s" : ""}`,
                  `Durée estimée : ~${timeEst} min`,
                  "12 documents analysés",
                  "5 risques pris en compte",
                ].map((item, i) => (
                  <span key={i} style={{ fontSize: 12, color: i === 0 ? S.teal : S.g600, fontWeight: i === 0 ? 600 : 400 }}>{item}</span>
                ))}
              </div>
            )}
            <button onClick={handleLaunch} disabled={!canLaunch}
              style={{ width: "100%", padding: "15px", background: canLaunch ? S.teal : S.g200, color: canLaunch ? S.white : S.g400, border: "none", borderRadius: 12, fontSize: 16, fontWeight: 700, cursor: canLaunch ? "pointer" : "default", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, transition: T, letterSpacing: "-0.3px" }}
              onMouseEnter={e => { if (canLaunch) e.currentTarget.style.background = S.tealDark; }}
              onMouseLeave={e => { if (canLaunch) e.currentTarget.style.background = S.teal; }}
            ><Send size={16} /> Exécuter la mission</button>
          </div>
        </div>

        {/* ── RIGHT: Intelligence panel ── */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

          {/* Live context analysis — appears when user types */}
          {(objective.length > 3 || missionText.length > 10) && (() => {
            const text = (objective + " " + missionText).toLowerCase();
            const docs = text.includes("api") || text.includes("architecture") || text.includes("veedda")
              ? ["Cahier des charges VEEDDA v2", "Architecture STAR v3.1"]
              : ["Rapport mensuel VEEDDA", "Spécification v2"];
            const agents = text.includes("risque") || text.includes("api")
              ? ["⬡ Architecture", "▲ Risk", "◷ Planning"]
              : ["⬡ Architecture", "◈ Finance"];
            const conf = Math.min(94, 55 + Math.ceil((objective.length + missionText.length) / 8));
            const missing = text.length < 60 ? ["Contexte programme", "Contraintes budget"] : text.length < 120 ? ["Contraintes budget"] : [];
            return (
              <div style={{ background: S.white, borderRadius: 12, border: `1.5px solid ${S.teal}55`, boxShadow: shadow.md, overflow: "hidden" }}>
                <div style={{ padding: "10px 14px", borderBottom: `1px solid ${S.g100}`, display: "flex", alignItems: "center", gap: 7 }}>
                  <span style={{ width: 7, height: 7, borderRadius: "50%", background: S.success, animation: "stPulse 1.5s ease infinite" }} />
                  <span style={{ fontSize: 11, fontWeight: 700, color: S.teal }}>ORCHESTRATOR analyse en direct</span>
                </div>
                <div style={{ padding: "12px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
                  <div>
                    <div style={{ fontSize: 10, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 5 }}>Documents détectés</div>
                    {docs.map((d, i) => <div key={i} style={{ fontSize: 12, color: S.teal, display: "flex", alignItems: "center", gap: 5, padding: "2px 0" }}><span style={{ fontSize: 9 }}>□</span>{d}</div>)}
                  </div>
                  <div>
                    <div style={{ fontSize: 10, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 5 }}>Agents sélectionnés</div>
                    <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                      {agents.map((a, i) => <span key={i} style={{ fontSize: 11, color: S.teal, background: S.tealLight, padding: "2px 7px", borderRadius: 5 }}>{a}</span>)}
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 14 }}>
                    <div><div style={{ fontSize: 10, color: S.g400 }}>Confiance</div><div style={{ fontSize: 14, fontWeight: 700, color: conf >= 80 ? S.success : S.warning }}>{conf}%</div></div>
                    <div><div style={{ fontSize: 10, color: S.g400 }}>Durée estimée</div><div style={{ fontSize: 14, fontWeight: 700, color: S.g900 }}>~{Math.max(2, Math.ceil(conf / 25))} min</div></div>
                  </div>
                  {missing.length > 0 && (
                    <div style={{ padding: "7px 10px", background: S.warningLight, border: `1px solid ${S.warning}44`, borderRadius: 7 }}>
                      <div style={{ fontSize: 10, fontWeight: 600, color: "#92400e", marginBottom: 4 }}>Informations manquantes</div>
                      {missing.map((m, i) => <div key={i} style={{ fontSize: 11, color: "#78350f" }}>· {m}</div>)}
                    </div>
                  )}
                </div>
              </div>
            );
          })()}

          {/* Bibliothèque de prompts */}
          <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, overflow: "hidden" }}>
            <div style={{ padding: "12px 14px", borderBottom: `1px solid ${S.g100}`, display: "flex", alignItems: "center", gap: 6 }}>
              <FileText size={13} color={S.teal} />
              <span style={{ fontSize: 11, fontWeight: 600, color: S.g700 }}>Bibliothèque</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0 }}>
              {MISSION_TEMPLATES.map((tpl, i) => (
                <button key={tpl.id}
                  onClick={() => { setObjective(tpl.objective); setMissionText(tpl.text); }}
                  style={{ padding: "9px 10px", background: "transparent", border: "none", borderBottom: i < MISSION_TEMPLATES.length - 2 ? `1px solid ${S.g100}` : "none", borderRight: i % 2 === 0 ? `1px solid ${S.g100}` : "none", cursor: "pointer", textAlign: "left", transition: T }}
                  onMouseEnter={e => (e.currentTarget.style.background = S.g50)}
                  onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
                >
                  <span style={{ fontSize: 12, color: S.g600 }}>{tpl.icon} </span>
                  <span style={{ fontSize: 11, fontWeight: 500, color: S.g700 }}>{tpl.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Agents — live cards */}
          <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, overflow: "hidden" }}>
            <div style={{ padding: "12px 14px", borderBottom: `1px solid ${S.g100}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <Bot size={13} color={S.teal} />
                <span style={{ fontSize: 11, fontWeight: 600, color: S.g700 }}>Équipe agents</span>
              </div>
              <button onClick={() => setAutoAgents(!autoAgents)}
                style={{ fontSize: 11, padding: "2px 8px", background: autoAgents ? S.teal20 : S.g100, border: `1px solid ${autoAgents ? S.teal + "44" : S.g200}`, borderRadius: 5, color: autoAgents ? S.teal : S.g500, cursor: "pointer", fontWeight: autoAgents ? 500 : 400, transition: T }}
              >{autoAgents ? "✓ Auto" : "Manuel"}</button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0 }}>
              {SPECIALIST_AGENTS.map((agent, i) => {
                const isAutoActive = autoAgents && ["architecture","planning","finance","risk"].includes(agent.id);
                const isSelected = !autoAgents && selectedAgentIds.includes(agent.id);
                const isActive = isAutoActive || isSelected;
                const liveState = agentLiveStates[agent.id];
                const phase = liveState?.phase || "ready";
                return (
                  <button key={agent.id}
                    onClick={() => { if (autoAgents) return; setSelectedAgentIds(prev => prev.includes(agent.id) ? prev.filter(x => x !== agent.id) : [...prev, agent.id]); }}
                    style={{ padding: "10px 10px", background: isActive ? S.teal20 : "transparent", border: "none", borderBottom: i < SPECIALIST_AGENTS.length - 2 ? `1px solid ${S.g100}` : "none", borderRight: i % 2 === 0 ? `1px solid ${S.g100}` : "none", cursor: autoAgents ? "default" : "pointer", textAlign: "left", transition: T, opacity: autoAgents && !isAutoActive ? 0.4 : 1 }}
                    onMouseEnter={e => { if (!autoAgents) e.currentTarget.style.background = S.teal20; }}
                    onMouseLeave={e => { if (!autoAgents) e.currentTarget.style.background = isSelected ? S.teal20 : "transparent"; }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 3 }}>
                      <span style={{ fontSize: 12, color: isActive ? agent.color : S.g400 }}>{agent.icon}</span>
                      <span style={{ fontSize: 11, fontWeight: 600, color: S.g900 }}>{agent.name}</span>
                      {isActive && (
                        <span style={{ width: 5, height: 5, borderRadius: "50%", background: phase === "done" ? S.success : phase === "active" ? S.teal : S.g300, marginLeft: "auto", flexShrink: 0, animation: phase === "active" ? "stPulse 1.5s ease infinite" : undefined }} />
                      )}
                    </div>
                    <div style={{ fontSize: 10, color: phase === "done" ? S.success : phase === "active" ? S.teal : S.g400, lineHeight: 1.3 }}>
                      {isActive ? (liveState?.text || "Disponible") : agent.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Historique missions */}
          <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, overflow: "hidden" }}>
            <div style={{ padding: "12px 14px", borderBottom: `1px solid ${S.g100}` }}>
              <span style={{ fontSize: 11, fontWeight: 600, color: S.g700 }}>Historique du jour</span>
            </div>
            {RECENT_MISSIONS.map((m, i) => (
              <div key={i} style={{ padding: "9px 12px", borderBottom: i < RECENT_MISSIONS.length - 1 ? `1px solid ${S.g100}` : "none", display: "flex", alignItems: "center", gap: 8, cursor: "pointer", transition: T }}
                onMouseEnter={e => (e.currentTarget.style.background = S.g50)}
                onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
              >
                <span style={{ fontSize: 10, color: S.g400, flexShrink: 0, fontVariantNumeric: "tabular-nums", width: 30 }}>{m.time}</span>
                <span style={{ flex: 1, fontSize: 12, color: S.g700, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.name}</span>
                <CheckCircle size={12} color={S.success} style={{ flexShrink: 0 }} />
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes stSpin { to { transform: rotate(360deg); } }
        @keyframes stPulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.6;transform:scale(1.3)} }
      `}</style>
    </div>
  );
}

// ─── MISSION CONTROL PAGE ─────────────────────────────────────────────────────
function MissionControlPage({ openDrawer, onNavigateToPilotage }: { openDrawer: (d: DrawerItem) => void; onNavigateToPilotage: () => void; }) {
  const [studioState, setStudioState] = useState<StudioState>("idle");
  const isStudioOpen = studioState !== "idle";

  function openStudio() { setStudioState("editing"); }
  function closeStudio() { setStudioState("idle"); }

  return (
    <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
      {/* Main area */}
      <div style={{ flex: 1, overflowY: "auto", background: S.g50 }}>
        {isStudioOpen ? (
          <MissionStudio
            studioState={studioState as "editing" | "running"}
            onStateChange={s => setStudioState(s)}
            onClose={closeStudio}
          />
        ) : (
          <CockpitContent
            openDrawer={openDrawer}
            onNavigateToPilotage={onNavigateToPilotage}
            onOpenStudio={openStudio}
          />
        )}
      </div>

      {/* Context sidebar — slides in via CSS width transition */}
      <div style={{
        width: isStudioOpen ? 300 : 0,
        flexShrink: 0,
        overflow: "hidden",
        transition: `width 420ms ${ease}`,
        borderLeft: isStudioOpen ? `1px solid ${S.g200}` : "none",
        background: S.white,
      }}>
        {isStudioOpen && <ContextSidebar openDrawer={openDrawer} />}
      </div>
    </div>
  );
}

// ─── ACTIVITY FEED ───────────────────────────────────────────────────────────
function ActivityFeed() {
  const [events, setEvents] = useState(INITIAL_ACTIVITY);
  useEffect(() => {
    const timer = setInterval(() => {
      const e = ACTIVITY_POOL[Math.floor(Math.random() * ACTIVITY_POOL.length)];
      const time = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
      setEvents(prev => [{ ...e, id: Date.now().toString(), time }, ...prev].slice(0, 7));
    }, 11000 + Math.random() * 7000);
    return () => clearInterval(timer);
  }, []);
  return (
    <div style={{ marginTop: 28 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <span style={{ width: 7, height: 7, borderRadius: "50%", background: S.success, display: "inline-block", animation: "stPulse 2s ease infinite" }} />
        <span style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px" }}>Activité système — En direct</span>
      </div>
      <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, overflow: "hidden" }}>
        {events.map((e, i) => (
          <div key={e.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "9px 18px", borderBottom: i < events.length - 1 ? `1px solid ${S.g100}` : "none", opacity: Math.max(0.45, 1 - i * 0.1), transition: T }}>
            <span style={{ fontSize: 11, color: S.g400, width: 36, flexShrink: 0, fontVariantNumeric: "tabular-nums" }}>{e.time}</span>
            <span style={{ fontSize: 12, color: e.color, flexShrink: 0, width: 14 }}>{e.icon}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: S.g900 }}>{e.agent}</span>
              <span style={{ fontSize: 13, color: S.g600 }}> {e.action}</span>
            </div>
            <span style={{ fontSize: 11, color: S.g400, flexShrink: 0 }}>{e.program}</span>
          </div>
        ))}
        {/* Breathing — agents working right now */}
        <div style={{ padding: "10px 18px", borderTop: `1px solid ${S.g100}`, background: S.g50 }}>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            {[
              { icon: "⬡", agent: "Architecture", task: "Analyse dépendances API...", color: S.teal, delay: "0s" },
              { icon: "▲", agent: "Risk", task: "Surveillance 4 vecteurs", color: S.error, delay: "0.4s" },
              { icon: "◷", agent: "Planning", task: "Recalcul jalons en cours...", color: S.cyan, delay: "0.8s" },
              { icon: "◉", agent: "Mémoire", task: "Indexation 3 documents...", color: S.g500, delay: "1.2s" },
            ].map((a, i) => (
              <span key={i} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: S.g500 }}>
                <span style={{ color: a.color, animation: `stPulse 2s ease ${a.delay} infinite`, fontSize: 10 }}>◌</span>
                <span style={{ fontWeight: 500, color: S.g700 }}>{a.agent}</span>
                <span style={{ color: S.g400 }}>{a.task}</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── PILOTAGE PAGE — OS Workspace ────────────────────────────────────────────
type OSSelection = { type: string; id: string };

function ObjectTree({ selected, onSelect }: { selected: OSSelection | null; onSelect: (s: OSSelection) => void }) {
  const tree = [
    { id: "missions", label: "Missions", icon: "◆", items: MISSIONS.map(m => ({ id: m.id, label: m.name, dot: m.status === "critique" || m.status === "bloqué" ? S.error : m.status === "retard" ? S.warning : m.status === "en cours" ? S.teal : S.g300 })) },
    { id: "agents",   label: "Agents",   icon: "⬡", items: SPECIALIST_AGENTS.slice(0, 4).map(a => ({ id: a.id, label: a.name, dot: ["architecture","risk"].includes(a.id) ? S.success : S.g300 })) },
    { id: "risques",  label: "Risques",  icon: "▲", items: RISKS.map(r => ({ id: r.id, label: r.title.length > 30 ? r.title.slice(0, 28) + "…" : r.title, dot: r.level === "critique" ? S.error : S.warning })) },
    { id: "roadmap",  label: "Roadmap",  icon: "◷", items: [{ id: "roadmap", label: "Vue planning", dot: S.teal }] },
    { id: "memoire",  label: "Mémoire",  icon: "◉", items: [{ id: "memoire", label: "Base de connaissances", dot: S.teal }] },
  ];
  return (
    <div style={{ width: 210, flexShrink: 0, background: S.white, borderRight: `1px solid ${S.g200}`, overflowY: "auto", paddingTop: 14 }}>
      <div style={{ padding: "0 14px 10px", fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px" }}>Système VEEDDA</div>
      {tree.map(section => (
        <div key={section.id} style={{ marginBottom: 4 }}>
          <div style={{ padding: "5px 14px", fontSize: 11, fontWeight: 600, color: S.g500, display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 9 }}>{section.icon}</span>{section.label}
          </div>
          {section.items.map(item => {
            const isSel = selected?.id === item.id;
            return (
              <button key={item.id} onClick={() => onSelect({ type: section.id, id: item.id })}
                style={{ width: "100%", padding: "5px 14px 5px 22px", background: isSel ? S.teal20 : "transparent", border: "none", textAlign: "left", cursor: "pointer", display: "flex", alignItems: "center", gap: 7, transition: T }}
                onMouseEnter={e => { if (!isSel) e.currentTarget.style.background = S.g50; }}
                onMouseLeave={e => { if (!isSel) e.currentTarget.style.background = "transparent"; }}
              >
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: item.dot, flexShrink: 0 }} />
                <span style={{ fontSize: 12, color: isSel ? S.teal : S.g700, fontWeight: isSel ? 600 : 400, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.label}</span>
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}

function MissionWorkspace({ id, openDrawer }: { id: string; openDrawer: (d: DrawerItem) => void }) {
  const [activeTab, setActiveTab] = useState("general");
  const mission = MISSIONS.find(m => m.id === id);
  if (!mission) return null;
  const barColor = mission.status === "critique" || mission.status === "bloqué" ? S.error : mission.status === "retard" ? S.warning : S.teal;
  const bv = (mission.status === "critique" || mission.status === "bloqué" ? "error" : mission.status === "retard" ? "warning" : mission.status === "en cours" ? "primary" : "neutral") as "error"|"warning"|"primary"|"neutral";
  const lbl = { critique: "Critique", bloqué: "Bloqué", retard: "En retard", "en cours": "En cours", planifié: "Planifié" }[mission.status];
  const linkedAgents = SPECIALIST_AGENTS.filter(a => ["architecture","risk"].includes(a.id));
  const linkedRisks = RISKS.filter(r => r.program === mission.program).slice(0, 2);
  const linkedDecisions = DECISIONS.filter(d => d.program === mission.program).slice(0, 2);
  const [warRoom, setWarRoom] = useState(false);
  const [quickActionDone, setQuickActionDone] = useState<string | null>(null);
  const [convInput, setConvInput] = useState("");
  const [convMessages, setConvMessages] = useState([
    { id: "c1", speaker: "Architecture Agent", icon: "⬡", color: S.teal, text: "J'ai analysé l'architecture multi-agents. Elle est techniquement solide. Je propose de valider immédiatement.", time: "09:14", type: "agent" as const, replyTo: null as string | null, actions: ["→ Créer une décision", "→ Ajouter à la mémoire"] },
    { id: "c2", speaker: "Planning Agent", icon: "◷", color: S.cyan, text: "→ Architecture : Impossible avant le 5 juillet dans l'état actuel. Le sprint 8 est bloqué depuis 5 jours.", time: "09:15", type: "agent" as const, replyTo: "Architecture Agent", actions: ["→ Mettre à jour le planning"] },
    { id: "c3", speaker: "Finance Agent", icon: "◈", color: S.success, text: "→ Planning : Le coût du blocage est de €9k/jour. Total cumulé : €45k. Chaque heure compte.", time: "09:16", type: "agent" as const, replyTo: "Planning Agent", actions: ["→ Créer un rapport", "→ Créer une décision"] },
    { id: "c4", speaker: "Risk Monitor", icon: "▲", color: S.error, text: "→ Finance : Le risque dépasse le seuil critique. Je détecte une cascade vers 3 autres missions si non résolu dans 48h.", time: "09:17", type: "agent" as const, replyTo: "Finance Agent", actions: ["→ Créer un risque", "→ Ouvrir War Room"] },
    { id: "c5", speaker: "ORCHESTRATOR", icon: "⚡", color: S.teal, text: "Synthèse de l'équipe : validation immédiate recommandée. Scénario B écarté. Risque technique maîtrisé (94% de confiance). Je propose une décision.", time: "09:18", type: "agent" as const, replyTo: null as string | null, actions: ["→ Créer la décision", "→ Mission Studio", "→ Ajouter à la mémoire"] },
    { id: "c6", speaker: "Jeff (vous)", icon: "JD", color: S.g500, text: "ORCHESTRATOR, prépare un dossier pour la revue de phase du 4 juillet.", time: "09:22", type: "user" as const, replyTo: null as string | null, actions: [] },
    { id: "c7", speaker: "ORCHESTRATOR", icon: "⚡", color: S.teal, text: "Dossier en préparation. VEEDDA Analyst et Document Agent mobilisés. Livrable estimé dans 4 minutes.", time: "09:22", type: "agent" as const, replyTo: "Jeff (vous)", actions: ["→ Suivre l'avancement", "→ Ouvrir le dossier"] },
  ]);
  const tabs = [
    { id: "general", label: "Vue générale" },
    { id: "agents", label: "Agents & IA" },
    { id: "conversation", label: "Conversation" },
    { id: "documents", label: "Documents" },
    { id: "decisions", label: "Décisions" },
    { id: "historique", label: "Passé · Présent · Futur" },
  ];
  const isCritical = mission.status === "critique" || mission.status === "bloqué";

  function sendConvMessage() {
    if (!convInput.trim()) return;
    const userMsg = { id: Date.now().toString(), speaker: "Jeff (vous)", icon: "JD", color: S.g500, text: convInput, time: new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), type: "user" as const };
    setConvMessages(prev => [...prev, userMsg]);
    setConvInput("");
    setTimeout(() => {
      const aiMsg = { id: (Date.now()+1).toString(), speaker: "ORCHESTRATOR", icon: "⚡", color: S.teal, text: `Analyse de votre demande : "${convInput.slice(0, 40)}…". Agents mobilisés. Résultats disponibles dans 2-3 minutes.`, time: new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), type: "agent" as const };
      setConvMessages(prev => [...prev, aiMsg]);
    }, 1200);
  }

  // Reset when mission changes
  useEffect(() => { setActiveTab("general"); setWarRoom(false); setQuickActionDone(null); }, [id]);

  return (
    <div style={{ display: "flex", height: "100%", overflow: "hidden", position: "relative" }}>
      {/* Main workspace */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Header + tabs */}
        <div style={{ background: S.white, borderBottom: `1px solid ${S.g200}`, padding: "18px 24px 0", flexShrink: 0 }}>
          <div style={{ display: "flex", gap: 8, marginBottom: 6, flexWrap: "wrap" }}>
            <STARBadge variant={bv} label={lbl} />
            <span style={{ fontSize: 12, color: S.g500 }}>{mission.program} · {mission.owner}</span>
          </div>
          <h2 style={{ fontSize: 19, fontWeight: 700, color: S.g900, margin: "0 0 4px" }}>{mission.name}</h2>
          <p style={{ fontSize: 13, color: S.g600, margin: "0 0 12px", lineHeight: 1.5 }}>{mission.description}</p>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: -1 }}>
            <div style={{ display: "flex", gap: 0 }}>
              {tabs.map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                  style={{ padding: "8px 14px", background: "none", border: "none", borderBottom: `2px solid ${activeTab === tab.id ? S.teal : "transparent"}`, fontSize: 12, fontWeight: activeTab === tab.id ? 600 : 400, color: activeTab === tab.id ? S.teal : S.g500, cursor: "pointer", transition: T }}
                >{tab.label}</button>
              ))}
            </div>
            {isCritical && (
              <button onClick={() => setWarRoom(!warRoom)}
                style={{ marginBottom: 2, padding: "5px 12px", background: warRoom ? S.error : S.errorLight, color: warRoom ? S.white : "#b91c1c", border: `1px solid ${S.error}44`, borderRadius: 7, fontSize: 11, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, transition: T, letterSpacing: "0.3px" }}
                onMouseEnter={e => (e.currentTarget.style.background = S.error)}
                onMouseLeave={e => (e.currentTarget.style.background = warRoom ? S.error : S.errorLight)}
              >
                <span style={{ color: warRoom ? S.white : S.error }}>⚡</span>
                {warRoom ? "Quitter War Room" : "War Room"}
              </button>
            )}
          </div>
        </div>

        {/* Quick Actions strip */}
        <div style={{ display: "flex", alignItems: "center", gap: 5, padding: "8px 24px", background: S.g50, borderBottom: `1px solid ${S.g200}`, flexShrink: 0, flexWrap: "wrap" }}>
          <span style={{ fontSize: 10, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.5px", marginRight: 4 }}>Créer :</span>
          {quickActionDone ? (
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: S.success, fontWeight: 500 }}>
              <CheckCircle size={13} />{quickActionDone} créé{quickActionDone === "Rapport" || quickActionDone === "Note" ? "" : "e"} avec succès
              <button onClick={() => setQuickActionDone(null)} style={{ background: "none", border: "none", color: S.g400, cursor: "pointer", fontSize: 11 }}>×</button>
            </div>
          ) : (
            <>
              {["Décision", "Risque", "Document", "Rapport", "Note", "COPIL", "Réunion"].map((label, i) => (
                <button key={i} onClick={() => setQuickActionDone(label)}
                  style={{ padding: "4px 10px", background: S.white, color: S.g600, border: `1px solid ${S.g200}`, borderRadius: 6, fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, transition: T }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = S.teal; e.currentTarget.style.color = S.teal; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = S.g200; e.currentTarget.style.color = S.g600; }}
                >
                  <span style={{ fontSize: 13, lineHeight: 1, color: S.teal }}>+</span>{label}
                </button>
              ))}
              <button onClick={() => { setQuickActionDone(null); setActiveTab("conversation"); }}
                style={{ padding: "4px 12px", background: S.teal, color: S.white, border: "none", borderRadius: 6, fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, transition: T, marginLeft: 4, fontWeight: 500 }}
                onMouseEnter={e => (e.currentTarget.style.background = S.tealDark)}
                onMouseLeave={e => (e.currentTarget.style.background = S.teal)}
              >
                <Zap size={11} /> Lancer une analyse
              </button>
            </>
          )}
        </div>

        {/* Tab content */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px" }}>

          {/* ── VUE GÉNÉRALE ── */}
          {activeTab === "general" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {/* PRIORITY 1: Blocages */}
              {mission.blockers.length > 0 && (
                <div style={{ padding: "14px 18px", background: S.errorLight, border: `1px solid ${S.error}33`, borderRadius: 12 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: S.error, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 8 }}>Blocages — Action immédiate requise</div>
                  {mission.blockers.map((b, i) => (
                    <div key={i} style={{ fontSize: 13, color: "#b91c1c", display: "flex", gap: 8, alignItems: "flex-start", marginBottom: i < mission.blockers.length - 1 ? 6 : 0 }}>
                      <AlertTriangle size={13} style={{ flexShrink: 0, marginTop: 2 }} />{b}
                    </div>
                  ))}
                </div>
              )}
              {/* PRIORITY 2: Décision liée urgente */}
              {linkedDecisions[0] && (
                <div style={{ padding: "14px 18px", background: S.teal20, border: `1px solid ${S.teal}22`, borderRadius: 12, display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 14 }}>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: S.teal, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 5 }}>Décision attendue</div>
                    <div style={{ fontSize: 13, color: S.g900, fontWeight: 500 }}>{linkedDecisions[0].title}</div>
                    <div style={{ fontSize: 11, color: S.g500, marginTop: 3 }}>Recommandé : {linkedDecisions[0].recommendation}</div>
                  </div>
                  <button onClick={() => openDrawer({ type: "decision", data: linkedDecisions[0] })}
                    style={{ padding: "7px 14px", background: S.teal, color: S.white, border: "none", borderRadius: 7, fontSize: 12, fontWeight: 600, cursor: "pointer", flexShrink: 0, transition: T }}
                    onMouseEnter={e => (e.currentTarget.style.background = S.tealDark)}
                    onMouseLeave={e => (e.currentTarget.style.background = S.teal)}
                  >Décider</button>
                </div>
              )}
              {/* Progress + milestones */}
              <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px 20px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 13 }}>
                  <span style={{ color: S.g600 }}>Avancement</span>
                  <div style={{ display: "flex", gap: 16 }}>
                    <span style={{ fontWeight: 700, color: S.g900, fontVariantNumeric: "tabular-nums" }}>{mission.progress}%</span>
                    <span style={{ color: mission.daysLeft <= 5 ? S.error : S.g500 }}>Échéance {mission.deadline} · J-{mission.daysLeft}</span>
                  </div>
                </div>
                <div style={{ height: 7, background: S.g100, borderRadius: 9999, overflow: "hidden", marginBottom: 16 }}>
                  <div style={{ height: "100%", width: `${mission.progress}%`, background: barColor, borderRadius: 9999, transition: T }} />
                </div>
                <div style={{ display: "flex", gap: 0 }}>
                  {mission.milestones.map((step, i) => (
                    <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 5 }}>
                      <div style={{ width: 16, height: 16, borderRadius: "50%", border: `2px solid ${step.done ? S.success : step.blocked ? S.error : step.active ? S.teal : S.g300}`, background: step.done ? S.success : step.blocked ? S.errorLight : step.active ? S.tealLight : S.white, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        {step.done && <span style={{ color: S.white, fontSize: 8, fontWeight: 700 }}>✓</span>}
                        {step.blocked && <span style={{ color: S.error, fontSize: 8, fontWeight: 700 }}>!</span>}
                      </div>
                      <div style={{ fontSize: 10, color: step.done ? S.g400 : step.active ? S.g900 : S.g400, textAlign: "center", lineHeight: 1.2 }}>{step.label}</div>
                    </div>
                  ))}
                </div>
              </div>
              {/* Relations */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                {[
                  {
                    title: "Agents mobilisés",
                    content: linkedAgents.map((a, i) => (
                      <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderBottom: i < linkedAgents.length - 1 ? `1px solid ${S.g100}` : "none" }}>
                        <span style={{ fontSize: 11, color: a.color }}>{a.icon}</span>
                        <span style={{ fontSize: 12, fontWeight: 500, color: S.g900 }}>{a.name}</span>
                        <span style={{ width: 6, height: 6, borderRadius: "50%", background: S.success, marginLeft: "auto", animation: "stPulse 2s ease infinite" }} />
                      </div>
                    ))
                  },
                  {
                    title: "Risques liés",
                    content: linkedRisks.map((r, i) => (
                      <button key={r.id} onClick={() => openDrawer({ type: "risk", data: r })}
                        style={{ width: "100%", display: "flex", gap: 7, padding: "6px 0", borderBottom: i < linkedRisks.length - 1 ? `1px solid ${S.g100}` : "none", background: "none", border: "none", cursor: "pointer", textAlign: "left" }}
                      >
                        <span style={{ fontSize: 10, color: S.error, marginTop: 1 }}>▲</span>
                        <span style={{ fontSize: 12, color: S.g700, lineHeight: 1.3 }}>{r.title.length > 32 ? r.title.slice(0, 30) + "…" : r.title}</span>
                      </button>
                    ))
                  },
                  {
                    title: "Documents",
                    content: ["Cahier des charges v2", "Architecture STAR", "Contrat API"].map((doc, i) => (
                      <div key={i} style={{ display: "flex", gap: 7, padding: "6px 0", borderBottom: i < 2 ? `1px solid ${S.g100}` : "none", fontSize: 12, color: S.g700, alignItems: "center" }}>
                        <span style={{ color: S.g400, fontSize: 10 }}>□</span>{doc}
                      </div>
                    ))
                  }
                ].map((section, i) => (
                  <div key={i} style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "14px 16px" }}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 10 }}>{section.title}</div>
                    {section.content}
                  </div>
                ))}
              </div>
              {/* Mission vitals — health, tension, probability */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr 1fr", gap: 10 }}>
                {[
                  {
                    label: "Prob. de succès",
                    value: mission.blockers.length > 0 ? "58%" : `${Math.min(94, 55 + Math.floor(mission.progress / 3))}%`,
                    color: mission.blockers.length > 0 ? S.warning : S.success,
                    sub: mission.blockers.length > 0 ? "À risque" : "Favorable",
                  },
                  {
                    label: "Tension",
                    value: mission.blockers.length > 0 ? "Critique" : mission.daysLeft <= 5 ? "Élevée" : "Modérée",
                    color: mission.blockers.length > 0 ? S.error : mission.daysLeft <= 5 ? S.warning : S.success,
                    sub: `J-${mission.daysLeft}`,
                  },
                  { label: "Agents actifs", value: "2", color: S.teal, sub: "⬡ ▲ en mission" },
                  { label: "Temps IA", value: "6h 20m", color: S.g700, sub: "consommé" },
                  { label: "Mémoire", value: "4", color: S.g700, sub: "insights générés" },
                ].map((m, i) => (
                  <div key={i} style={{ background: S.white, borderRadius: 10, border: `1px solid ${S.g200}`, padding: "11px 13px", boxShadow: shadow.kpi }}>
                    <div style={{ fontSize: 10, color: S.g400, marginBottom: 4 }}>{m.label}</div>
                    <div style={{ fontSize: 15, fontWeight: 700, color: m.color, fontVariantNumeric: "tabular-nums", lineHeight: 1.2 }}>{m.value}</div>
                    <div style={{ fontSize: 10, color: S.g400, marginTop: 3 }}>{m.sub}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── AGENTS ── */}
          {activeTab === "agents" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {linkedAgents.map(a => {
                const profile = AGENT_PROFILES[a.id];
                return profile ? (
                  <div key={a.id} style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "18px 20px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
                      <div style={{ width: 40, height: 40, borderRadius: 12, background: S.teal20, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <span style={{ fontSize: 18, color: a.color }}>{a.icon}</span>
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 14, fontWeight: 700, color: S.g900 }}>{a.name}</div>
                        <div style={{ fontSize: 12, color: S.g500 }}>{profile.specialty}</div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ width: 7, height: 7, borderRadius: "50%", background: S.success, animation: "stPulse 2s ease infinite" }} />
                        <span style={{ fontSize: 12, color: S.success, fontWeight: 500 }}>En mission</span>
                        <span style={{ fontSize: 12, color: S.g400 }}>· confiance {profile.metrics.confidence}%</span>
                      </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                      <div>
                        <div style={{ fontSize: 10, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 7 }}>Travaux récents</div>
                        {profile.recentWork.map((w, i) => (
                          <div key={i} style={{ fontSize: 12, color: S.g700, padding: "4px 0", borderBottom: i < profile.recentWork.length - 1 ? `1px solid ${S.g100}` : "none" }}>
                            {w.label} <span style={{ color: S.g400 }}>· {w.time}</span>
                          </div>
                        ))}
                      </div>
                      <div>
                        <div style={{ fontSize: 10, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 7 }}>Expertise</div>
                        <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                          {profile.expertise.slice(0, 3).map((e, i) => (
                            <span key={i} style={{ padding: "3px 8px", background: S.teal20, border: `1px solid ${S.teal}33`, borderRadius: 5, fontSize: 11, color: S.teal }}>{e}</span>
                          ))}
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: 10, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 7 }}>Mémoire</div>
                        {profile.memory.slice(0, 2).map((m, i) => (
                          <div key={i} style={{ fontSize: 11, color: S.g600, padding: "3px 0", display: "flex", gap: 5 }}>
                            <span style={{ color: S.teal, flexShrink: 0 }}>💡</span>{m.length > 40 ? m.slice(0, 38) + "…" : m}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : null;
              })}
            </div>
          )}

          {/* ── CONVERSATION ── */}
          {activeTab === "conversation" && (
            <div style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 280px)", minHeight: 400 }}>
              {/* Participants */}
              <div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>
                <span style={{ fontSize: 11, color: S.g400, marginRight: 4 }}>Participants :</span>
                {[
                  { label: "ORCHESTRATOR", icon: "⚡", color: S.teal },
                  { label: "Architecture", icon: "⬡", color: S.teal },
                  { label: "Risk", icon: "▲", color: S.error },
                  { label: "Planning", icon: "◷", color: S.cyan },
                  { label: "Finance", icon: "◈", color: S.success },
                  { label: "Jeff (vous)", icon: "JD", color: S.g500 },
                ].map((p, i) => (
                  <span key={i} style={{ display: "flex", alignItems: "center", gap: 4, padding: "3px 8px", background: S.white, border: `1px solid ${S.g200}`, borderRadius: 9999, fontSize: 11, color: S.g700 }}>
                    <span style={{ fontSize: 10, color: p.color }}>{p.icon}</span>{p.label}
                    <span style={{ width: 5, height: 5, borderRadius: "50%", background: i < 5 ? S.success : S.g300, animation: i < 5 ? "stPulse 2s ease infinite" : undefined }} />
                  </span>
                ))}
              </div>
              {/* Messages */}
              <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 12, marginBottom: 14 }}>
                {convMessages.map(msg => (
                  <div key={msg.id} style={{ display: "flex", flexDirection: msg.type === "user" ? "row-reverse" : "row", gap: 10, alignItems: "flex-start" }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", background: msg.type === "user" ? S.g200 : msg.color, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: msg.replyTo ? 18 : 2 }}>
                      <span style={{ fontSize: msg.icon === "JD" ? 9 : 11, color: msg.type === "user" ? S.g600 : S.white, fontWeight: 700 }}>{msg.icon}</span>
                    </div>
                    <div style={{ maxWidth: "78%", minWidth: 0 }}>
                      {msg.replyTo && (
                        <div style={{ fontSize: 10, color: S.g400, marginBottom: 3, display: "flex", alignItems: "center", gap: 4 }}>
                          <span>↩</span> répondant à <span style={{ fontWeight: 600, color: S.g600 }}>{msg.replyTo}</span>
                        </div>
                      )}
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4, flexDirection: msg.type === "user" ? "row-reverse" : "row" }}>
                        <span style={{ fontSize: 11, fontWeight: 600, color: msg.color }}>{msg.speaker}</span>
                        <span style={{ fontSize: 10, color: S.g400 }}>{msg.time}</span>
                      </div>
                      <div style={{ padding: "10px 14px", background: msg.type === "user" ? S.teal20 : msg.speaker === "ORCHESTRATOR" ? S.tealLight : S.white, borderRadius: 12, borderBottomRightRadius: msg.type === "user" ? 4 : 12, borderBottomLeftRadius: msg.type === "agent" ? 4 : 12, border: `1px solid ${msg.type === "user" ? S.teal + "33" : msg.speaker === "ORCHESTRATOR" ? S.teal + "44" : S.g200}`, fontSize: 13, color: S.g700, lineHeight: 1.6, boxShadow: shadow.kpi }}>
                        {msg.text}
                      </div>
                      {msg.type === "agent" && msg.actions && msg.actions.length > 0 && (
                        <div style={{ display: "flex", gap: 5, marginTop: 5, flexWrap: "wrap" }}>
                          {msg.actions.map((action, ai) => (
                            <button key={ai}
                              style={{ padding: "3px 9px", background: "transparent", border: `1px solid ${S.g200}`, borderRadius: 5, fontSize: 11, color: S.teal, cursor: "pointer", transition: T }}
                              onMouseEnter={e => { e.currentTarget.style.background = S.tealLight; e.currentTarget.style.borderColor = S.teal; }}
                              onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.borderColor = S.g200; }}
                            >{action}</button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              {/* Input */}
              <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "10px 14px", display: "flex", gap: 10, flexShrink: 0 }}>
                <input value={convInput} onChange={e => setConvInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendConvMessage(); } }}
                  placeholder="Posez une question, demandez une analyse, déclenchez une tâche... (@agent, @mission, @risque)"
                  style={{ flex: 1, border: "none", outline: "none", fontSize: 13, color: S.g900, fontFamily: FONT, background: "transparent" }}
                />
                <button onClick={sendConvMessage} disabled={!convInput.trim()}
                  style={{ padding: "6px 14px", background: convInput.trim() ? S.teal : S.g200, color: convInput.trim() ? S.white : S.g400, border: "none", borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: convInput.trim() ? "pointer" : "default", display: "flex", alignItems: "center", gap: 5, transition: T, flexShrink: 0 }}
                  onMouseEnter={e => { if (convInput.trim()) e.currentTarget.style.background = S.tealDark; }}
                  onMouseLeave={e => { if (convInput.trim()) e.currentTarget.style.background = S.teal; }}
                >
                  <Send size={12} /> Envoyer
                </button>
              </div>
            </div>
          )}

          {/* ── DOCUMENTS ── */}
          {activeTab === "documents" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {[
                { name: "Cahier des charges VEEDDA v2", missions: 3, agents: ["Architecture", "VEEDDA Analyst"], confidence: 94, lastSeen: "Il y a 2h", decisions: 2 },
                { name: "Architecture STAR — v3.1", missions: 2, agents: ["Architecture"], confidence: 89, lastSeen: "Il y a 4h", decisions: 1 },
                { name: "Contrat API Partenaires", missions: 1, agents: ["Risk", "Legal"], confidence: 76, lastSeen: "Hier 16:30", decisions: 1 },
                { name: "Spécification API v2 (Draft)", missions: 1, agents: ["Architecture"], confidence: 45, lastSeen: "Il y a 6h", decisions: 0 },
              ].map((doc, i) => (
                <div key={i} style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px 20px" }}>
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 14, fontWeight: 600, color: S.g900, marginBottom: 8 }}>□ {doc.name}</div>
                      <div style={{ display: "flex", gap: 16, fontSize: 12, color: S.g500, flexWrap: "wrap" }}>
                        <span>{doc.missions} mission{doc.missions > 1 ? "s" : ""}</span>
                        <span>Agents : {doc.agents.join(", ")}</span>
                        <span>{doc.decisions} décision{doc.decisions !== 1 ? "s" : ""} liée{doc.decisions !== 1 ? "s" : ""}</span>
                        <span>Consultation : {doc.lastSeen}</span>
                      </div>
                    </div>
                    <div style={{ textAlign: "right", flexShrink: 0 }}>
                      <div style={{ fontSize: 10, color: S.g400 }}>Confiance</div>
                      <div style={{ fontSize: 18, fontWeight: 700, color: doc.confidence >= 85 ? S.success : doc.confidence >= 70 ? S.warning : S.error }}>{doc.confidence}%</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ── DÉCISIONS ── */}
          {activeTab === "decisions" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {linkedDecisions.map(d => (
                <div key={d.id} style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, overflow: "hidden" }}>
                  <div style={{ padding: "16px 20px", borderBottom: `1px solid ${S.g100}` }}>
                    <div style={{ display: "flex", gap: 8, marginBottom: 6 }}>
                      <STARBadge variant={d.priority === "critique" ? "error" : d.priority === "haute" ? "warning" : "primary"} label={d.priority === "critique" ? "Critique" : d.priority === "haute" ? "Haute" : "Normale"} />
                      <span style={{ fontSize: 12, color: S.g500 }}>depuis {d.waitingDays}j · Échéance {d.deadline}</span>
                    </div>
                    <div style={{ fontSize: 15, fontWeight: 600, color: S.g900 }}>{d.title}</div>
                  </div>
                  <div style={{ padding: "14px 20px", display: "flex", flexDirection: "column", gap: 12 }}>
                    {[
                      { label: "Impact", text: d.impact, color: S.error },
                      { label: "Contexte", text: d.context, color: S.g600 },
                      { label: "Recommandé par ORCHESTRATOR", text: d.recommendation, color: S.teal },
                    ].map((item, i) => (
                      <div key={i}>
                        <div style={{ fontSize: 10, fontWeight: 700, color: item.color, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 4 }}>{item.label}</div>
                        <div style={{ fontSize: 13, color: S.g700, lineHeight: 1.6 }}>{item.text}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ padding: "12px 20px", borderTop: `1px solid ${S.g100}`, display: "flex", gap: 8 }}>
                    <button onClick={() => openDrawer({ type: "decision", data: d })}
                      style={{ padding: "8px 18px", background: S.teal, color: S.white, border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer", transition: T }}
                      onMouseEnter={e => (e.currentTarget.style.background = S.tealDark)}
                      onMouseLeave={e => (e.currentTarget.style.background = S.teal)}
                    >{d.recommendation}</button>
                    <button style={{ padding: "8px 14px", background: "transparent", color: S.g600, border: `1px solid ${S.g200}`, borderRadius: 8, fontSize: 13, cursor: "pointer" }}>Reporter</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ── HISTORIQUE ── */}
          {activeTab === "historique" && (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
              {/* PASSÉ */}
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.7px", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                  <span>←</span> Passé
                </div>
                <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, overflow: "hidden" }}>
                  {[
                    { time: "Hier 17:30", agent: "Finance Agent", action: "Estimation coût retard : €36k", icon: "◈", color: S.success },
                    { time: "Hier 14:22", agent: "ORCHESTRATOR", action: "Alerte créée : blocage API", icon: "⚡", color: S.teal },
                    { time: "Hier 09:00", agent: "Architecture", action: "Analyse dépendances démarrée", icon: "⬡", color: S.teal },
                  ].map((e, i, arr) => (
                    <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 14px", borderBottom: i < arr.length - 1 ? `1px solid ${S.g100}` : "none" }}>
                      <span style={{ fontSize: 11, color: e.color, flexShrink: 0, marginTop: 1 }}>{e.icon}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 500, color: S.g700 }}>{e.agent}</div>
                        <div style={{ fontSize: 11, color: S.g500, marginTop: 2 }}>{e.action}</div>
                        <div style={{ fontSize: 10, color: S.g400, marginTop: 3 }}>{e.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* PRÉSENT */}
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: S.teal, textTransform: "uppercase", letterSpacing: "0.7px", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ width: 7, height: 7, borderRadius: "50%", background: S.success, display: "inline-block", animation: "stPulse 2s ease infinite" }} />
                  En cours
                </div>
                <div style={{ background: S.white, borderRadius: 12, border: `1.5px solid ${S.teal}44`, boxShadow: shadow.md, overflow: "hidden" }}>
                  {[
                    { time: "11:24", agent: "Risk Monitor", action: "Détection risque en cours", icon: "▲", color: S.error, active: true },
                    { time: "10:11", agent: "Architecture", action: "Analyse architecturale complète", icon: "⬡", color: S.teal, active: false },
                    { time: "09:32", agent: "Planning", action: "Jalons mis à jour — 1 conflit résolu", icon: "◷", color: S.cyan, active: false },
                    { time: "09:14", agent: "VEEDDA Analyst", action: "12 documents analysés", icon: "◉", color: S.teal, active: false },
                  ].map((e, i, arr) => (
                    <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 14px", borderBottom: i < arr.length - 1 ? `1px solid ${S.g100}` : "none", background: e.active ? S.teal20 : "transparent" }}>
                      <span style={{ fontSize: 11, color: e.color, flexShrink: 0, marginTop: 1, animation: e.active ? "stPulse 1.5s ease infinite" : undefined }}>{e.icon}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 500, color: S.g700 }}>{e.agent}</div>
                        <div style={{ fontSize: 11, color: e.active ? S.teal : S.g500, marginTop: 2 }}>{e.action}</div>
                        <div style={{ fontSize: 10, color: S.g400, marginTop: 3 }}>{e.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* PROJECTION */}
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: S.g500, textTransform: "uppercase", letterSpacing: "0.7px", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                  <span>→</span> Projection
                </div>
                <div style={{ background: S.white, borderRadius: 12, border: `1px dashed ${S.g300}`, overflow: "hidden" }}>
                  {[
                    { time: "J+1", label: "Si décision validée", action: "Sprint 8 démarre — €45k débloqués", icon: "✓", color: S.success, type: "positif" as const },
                    { time: "J+3", label: "Si non résolu", action: "Retard en cascade sur l'Interface v2", icon: "⚠", color: S.warning, type: "risque" as const },
                    { time: "J+5", label: "Scénario critique", action: "Deadline API (5 juil.) non atteignable", icon: "⚡", color: S.error, type: "critique" as const },
                  ].map((e, i, arr) => (
                    <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 14px", borderBottom: i < arr.length - 1 ? `1px solid ${S.g100}` : "none", background: e.type === "positif" ? S.successLight : "transparent" }}>
                      <span style={{ fontSize: 12, color: e.color, flexShrink: 0, marginTop: 1 }}>{e.icon}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <span style={{ fontSize: 10, fontWeight: 700, color: e.color, fontVariantNumeric: "tabular-nums" }}>{e.time}</span>
                          <span style={{ fontSize: 10, color: S.g400 }}>· {e.label}</span>
                        </div>
                        <div style={{ fontSize: 11, color: e.type === "positif" ? "#065f46" : S.g600, marginTop: 3, lineHeight: 1.4 }}>{e.action}</div>
                      </div>
                    </div>
                  ))}
                  <div style={{ padding: "8px 14px", fontSize: 10, color: S.g400, fontStyle: "italic", borderTop: `1px solid ${S.g100}` }}>
                    Projections ORCHESTRATOR · mise à jour en temps réel
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ORCHESTRATOR analysis panel */}
      <OrchestratorPanel mission={mission} openDrawer={openDrawer} />

      {/* War Room overlay */}
      {warRoom && (
        <div style={{ position: "absolute", inset: 0, background: "#0a0f1a", zIndex: 20, overflowY: "auto", display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "20px 28px", borderBottom: "1px solid rgba(239,68,68,0.3)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: S.error, animation: "stPulse 1.2s ease infinite" }} />
              <span style={{ fontSize: 14, fontWeight: 700, color: S.white, letterSpacing: "0.5px" }}>WAR ROOM</span>
              <span style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>·</span>
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.6)" }}>{mission.name}</span>
            </div>
            <button onClick={() => setWarRoom(false)} style={{ padding: "5px 12px", background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.6)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 7, fontSize: 12, cursor: "pointer", transition: T }}
              onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.15)")}
              onMouseLeave={e => (e.currentTarget.style.background = "rgba(255,255,255,0.08)")}
            >↑ Quitter</button>
          </div>
          <div style={{ flex: 1, padding: "24px 28px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gridTemplateRows: "auto auto", gap: 16 }}>
            {/* Blocages */}
            <div style={{ background: "rgba(239,68,68,0.1)", borderRadius: 12, border: "1px solid rgba(239,68,68,0.3)", padding: "16px" }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: S.error, textTransform: "uppercase", letterSpacing: "0.7px", marginBottom: 12 }}>Blocages actifs</div>
              {mission.blockers.length > 0 ? mission.blockers.map((b, i) => (
                <div key={i} style={{ fontSize: 13, color: "#fca5a5", display: "flex", gap: 8, marginBottom: 8, lineHeight: 1.5 }}>
                  <span style={{ color: S.error, flexShrink: 0 }}>⚠</span>{b}
                </div>
              )) : <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)" }}>Aucun blocage actif</div>}
            </div>
            {/* Agents */}
            <div style={{ background: "rgba(15,89,98,0.15)", borderRadius: 12, border: "1px solid rgba(15,89,98,0.3)", padding: "16px" }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#6CB4C7", textTransform: "uppercase", letterSpacing: "0.7px", marginBottom: 12 }}>Équipe mobilisée</div>
              {linkedAgents.map((a, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 0", borderBottom: i < linkedAgents.length - 1 ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
                  <span style={{ fontSize: 13, color: a.color }}>{a.icon}</span>
                  <span style={{ fontSize: 13, color: "rgba(255,255,255,0.8)", fontWeight: 500 }}>{a.name}</span>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: S.success, marginLeft: "auto", animation: "stPulse 2s ease infinite" }} />
                </div>
              ))}
            </div>
            {/* Décisions */}
            <div style={{ background: "rgba(245,158,11,0.1)", borderRadius: 12, border: "1px solid rgba(245,158,11,0.3)", padding: "16px" }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: S.warning, textTransform: "uppercase", letterSpacing: "0.7px", marginBottom: 12 }}>Décisions requises</div>
              {linkedDecisions.map((d, i) => (
                <div key={i} style={{ marginBottom: 10 }}>
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.7)", lineHeight: 1.4, marginBottom: 6 }}>{d.title}</div>
                  <button onClick={() => openDrawer({ type: "decision", data: d })}
                    style={{ padding: "5px 12px", background: S.teal, color: S.white, border: "none", borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: "pointer", transition: T }}
                  >Décider</button>
                </div>
              ))}
            </div>
            {/* Analyse ORCHESTRATOR */}
            <div style={{ gridColumn: "1 / -1", background: "rgba(15,89,98,0.1)", borderRadius: 12, border: "1px solid rgba(15,89,98,0.25)", padding: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                <div style={{ width: 22, height: 22, borderRadius: "50%", background: S.teal, display: "flex", alignItems: "center", justifyContent: "center", animation: "stPulse 2.5s ease infinite" }}><Zap size={10} color={S.white} /></div>
                <span style={{ fontSize: 12, fontWeight: 700, color: S.teal }}>ORCHESTRATOR — Analyse War Room</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
                <div>
                  <div style={{ fontSize: 10, fontWeight: 600, color: S.teal, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 7 }}>Situation</div>
                  <p style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", margin: 0, lineHeight: 1.6 }}>
                    {mission.blockers.length > 0 ? `${mission.blockers.length} blocage critique. Coût cumulé estimé : €${Math.ceil(mission.daysLeft * 9)}k. Chaque heure compte.` : `Mission sous contrôle à ${mission.progress}%. Aucune action immédiate requise.`}
                  </p>
                </div>
                <div>
                  <div style={{ fontSize: 10, fontWeight: 600, color: S.teal, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 7 }}>Action immédiate</div>
                  <p style={{ fontSize: 13, color: "rgba(255,255,255,0.8)", margin: 0, lineHeight: 1.6, fontWeight: 500 }}>
                    {mission.status === "bloqué" ? "Valider l'architecture multi-agents. Risque technique faible, impact économique fort." : "Contacter le partenaire et préparer plan B avant J+2."}
                  </p>
                </div>
                <div>
                  <div style={{ fontSize: 10, fontWeight: 600, color: S.teal, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 7 }}>Projection J+5</div>
                  <p style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", margin: 0, lineHeight: 1.6 }}>
                    {mission.blockers.length > 0 ? "Si résolu aujourd'hui : sprint 8 démarrable demain. Deadline du 18 juil. maintenue." : "Progression conforme. Objectif atteignable sans intervention."}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function AgentWorkspace({ id }: { id: string }) {
  const agent = SPECIALIST_AGENTS.find(a => a.id === id);
  const profile = AGENT_PROFILES[id];
  if (!agent || !profile) return null;
  return (
    <div style={{ padding: "28px 32px", overflowY: "auto", height: "100%" }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 18, marginBottom: 24 }}>
        <div style={{ width: 52, height: 52, borderRadius: 14, background: S.teal20, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <span style={{ fontSize: 22, color: agent.color }}>{agent.icon}</span>
        </div>
        <div>
          <div style={{ display: "flex", gap: 8, marginBottom: 5 }}>
            <STARBadge variant="success" label="Actif" />
            <span style={{ fontSize: 12, color: S.g500 }}>{agent.id === "architecture" || agent.id === "risk" ? "En mission" : "Disponible"}</span>
          </div>
          <h2 style={{ fontSize: 21, fontWeight: 700, color: S.g900, margin: "0 0 4px" }}>{agent.name}</h2>
          <p style={{ fontSize: 14, color: S.g600, margin: 0 }}>{profile.specialty}</p>
        </div>
      </div>
      <div style={{ display: "flex", gap: 7, flexWrap: "wrap", marginBottom: 22 }}>
        {profile.expertise.map((e, i) => (
          <span key={i} style={{ padding: "4px 10px", background: S.teal20, border: `1px solid ${S.teal}33`, borderRadius: 6, fontSize: 12, color: S.teal }}>{e}</span>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, marginBottom: 20 }}>
        <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px 18px" }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 12 }}>Travaux récents</div>
          {profile.recentWork.map((w, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 0", borderBottom: i < profile.recentWork.length - 1 ? `1px solid ${S.g100}` : "none" }}>
              <span style={{ fontSize: 10, color: S.g400, flexShrink: 0 }}>□</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: S.g900, fontWeight: 500 }}>{w.label}</div>
                <div style={{ fontSize: 11, color: S.g400, marginTop: 2 }}>{w.time}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px 18px" }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 12 }}>Performances</div>
          {[
            { label: "Missions réalisées", value: String(profile.metrics.missionsRealized) },
            { label: "Niveau de confiance", value: profile.metrics.confidence + "%" },
            { label: "Temps IA consommé", value: profile.metrics.timeConsumed },
            { label: "Documents produits", value: String(profile.metrics.documents) },
          ].map((m, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: i < 3 ? `1px solid ${S.g100}` : "none", fontSize: 13 }}>
              <span style={{ color: S.g600 }}>{m.label}</span>
              <span style={{ fontWeight: 600, color: S.g900 }}>{m.value}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px 18px" }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 12 }}>Mémoire ({profile.memory.length} insights)</div>
        {profile.memory.map((insight, i) => (
          <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 8, padding: "8px 0", borderBottom: i < profile.memory.length - 1 ? `1px solid ${S.g100}` : "none" }}>
            <span style={{ fontSize: 13, color: S.teal, flexShrink: 0, marginTop: 1 }}>💡</span>
            <span style={{ fontSize: 13, color: S.g700, lineHeight: 1.4 }}>{insight}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function RiskWorkspace({ id, openDrawer }: { id: string; openDrawer: (d: DrawerItem) => void }) {
  const risk = RISKS.find(r => r.id === id);
  if (!risk) return null;
  const isCritical = risk.level === "critique";
  const impactChain = [
    { label: risk.title, type: "risk" as const, color: isCritical ? S.error : S.warning },
    { label: "Mission : Intégration API Partenaires (34%)", type: "mission" as const, color: S.teal },
    { label: "Décision : " + DECISIONS.find(d => d.program === risk.program)?.title?.slice(0, 40) + "…", type: "decision" as const, color: S.warning },
    { label: "Jalon : 5 juillet 2026 — À RISQUE", type: "milestone" as const, color: S.error },
  ];
  return (
    <div style={{ padding: "28px 32px", overflowY: "auto", height: "100%" }}>
      <div style={{ marginBottom: 22 }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
          <STARBadge variant={isCritical ? "error" : "warning"} label={isCritical ? "Critique" : "Moyen"} />
          <span style={{ fontSize: 12, color: S.g500 }}>{risk.program} · {risk.owner}</span>
        </div>
        <h2 style={{ fontSize: 21, fontWeight: 700, color: S.g900, margin: "0 0 4px" }}>{risk.title}</h2>
        <p style={{ fontSize: 14, color: S.g600, margin: 0 }}>Probabilité {risk.probability} · Impact : {risk.impact}</p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
        <div>
          <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 14 }}>Chaîne d'impact</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
            {impactChain.map((item, i) => (
              <div key={i}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", background: S.white, borderRadius: 10, border: `1px solid ${item.color}33`, marginBottom: 0 }}>
                  <span style={{ width: 8, height: 8, borderRadius: "50%", background: item.color, flexShrink: 0 }} />
                  <span style={{ fontSize: 13, color: S.g700, lineHeight: 1.3 }}>{item.label}</span>
                </div>
                {i < impactChain.length - 1 && (
                  <div style={{ width: 1, height: 14, background: S.g200, margin: "0 auto", marginLeft: 17 }} />
                )}
              </div>
            ))}
          </div>
          <div style={{ marginTop: 18 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 10 }}>Agents mobilisés</div>
            {SPECIALIST_AGENTS.filter(a => ["risk","planning","finance"].includes(a.id)).map(a => (
              <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderBottom: `1px solid ${S.g100}` }}>
                <span style={{ fontSize: 12, color: a.color }}>{a.icon}</span>
                <span style={{ fontSize: 12, fontWeight: 500, color: S.g900 }}>{a.name}</span>
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: S.success, marginLeft: "auto" }} />
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px" }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 10 }}>Plan de mitigation</div>
            <p style={{ fontSize: 14, color: S.g700, lineHeight: 1.6, margin: 0 }}>{risk.mitigation}</p>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={{ flex: 1, padding: "10px", background: S.teal, color: S.white, border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer", transition: T }}
              onMouseEnter={e => (e.currentTarget.style.background = S.tealDark)}
              onMouseLeave={e => (e.currentTarget.style.background = S.teal)}
            >Créer une décision</button>
            <button style={{ flex: 1, padding: "10px", background: S.white, color: S.teal, border: `1px solid ${S.teal}`, borderRadius: 8, fontSize: 13, fontWeight: 500, cursor: "pointer", transition: T }}>Notifier {risk.owner.split(" ")[0]}</button>
          </div>
          <div style={{ fontSize: 11, color: S.g400, borderTop: `1px solid ${S.g200}`, paddingTop: 12 }}>Mise à jour : {risk.updatedAt}</div>
        </div>
      </div>
    </div>
  );
}

function RoadmapWorkspace() {
  const milestones = [
    { date: "4 juil.", label: "Revue de phase VEEDDA", program: "VEEDDA", critical: true },
    { date: "5 juil.", label: "Deadline API Partenaires", program: "VEEDDA", critical: true },
    { date: "7 juil.", label: "Décision budget infrastructure", program: "VEEDDA", critical: true },
    { date: "7 juil.", label: "Sprint Review ORCHESTRATOR", program: "ORCHESTRATOR", critical: false },
    { date: "10 juil.", label: "Sélection partenaire intégration", program: "ORCHESTRATOR", critical: false },
    { date: "12 juil.", label: "Module classification IA", program: "VEEDDA", critical: false },
    { date: "18 juil.", label: "Architecture multi-agents", program: "VEEDDA", critical: false },
    { date: "25 juil.", label: "Interface utilisateur v2", program: "VEEDDA", critical: false },
    { date: "31 juil.", label: "Module mémoire programme", program: "ORCHESTRATOR", critical: false },
  ];
  return (
    <div style={{ padding: "28px 32px", overflowY: "auto", height: "100%" }}>
      <h2 style={{ fontSize: 21, fontWeight: 700, color: S.g900, margin: "0 0 4px" }}>Roadmap</h2>
      <p style={{ fontSize: 14, color: S.g500, margin: "0 0 24px" }}>Juillet 2026 · 2 programmes actifs</p>
      <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "24px 28px" }}>
        {milestones.map((m, i) => (
          <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
            <div style={{ width: 64, flexShrink: 0, textAlign: "right", paddingTop: 1 }}><span style={{ fontSize: 12, fontWeight: 500, color: S.g500 }}>{m.date}</span></div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
              <div style={{ width: 10, height: 10, borderRadius: "50%", background: m.critical ? S.error : S.cyan, marginTop: 2 }} />
              {i < milestones.length - 1 && <div style={{ width: 1, background: S.g200, minHeight: 24, margin: "3px 0" }} />}
            </div>
            <div style={{ paddingBottom: i < milestones.length - 1 ? 18 : 0 }}>
              <div style={{ fontSize: 14, fontWeight: 500, color: m.critical ? S.g900 : S.g700 }}>{m.label}</div>
              <div style={{ fontSize: 12, color: S.g500, marginTop: 2 }}>{m.program}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MemoireWorkspace() {
  const [filter, setFilter] = useState("all");
  const filters = ["all", "Architecture", "Risk", "Finance", "VEEDDA Analyst"];
  const filtered = filter === "all" ? KNOWLEDGE_BASE : KNOWLEDGE_BASE.filter(k => k.agent === filter);
  return (
    <div style={{ padding: "28px 32px", overflowY: "auto", height: "100%" }}>
      <h2 style={{ fontSize: 21, fontWeight: 700, color: S.g900, margin: "0 0 4px" }}>Base de connaissances</h2>
      <p style={{ fontSize: 14, color: S.g500, margin: "0 0 20px" }}>{KNOWLEDGE_BASE.length} insights · 4 agents · Depuis le 24 juin 2026</p>
      <div style={{ display: "flex", gap: 6, marginBottom: 20, flexWrap: "wrap" }}>
        {filters.map(f => (
          <button key={f} onClick={() => setFilter(f)}
            style={{ padding: "5px 12px", background: filter === f ? S.teal : S.white, color: filter === f ? S.white : S.g600, border: `1px solid ${filter === f ? S.teal : S.g200}`, borderRadius: 7, fontSize: 12, cursor: "pointer", fontWeight: filter === f ? 500 : 400, transition: T }}
            onMouseEnter={e => { if (filter !== f) e.currentTarget.style.borderColor = S.g300; }}
            onMouseLeave={e => { if (filter !== f) e.currentTarget.style.borderColor = S.g200; }}
          >{f === "all" ? "Tous" : f}</button>
        ))}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {filtered.map(k => (
          <div key={k.id} style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px 20px" }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
              <span style={{ fontSize: 16, marginTop: 1 }}>💡</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: S.g900, lineHeight: 1.4, marginBottom: 8 }}>{k.insight}</div>
                <div style={{ display: "flex", gap: 16, fontSize: 12, color: S.g500, flexWrap: "wrap" }}>
                  <span>Agent : <strong style={{ color: S.g700 }}>{k.agent}</strong></span>
                  <span>Confiance : <strong style={{ color: k.confidence >= 90 ? S.success : k.confidence >= 75 ? S.warning : S.g700 }}>{k.confidence}%</strong></span>
                  <span>{k.usages} utilisations</span>
                  <span>{k.missions} mission{k.missions > 1 ? "s" : ""}</span>
                  <span>{k.docs} document{k.docs > 1 ? "s" : ""}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function GraphWorkspace() {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const nodes = [
    { id: "m3", type: "mission", label: "Architecture multi-agents", x: 50, y: 45, color: S.error, icon: "◆" },
    { id: "arch", type: "agent", label: "Architecture Agent", x: 18, y: 18, color: S.teal, icon: "⬡" },
    { id: "risk-a", type: "agent", label: "Risk Agent", x: 82, y: 18, color: S.error, icon: "▲" },
    { id: "r1", type: "risk", label: "Retard partenaire", x: 18, y: 72, color: S.error, icon: "▲" },
    { id: "r2", type: "risk", label: "Budget dépassé", x: 82, y: 72, color: S.warning, icon: "▲" },
    { id: "d1", type: "decision", label: "Valider architecture", x: 50, y: 12, color: S.teal, icon: "◆" },
    { id: "doc1", type: "document", label: "Cahier des charges", x: 50, y: 82, color: S.g500, icon: "□" },
    { id: "mem1", type: "memoire", label: "Pattern multi-agents", x: 82, y: 48, color: S.g500, icon: "💡" },
  ];
  const edges = [
    { from: "m3", to: "arch" }, { from: "m3", to: "risk-a" }, { from: "m3", to: "r1" },
    { from: "m3", to: "r2" }, { from: "m3", to: "d1" }, { from: "m3", to: "doc1" },
    { from: "arch", to: "d1" }, { from: "arch", to: "mem1" }, { from: "risk-a", to: "r1" },
  ];
  const W = 640, H = 380;
  const pos = (x: number, y: number) => ({ cx: (x / 100) * W, cy: (y / 100) * H });
  return (
    <div style={{ padding: "28px 32px", overflowY: "auto", height: "100%" }}>
      <h2 style={{ fontSize: 21, fontWeight: 700, color: S.g900, margin: "0 0 4px" }}>Graphe des relations</h2>
      <p style={{ fontSize: 14, color: S.g500, margin: "0 0 22px" }}>Visualisation des liens entre entités du système VEEDDA</p>
      <div style={{ background: S.white, borderRadius: 14, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "24px", overflow: "hidden" }}>
        <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ display: "block" }}>
          {edges.map((e, i) => {
            const f = nodes.find(n => n.id === e.from); const t = nodes.find(n => n.id === e.to);
            if (!f || !t) return null;
            const fp = pos(f.x, f.y); const tp = pos(t.x, t.y);
            return <line key={i} x1={fp.cx} y1={fp.cy} x2={tp.cx} y2={tp.cy} stroke={S.g200} strokeWidth={1.5} strokeDasharray="4 3" />;
          })}
          {nodes.map(n => {
            const { cx, cy } = pos(n.x, n.y); const isSel = selectedNode === n.id;
            return (
              <g key={n.id} style={{ cursor: "pointer" }} onClick={() => setSelectedNode(isSel ? null : n.id)}>
                <circle cx={cx} cy={cy} r={isSel ? 26 : 22} fill={isSel ? n.color : S.white} stroke={n.color} strokeWidth={2} />
                <text x={cx} y={cy + 1} textAnchor="middle" dominantBaseline="middle" fontSize={12} fill={isSel ? S.white : n.color}>{n.icon}</text>
                <text x={cx} y={cy + 34} textAnchor="middle" fontSize={9} fill={S.g500}>{n.label.length > 16 ? n.label.slice(0, 14) + "…" : n.label}</text>
              </g>
            );
          })}
        </svg>
        <div style={{ display: "flex", gap: 18, marginTop: 8, paddingTop: 12, borderTop: `1px solid ${S.g100}` }}>
          {[{ icon: "◆", label: "Mission", color: S.teal }, { icon: "⬡", label: "Agent", color: S.teal }, { icon: "▲", label: "Risque", color: S.error }, { icon: "□", label: "Document", color: S.g500 }, { icon: "💡", label: "Mémoire", color: S.g500 }].map((l, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, color: S.g500 }}>
              <span style={{ color: l.color, fontSize: 11 }}>{l.icon}</span>{l.label}
            </div>
          ))}
        </div>
      </div>
      {selectedNode && (() => {
        const n = nodes.find(x => x.id === selectedNode);
        const connections = edges.filter(e => e.from === selectedNode || e.to === selectedNode);
        return n ? (
          <div style={{ marginTop: 16, padding: "16px 20px", background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, display: "flex", alignItems: "center", gap: 14 }}>
            <span style={{ fontSize: 18, color: n.color }}>{n.icon}</span>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: S.g900 }}>{n.label}</div>
              <div style={{ fontSize: 12, color: S.g500, marginTop: 3 }}>Type : {n.type} · {connections.length} relation{connections.length > 1 ? "s" : ""} détectée{connections.length > 1 ? "s" : ""}</div>
            </div>
          </div>
        ) : null;
      })()}
    </div>
  );
}

function PilotagePage({ openDrawer, onMissionSelect }: { openDrawer: (d: DrawerItem) => void; onMissionSelect?: (id: string) => void }) {
  const [selected, setSelected] = useState<OSSelection>({ type: "missions", id: "m1" });

  function handleSelect(s: OSSelection) {
    setSelected(s);
    if (s.type === "missions") onMissionSelect?.(s.id);
  }
  const tree = [
    { id: "missions", label: "Missions", icon: "◆", items: MISSIONS.map(m => ({ id: m.id, label: m.name, dot: m.status === "critique" || m.status === "bloqué" ? S.error : m.status === "retard" ? S.warning : m.status === "en cours" ? S.teal : S.g300 })) },
    { id: "agents",   label: "Agents",   icon: "⬡", items: SPECIALIST_AGENTS.slice(0, 4).map(a => ({ id: a.id, label: a.name, dot: ["architecture","risk"].includes(a.id) ? S.success : S.g300 })) },
    { id: "risques",  label: "Risques",  icon: "▲", items: RISKS.map(r => ({ id: r.id, label: r.title.length > 30 ? r.title.slice(0, 28) + "…" : r.title, dot: r.level === "critique" ? S.error : S.warning })) },
    { id: "roadmap",  label: "Roadmap",  icon: "◷", items: [{ id: "roadmap", label: "Vue planning", dot: S.teal }] },
    { id: "memoire",  label: "Mémoire",  icon: "◉", items: [{ id: "memoire", label: "Base de connaissances", dot: S.teal }] },
    { id: "graphe",   label: "Graphe",   icon: "◈", items: [{ id: "graphe", label: "Relations système", dot: S.teal }] },
  ];
  return (
    <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
      {/* OS navigator */}
      <div style={{ width: 210, flexShrink: 0, background: S.white, borderRight: `1px solid ${S.g200}`, overflowY: "auto", paddingTop: 14 }}>
        <div style={{ padding: "0 14px 10px", fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.8px" }}>Système VEEDDA</div>
        {tree.map(section => (
          <div key={section.id} style={{ marginBottom: 4 }}>
            <div style={{ padding: "5px 14px", fontSize: 11, fontWeight: 600, color: S.g500, display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontSize: 9 }}>{section.icon}</span>{section.label}
            </div>
            {section.items.map(item => {
              const isSel = selected?.id === item.id;
              return (
                <button key={item.id} onClick={() => handleSelect({ type: section.id, id: item.id })}
                  style={{ width: "100%", padding: "5px 14px 5px 22px", background: isSel ? S.teal20 : "transparent", border: "none", textAlign: "left", cursor: "pointer", display: "flex", alignItems: "center", gap: 7, transition: T }}
                  onMouseEnter={e => { if (!isSel) e.currentTarget.style.background = S.g50; }}
                  onMouseLeave={e => { if (!isSel) e.currentTarget.style.background = "transparent"; }}
                >
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: item.dot, flexShrink: 0 }} />
                  <span style={{ fontSize: 12, color: isSel ? S.teal : S.g700, fontWeight: isSel ? 600 : 400, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.label}</span>
                </button>
              );
            })}
          </div>
        ))}
      </div>
      {/* Workspace */}
      <div style={{ flex: 1, background: S.g50, overflow: "hidden", display: "flex" }}>
        {selected.type === "missions" && <MissionWorkspace id={selected.id} openDrawer={openDrawer} />}
        {selected.type === "agents" && <div style={{ flex: 1, overflowY: "auto" }}><AgentWorkspace id={selected.id} /></div>}
        {selected.type === "risques" && <div style={{ flex: 1, overflowY: "auto" }}><RiskWorkspace id={selected.id} openDrawer={openDrawer} /></div>}
        {selected.type === "roadmap" && <div style={{ flex: 1, overflowY: "auto" }}><RoadmapWorkspace /></div>}
        {selected.type === "memoire" && <div style={{ flex: 1, overflowY: "auto" }}><MemoireWorkspace /></div>}
        {selected.type === "graphe" && <div style={{ flex: 1, overflowY: "auto" }}><GraphWorkspace /></div>}
      </div>
    </div>
  );
}

// ─── ORCHESTRATOR PANEL ───────────────────────────────────────────────────────
function OrchestratorPanel({ mission, openDrawer }: { mission: (typeof MISSIONS)[number]; openDrawer: (d: DrawerItem) => void }) {
  const [simulating, setSimulating] = useState(false);
  const [actionDone, setActionDone] = useState<string | null>(null);
  const linkedDecision = DECISIONS.find(d => d.program === mission.program);

  // Reasoning chain — each agent's contribution visible
  // Each agent has a distinct professional personality and vocabulary
  const chain = [
    {
      agent: "Architecture", icon: "⬡", color: S.teal, done: true,
      insight: mission.status === "bloqué"
        ? "Analyse structurelle complète. Robustesse : 94%. Dépendances maîtrisées. Implémentation viable sans révision architecturale."
        : `Cartographie des dépendances : ${mission.progress}% de cohérence atteint. Aucun anti-pattern détecté.`,
      time: "Il y a 14 min",
    },
    {
      agent: "Risk", icon: "▲", color: S.error, done: true,
      insight: mission.blockers.length > 0
        ? `Probabilité de dérive : 78%. Magnitude : critique. ${mission.blockers.length} vecteur${mission.blockers.length > 1 ? "s" : ""} d'impact en cascade détecté${mission.blockers.length > 1 ? "s" : ""}. Seuil de tolérance : dépassé.`
        : "Probabilité d'incident : <12%. Surveillance passive maintenue. Aucun seuil d'alerte dépassé.",
      time: "Il y a 11 min",
    },
    {
      agent: "Planning", icon: "◷", color: S.cyan, done: true,
      insight: mission.daysLeft <= 5
        ? `Window d'action : ${mission.daysLeft * 24}h. Avancement actuel : ${mission.progress}%. Objectif requis : 85%. Delta critique : ${85 - mission.progress} points.`
        : `Timeline conforme. ${mission.progress}% réalisé. Jalons suivants : atteignables avec la vélocité actuelle.`,
      time: "Il y a 8 min",
    },
    {
      agent: "Finance", icon: "◈", color: S.success, done: true,
      insight: mission.blockers.length > 0
        ? `ROI si résolu aujourd'hui : +340%. Coût d'inaction : €9k/j. Projection J+${mission.daysLeft} : -€${Math.ceil(mission.daysLeft * 9)}k. Recommandation financière : agir maintenant.`
        : "Budget nominal. Variance : <3%. Aucun dépassement projeté à l'horizon de la phase.",
      time: "Il y a 4 min",
    },
    {
      agent: "Mémoire", icon: "◉", color: S.g500, done: true,
      insight: mission.blockers.length > 0
        ? "Précédent retrouvé : Mission API Gateway — 15 mai 2026. Résolution en 48h via validation architecturale préalable. Pattern confirmé sur 3 cas. Confiance historique : 91%."
        : "Base de connaissances consultée. Aucun précédent à risque. Mission archétypale : vélocité conforme aux patterns de la phase.",
      time: "Il y a 3 min",
    },
    {
      agent: "ORCHESTRATOR", icon: "⚡", color: S.teal, done: true,
      insight: mission.blockers.length > 0
        ? `Synthèse : 3/4 agents recommandent l'action. Conflit Architecture↔Planning arbitré. Mémoire confirme le pattern. Verdict : validation immédiate — rapport coût/risque optimal.`
        : "Consensus 4/4. Aucun conflit. Mémoire valide la trajectoire. Niveau de confiance global : 82%. Surveillance continue.",
      time: "Il y a 2 min",
    },
  ];

  const conclusion = mission.blockers.length > 0
    ? `Blocage critique actif. La décision de validation libérera €${Math.ceil(mission.daysLeft * 9)}k de valeur bloquée et 3 développeurs dès J+1.`
    : `Mission progresse à ${mission.progress}%. Confiance système : 82%. Aucune intervention requise.`;

  const recommendation = mission.status === "bloqué"
    ? "Validez immédiatement. Le risque technique est maîtrisé. Chaque jour coûte ~€9k."
    : mission.status === "critique"
    ? "Identifiez un partenaire alternatif dans les 48h. Le planning du 5 juillet est menacé."
    : mission.status === "retard"
    ? "Renforcez l'équipe sur la collecte du dataset. La deadline du 12 juil. est récupérable."
    : `Maintenez le rythme. La deadline du ${mission.deadline} est atteignable avec l'avancement actuel.`;

  return (
    <div style={{ width: 256, flexShrink: 0, background: S.white, borderLeft: `1px solid ${S.g200}`, overflowY: "auto", display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "14px 14px 20px" }}>

        {/* Animated header */}
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 16, padding: "10px 12px", background: S.teal20, borderRadius: 10, border: `1px solid ${S.teal}22` }}>
          <div style={{ width: 24, height: 24, borderRadius: "50%", background: S.teal, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, animation: "stPulse 2.5s ease infinite" }}>
            <Zap size={11} color={S.white} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: S.teal }}>ORCHESTRATOR</div>
            <div style={{ fontSize: 10, color: S.g500, display: "flex", alignItems: "center", gap: 4 }}>
              <span style={{ width: 5, height: 5, borderRadius: "50%", background: S.success, display: "inline-block", animation: "stPulse 1.5s ease infinite" }} />
              Raisonnement actif
            </div>
          </div>
        </div>

        {/* Action bar */}
        {actionDone ? (
          <div style={{ marginBottom: 14, padding: "8px 10px", background: S.successLight, border: `1px solid ${S.success}44`, borderRadius: 8, display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "#065f46" }}>
            <CheckCircle size={12} />{actionDone} <button onClick={() => setActionDone(null)} style={{ background: "none", border: "none", color: S.g400, cursor: "pointer", marginLeft: "auto", fontSize: 12 }}>×</button>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 5, marginBottom: 14 }}>
            {[
              { label: "Assigner", icon: "◆", action: () => setActionDone("Assignation créée") },
              { label: "Simuler", icon: "⊞", action: () => setSimulating(!simulating) },
              { label: "Rapport", icon: "□", action: () => setActionDone("Rapport lancé") },
              { label: "COPIL", icon: "◷", action: () => setActionDone("COPIL préparé") },
            ].map((a, i) => (
              <button key={i} onClick={a.action}
                style={{ padding: "6px 4px", background: simulating && a.label === "Simuler" ? S.teal20 : S.g50, border: `1px solid ${simulating && a.label === "Simuler" ? S.teal + "44" : S.g200}`, borderRadius: 7, fontSize: 11, color: simulating && a.label === "Simuler" ? S.teal : S.g700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 4, transition: T, fontWeight: simulating && a.label === "Simuler" ? 600 : 400 }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = S.teal; e.currentTarget.style.color = S.teal; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = simulating && a.label === "Simuler" ? S.teal + "44" : S.g200; e.currentTarget.style.color = simulating && a.label === "Simuler" ? S.teal : S.g700; }}
              >
                <span style={{ fontSize: 10, color: S.teal }}>{a.icon}</span>{a.label}
              </button>
            ))}
          </div>
        )}

        {/* Simulation panel */}
        {simulating && (
          <div style={{ marginBottom: 16, padding: "12px 12px", background: S.g50, borderRadius: 10, border: `1px solid ${S.g200}` }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: S.teal, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 10 }}>Simulation "Que se passe-t-il si…"</div>
            {[
              { q: "Je refuse cette décision ?", scenarios: [{ label: "Optimiste", text: "Révision en 48h, retard minimal.", color: S.success }, { label: "Réaliste", text: "Sprint 8 retardé de 3 jours, €27k de coût.", color: S.warning }, { label: "Pessimiste", text: "Blocage 3 semaines, €108k, deadline à risque.", color: S.error }] },
              { q: "Je décale de 2 semaines ?", scenarios: [{ label: "Optimiste", text: "Planning absorbé, budget stable.", color: S.success }, { label: "Réaliste", text: "Interface v2 retardée, budget +€18k.", color: S.warning }, { label: "Pessimiste", text: "Cascade sur 3 missions, revue de phase compromise.", color: S.error }] },
            ].map((item, qi) => (
              <details key={qi} style={{ marginBottom: 8 }}>
                <summary style={{ fontSize: 12, color: S.g700, cursor: "pointer", padding: "5px 0", userSelect: "none" }}>{item.q}</summary>
                <div style={{ display: "flex", flexDirection: "column", gap: 5, marginTop: 8, paddingLeft: 8 }}>
                  {item.scenarios.map((s, si) => (
                    <div key={si} style={{ padding: "7px 10px", borderRadius: 7, background: S.white, border: `1px solid ${s.color}33` }}>
                      <div style={{ fontSize: 10, fontWeight: 700, color: s.color, marginBottom: 3 }}>{s.label}</div>
                      <div style={{ fontSize: 11, color: S.g600, lineHeight: 1.4 }}>{s.text}</div>
                    </div>
                  ))}
                </div>
              </details>
            ))}
          </div>
        )}

        {/* Reasoning chain */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 12 }}>Chaîne de raisonnement</div>
          {chain.map((step, i) => (
            <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
                <div style={{ width: 22, height: 22, borderRadius: "50%", background: step.done ? step.color : S.g200, display: "flex", alignItems: "center", justifyContent: "center", border: `2px solid ${step.done ? step.color : S.g200}` }}>
                  <span style={{ fontSize: 9, color: step.done ? S.white : S.g400, fontWeight: 700 }}>{step.icon}</span>
                </div>
                {i < chain.length - 1 && <div style={{ width: 1, height: 18, background: S.g100, margin: "3px 0" }} />}
              </div>
              <div style={{ flex: 1, paddingBottom: i < chain.length - 1 ? 6 : 0 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 2 }}>
                  <span style={{ fontSize: 11, fontWeight: 600, color: step.agent === "ORCHESTRATOR" ? S.teal : S.g900 }}>{step.agent}</span>
                  <span style={{ fontSize: 9, color: S.g400 }}>{step.time}</span>
                </div>
                <div style={{ fontSize: 11, color: S.g600, lineHeight: 1.45, fontStyle: "italic" }}>"{step.insight}"</div>
              </div>
            </div>
          ))}
        </div>

        {/* Conclusion */}
        <div style={{ marginBottom: 14, padding: "10px 12px", background: mission.blockers.length > 0 ? S.errorLight : S.successLight, borderRadius: 8, border: `1px solid ${mission.blockers.length > 0 ? S.error + "33" : S.success + "44"}` }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: mission.blockers.length > 0 ? S.error : S.success, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 5 }}>Conclusion</div>
          <p style={{ fontSize: 12, color: S.g700, margin: 0, lineHeight: 1.55 }}>{conclusion}</p>
        </div>

        {/* Conflict detection — shows when agents disagree */}
        {mission.blockers.length > 0 && (
          <div style={{ marginBottom: 14, padding: "11px 12px", background: S.warningLight, border: `1px solid ${S.warning}55`, borderRadius: 9 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 9 }}>
              <span style={{ fontSize: 11, color: S.warning }}>⚡</span>
              <span style={{ fontSize: 10, fontWeight: 700, color: "#92400e", textTransform: "uppercase", letterSpacing: "0.5px" }}>Conflit inter-agents</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              <div style={{ display: "flex", gap: 7, fontSize: 11, color: "#78350f", alignItems: "flex-start" }}>
                <span style={{ color: S.teal, flexShrink: 0, fontWeight: 600 }}>⬡</span>
                <span>"Architecture valide à 94%. Implémentation techniquement solide."</span>
              </div>
              <div style={{ display: "flex", gap: 7, fontSize: 11, color: "#78350f", alignItems: "flex-start" }}>
                <span style={{ color: S.cyan, flexShrink: 0, fontWeight: 600 }}>◷</span>
                <span>"Planning : délai incompatible. J-{mission.daysLeft} insuffisant pour intégrer."</span>
              </div>
            </div>
            <div style={{ marginTop: 8, paddingTop: 7, borderTop: "1px solid rgba(0,0,0,0.08)", fontSize: 11, color: "#92400e", fontWeight: 500 }}>
              Arbitrage requis · Impact si non résolu : J+3 sur la deadline
            </div>
          </div>
        )}

        {/* Recommendation */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: S.teal, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 7 }}>Recommandation</div>
          <div style={{ fontSize: 12, color: S.g700, lineHeight: 1.6, padding: "9px 11px", background: S.teal20, borderRadius: 8, border: `1px solid ${S.teal}22` }}>
            {recommendation}
          </div>
        </div>

        {/* Decision CTA */}
        {linkedDecision && (
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: S.g600, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 7 }}>Décision suggérée</div>
            <div style={{ padding: "10px 11px", background: S.g50, borderRadius: 8, border: `1px solid ${S.g200}`, marginBottom: 8 }}>
              <div style={{ fontSize: 12, color: S.g700, lineHeight: 1.4 }}>{linkedDecision.title.length > 55 ? linkedDecision.title.slice(0, 53) + "…" : linkedDecision.title}</div>
            </div>
            <button onClick={() => openDrawer({ type: "decision", data: linkedDecision })}
              style={{ width: "100%", padding: "8px", background: S.teal, color: S.white, border: "none", borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: "pointer", transition: T }}
              onMouseEnter={e => (e.currentTarget.style.background = S.tealDark)}
              onMouseLeave={e => (e.currentTarget.style.background = S.teal)}
            >Créer la décision</button>
          </div>
        )}

        {/* ORCHESTRATOR Executive — arbitrage de plus haut niveau */}
        <div style={{ marginTop: 16, padding: "12px 12px", background: "#0d1926", borderRadius: 10, border: `1px solid ${S.teal}44` }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 8 }}>
            <div style={{ width: 18, height: 18, borderRadius: "50%", background: S.teal, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, animation: "stPulse 2.5s ease infinite" }}>
              <Zap size={8} color={S.white} />
            </div>
            <span style={{ fontSize: 10, fontWeight: 700, color: S.teal, textTransform: "uppercase", letterSpacing: "0.6px" }}>Executive · Arbitrage final</span>
          </div>
          <p style={{ fontSize: 11, color: "rgba(255,255,255,0.6)", margin: "0 0 10px", lineHeight: 1.6 }}>
            {mission.blockers.length > 0
              ? "3/4 agents recommandent l'action. Conflit Architecture↔Planning arbitré en faveur du ROI économique. Biais détecté : Planning tend à surestimer la contrainte temporelle. Mémoire valide le pattern."
              : "Consensus 4/4 agents. Aucun biais détecté. Raisonnement convergent et cohérent avec les précédents historiques."}
          </p>
          <div style={{ padding: "8px 10px", background: "rgba(16,185,129,0.12)", borderRadius: 7, border: "1px solid rgba(16,185,129,0.25)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 10, color: S.success, fontWeight: 700, marginBottom: 2 }}>Verdict : {mission.blockers.length > 0 ? "Valider immédiatement" : "Poursuivre le plan actuel"}</div>
                <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}>Confiance Executive : {mission.blockers.length > 0 ? "87%" : "93%"} · Précédent : {mission.blockers.length > 0 ? "15 mai 2026" : "Pattern établi"}</div>
              </div>
              <div style={{ fontSize: 16, fontWeight: 700, color: S.success, fontVariantNumeric: "tabular-nums" }}>{mission.blockers.length > 0 ? "87%" : "93%"}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── CENTRE DE COMMANDEMENT ───────────────────────────────────────────────────
function CommandementPage({ openDrawer }: { openDrawer: (d: DrawerItem) => void }) {
  return (
    <div style={{ flex: 1, overflowY: "auto", background: S.g50 }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "28px 32px 48px" }}>
        {/* Header */}
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 24 }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 6 }}>Mardi 1 juillet 2026 · Vue exécutive CODIR</div>
            <h1 style={{ fontSize: 22, fontWeight: 700, color: S.g900, margin: 0 }}>Centre de Commandement</h1>
            <p style={{ fontSize: 14, color: S.g500, margin: "6px 0 0" }}>État global du système · Mise à jour il y a 2 min</p>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 11, color: S.g400, marginBottom: 4 }}>Santé globale</div>
            <div style={{ fontSize: 32, fontWeight: 700, color: S.warning, fontVariantNumeric: "tabular-nums" }}>85%</div>
            <div style={{ fontSize: 11, color: S.g500 }}>2 programmes actifs</div>
          </div>
        </div>

        {/* Programs */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
          {PROGRAMS.map(p => {
            const hc = p.health >= 85 ? S.success : p.health >= 70 ? S.warning : S.error;
            return (
              <button key={p.id} onClick={() => openDrawer({ type: "program", data: p })}
                style={{ background: S.white, borderRadius: 14, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "18px 22px", textAlign: "left", cursor: "pointer", transition: T, position: "relative", overflow: "hidden" }}
                onMouseEnter={e => (e.currentTarget.style.boxShadow = shadow.md)}
                onMouseLeave={e => (e.currentTarget.style.boxShadow = shadow.kpi)}
              >
                <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 5, background: hc }} />
                <div style={{ paddingLeft: 4, display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <div style={{ fontSize: 16, fontWeight: 700, color: S.g900 }}>{p.name}</div>
                    <div style={{ fontSize: 12, color: S.g500, marginTop: 3 }}>{p.tagline} · {p.phase}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 28, fontWeight: 700, color: hc, fontVariantNumeric: "tabular-nums" }}>{p.health}%</div>
                    <div style={{ fontSize: 11, color: S.g400 }}>santé</div>
                  </div>
                </div>
                <div style={{ height: 5, background: S.g100, borderRadius: 9999, margin: "14px 0 12px", overflow: "hidden" }}>
                  <div style={{ height: "100%", width: `${p.health}%`, background: hc, borderRadius: 9999 }} />
                </div>
                <div style={{ display: "flex", gap: 18, fontSize: 12, paddingLeft: 4 }}>
                  <span style={{ color: S.g500 }}>{p.missionsActive} missions actives</span>
                  {p.missionsCritical > 0 && <span style={{ color: S.error, fontWeight: 600 }}>{p.missionsCritical} critiques</span>}
                  <span style={{ color: S.g500 }}>Budget {p.budgetUsed}%</span>
                  <span style={{ color: p.nextMilestone.daysLeft <= 3 ? S.error : S.g500 }}>J-{p.nextMilestone.daysLeft} {p.nextMilestone.label}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* 4-column command grid */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 16, marginBottom: 20 }}>
          {/* Agents actifs */}
          <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px" }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 12 }}>Agents actifs</div>
            {SPECIALIST_AGENTS.slice(0, 4).map((a, i) => {
              const isActive = ["architecture", "risk"].includes(a.id);
              return (
                <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 0", borderBottom: i < 3 ? `1px solid ${S.g100}` : "none" }}>
                  <span style={{ fontSize: 12, color: a.color }}>{a.icon}</span>
                  <span style={{ fontSize: 12, fontWeight: 500, color: S.g900, flex: 1 }}>{a.name}</span>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: isActive ? S.success : S.g300, animation: isActive ? "stPulse 2s ease infinite" : undefined }} />
                </div>
              );
            })}
          </div>
          {/* Décisions urgentes */}
          <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px" }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 12 }}>Décisions urgentes</div>
            {DECISIONS.slice(0, 3).map((d, i) => (
              <button key={d.id} onClick={() => openDrawer({ type: "decision", data: d })}
                style={{ width: "100%", display: "flex", alignItems: "flex-start", gap: 7, padding: "7px 0", borderBottom: i < 2 ? `1px solid ${S.g100}` : "none", background: "none", border: "none", cursor: "pointer", textAlign: "left" }}
              >
                <span style={{ fontSize: 10, color: d.priority === "critique" ? S.error : S.warning, marginTop: 1, flexShrink: 0 }}>◆</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, color: S.g700, lineHeight: 1.3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.title}</div>
                  <div style={{ fontSize: 10, color: d.priority === "critique" ? S.error : S.g400, marginTop: 2 }}>{d.waitingDays === 0 ? "Aujourd'hui" : `Depuis ${d.waitingDays}j`}</div>
                </div>
              </button>
            ))}
          </div>
          {/* Risques critiques */}
          <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px" }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 12 }}>Risques critiques</div>
            {RISKS.filter(r => r.level === "critique").map((r, i, arr) => (
              <button key={r.id} onClick={() => openDrawer({ type: "risk", data: r })}
                style={{ width: "100%", display: "flex", alignItems: "flex-start", gap: 7, padding: "7px 0", borderBottom: i < arr.length - 1 ? `1px solid ${S.g100}` : "none", background: "none", border: "none", cursor: "pointer", textAlign: "left" }}
              >
                <span style={{ fontSize: 10, color: S.error, marginTop: 1, flexShrink: 0 }}>▲</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, color: "#b91c1c", lineHeight: 1.3 }}>{r.title}</div>
                  <div style={{ fontSize: 10, color: S.g400, marginTop: 2 }}>{r.probability}</div>
                </div>
              </button>
            ))}
          </div>
          {/* Jalons imminents */}
          <div style={{ background: S.white, borderRadius: 12, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "16px" }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 12 }}>Jalons imminents</div>
            {UPCOMING_MILESTONES.slice(0, 4).map((m, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 0", borderBottom: i < 3 ? `1px solid ${S.g100}` : "none" }}>
                <div style={{ width: 28, flexShrink: 0, textAlign: "center" }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: m.daysLeft <= 3 ? S.error : m.daysLeft <= 6 ? S.warning : S.g500, fontVariantNumeric: "tabular-nums" }}>J-{m.daysLeft}</div>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, color: S.g700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.label}</div>
                  <div style={{ fontSize: 10, color: S.g400 }}>{m.program}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Agent Collaboration Chain */}
        <div style={{ background: S.white, borderRadius: 14, border: `1px solid ${S.g200}`, boxShadow: shadow.kpi, padding: "18px 24px", marginBottom: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.7px", marginBottom: 16 }}>Chaîne de collaboration active</div>
          <div style={{ display: "flex", alignItems: "center", gap: 0, overflowX: "auto" }}>
            {[
              { agent: "Architecture", icon: "⬡", color: S.teal, status: "done", label: "Analyse", time: "11:38" },
              { agent: "Planning", icon: "◷", color: S.cyan, status: "done", label: "Jalons", time: "11:42" },
              { agent: "Finance", icon: "◈", color: S.success, status: "done", label: "Budget", time: "11:45" },
              { agent: "Risk", icon: "▲", color: S.error, status: "active", label: "Risques", time: "En cours" },
              { agent: "ORCHESTRATOR", icon: "⚡", color: S.teal, status: "pending", label: "Synthèse", time: "En attente" },
            ].map((step, i, arr) => (
              <div key={i} style={{ display: "flex", alignItems: "center" }}>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 7, minWidth: 100, padding: "0 8px" }}>
                  <div style={{ width: 38, height: 38, borderRadius: "50%", background: step.status === "done" ? step.color : step.status === "active" ? step.color + "25" : S.g100, display: "flex", alignItems: "center", justifyContent: "center", border: `2px solid ${step.status === "done" ? step.color : step.status === "active" ? step.color : S.g200}`, animation: step.status === "active" ? "stPulse 2s ease infinite" : undefined }}>
                    <span style={{ fontSize: 15, color: step.status === "done" ? S.white : step.status === "active" ? step.color : S.g400 }}>{step.icon}</span>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: S.g900 }}>{step.agent}</div>
                    <div style={{ fontSize: 10, color: step.status === "done" ? S.success : step.status === "active" ? step.color : S.g400, marginTop: 2 }}>
                      {step.status === "done" ? "✓ " : step.status === "active" ? "◌ " : "○ "}{step.label}
                    </div>
                    <div style={{ fontSize: 9, color: S.g400, marginTop: 1 }}>{step.time}</div>
                  </div>
                </div>
                {i < arr.length - 1 && (
                  <div style={{ width: 28, height: 1.5, background: step.status === "done" ? S.g300 : S.g200, flexShrink: 0, marginBottom: 22 }} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ORCHESTRATOR Analysis */}
        <div style={{ background: S.white, borderRadius: 14, border: `1px solid ${S.teal}22`, boxShadow: shadow.kpi, padding: "20px 24px", marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
            <div style={{ width: 28, height: 28, borderRadius: "50%", background: S.teal, display: "flex", alignItems: "center", justifyContent: "center", animation: "stPulse 2.5s ease infinite" }}><Zap size={12} color={S.white} /></div>
            <span style={{ fontSize: 14, fontWeight: 700, color: S.g900 }}>Analyse ORCHESTRATOR</span>
            <span style={{ fontSize: 11, color: S.g400 }}>— Mise à jour il y a 2 min</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
            <div>
              <div style={{ fontSize: 10, fontWeight: 700, color: S.teal, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 8 }}>Recommandations</div>
              {["Valider l'architecture immédiatement — débloque 3 personnes", "Soumettre la demande de budget +€12k avant le 7 juillet", "Approuver la communication revue de phase aujourd'hui"].map((r, i) => (
                <div key={i} style={{ display: "flex", gap: 7, padding: "6px 0", borderBottom: i < 2 ? `1px solid ${S.g100}` : "none", fontSize: 13, color: S.g700, alignItems: "flex-start" }}>
                  <span style={{ color: S.teal, flexShrink: 0, fontSize: 11, marginTop: 2 }}>✓</span>{r}
                </div>
              ))}
            </div>
            <div>
              <div style={{ fontSize: 10, fontWeight: 700, color: S.error, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 8 }}>Conflits détectés</div>
              {["Sprint 8 bloqué depuis 5 jours — coût €45k", "Deadline API (5 juil.) incompatible avec avancement (34%)", "Budget infrastructure dépassé — SLA à risque"].map((c, i) => (
                <div key={i} style={{ display: "flex", gap: 7, padding: "6px 0", borderBottom: i < 2 ? `1px solid ${S.g100}` : "none", fontSize: 13, color: "#b91c1c", alignItems: "flex-start" }}>
                  <span style={{ flexShrink: 0, fontSize: 11, marginTop: 2 }}>⚠</span>{c}
                </div>
              ))}
            </div>
            <div>
              <div style={{ fontSize: 10, fontWeight: 700, color: S.g600, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 8 }}>Opportunités</div>
              {["Déléguer la décision #4 à Sophie Martin — gain de temps", "Architecture validée = sprint 8 démarre J+1", "Partenaire alternatif disponible pour API"].map((o, i) => (
                <div key={i} style={{ display: "flex", gap: 7, padding: "6px 0", borderBottom: i < 2 ? `1px solid ${S.g100}` : "none", fontSize: 13, color: S.g600, alignItems: "flex-start" }}>
                  <span style={{ color: S.warning, flexShrink: 0, fontSize: 11, marginTop: 2 }}>◈</span>{o}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Live activity */}
        <ActivityFeed />
      </div>
    </div>
  );
}

// ─── DRAWER ───────────────────────────────────────────────────────────────────
function DrawerContent({ item }: { item: DrawerItem }) {
  const sT = (l: string) => <div style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px", margin: "22px 0 10px" }}>{l}</div>;
  const sb = (label: string, value: string, warn?: boolean) => (
    <div style={{ padding: "13px 15px", borderRadius: 10, border: `1px solid ${warn ? S.warning + "55" : S.g200}`, background: warn ? S.warningLight : S.g50 }}>
      <div style={{ fontSize: 11, color: S.g500 }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: 700, color: warn ? "#92400e" : S.g900, marginTop: 3, fontVariantNumeric: "tabular-nums" }}>{value}</div>
    </div>
  );
  if (item.type === "decision") {
    const d = item.data;
    return (
      <div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}><STARBadge variant={d.priority === "critique" ? "error" : d.priority === "haute" ? "warning" : "primary"} label={d.priority === "critique" ? "Critique" : d.priority === "haute" ? "Haute" : "Normale"} /><span style={{ fontSize: 12, color: S.g500 }}>{d.program}</span></div>
        <h2 style={{ fontSize: 19, fontWeight: 700, color: S.g900, margin: "0 0 8px", lineHeight: 1.3 }}>{d.title}</h2>
        <div style={{ display: "flex", gap: 16, fontSize: 12, color: S.g500 }}><span style={{ display: "flex", alignItems: "center", gap: 4 }}><Clock size={12} />{d.waitingDays === 0 ? "Aujourd'hui" : `${d.waitingDays}j en attente`}</span><span style={{ display: "flex", alignItems: "center", gap: 4 }}><Calendar size={12} />Échéance : {d.deadline}</span></div>
        <div style={{ marginTop: 18, padding: "13px 15px", borderRadius: 10, background: S.warningLight, border: `1px solid ${S.warning}44` }}><div style={{ fontSize: 11, fontWeight: 600, color: "#92400e", textTransform: "uppercase", letterSpacing: "0.4px", marginBottom: 4 }}>Impact si non décidé</div><div style={{ fontSize: 13, color: "#78350f" }}>{d.impact}</div></div>
        {sT("Contexte")}<p style={{ fontSize: 14, color: S.g700, lineHeight: 1.65, margin: 0 }}>{d.context}</p>
        {d.agent && <div style={{ marginTop: 12, padding: "9px 13px", borderRadius: 8, background: S.tealLight, border: `1px solid ${S.teal}33`, display: "flex", alignItems: "center", gap: 8 }}><Bot size={13} color={S.teal} /><span style={{ fontSize: 12, color: S.teal }}>{d.agent}</span></div>}
        {sT("Options")}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {d.options.map((opt, i) => (
            <button key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 15px", borderRadius: 10, border: `1px solid ${i === 0 ? S.teal + "55" : S.g200}`, background: i === 0 ? S.tealLight : S.white, cursor: "pointer", textAlign: "left", transition: T }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = S.teal)}
              onMouseLeave={e => (e.currentTarget.style.borderColor = i === 0 ? S.teal + "55" : S.g200)}
            >
              <div style={{ width: 20, height: 20, borderRadius: "50%", border: `2px solid ${i === 0 ? S.teal : S.g300}`, background: i === 0 ? S.teal : "transparent", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{i === 0 && <span style={{ color: S.white, fontSize: 10, fontWeight: 700 }}>✓</span>}</div>
              <span style={{ fontSize: 13, fontWeight: 500, color: i === 0 ? S.teal : S.g700, flex: 1 }}>{opt.label}</span>
              {i === 0 && <span style={{ fontSize: 11, fontWeight: 600, color: S.teal }}>Recommandé</span>}
            </button>
          ))}
        </div>
        {/* Full simulation — 3 scenarios */}
        <div style={{ marginTop: 18 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: S.teal, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
            <Zap size={10} color={S.teal} /> Simulation d'impact — 3 scénarios
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
            {[
              {
                label: "Valider", color: S.success, bg: S.successLight, border: S.success + "44",
                items: [
                  d.program === "VEEDDA" && d.priority === "critique" ? "Sprint 8 démarre J+1" : "Action démarre J+1",
                  `Budget libéré : ${d.impact.match(/€\d+k/)?.[0] || "€12k"}`,
                  "Risque → modéré",
                  "Planning mis à jour",
                ],
                prob: d.priority === "critique" ? "91%" : "87%", probLabel: "Succès",
              },
              {
                label: "Reporter", color: S.warning, bg: S.warningLight, border: S.warning + "44",
                items: [
                  "Délai : J+7 minimum",
                  d.priority === "critique" ? "Coût : +€63k supplémentaires" : "Budget en attente",
                  "Risque maintenu",
                  "Jalon repoussé",
                ],
                prob: "54%", probLabel: "Récupérable",
              },
              {
                label: "Refuser", color: S.error, bg: S.errorLight, border: S.error + "33",
                items: [
                  "Blocage prolongé",
                  d.priority === "critique" ? `Coût total : €${Math.ceil(d.waitingDays * 9 + 30)}k+` : "Révision complète",
                  "Risque → critique",
                  "Escalade requise",
                ],
                prob: "23%", probLabel: "À risque",
              },
            ].map((scenario, si) => (
              <div key={si} style={{ padding: "10px 11px", background: scenario.bg, border: `1px solid ${scenario.border}`, borderRadius: 9 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: scenario.color, marginBottom: 7 }}>{scenario.label}</div>
                {scenario.items.map((item, i) => (
                  <div key={i} style={{ fontSize: 11, color: S.g700, padding: "2px 0", display: "flex", gap: 5, alignItems: "flex-start" }}>
                    <span style={{ color: scenario.color, flexShrink: 0, fontSize: 9, marginTop: 2 }}>›</span>{item}
                  </div>
                ))}
                <div style={{ marginTop: 8, paddingTop: 6, borderTop: `1px solid rgba(0,0,0,0.07)`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 9, color: S.g500 }}>{scenario.probLabel}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: scenario.color, fontVariantNumeric: "tabular-nums" }}>{scenario.prob}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        <button style={{ marginTop: 14, width: "100%", padding: "13px", borderRadius: 10, background: S.teal, color: S.white, border: "none", fontSize: 14, fontWeight: 600, cursor: "pointer", transition: T }}
          onMouseEnter={e => (e.currentTarget.style.background = S.tealDark)}
          onMouseLeave={e => (e.currentTarget.style.background = S.teal)}
        >{d.recommendation}</button>
      </div>
    );
  }
  if (item.type === "program") {
    const p = item.data;
    return (
      <div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}><STARBadge variant={p.status === "nominal" ? "success" : "warning"} label={p.status === "nominal" ? "Nominal" : "Attention"} />{p.tags.map(t => <span key={t} style={{ fontSize: 11, background: S.g100, color: S.g600, padding: "2px 8px", borderRadius: 9999 }}>{t}</span>)}</div>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: S.g900, margin: "0 0 4px" }}>{p.name}</h2>
        <p style={{ fontSize: 13, color: S.g500, margin: 0 }}>{p.tagline}</p>
        <p style={{ fontSize: 14, color: S.g700, lineHeight: 1.6, marginTop: 16 }}>{p.description}</p>
        {sT("Indicateurs")}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {sb("Santé", `${p.health}%`, p.health < 80)}{sb("Phase", p.phase)}{sb("Budget", `${p.budgetUsed}%`, p.budgetUsed > 80)}{sb("Missions", `${p.missionsActive}`)}
        </div>
        {sT("Prochain jalon")}
        <div style={{ padding: "13px 15px", borderRadius: 10, border: `1px solid ${p.nextMilestone.daysLeft <= 3 ? S.error + "44" : S.g200}`, background: p.nextMilestone.daysLeft <= 3 ? S.errorLight : S.g50 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: S.g900 }}>{p.nextMilestone.label}</div>
          <div style={{ fontSize: 12, color: p.nextMilestone.daysLeft <= 3 ? S.error : S.g500, marginTop: 4 }}>{p.nextMilestone.date} · dans {p.nextMilestone.daysLeft} jours</div>
        </div>
        {sT("Responsable")}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><div style={{ width: 32, height: 32, borderRadius: "50%", background: S.tealLight, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, color: S.teal }}>{p.owner.split(" ").map(n => n[0]).join("")}</div><div><div style={{ fontSize: 13, fontWeight: 600, color: S.g900 }}>{p.owner}</div><div style={{ fontSize: 12, color: S.g500 }}>{p.team} personnes</div></div></div>
      </div>
    );
  }
  if (item.type === "mission") {
    const m = item.data;
    const bar = m.status === "critique" || m.status === "bloqué" ? S.error : m.status === "retard" ? S.warning : S.teal;
    return (
      <div>
        <STARBadge variant={m.status === "critique" || m.status === "bloqué" ? "error" : m.status === "retard" ? "warning" : m.status === "en cours" ? "primary" : "neutral"} label={{ critique: "Critique", bloqué: "Bloqué", retard: "En retard", "en cours": "En cours", planifié: "Planifié" }[m.status]} />
        <h2 style={{ fontSize: 18, fontWeight: 700, color: S.g900, margin: "10px 0 4px", lineHeight: 1.3 }}>{m.name}</h2>
        <p style={{ fontSize: 13, color: S.g500, margin: "0 0 20px" }}>{m.program} · {m.owner}</p>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 8 }}><span style={{ color: S.g600 }}>Avancement</span><span style={{ fontWeight: 700, color: S.g900 }}>{m.progress}%</span></div>
        <div style={{ height: 6, background: S.g100, borderRadius: 9999, overflow: "hidden" }}><div style={{ height: "100%", width: `${m.progress}%`, background: bar }} /></div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 16 }}>{sb("Responsable", m.owner)}{sb("Échéance", `${m.deadline} · J-${m.daysLeft}`, m.daysLeft <= 5)}</div>
        {m.blockers.length > 0 && <>{sT(`Blocages (${m.blockers.length})`)}{m.blockers.map((b, i) => <div key={i} style={{ display: "flex", gap: 10, padding: "11px 13px", borderRadius: 8, background: S.errorLight, border: `1px solid ${S.error}33`, marginBottom: 8 }}><AlertTriangle size={13} color={S.error} style={{ flexShrink: 0, marginTop: 1 }} /><span style={{ fontSize: 13, color: "#b91c1c" }}>{b}</span></div>)}</>}
        {sT("Jalons")}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {m.milestones.map((step, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 22, height: 22, borderRadius: "50%", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", border: `2px solid ${step.done ? S.success : step.blocked ? S.error : step.active ? S.teal : S.g300}`, background: step.done ? S.success : step.blocked ? S.errorLight : step.active ? S.tealLight : S.white }}>
                {step.done && <span style={{ color: S.white, fontSize: 10, fontWeight: 700 }}>✓</span>}
                {step.blocked && <span style={{ color: S.error, fontSize: 10, fontWeight: 700 }}>!</span>}
                {step.active && !step.done && !step.blocked && <span style={{ width: 6, height: 6, borderRadius: "50%", background: S.teal, display: "block" }} />}
              </div>
              <span style={{ fontSize: 13, color: step.done ? S.g400 : step.blocked ? "#b91c1c" : step.active ? S.g900 : S.g500, fontWeight: step.active && !step.done ? 500 : 400, textDecoration: step.done ? "line-through" : "none" }}>{step.label}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }
  if (item.type === "risk") {
    const r = item.data;
    return (
      <div>
        <STARBadge variant={r.level === "critique" ? "error" : "warning"} label={r.level === "critique" ? "Critique" : "Moyen"} />
        <h2 style={{ fontSize: 18, fontWeight: 700, color: S.g900, margin: "10px 0 4px" }}>{r.title}</h2>
        <p style={{ fontSize: 12, color: S.g500, margin: 0 }}>{r.program}</p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 20 }}>{sb("Probabilité", r.probability)}<div style={{ padding: "13px 15px", borderRadius: 10, border: `1px solid ${S.error}33`, background: S.errorLight }}><div style={{ fontSize: 11, color: "#b91c1c" }}>Impact</div><div style={{ fontSize: 13, fontWeight: 600, color: "#b91c1c", marginTop: 3 }}>{r.impact}</div></div></div>
        {sT("Plan de mitigation")}<div style={{ padding: "13px 15px", borderRadius: 10, background: S.tealLight, border: `1px solid ${S.teal}33` }}><p style={{ fontSize: 14, color: S.teal, margin: 0, lineHeight: 1.5 }}>{r.mitigation}</p></div>
        {sT("Responsable")}<div style={{ display: "flex", alignItems: "center", gap: 10 }}><div style={{ width: 32, height: 32, borderRadius: "50%", background: S.tealLight, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, color: S.teal }}>{r.owner.split(" ").map(n => n[0]).join("")}</div><span style={{ fontSize: 13, fontWeight: 500, color: S.g900 }}>{r.owner}</span></div>
        <div style={{ marginTop: 20, fontSize: 12, color: S.g400, borderTop: `1px solid ${S.g200}`, paddingTop: 16 }}>Mise à jour : {r.updatedAt}</div>
      </div>
    );
  }
  if (item.type === "agent") {
    const a = item.data;
    return (
      <div>
        <STARBadge variant={a.status === "actif" ? "success" : "neutral"} label={a.status === "actif" ? "Actif" : "Veille"} />
        <h2 style={{ fontSize: 20, fontWeight: 700, color: S.g900, margin: "10px 0 4px" }}>{a.name}</h2>
        <p style={{ fontSize: 13, color: S.g500, margin: 0 }}>{a.role}</p>
        <div style={{ marginTop: 20, padding: "15px", borderRadius: 10, background: S.g50, border: `1px solid ${S.g200}` }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 8 }}>Tâche en cours</div>
          <p style={{ fontSize: 13, color: S.g700, margin: 0 }}>{a.currentTask}</p>
          {a.progress !== null && <div style={{ marginTop: 10 }}><div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: S.g500, marginBottom: 5 }}><span>Progression</span><span style={{ fontWeight: 600, color: S.g700 }}>{a.progress}%</span></div><div style={{ height: 4, background: S.g200, borderRadius: 9999, overflow: "hidden" }}><div style={{ height: "100%", width: `${a.progress}%`, background: S.success }} /></div></div>}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 16 }}>{sb("Tâches complétées", String(a.tasksCompleted))}<div style={{ padding: "13px 15px", borderRadius: 10, background: S.g50, border: `1px solid ${S.g200}` }}><div style={{ fontSize: 11, color: S.g500 }}>Dernière activité</div><div style={{ fontSize: 13, fontWeight: 600, color: S.g700, marginTop: 3 }}>{a.lastActivity}</div></div></div>
        <div style={{ marginTop: 16, padding: "13px 15px", borderRadius: 10, background: S.tealLight, border: `1px solid ${S.teal}33` }}><div style={{ fontSize: 11, fontWeight: 600, color: S.teal, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 6 }}>Mémoire agent</div><p style={{ fontSize: 13, color: S.teal, margin: 0 }}>{a.memory}</p></div>
        <div style={{ display: "flex", gap: 8, marginTop: 20 }}>
          <button style={{ flex: 1, padding: "11px", borderRadius: 8, background: S.teal, color: S.white, border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer", transition: T }} onMouseEnter={e => (e.currentTarget.style.background = S.tealDark)} onMouseLeave={e => (e.currentTarget.style.background = S.teal)}>Lancer une tâche</button>
          <button style={{ flex: 1, padding: "11px", borderRadius: 8, background: "transparent", color: S.g700, border: `1px solid ${S.g300}`, fontSize: 13, fontWeight: 500, cursor: "pointer", transition: T }} onMouseEnter={e => { e.currentTarget.style.borderColor = S.teal; e.currentTarget.style.color = S.teal; }} onMouseLeave={e => { e.currentTarget.style.borderColor = S.g300; e.currentTarget.style.color = S.g700; }}>Voir l'historique</button>
        </div>
      </div>
    );
  }
  return null;
}
function Drawer({ item, onClose }: { item: DrawerItem | null; onClose: () => void }) {
  const label = item?.type === "decision" ? "Décision" : item?.type === "program" ? "Programme" : item?.type === "mission" ? "Mission" : item?.type === "risk" ? "Risque" : "Agent IA";
  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.18)", backdropFilter: "blur(2px)", zIndex: 40, opacity: item ? 1 : 0, pointerEvents: item ? "auto" : "none", transition: "opacity 200ms" }} />
      <div style={{ position: "fixed", right: 0, top: 0, height: "100%", width: 520, background: S.white, borderLeft: `1px solid ${S.g200}`, boxShadow: shadow.xl, zIndex: 50, display: "flex", flexDirection: "column", transform: item ? "translateX(0)" : "translateX(100%)", transition: `transform 300ms ${ease}` }}>
        <div style={{ height: 52, borderBottom: `1px solid ${S.g200}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 20px", flexShrink: 0 }}>
          <span style={{ fontSize: 11, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.6px" }}>{label}</span>
          <button onClick={onClose} style={{ width: 30, height: 30, borderRadius: 8, border: "none", background: "none", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", transition: T }} onMouseEnter={e => (e.currentTarget.style.background = S.g100)} onMouseLeave={e => (e.currentTarget.style.background = "none")}><X size={16} color={S.g500} /></button>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: "22px 22px 32px" }}>{item && <DrawerContent item={item} />}</div>
      </div>
    </>
  );
}

// ─── APP ──────────────────────────────────────────────────────────────────────
// ─── CONTEXT BAR — permanent context, navigable ────────────────────────────────
function ContextBar({ missionId, onNavigate }: { missionId: string | null; onNavigate: () => void }) {
  if (!missionId) return null;
  const mission = MISSIONS.find(m => m.id === missionId);
  if (!mission) return null;
  const dotColor = mission.status === "critique" || mission.status === "bloqué" ? S.error : mission.status === "retard" ? S.warning : S.teal;
  const program = PROGRAMS.find(p => p.name === mission.program);
  const crumbBtn = (label: string, icon: string, color: string, onClick?: () => void) => (
    <button onClick={onClick}
      style={{ display: "flex", alignItems: "center", gap: 5, padding: "2px 9px", background: color + "12", border: `1px solid ${color}33`, borderRadius: 9999, cursor: onClick ? "pointer" : "default", transition: T }}
      onMouseEnter={e => { if (onClick) e.currentTarget.style.background = color + "22"; }}
      onMouseLeave={e => { if (onClick) e.currentTarget.style.background = color + "12"; }}
    >
      <span style={{ fontSize: 9, color }}>{icon}</span>
      <span style={{ fontSize: 11, fontWeight: 600, color: S.g900 }}>{label}</span>
    </button>
  );
  return (
    <div style={{ height: 36, background: S.white, borderBottom: `1px solid ${S.g200}`, display: "flex", alignItems: "center", padding: "0 28px", gap: 6, flexShrink: 0, overflow: "hidden" }}>
      {/* Breadcrumb navigation */}
      <span style={{ fontSize: 10, fontWeight: 600, color: S.g400, textTransform: "uppercase", letterSpacing: "0.5px", flexShrink: 0, marginRight: 2 }}>Contexte</span>
      {program && crumbBtn(program.name, "●", S.teal, onNavigate)}
      <span style={{ color: S.g300, fontSize: 12, flexShrink: 0 }}>›</span>
      {crumbBtn(mission.name.length > 28 ? mission.name.slice(0, 26) + "…" : mission.name, "◆", dotColor, onNavigate)}
      {/* Active agents */}
      <div style={{ display: "flex", gap: 4, flexShrink: 0, marginLeft: 4 }}>
        {[{ icon: "⬡", label: "Architecture" }, { icon: "▲", label: "Risk" }].map((a, i) => (
          <span key={i} style={{ fontSize: 10, color: S.teal, background: S.tealLight, padding: "2px 7px", borderRadius: 4, display: "flex", alignItems: "center", gap: 4, border: `1px solid ${S.teal}22` }}>
            {a.icon} {a.label}
            <span style={{ width: 4, height: 4, borderRadius: "50%", background: S.success, animation: "stPulse 2s ease infinite" }} />
          </span>
        ))}
      </div>
      <span style={{ fontSize: 11, color: S.g400, flexShrink: 0 }}>· ◉ Conv. active · ◆ {DECISIONS.filter(d => d.program === mission.program).length} décisions</span>
      <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
        <span style={{ fontSize: 11, color: mission.daysLeft <= 5 ? S.error : S.g400, fontVariantNumeric: "tabular-nums" }}>J-{mission.daysLeft}</span>
        <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
          <div style={{ height: 4, width: 56, background: S.g100, borderRadius: 9999, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${mission.progress}%`, background: dotColor }} />
          </div>
          <span style={{ fontSize: 10, color: S.g400, fontVariantNumeric: "tabular-nums" }}>{mission.progress}%</span>
        </div>
        <button onClick={onNavigate} style={{ fontSize: 11, color: S.teal, background: "none", border: "none", cursor: "pointer", padding: "2px 6px", borderRadius: 4, transition: T }}
          onMouseEnter={e => (e.currentTarget.style.background = S.tealLight)}
          onMouseLeave={e => (e.currentTarget.style.background = "none")}
        >Ouvrir →</button>
      </div>
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState<Page>("mission-control");
  const [drawer, setDrawer] = useState<DrawerItem | null>(null);
  const [activeMissionId, setActiveMissionId] = useState<string | null>("m1");
  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column", fontFamily: FONT, background: S.g50, overflow: "hidden" }}>
      <TopBar page={page} setPage={setPage} />
      <ContextBar missionId={activeMissionId} onNavigate={() => setPage("pilotage")} />
      {page === "mission-control" && <MissionControlPage openDrawer={setDrawer} onNavigateToPilotage={() => setPage("pilotage")} />}
      {page === "commandement" && <CommandementPage openDrawer={setDrawer} />}
      {page === "pilotage" && <PilotagePage openDrawer={setDrawer} onMissionSelect={setActiveMissionId} />}
      <Drawer item={drawer} onClose={() => setDrawer(null)} />
    </div>
  );
}
