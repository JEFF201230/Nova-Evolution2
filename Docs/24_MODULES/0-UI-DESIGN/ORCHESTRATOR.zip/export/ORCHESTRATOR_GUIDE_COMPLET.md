# ORCHESTRATOR — Guide de reproduction pixel-perfect
## Document de référence complet · Juillet 2026

---

## 1. STRUCTURE DES FICHIERS

```
src/
├── app/
│   └── App.tsx              ← 2 974 lignes · tout le produit en un fichier
├── styles/
│   ├── index.css            ← orchestrateur CSS (3 imports)
│   ├── fonts.css            ← vide (police système)
│   ├── tailwind.css         ← import Tailwind v4
│   └── theme.css            ← tokens STAR + mapping Tailwind
```

---

## 2. STACK TECHNIQUE

```json
{
  "react": "^18",
  "react-dom": "^18",
  "lucide-react": "*",
  "@tailwindcss/vite": "*",
  "@vitejs/plugin-react": "*",
  "tailwindcss": "^4",
  "vite": "^6",
  "typescript": "*"
}
```

**Icônes Lucide utilisées :**
`ChevronRight, X, Bot, Calendar, Shield, BarChart2, Bell, List, Brain, AlertTriangle, CheckCircle, Clock, Zap, FileText, Send, Sparkles, ChevronDown, Bold, Italic, AlignLeft, Paperclip, Plus`

**Règle de style :** 100% inline React styles — ZÉRO classe Tailwind dans le JSX.

---

## 3. DESIGN SYSTEM STAR — TOKENS COMPLETS

```typescript
const S = {
  // Marque principale
  teal:         "#0F5962",   // Couleur principale, nav, CTAs, headers
  tealDark:     "#0d4a52",   // Hover états teal
  tealLight:    "#e8f4f6",   // Fond teal très clair
  teal20:       "rgba(15,89,98,0.10)", // Teal ultra transparent

  // Palette secondaire
  cyan:         "#6CB4C7",   // Planning Agent, éléments secondaires
  coral:        "#FF9076",   // Badge de notification TopBar

  // États sémantiques
  success:      "#10b981",   // Nominal, validé, actif
  successLight: "#d1fae5",   // Fond success
  warning:      "#f59e0b",   // Attention, retard
  warningLight: "#fef3c7",   // Fond warning
  error:        "#ef4444",   // Critique, bloqué, urgent
  errorLight:   "#fee2e2",   // Fond error

  // Échelle de gris
  g50:  "#f9fafb",  // Fond page principal
  g100: "#f3f4f6",  // Fond secondaire, hover doux
  g200: "#e5e7eb",  // Bordures standard
  g300: "#d1d5db",  // Bordures renforcées
  g400: "#9ca3af",  // Icônes désactivées, timestamps
  g500: "#6b7280",  // Texte secondaire
  g600: "#4b5563",  // Texte tertiaire
  g700: "#374151",  // Texte principal
  g900: "#111827",  // Titres, texte très important

  white: "#ffffff",
};
```

---

## 4. OMBRES

```typescript
const shadow = {
  kpi: "0 2px 8px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04)",
  md:  "0 4px 12px rgba(0,0,0,0.08), 0 2px 4px rgba(0,0,0,0.05)",
  lg:  "0 10px 24px rgba(0,0,0,0.10), 0 4px 6px rgba(0,0,0,0.05)",
  xl:  "0 20px 40px rgba(0,0,0,0.14), 0 8px 12px rgba(0,0,0,0.06)",
};
```

Usage :
- `shadow.kpi` → toutes les cartes en état repos
- `shadow.md`  → hover des cartes, éléments flottants légers
- `shadow.lg`  → éléments persistants flottants
- `shadow.xl`  → Drawer (panneau slide-in)

---

## 5. TYPOGRAPHIE ET ANIMATIONS

```typescript
const FONT = "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif";
const ease = "cubic-bezier(0.4,0,0.2,1)";
const T    = `all 250ms ${ease}`;  // transition standard de TOUS les éléments interactifs
```

**Échelle typographique complète :**
| Taille | Usage |
|--------|-------|
| 9px    | Icônes mini, indices |
| 10px   | Labels uppercase, timestamps secondaires |
| 11px   | Labels, timestamps, badges, meta |
| 12px   | Texte secondaire, labels de cartes |
| 13px   | Texte standard corps |
| 14px   | Texte important, boutons |
| 15px   | Texte éditorial (situation du jour) |
| 17px   | Titres de cartes héros |
| 19px   | Titres workspace h2 |
| 21px   | Titres de pages (AgentWorkspace, RiskWorkspace) |
| 22px   | h1 Mission Control, Commandement |
| 28px   | KPI grands (santé programme dans drawer) |
| 32px   | Valeur globale santé (Centre de commandement) |

**Poids :**
- `400` → texte normal
- `500` → medium (navigation, labels interactifs)
- `600` → semibold (titres sections, badges)
- `700` → bold (titres, valeurs importantes)

---

## 6. DIMENSIONS ET LAYOUT

```
LAYOUT PRINCIPAL (colonne flex 100vh)
──────────────────────────────────────
TopBar:         height: 54px
ContextBar:     height: 36px
Content:        flex: 1 (remplit l'espace restant)

ÉLÉMENTS FIXES
──────────────────────────────────────
Drawer:              width: 520px, slide depuis la droite
ContextSidebar:      width: 300px (dans MissionControlPage quand Studio ouvert)
OS Navigator:        width: 210px (dans PilotagePage)
OrchestratorPanel:   width: 256px (dans MissionWorkspace)
Page max-width:      1100px (Mission Control, Commandement = 1200px)

TOPBAR INTERNE
──────────────────────────────────────
Logo zone:       width: 200px, padding: 0 28px
Logo box:        28×28px, borderRadius: 8px, bg: rgba(255,255,255,0.15)
Logo icon Zap:   14px
"ORCHESTRATOR":  13px, fontWeight: 700, letterSpacing: -0.2px
Nav:             flex: 1, centré, gap: 2px entre pills
Tab pill:        padding: 6px 16px, borderRadius: 20px
Actif bg:        rgba(255,255,255,0.18)
Inactif color:   rgba(255,255,255,0.6)
User zone:       width: 200px, justifyContent: flex-end
Bell icon:       16px, color: rgba(255,255,255,0.7)
Notif badge:     7×7px, background: S.coral, border: 1.5px S.teal
Avatar:          28×28px, borderRadius: 50%

CONTEXTBAR INTERNE
──────────────────────────────────────
Padding:         0 28px
Gap entre éléments: 6px
Breadcrumb pill: padding: 2px 9px, borderRadius: 9999px
Progress bar:    height: 4px, width: 56px
"Ouvrir →":      fontSize: 11px, color: S.teal

CARTES (STAR KPI Style)
──────────────────────────────────────
Barre accent gauche: width: 4-5px, height: 100%, position: absolute
Border-radius:       12px standard, 14px héros/studio
Padding:             16-22px standard, 22-27px héros
Shadow repos:        shadow.kpi
Shadow hover:        shadow.md
Transition:          T (250ms ease)

BADGES STAR (STARBadge)
──────────────────────────────────────
Padding:     2px 8px
Radius:      9999px (pill)
Font-size:   11px, fontWeight: 500
Point:       6×6px, borderRadius: 50%
Variants:
  error   → bg: errorLight,   color: #b91c1c, dot: error
  warning → bg: warningLight, color: #92400e, dot: warning
  success → bg: successLight, color: #065f46, dot: success
  primary → bg: tealLight,    color: teal,    dot: teal
  neutral → bg: g100,         color: g600,    dot: g400

GRILLES
──────────────────────────────────────
Mission Control 2-col:  gridTemplateColumns: "1fr 1fr", gap: 20px
Secondary synthesis:    gridTemplateColumns: "1fr 1fr 1fr", gap: 16px
Studio editing:         gridTemplateColumns: "1fr 300px", gap: 20px
MissionWorkspace:       flex row (workspace flex:1 + OrchestratorPanel 256px)
Commandement grid:      gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 16px
MissionWorkspace Générale Vitals: gridTemplateColumns: "1fr 1fr 1fr 1fr 1fr", gap: 10px
MissionWorkspace Relations: gridTemplateColumns: "1fr 1fr 1fr", gap: 12px
Drawer simulation:      gridTemplateColumns: "1fr 1fr 1fr", gap: 8px
OrchestratorPanel actions: gridTemplateColumns: "1fr 1fr", gap: 5px
AgentWorkspace grid:    gridTemplateColumns: "1fr 1fr", gap: 18px
War Room:               gridTemplateColumns: "1fr 1fr 1fr", gap: 16px

GAP STANDARDS
──────────────────────────────────────
Entre sections:    28-32px (marginTop/Bottom)
Entre cartes:      16px (grilles standard), 20px (grands éléments)
Dans une carte:    8-12px entre éléments
Labels/contenu:    6-8px
Icône/texte:       4-6px

BORDURES
──────────────────────────────────────
Standard:   1px solid S.g200 (#e5e7eb)
Active/teal: 1px solid S.teal + "44" (teal à 27% opacity)
Active/focus: 1.5px solid S.teal + "99"
Error:      1px solid S.error + "33"
Warning:    1px solid S.warning + "44"
Success:    1px solid S.success + "44"
Border-radius (toutes valeurs):
  4px → micro (points, mini badges)
  5-6px → petits éléments (pills de mode)
  7-8px → boutons standards
  9px → simulation cards
  10px → éléments médiums
  12px → cartes standard
  14px → grandes cartes héros
  9999px → pills/badges
  50% → cercles/avatars

BOUTONS — STANDARDS
──────────────────────────────────────
CTA primaire teal: padding: 8-16px, background: S.teal, color: white,
                   borderRadius: 8px, fontSize: 13-14px, fontWeight: 600
CTA secondaire:    padding: 8-14px, transparent/white, border: 1px S.g300,
                   borderRadius: 8px, fontSize: 13px, fontWeight: 500
CTA ghost:         padding: 8px, border: none, color: S.teal
CTA grand (Studio): padding: 15px, fontSize: 16px, fontWeight: 700,
                    borderRadius: 12px, width: 100%
Hover tous CTA:    onMouseEnter/onMouseLeave avec style direct
```

---

## 7. ANIMATIONS — KEYFRAMES

```css
/* Injectées via <style> inline dans les composants */

@keyframes stPulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%       { opacity: 0.6; transform: scale(1.3); }
}
/* Usage: pulsation des dots actifs, logos ORCHESTRATOR, badges live */
/* Animation: "stPulse 2s ease infinite" (2.5s pour ORCHESTRATOR header) */

@keyframes stBounce {
  0%, 60%, 100% { transform: translateY(0); }
  30%           { transform: translateY(-5px); }
}
/* Usage: indicateur de frappe "typing..." (3 dots) */
/* Animation: "stBounce 1.2s ease 0s/0.18s/0.36s infinite" */

@keyframes stSpin {
  to { transform: rotate(360deg); }
}
/* Usage: symbole ◌ pendant l'analyse live en Studio */
/* Animation: "stSpin 2s linear infinite" */
```

---

## 8. ARCHITECTURE DES COMPOSANTS

```
App (root — state: page, drawer, activeMissionId)
│
├── TopBar
│   ├── Logo [Zap icon + "ORCHESTRATOR"]
│   ├── Nav [3 pills: Mission Control | Centre de commandement | Pilotage opérationnel]
│   └── User [Bell+badge | Avatar JD]
│
├── ContextBar
│   ├── "Contexte" label
│   ├── Programme pill → navigate to pilotage
│   ├── "›"
│   ├── Mission pill → navigate to pilotage
│   ├── Agents actifs [⬡ Architecture · ▲ Risk avec pulse dots]
│   ├── "· ◉ Conv. active · ◆ N décisions"
│   └── Right: [J-N | progress bar | "Ouvrir →"]
│
├── MissionControlPage  [page="mission-control"]
│   │   state: studioState ("idle"|"editing"|"running")
│   │
│   ├── (studioState==="idle") CockpitContent
│   │   ├── Header: date + h1 + description + "Pendant votre absence" bar
│   │   ├── Grid 2-col:
│   │   │   ├── PriorityActionCard (decision critique)
│   │   │   │   ├── Barre accent rouge gauche 5px
│   │   │   │   ├── STARBadge "Critique"
│   │   │   │   ├── Titre décision (17px bold)
│   │   │   │   ├── Impact callout (errorLight bg)
│   │   │   │   ├── Recommandation (teal20 bg + Sparkles icon)
│   │   │   │   ├── Boutons: [Valider] [Reporter] [Contexte →]
│   │   │   │   └── Footer: "N autres décisions →"
│   │   │   └── MissionStudio trigger card
│   │   │       ├── Zap icon 32×32 (teal20 bg)
│   │   │       ├── Titre + description
│   │   │       ├── 4 exemple pills
│   │   │       ├── Agent avatars 22×22 (5 + "+3")
│   │   │       └── "Ouvrir le Studio →"
│   │   ├── SecondarySynthesis (3-col grid)
│   │   │   ├── Programmes (health bars)
│   │   │   ├── Missions sous attention (status dots)
│   │   │   └── Prochains jalons (J-N countdown)
│   │   └── ActivityFeed
│   │       ├── Événements (7 max, opacity gradient)
│   │       └── Breathing agents footer (⬡◌ ▲◌ ◷◌ ◉◌)
│   │
│   ├── (studioState!=="idle") MissionStudio
│   │   ├── [editing state]
│   │   │   ├── Mode selector (10 pills: Analyse/Audit/Simulation/...)
│   │   │   ├── Header + "Réduire" button
│   │   │   ├── Grid 2-col (1fr 300px):
│   │   │   │   ├── LEFT: Mission editor
│   │   │   │   │   ├── Objectif (input 15px)
│   │   │   │   │   ├── Contexte chips (7 types, dropdown menus)
│   │   │   │   │   ├── Mission editor (textarea + toolbar Bold/Italic/Align/@/📎)
│   │   │   │   │   │   └── Metadata strip: tokens / complexité / durée / agents / mots
│   │   │   │   │   ├── ORCHESTRATOR analyse (apparaît au typing, teal20 bg)
│   │   │   │   │   ├── Résultat attendu (8 deliverables chips)
│   │   │   │   │   └── Pre-launch summary + "Exécuter la mission" (16px bold, full-width)
│   │   │   │   └── RIGHT: Intelligence panel
│   │   │   │       ├── Live context analysis (teal border, apparaît si >3 chars)
│   │   │   │       ├── Bibliothèque (8 templates, grid 2-col)
│   │   │   │       ├── Équipe agents (8 agents, grid 2-col, live states)
│   │   │   │       └── Historique du jour (4 missions récentes)
│   │   └── [running state]
│   │       ├── Header + [+ Nouvelle mission] [↑ Réduire]
│   │       ├── Agents en activité (2×2 grid, animated progress bars)
│   │       ├── Conversation (messages + follow-up input)
│   │       └── Missions récentes (liste avec ✓ badges)
│   │
│   └── ContextSidebar (w=0→300px slide, visible si Studio ouvert)
│       ├── Programme card
│       ├── Décision active (errorLight bg)
│       ├── Documents liés (4 items)
│       ├── Risques liés (critiques)
│       ├── Missions liées (critique+bloqué)
│       ├── Conversations récentes (3 items)
│       └── Prompts utilisés (3 extraits)
│
├── CommandementPage  [page="commandement"]
│   ├── Header: date + h1 + "85%" global (32px bold warning)
│   ├── Programmes (2-col, health bars, barre accent gauche 5px)
│   ├── Grid 4-col:
│   │   ├── Agents actifs (pulse dots)
│   │   ├── Décisions urgentes (clickable → Drawer)
│   │   ├── Risques critiques (clickable → Drawer)
│   │   └── Jalons imminents (J-N countdown)
│   ├── Chaîne de collaboration (5 nœuds horizontaux animés)
│   │   Architecture(done) → Planning(done) → Finance(done) → Risk(active) → ORCHESTRATOR(pending)
│   ├── Analyse ORCHESTRATOR (3-col: Recommandations | Conflits | Opportunités)
│   └── ActivityFeed
│
└── PilotagePage  [page="pilotage"]
    ├── OS Navigator (w=210px, bg: white)
    │   ├── "Système VEEDDA" header label
    │   └── Sections: Missions | Agents | Risques | Roadmap | Mémoire | Graphe
    │       └── Items avec dot coloré + label (selected = teal20 bg)
    └── Workspace (flex:1, overflow hidden)
        ├── MissionWorkspace (selected.type="missions")
        │   ├── Main area (flex:1, flex column)
        │   │   ├── Header (bg: white, border-bottom)
        │   │   │   ├── Badges + programme + owner
        │   │   │   ├── h2 19px bold
        │   │   │   ├── description 13px
        │   │   │   ├── Tabs [Vue générale | Agents & IA | Conversation | Documents | Décisions | Passé·Présent·Futur]
        │   │   │   │   └── Tab active: borderBottom 2px teal
        │   │   │   └── "War Room" button (visible si critique/bloqué)
        │   │   ├── QuickActions strip (bg: g50, border-bottom)
        │   │   │   ├── Créer: [Décision][Risque][Document][Rapport][Note][COPIL][Réunion]
        │   │   │   └── [⚡ Lancer une analyse] (teal bg)
        │   │   └── Tab content (flex:1, overflow-y auto, padding 20px 24px)
        │   │       ├── Vue générale:
        │   │       │   ├── Blocages (errorLight, AlertTriangle icons)
        │   │       │   ├── Décision attendue (teal20, "Décider" button)
        │   │       │   ├── Avancement + jalons (progress bar 7px + milestone dots 16px)
        │   │       │   ├── Relations (3-col: Agents | Risques | Documents)
        │   │       │   └── Vitals (5-col: Prob succès | Tension | Agents | Temps IA | Mémoire)
        │   │       ├── Agents & IA:
        │   │       │   └── AgentProfileCards (40×40 icon + expertise + travaux + mémoire, 3-col)
        │   │       ├── Conversation:
        │   │       │   ├── Participants pills (6 agents + user)
        │   │       │   ├── Messages (bubble-style, reply-to support)
        │   │       │   │   └── Action buttons sous chaque message agent
        │   │       │   └── Input + "Envoyer"
        │   │       ├── Documents:
        │   │       │   └── DocCards (nom + missions + agents + confiance %)
        │   │       ├── Décisions:
        │   │       │   └── DecisionCards (badge + titre + impact/contexte/recommandation + CTA)
        │   │       └── Passé·Présent·Futur:
        │   │           └── 3-col: Passé (grey) | Présent (teal, active pulse) | Projection (dashed border)
        │   ├── OrchestratorPanel (w=256px, bg: white, border-left)
        │   │   ├── Header animé (24px circle teal + pulse)
        │   │   ├── Action bar 2×2: [Assigner][Simuler][Rapport][COPIL]
        │   │   ├── Simulation panel (collapsible <details>, 2 questions, 3 scénarios chacune)
        │   │   ├── Chaîne de raisonnement (6 étapes avec ligne verticale)
        │   │   │   Architecture → Risk → Planning → Finance → Mémoire → ORCHESTRATOR
        │   │   ├── Conclusion (errorLight ou successLight selon état)
        │   │   ├── Conflit inter-agents (warningLight, visible si blockers)
        │   │   ├── Recommandation (teal20 bg)
        │   │   ├── Décision suggérée + "Créer la décision" (full-width teal)
        │   │   └── Executive block (#0d1926, teal border)
        │   │       ├── Texte arbitrage (white/60% opacity, italique)
        │   │       └── Verdict card (successLight/12%, borderRadius 7px)
        │   └── War Room overlay (position:absolute, inset:0, bg:#0a0f1a, zIndex:20)
        │       ├── Header: pulse red dot + "WAR ROOM" + mission name
        │       ├── Grid 3-col: Blocages | Équipe | Décisions
        │       └── ORCHESTRATOR analyse (full-width, 3-col: situation/action/projection)
        ├── AgentWorkspace (selected.type="agents")
        │   ├── Header: 52×52 icon + STARBadge + h2 + specialty
        │   ├── Expertise chips (teal20)
        │   ├── Grid 2-col: Travaux récents | Performances
        │   └── Mémoire (insights avec 💡)
        ├── RiskWorkspace (selected.type="risques")
        │   ├── Header: STARBadge + h2 + probabilité
        │   └── Grid 2-col: Chaîne d'impact (navigable) | Plan mitigation + CTA
        ├── RoadmapWorkspace (selected.type="roadmap")
        │   └── Timeline verticale (dot + ligne + date + label)
        ├── MemoireWorkspace (selected.type="memoire")
        │   ├── Filtres agents (pills)
        │   └── Knowledge cards (💡 insight + meta)
        └── GraphWorkspace (selected.type="graphe")
            ├── SVG interactif (640×380 viewBox)
            │   ├── Edges (lignes pointillées S.g200)
            │   └── Nodes (cercles clickables, 22px radius → 26px selected)
            └── Légende + détail node sélectionné

Drawer (position:fixed, right:0, w=520px, zIndex:50)
├── Backdrop (rgba(0,0,0,0.18) + blur 2px, zIndex:40)
├── Header (52px, label type + X button 30×30)
└── DrawerContent (scrollable, padding 22px)
    ├── type="decision": Badge + titre + impact callout + contexte + options + simulation 3 scénarios + CTA
    ├── type="program":  Badge + tags + nom + desc + indicateurs 2×2 + jalon + responsable
    ├── type="mission":  Badge + nom + progress bar + grid 2-col + blocages + jalons
    ├── type="risk":     Badge + nom + grid 2-col (prob/impact) + mitigation + responsable
    └── type="agent":    Badge + nom + rôle + tâche + progress + stats + mémoire + CTA
```

---

## 9. FLUX D'INTERACTIONS COMPLETS

### Navigation principale
```
TopBar pill click → setPage(id)
"Mission Control"         → page = "mission-control"
"Centre de commandement"  → page = "commandement"
"Pilotage opérationnel"   → page = "pilotage"
```

### ContextBar (tous les clics naviguent vers pilotage)
```
Programme pill → setPage("pilotage")
Mission pill   → setPage("pilotage")
"Ouvrir →"    → setPage("pilotage")
```

### Drawers
```
openDrawer(item) → setDrawer(item) → Drawer visible (slide depuis droite)
Fermeture: backdrop click | X button → setDrawer(null)

Déclencheurs:
SecondarySynthesis > Programme card      → {type:"program",  data: PROGRAMS[i]}
SecondarySynthesis > Mission card        → {type:"mission",  data: MISSIONS[i]}
PriorityActionCard > "Contexte"          → {type:"decision", data: DECISIONS[0]}
PriorityActionCard > "Tout voir →"       → setPage("pilotage") (pas drawer)
CommandementPage > Programme card        → {type:"program",  data: PROGRAMS[i]}
CommandementPage > Décision urgente      → {type:"decision", data: DECISIONS[i]}
CommandementPage > Risque critique       → {type:"risk",     data: RISKS[i]}
MissionWorkspace > "Décider"             → {type:"decision", data: linkedDecision}
MissionWorkspace > Risque lié            → {type:"risk",     data: RISKS[i]}
OrchestratorPanel > "Créer la décision"  → {type:"decision", data: linkedDecision}
```

### Mission Studio
```
CockpitContent > "Ouvrir le Studio"    → setStudioState("editing")
                                          ContextSidebar slide-in (w: 0→300px)

MissionStudio[editing]:
  Champ objectif typing → objective setState → déclenche:
    - analysisStarted=true → setInterval(420ms) → analysisStep++ (6 étapes)
    - useEffect sur !!objective → séquence AGENT_PRE_STATES (400ms + 1000ms/étape)
  
  Context chip + → showContextMenu=chipId → dropdown
  Dropdown option → addContext(type, value) → contexts push
  Context × → contexts filter remove
  
  Template click → setObjective(tpl.objective) + setMissionText(tpl.text)
  
  Toolbar Bold/Italic/Align → decoratif (pas d'action)
  "@Référence" → decoratif
  📎 Joindre → file input → attachments push
  Drag&Drop → onDragOver/onDrop → attachments push
  
  "Exécuter la mission" (si canLaunch) → setStudioState("running")
  "Réduire" → onClose() → setStudioState("idle")

MissionStudio[running]:
  useEffect[studioState="running"] → setInterval(120ms):
    progress += 2-10 par agent jusqu'à target%
    tâche change selon idx = floor(progress/100 * tasks.length)
    tous done → clearInterval → setTimeout(600ms) → generateResponse → setMessages
  
  Follow-up input Enter/button → handleFollowUp():
    push userMsg + typingMsg
    setTimeout(1800ms) → generateResponse → push aiMsg, remove typing
  
  "Nouvelle mission" → setStudioState("editing") + reset progress/messages
  "Réduire" → setStudioState("idle")
```

### PilotagePage — OS Workspace
```
ObjectTree item click → handleSelect({type, id}):
  type="missions" → MissionWorkspace(id) + onMissionSelect(id) → ContextBar update
  type="agents"   → AgentWorkspace(id)
  type="risques"  → RiskWorkspace(id)
  type="roadmap"  → RoadmapWorkspace()
  type="memoire"  → MemoireWorkspace()
  type="graphe"   → GraphWorkspace()

MissionWorkspace tabs:
  tab click → setActiveTab(id)
  "Vue générale" | "Agents & IA" | "Conversation" | "Documents" | "Décisions" | "Passé·Présent·Futur"

QuickActions:
  [Décision|Risque|Document|Rapport|Note|COPIL|Réunion] → setQuickActionDone(label)
    → affiche confirmation 3s puis × pour dismiss
  [⚡ Lancer une analyse] → setActiveTab("conversation") + setQuickActionDone(null)

War Room (visible si critique/bloqué):
  "War Room" button → setWarRoom(true) → overlay position:absolute inset:0
  "↑ Quitter" → setWarRoom(false)

Conversation tab:
  input Enter (sans Shift) | "Envoyer" → sendConvMessage():
    push user message
    setTimeout(1200ms) → push ORCHESTRATOR response
  Actions sur message agent → boutons décroatifs (pas d'action définie)

OrchestratorPanel:
  [Assigner] → setActionDone("Assignation créée") → confirmation bar (succès)
  [Simuler]  → setSimulating(!simulating) → toggle panneau de simulation
  [Rapport]  → setActionDone("Rapport lancé")
  [COPIL]    → setActionDone("COPIL préparé")
  actionDone × → setActionDone(null)
  "Créer la décision" → openDrawer({type:"decision"})

ActivityFeed:
  useEffect → setInterval(11000-18000ms) → push random event de ACTIVITY_POOL

GraphWorkspace:
  Node click → setSelectedNode(id) ou null si déjà sélectionné
  → node radius: 22 → 26px, fill: white → node.color
```

### Drawer — Actions internes
```
DrawerContent[type="decision"]:
  Option bouton click → décoratif (outline change)
  "Recommandation" teal button → validation (CTA principal)
  Simulation cards → affichage seul

DrawerContent[type="mission"]:
  Lecture seule + jalons visuels

DrawerContent[type="agent"]:
  "Lancer une tâche" → CTA décoratif
  "Voir l'historique" → CTA décoratif
```

---

## 10. DONNÉES — STRUCTURE COMPLÈTE

### Types TypeScript
```typescript
type Page = "mission-control" | "commandement" | "pilotage";
type StudioState = "idle" | "editing" | "running";
type OSSelection = { type: string; id: string };

type DrawerItem =
  | { type: "decision"; data: Decision }
  | { type: "program";  data: Program }
  | { type: "mission";  data: Mission }
  | { type: "risk";     data: Risk }
  | { type: "agent";    data: Agent };

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  time: string;
  typing?: boolean;
  actions?: string[];
}
```

### Données simulées
- `PROGRAMS[2]` → VEEDDA (health:78, attention) + ORCHESTRATOR (health:91, nominal)
- `DECISIONS[4]` → 1 critique + 1 haute + 2 normale, toutes avec options[]
- `MISSIONS[6]` → m1(critique,34%) m2(retard,61%) m3(bloqué,20%) m4(en cours,74%) m5(en cours,88%) m6(planifié,0%)
- `RISKS[4]` → r1(critique,VEEDDA) r2(critique,VEEDDA) r3(moyen,ORCHESTRATOR) r4(moyen,VEEDDA)
- `SPECIALIST_AGENTS[8]` → Architecture/Planning/Finance/Risk/Legal/QA/Document/Classification
- `AGENTS_DATA[3]` → VEEDDA Analyst / Risk Monitor / Decision Assistant
- `KNOWLEDGE_BASE[6]` → 6 insights avec usages/confidence/missions/docs
- `AGENT_PROFILES` → profils détaillés pour architecture/planning/finance/risk

---

## 11. COULEURS WAR ROOM (dark mode partiel)

```typescript
// War Room overlay background
"#0a0f1a"

// War Room ORCHESTRATOR analyse background
"rgba(15,89,98,0.1)" → border rgba(15,89,98,0.25)

// Blocages panel
"rgba(239,68,68,0.1)" → border rgba(239,68,68,0.3)

// Agents panel
"rgba(15,89,98,0.15)" → border rgba(15,89,98,0.3)

// Décisions panel
"rgba(245,158,11,0.1)" → border rgba(245,158,11,0.3)

// Texte dans War Room
rgba(255,255,255,0.8)  → texte important
rgba(255,255,255,0.6)  → texte secondaire
rgba(255,255,255,0.4)  → texte tertiaire
rgba(255,255,255,0.07) → séparateurs

// ORCHESTRATOR Executive dark block
"#0d1926"              → background
S.teal + "44"          → border
rgba(255,255,255,0.6)  → texte arbitrage
rgba(16,185,129,0.12)  → bg verdict card
rgba(16,185,129,0.25)  → border verdict card
rgba(255,255,255,0.35) → meta confiance
```

---

## 12. RESPONSABILITÉS DES COMPOSANTS

| Composant | State local | Props reçues | Effets |
|-----------|-------------|--------------|--------|
| App | page, drawer, activeMissionId | — | — |
| TopBar | — | page, setPage | — |
| ContextBar | — | missionId, onNavigate | — |
| MissionControlPage | studioState | openDrawer, onNavigateToPilotage | — |
| CockpitContent | — | openDrawer, onNavigateToPilotage, onOpenStudio | — |
| MissionStudio | objective, contexts, missionText, agentProgress, messages, ... | studioState, onStateChange, onClose | setInterval progress sim |
| ContextSidebar | — | openDrawer | — |
| PriorityActionCard | actionTaken, hovered | decision, totalDecisions, compact, onContext, onViewAll | — |
| SecondarySynthesis | — | openDrawer, onNavigateToPilotage | — |
| ActivityFeed | events | — | setInterval 11-18s |
| CommandementPage | — | openDrawer | — |
| PilotagePage | selected | openDrawer, onMissionSelect | — |
| MissionWorkspace | activeTab, warRoom, quickActionDone, convInput, convMessages | id, openDrawer | useEffect reset on id change |
| OrchestratorPanel | simulating, actionDone | mission, openDrawer | — |
| AgentWorkspace | — | id | — |
| RiskWorkspace | — | id, openDrawer | — |
| MemoireWorkspace | filter | — | — |
| GraphWorkspace | selectedNode | — | — |
| Drawer | — | item, onClose | — |
| DrawerContent | — | item | — |

---

## 13. REPRODUCTION — ORDRE DE BUILD RECOMMANDÉ

1. **Setup** : Vite + React 18 + TypeScript + Tailwind v4
2. **CSS** : Copier index.css, tailwind.css, fonts.css, theme.css tels quels
3. **Tokens** : Déclarer `S`, `shadow`, `ease`, `T`, `FONT` en tête de App.tsx
4. **Data** : Déclarer `PROGRAMS`, `DECISIONS`, `MISSIONS`, `RISKS`, `SPECIALIST_AGENTS`, `AGENTS_DATA`, `KNOWLEDGE_BASE`, `AGENT_PROFILES`, `RECENT_MISSIONS`, `ACTIVITY_POOL`, `INITIAL_ACTIVITY`, `ANALYSIS_STEPS`, `AGENT_PRE_STATES`, `AGENT_PHASES`, `MISSION_TEMPLATES`, `DELIVERABLES`, `CONTEXT_TYPES`
5. **Types** : `Page`, `OpTab`, `StudioState`, `DrawerItem`, `ChatMessage`
6. **Utilities** : `generateResponse()`, `renderMD()`
7. **Composants atomiques** : `STARBadge`
8. **Layout** : `TopBar`, `ContextBar`
9. **Drawers** : `DrawerContent`, `Drawer`
10. **Workspaces** : `AgentWorkspace`, `RiskWorkspace`, `RoadmapWorkspace`, `MemoireWorkspace`, `GraphWorkspace`
11. **Mission Workspace** : `OrchestratorPanel`, `MissionWorkspace`
12. **Pilotage** : `ObjectTree`, `PilotagePage`
13. **Mission Control** : `ActivityFeed`, `SecondarySynthesis`, `PriorityActionCard`, `ContextSidebar`, `MissionStudio`, `CockpitContent`, `MissionControlPage`
14. **Commandement** : `CommandementPage`
15. **App root** : `export default function App()`

---

*Référence générée le 11 juillet 2026 · ORCHESTRATOR MVP Final*
