# Gate Register

| Gate | Preuve | Décision |
|---|---|---|
| RUNTIME_BASELINE_CERTIFIED | Audit des trois scripts et du registre de profils | GO |
| EXECUTION_JOURNAL_CERTIFIED | Écriture persistante JSONL UTF-8 par étape | GO |
| WORKSPACE_SNAPSHOT_CERTIFIED | Empreintes avant/après et test préexistant/non suivi | GO |
| REPORTING_ENGINE_CERTIFIED | Objet, JSON, Markdown et transcript séparé | GO |
| VALIDATION_ENGINE_CERTIFIED | Allowlist et validation du manifeste | GO |
| CLASSIFICATION_ENGINE_CERTIFIED | Tests des sept statuts | GO |
| DIAGNOSTIC_ENGINE_CERTIFIED | Diagnostics structurés fait, conséquence, hypothèse, action corrective ; rapport de secours testé avant Codex | GO |
| MISSION_MANIFEST_CERTIFIED | `allowedPaths`, `forbiddenPaths`, `expectedFiles` et quatre commandes nommées validés | GO |
| RUNTIME_REGRESSION_SUITE_CERTIFIED | 15/15 tests unitaires, 13/13 captures d'exception et 15/15 scénarios processus avec faux Codex | GO |
| OPERATIONS_DOCUMENTATION_CERTIFIED | Guide Git Guardian, rollback, reprise et maintenance présent | GO |
| CEREBRAU_REPORTING_E2E_CERTIFIED | Tous les gates amont GO ; validations gouvernées 10/10 et `git diff --check` réussi | GO |
