# PDS — CEREBRAU Reporting E2E

Programme directeur : `PROGRAM-CEREBRAU-REPORTING-E2E`.

## Autorité et finalité

Le runtime, et non le transcript Codex, certifie les faits d'exécution. Les autorités sont Git, le système de fichiers, les codes de sortie, les validations et les horodatages.

## Architecture

```text
mission.json + prompt.md
          |
          v
Invoke-CerebrauMission.ps1
  |-- journal JSONL
  |-- snapshot Git avant + sauvegarde temporaire
  |-- codex exec + transcript non autoritatif
  |-- snapshot Git après
  |-- delta propre à la mission
  |-- validations allowlistées
  |-- classification
  `-- rapport objet + JSON + Markdown
```

## Gouvernance

Les lots sont exécutés dans l'ordre. Un gate non démontré bloque la certification finale. Aucun statut positif ne peut provenir du seul texte du modèle.

## Compatibilité

Le contrat `mission.json` 1.0.0, STDIN UTF-8, `--output-last-message` et les propriétés historiques de l'objet PowerShell sont conservés.
