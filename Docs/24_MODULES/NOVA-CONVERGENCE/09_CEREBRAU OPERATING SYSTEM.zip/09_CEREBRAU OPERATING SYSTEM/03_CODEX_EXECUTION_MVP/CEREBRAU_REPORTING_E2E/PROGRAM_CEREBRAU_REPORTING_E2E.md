# PROGRAM — CEREBRAU Reporting E2E

## Périmètre

Le programme porte exclusivement sur `tools/cerebrau/` et sa documentation. Aucun composant métier VEEDDA n'est dans son périmètre.

## Contrats produits

- Journal persistant : JSON Lines UTF-8 sans BOM.
- Snapshots : branche, HEAD, porcelain, inventaire suivi/non suivi et empreintes SHA-256.
- Delta : créations, modifications, suppressions, renommages, insertions et suppressions.
- Rapport : objet PowerShell, JSON et Markdown.
- Transcript : conservé séparément avec `TranscriptAuthoritative=false`.

## Statuts

`SUCCESS`, `READY_FOR_REVIEW`, `BLOCKED`, `FAILED`, `CANCELLED`, `NO_CHANGE`, `PARTIAL`.

## Baseline certifiée

Le runtime historique validait mission/profil/branche/version, lisait le prompt UTF-8, appelait Codex via STDIN, capturait le dernier message et retournait un objet PowerShell. Il ne mesurait pas le delta ni les validations et déduisait le succès du seul ExitCode.
