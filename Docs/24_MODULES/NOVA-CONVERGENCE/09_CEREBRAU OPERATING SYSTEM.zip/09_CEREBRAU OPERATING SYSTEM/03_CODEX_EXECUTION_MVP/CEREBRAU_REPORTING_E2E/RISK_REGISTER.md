# Risk Register

| ID | Risque | État | Traitement |
|---|---|---|---|
| R-001 | Transcript contradictoire avec Git | MITIGÉ | Transcript non autoritatif, delta issu des snapshots |
| R-002 | Attribution d'une modification préexistante | MITIGÉ | Comparaison d'empreintes avant/après |
| R-003 | Auto-attribution des rapports runtime | MITIGÉ | Répertoire de rapports exclu des snapshots |
| R-004 | Renommages avec contenu modifié mal classés | OUVERT | Ajouter détection de similarité Git |
| R-005 | Fichiers sensibles copiés dans le backup temporaire | OUVERT | Ajouter exclusions sensibles explicites avant certification |
| R-006 | Crash avant génération du rapport final | OUVERT | Journal persistant existe ; rapport de secours à ajouter |
| R-007 | Commandes compilation/tests arbitraires | CONTRÔLÉ | Non implémentées avant gouvernance allowlistée |
| R-008 | Encodage console Windows | OUVERT | Tests UTF-8 fichiers passent ; matrice PowerShell 5.1/7 à exécuter |
