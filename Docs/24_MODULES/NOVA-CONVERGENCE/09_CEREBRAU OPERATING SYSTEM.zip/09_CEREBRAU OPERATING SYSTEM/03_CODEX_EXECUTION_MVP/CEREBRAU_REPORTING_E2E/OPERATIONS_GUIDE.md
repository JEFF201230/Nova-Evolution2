# Guide d'exploitation — CEREBRAU Reporting E2E

## Précontrôles

1. Exécuter `Test-CerebrauMission.ps1` et vérifier `Status=VALID`.
2. Vérifier que la branche courante correspond à `expectedBranch`.
3. Examiner `git status --short` et conserver les changements préexistants comme appartenant à l'opérateur.
4. Vérifier les périmètres `allowedPaths`, `forbiddenPaths`, les `expectedFiles` et la liste fermée des commandes nommées.

## Exécution et preuves

Lancer `Invoke-CerebrauMission.ps1 -MissionFile <manifest>`. Chaque exécution écrit un répertoire distinct sous `reportDirectory` avec le journal JSONL, les snapshots avant/après, le delta, le transcript non autoritatif et les rapports JSON/Markdown. Un ExitCode Codex nul ne suffit jamais à certifier la mission : le statut officiel dépend aussi du delta et des validations requises.

## Git Guardian

- Ne jamais changer de branche, committer, pousser, restaurer ou supprimer automatiquement un changement préexistant.
- Traiter toute modification qui ne correspond à aucun motif `allowedPaths`, ou qui correspond à `forbiddenPaths`, comme une violation bloquante.
- Vérifier `BranchChanged=false`, `HeadChanged=false`, puis exécuter `git diff --check`.
- Comparer le diff final au snapshot initial et au périmètre de la mission, pas au transcript Codex.

## Échec, interruption et reprise

Le journal persistant est l'autorité chronologique. En cas d'exception, lire la dernière entrée `FAILURE` et le diagnostic associé : `Fact`, `Consequence`, `Hypothesis`, `CorrectiveAction`. Le rapport de secours couvre les échecs survenus avant le rapport nominal. La reprise s'effectue au premier diagnostic en erreur, avec le même manifeste corrigé ; un gate échoué reste `NO GO` jusqu'à nouvelle preuve réussie.

## Rollback

Le runtime ne réalise aucun rollback automatique. L'opérateur identifie d'abord les seuls fichiers attribués à la mission dans `mission-delta.json`, sauvegarde les changements utiles, puis applique une restauration explicite et ciblée. Les changements préexistants et les fichiers hors mission ne doivent jamais être touchés. Après rollback, refaire un snapshot et confirmer que la branche et HEAD sont inchangés.

## Maintenance

Toute nouvelle validation exécutable doit recevoir un nom canonique ajouté à la fois au validateur du manifeste et au registre fermé du module. Ajouter un scénario processus avant activation. Exécuter, dans l'ordre : syntaxe PowerShell, tests Reporting, tests de capture d'exception, puis les 15 scénarios E2E. Conserver UTF-8 sans BOM pour les artefacts et ne jamais rendre le transcript autoritatif.
