# Decision Register

| ID | Décision | Motif |
|---|---|---|
| D-001 | Git et filesystem sont autoritatifs | Le modèle peut se tromper sur les changements |
| D-002 | Transcript séparé et marqué non autoritatif | Préserve l'explication sans certifier ses affirmations |
| D-003 | Empreintes SHA-256 par fichier | Distingue les changements produits pendant la mission |
| D-004 | Sauvegarde avant en répertoire temporaire | Permet de mesurer le diff de lignes propre à la mission |
| D-005 | Validations sur allowlist fermée | Empêche l'exécution arbitraire depuis le manifeste |
| D-006 | Compatibilité additive de l'objet de retour | Préserve les consommateurs historiques |
| D-007 | Certification finale refusée | LOT-007 à LOT-010 ne sont pas entièrement démontrés |
