# Implementation Backlog

## Terminé

- B-001 Inventaire et invariants de la baseline.
- B-002 Journal JSONL par étape.
- B-003 Snapshots avant/après avec empreintes et sauvegarde temporaire.
- B-004 Calcul du delta indépendant du transcript.
- B-005 Rapports PowerShell, JSON et Markdown.
- B-006 Validations allowlistées : fichier, JSON, UTF-8, PowerShell, diff Git.
- B-007 Classification canonique.
- B-008 Extension optionnelle et compatible du manifeste.
- B-009 Harness de 15 contrôles unitaires.

- B-010 Diagnostic structuré avec fait, conséquence, hypothèse et correction.
- B-011 Restrictions explicites `allowedPaths`/`forbiddenPaths` et fichiers attendus.
- B-012 Validations compilation/tests via commandes nommées gouvernées.
- B-013 Scénarios processus réels : interruption, ExitCode non nul, compilation et tests échoués.
- B-014 Test E2E du script d'invocation avec faux exécutable Codex contrôlé.
- B-015 Guide complet Git Guardian, rollback et maintenance.
- B-016 Certification finale sur les quinze scénarios obligatoires.

## À faire

Aucun élément restant.
