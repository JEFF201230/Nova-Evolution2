# Traceability Matrix

| Exigence | Implémentation | Validation |
|---|---|---|
| Journal factuel | `Invoke-CerebrauMission.ps1` JSONL | parseur JSONL + capture de 3 exceptions indépendantes |
| Snapshot avant/après | `New-CerebrauWorkspaceSnapshot` | tests création, modification, préexistant et chemin UTF-8 |
| Delta | `Compare-CerebrauWorkspaceSnapshot` | tests insertions et fichiers |
| Transcript non autoritatif | `New-CerebrauOfficialReport` | scénario contradiction transcript/Git |
| Validation gouvernée | `Invoke-CerebrauValidation` | allowlist de types et registre fermé de commandes nommées |
| Classification | `Get-CerebrauClassification` | tests FAILED/CANCELLED/BLOCKED/PARTIAL/NO_CHANGE/READY_FOR_REVIEW/SUCCESS |
| JSON/Markdown/objet | module Reporting + objet Invoke | parsing JSON et inspection Markdown E2E |
| Compatibilité runtime | propriétés historiques conservées | analyse syntaxique et revue de diff |
| Diagnostic complet | `New-CerebrauDiagnostic`, `New-CerebrauDiagnostics` et rapport de secours | scénarios échec, interruption, validations et exception pré-Codex |
| Périmètre manifeste | `allowedPaths`, `forbiddenPaths`, `expectedFiles` | scénarios interdit, hors allowlist, attendu absent/présent |
| Compilation/tests gouvernés | `Invoke-CerebrauNamedCommand` | échecs compilation/tests et validations nommées 4/4 |
| Suite E2E complète | `Test-CerebrauRuntimeE2E.ps1` + faux Codex | 15/15 scénarios processus réussis |
| Exploitation | `OPERATIONS_GUIDE.md` | revue Git Guardian, rollback, reprise et maintenance |
| Certification finale | registres du programme | validations manifeste 10/10 + `git diff --check` réussi |
