# CEREBRAU Codex Execution MVP — Checklist de certification

## 1. Objet

Cette checklist constitue la définition officielle de « MVP terminé » pour l'adaptateur d'exécution CEREBRAU → Codex CLI.

Le MVP est limité à la chaîne suivante :

```text
Mission validée
→ Résolution du profil
→ Préparation de l'exécution Codex
→ Transmission du prompt
→ Exécution dans le dépôt cible
→ Normalisation du résultat
→ Retour du résultat à CEREBRAU
```

Il ne crée ni ne remplace les mécanismes CEREBRAU de gouvernance, de planification ou d'orchestration.

## 2. Règle de certification

Chaque critère doit être accompagné d'une preuve reproductible. La certification finale est interdite tant qu'un critère obligatoire est en échec, non testé ou seulement supposé.

Statuts autorisés :

- `[ ]` Non certifié
- `[x]` Certifié
- `[!]` Bloquant

## 3. Checklist obligatoire

### Configuration et validation

- [ ] **Résolution du profil** — Le profil demandé existe et restitue exactement `Model`, `ReasoningEffort`, `Sandbox` et `ApprovalPolicy`.
- [ ] **Validation de la mission** — Tous les champs obligatoires, chemins, états et contraintes de la mission sont validés en mode fermé avant l'exécution.
- [ ] **Détection de Codex** — Le wrapper ou l'exécutable réellement invoqué est identifié et son absence produit une erreur bloquante normalisée.
- [ ] **Vérification de la version de Codex** — La version locale est lue et reconnue comme compatible avec le contrat du MVP.
- [ ] **Vérification de la branche Git** — La branche active correspond à `expectedBranch`; aucune commande Git d'écriture n'est exécutée.

### Préparation de l'exécution

- [ ] **Construction des arguments** — Les arguments sont construits sous forme de tableau PowerShell, dans l'ordre accepté par la CLI locale, sans `Invoke-Expression` ni commande shell brute.
- [ ] **Cohérence des paramètres** — Le modèle, le niveau de raisonnement, le sandbox et les autres paramètres effectifs correspondent au profil résolu.
- [ ] **Cohérence entre ApprovalPolicy et le runtime** — La politique déclarée par CEREBRAU correspond à celle effectivement appliquée et rapportée par Codex; toute divergence est bloquante.
- [ ] **Sécurité** — Les valeurs et options interdites sont rejetées avant le lancement de Codex.

### Prompt et encodage

- [ ] **Transmission complète du prompt** — Le bloc `user` reçu par Codex contient l'intégralité du prompt, sans troncature ni transformation structurelle.
- [ ] **Gestion UTF-8** — Les caractères UTF-8, notamment les accents, sont identiques dans le fichier source, le prompt reçu et la réponse récupérée.

### Exécution et résultat

- [ ] **Exécution dans le dépôt cible** — Le runtime Codex confirme que son répertoire de travail est le dépôt validé par la mission.
- [ ] **Récupération de la dernière réponse** — La réponse métier est obtenue au moyen du contrat officiel `--output-last-message`, indépendamment des sorties de diagnostic de la console.
- [ ] **Gestion des codes de sortie** — Le code natif réel est récupéré et normalisé en `SUCCESS`, `FAILURE` ou `CANCELLED` sans masquer les erreurs.
- [ ] **Nettoyage des fichiers temporaires** — Chaque fichier temporaire est créé hors du dépôt et supprimé dans tous les chemins de sortie, y compris erreur et annulation.
- [ ] **Journalisation minimale** — Le résultat unique contient au minimum `MissionId`, `Status`, `ExitCode`, `StartedAt`, `FinishedAt`, `DurationMs`, `Model`, `Sandbox`, `Approval` et `Transcript`.

### Certification finale

- [ ] **Certification finale du runtime** — Un test réel reproductible retourne un objet unique avec `Status = SUCCESS`, `ExitCode = 0`, un `Transcript` complet, les paramètres runtime attendus et aucune modification hors périmètre.

## 4. Critères bloquants connus

La certification reste refusée si au moins une des situations suivantes est observée :

- prompt tronqué ou caractères altérés;
- politique d'approbation déclarée différente de la politique runtime;
- code de sortie synthétique à la place du code natif;
- résultat métier dérivé de la sortie console au lieu de `--output-last-message`;
- fichier temporaire conservé après l'exécution;
- branche ou dépôt cible incorrect;
- option dangereuse acceptée;
- modification automatique de Git;
- responsabilité Program, Wave, Squad, Gate ou dépendance ajoutée à l'adaptateur.

## 5. Hors périmètre du MVP

Les capacités suivantes relèvent d'une version ultérieure et ne conditionnent pas la certification du MVP :

- orchestration multi-agent;
- orchestration parallèle;
- sélection automatique du profil;
- planification Program/Wave/Squad;
- calcul des dépendances, locks ou gates;
- interface graphique;
- journalisation avancée et observabilité distribuée;
- persistance en base de données;
- multi-fournisseur;
- commit ou push automatique.

## 6. Décision de certification

| Champ | Valeur |
| --- | --- |
| Version du MVP | 1.0.0 |
| Version Codex certifiée | À renseigner par la preuve d'exécution |
| Date de certification | À renseigner |
| Responsable | À renseigner |
| Résultat | NON CERTIFIÉ |
| Bloquants | À renseigner |
| Preuve de certification | À renseigner |

La valeur `Résultat` ne peut devenir `CERTIFIÉ` qu'après validation de tous les critères obligatoires de la section 3.
