\# PDS-001 — CEREBRAU AI EXECUTION DIRECTOR



\## 1. Statut du document



| Champ | Valeur |

|---|---|

| Produit | CEREBRAU Operating System |

| Capacité | AI Execution Director |

| Identifiant | PDS-001 |

| Version | 1.0.0 |

| Statut | PROPOSITION POUR IMPLÉMENTATION |

| Priorité | HAUTE |

| Auteur fonctionnel | CEREBRAU Program Direction |

| Cible d’exécution | Codex CLI via PowerShell |

| Plateforme initiale | Windows / PowerShell |

| Extension future | macOS, Linux, API, agents multiples |



\---



\## 2. Résumé exécutif



CEREBRAU doit devenir la source de décision unique pour l’exécution des travaux confiés à des agents IA.



La nouvelle capacité \*\*AI Execution Director\*\* transforme une mission CEREBRAU en exécution Codex entièrement paramétrée :



1\. CEREBRAU reçoit ou charge une mission.

2\. CEREBRAU qualifie la nature du travail.

3\. CEREBRAU détermine le niveau de risque et de complexité.

4\. CEREBRAU sélectionne un profil d’exécution.

5\. Le profil détermine :

&#x20;  - le modèle autorisé ;

&#x20;  - le niveau de raisonnement ;

&#x20;  - le mode sandbox ;

&#x20;  - la politique d’approbation ;

&#x20;  - le répertoire de travail ;

&#x20;  - les outils autorisés ;

&#x20;  - les règles de sécurité ;

&#x20;  - les gates obligatoires.

6\. CEREBRAU génère un descripteur d’exécution immuable.

7\. Un lanceur PowerShell valide ce descripteur.

8\. PowerShell invoque Codex avec la configuration décidée par CEREBRAU.

9\. Les résultats, journaux et preuves d’exécution sont réinjectés dans le journal CEREBRAU.



Le système ne crée pas un nouvel orchestrateur. Il étend l’orchestrateur CEREBRAU existant par une capacité transverse d’exécution IA.



\---



\## 3. Problème à résoudre



Aujourd’hui, l’utilisateur travaille entre deux surfaces :



\- ChatGPT pour analyser, concevoir et produire les prompts ;

\- PowerShell pour lancer Codex et exécuter les modifications dans les dépôts locaux.



Le lien entre ces deux surfaces est manuel.



L’utilisateur doit actuellement :



\- choisir le modèle ;

\- choisir le niveau de raisonnement ;

\- choisir le mode d’approbation ;

\- choisir le répertoire ;

\- copier le prompt ;

\- lancer Codex ;

\- vérifier que les règles du programme sont respectées ;

\- conserver lui-même la traçabilité de la mission.



Cette organisation présente plusieurs risques :



\- choix incohérent du modèle ;

\- niveau de raisonnement insuffisant ou excessif ;

\- perte de contexte entre ChatGPT et Codex ;

\- lancement depuis le mauvais dépôt ;

\- permissions trop larges ;

\- absence de preuve du prompt réellement exécuté ;

\- absence de corrélation entre programme, mission, lot et exécution ;

\- divergences entre règles CEREBRAU et comportement Codex ;

\- difficulté à reproduire une exécution ;

\- risque de modification hors périmètre.



\---



\## 4. Vision produit



L’utilisateur ne choisit plus manuellement le modèle ni le niveau de raisonnement.



Il indique uniquement le travail à réaliser :



```text

PROGRAM-006

LOT-004

Construire le workflow décisionnel QF

```



CEREBRAU produit alors une mission exécutable :



```text

Programme      : PROGRAM-006

Lot            : LOT-004

Profil         : CRITICAL

Agent          : CODEX

Modèle         : modèle autorisé par le registre

Raisonnement   : élevé

Sandbox        : workspace-write

Approbation    : on-request

Dépôt          : C:\\DEV\\veedda-cseV7-core

Prompt         : artefact versionné

Gates          : sécurité, tests, Git Guardian

```



L’utilisateur exécute ensuite une commande unique :



```powershell

.\\tools\\cerebrau\\Invoke-CerebrauMission.ps1

```



CEREBRAU reste responsable de la décision.

PowerShell reste responsable du lancement local.

Codex reste responsable de l’exécution technique.



\---



\## 5. Objectifs



\### 5.1 Objectifs fonctionnels



Le système doit :



\- recevoir une mission CEREBRAU structurée ;

\- classifier le travail ;

\- calculer un profil d’exécution ;

\- sélectionner un modèle parmi un registre autorisé ;

\- sélectionner le niveau de raisonnement ;

\- sélectionner la politique d’approbation ;

\- sélectionner le mode sandbox ;

\- sélectionner le répertoire de travail ;

\- produire un prompt final contrôlé ;

\- lancer Codex via PowerShell ;

\- journaliser l’exécution ;

\- corréler le résultat avec le programme, la mission et le lot ;

\- bloquer les exécutions non conformes ;

\- supporter le mode strict PS / Notepad ;

\- rester indépendant du projet exécuté.



\### 5.2 Objectifs non fonctionnels



Le système doit être :



\- déterministe ;

\- auditable ;

\- idempotent ;

\- sécurisé par défaut ;

\- compatible avec plusieurs dépôts ;

\- compatible avec plusieurs profils ;

\- extensible à plusieurs agents ;

\- exploitable sans interface graphique ;

\- tolérant aux changements de versions de Codex ;

\- indépendant des noms commerciaux de modèles.



\---



\## 6. Hors périmètre initial



La version 1 ne doit pas :



\- piloter directement l’interface web ChatGPT ;

\- récupérer automatiquement une réponse ChatGPT depuis le navigateur ;

\- contourner l’authentification Codex ;

\- stocker des secrets dans les fichiers de mission ;

\- exécuter plusieurs agents en parallèle ;

\- modifier automatiquement le registre de modèles ;

\- autoriser un modèle non déclaré ;

\- exécuter des commandes destructrices sans gate ;

\- gérer macOS ou Linux ;

\- remplacer les processus Git existants ;

\- remplacer Git Guardian ;

\- lancer automatiquement un commit ou un push.



\---



\## 7. Personas



\### 7.1 Program Director



Responsable de la cohérence entre :



\- programme ;

\- mission ;

\- lot ;

\- niveau de risque ;

\- règles de gouvernance ;

\- preuve de clôture.



\### 7.2 Technical Architect



Définit :



\- le type de mission ;

\- le profil d’exécution ;

\- les outils autorisés ;

\- les fichiers protégés ;

\- les gates techniques.



\### 7.3 Operator



Utilisateur qui lance la mission depuis PowerShell.



Il ne doit pas avoir à choisir le modèle ou le niveau de raisonnement.



\### 7.4 Codex Agent



Agent d’exécution.



Il reçoit :



\- un prompt final ;

\- un dépôt ;

\- une politique d’approbation ;

\- un mode sandbox ;

\- des contraintes explicites.



\---



\## 8. Parcours utilisateur canonique



\### 8.1 Création de la mission



L’utilisateur travaille avec ChatGPT ou directement avec CEREBRAU et définit :



\- le programme ;

\- le lot ;

\- l’objectif ;

\- les fichiers concernés ;

\- les contraintes ;

\- les critères GO / NO GO.



\### 8.2 Qualification



CEREBRAU calcule :



\- la classe de travail ;

\- le risque ;

\- la complexité ;

\- l’impact transverse ;

\- le niveau de sécurité ;

\- le besoin de migration ;

\- le besoin d’audit ;

\- le profil d’exécution.



\### 8.3 Production des artefacts runtime



CEREBRAU produit :



```text

.cerebrau/runtime/current/mission.json

.cerebrau/runtime/current/prompt.md

.cerebrau/runtime/current/execution.json

.cerebrau/runtime/current/policy.snapshot.json

```



\### 8.4 Validation locale



PowerShell valide :



\- présence des fichiers ;

\- conformité JSON ;

\- dépôt attendu ;

\- branche attendue ;

\- modèle autorisé ;

\- effort autorisé ;

\- sandbox autorisé ;

\- politique d’approbation autorisée ;

\- absence de secret ;

\- hash du prompt ;

\- expiration de la mission.



\### 8.5 Invocation



PowerShell lance Codex avec les paramètres validés.



\### 8.6 Collecte



À la fin de l’exécution :



\- code retour ;

\- horodatage ;

\- modèle effectif ;

\- effort effectif ;

\- dépôt ;

\- branche ;

\- commit avant ;

\- commit après ;

\- fichiers modifiés ;

\- transcript ;

\- statut final.



\### 8.7 Clôture



CEREBRAU classe le résultat :



\- SUCCESS ;

\- PARTIAL ;

\- BLOCKED ;

\- FAILED ;

\- CANCELLED.



\---



\## 9. Architecture cible



```text

ChatGPT / Program Director

&#x20;           |

&#x20;           v

CEREBRAU Mission Definition

&#x20;           |

&#x20;           v

AI Execution Director

&#x20; - Task Classifier

&#x20; - Risk Evaluator

&#x20; - Model Policy Engine

&#x20; - Reasoning Policy Engine

&#x20; - Sandbox Policy Engine

&#x20; - Approval Policy Engine

&#x20; - Prompt Compiler

&#x20; - Execution Manifest Builder

&#x20;           |

&#x20;           v

CEREBRAU Runtime Artifacts

&#x20;           |

&#x20;           v

PowerShell Execution Adapter

&#x20; - Schema validation

&#x20; - Repository validation

&#x20; - Policy validation

&#x20; - Codex capability detection

&#x20; - Command construction

&#x20; - Process execution

&#x20; - Result capture

&#x20;           |

&#x20;           v

Codex CLI

&#x20;           |

&#x20;           v

Execution Evidence

&#x20;           |

&#x20;           v

CEREBRAU Audit / Gate Registry

```



\---



\## 10. Composants fonctionnels



\### 10.1 Task Classifier



Responsabilité :



\- identifier la nature principale du travail ;

\- détecter les dimensions secondaires ;

\- produire une classification stable.



Classes initiales :



```text

DOCUMENTATION

GIT\_OPERATION

LOCAL\_UI\_FIX

FRONTEND\_BUILD

BACKEND\_BUILD

DATABASE\_CHANGE

MIGRATION

WORKFLOW\_ARCHITECTURE

SECURITY\_AUDIT

INCIDENT\_RESPONSE

RESEARCH

TESTING

REFACTORING

```



\### 10.2 Risk Evaluator



Niveaux :



```text

LOW

MEDIUM

HIGH

CRITICAL

```



Facteurs :



\- écriture disque ;

\- nombre de fichiers ;

\- base de données ;

\- migration ;

\- sécurité ;

\- authentification ;

\- données personnelles ;

\- impact production ;

\- impact transverse ;

\- irréversibilité ;

\- exécution réseau ;

\- Git ;

\- déploiement.



\### 10.3 Model Policy Engine



Le moteur ne doit pas dépendre d’un nom de modèle codé en dur.



Il utilise un registre :



```json

{

&#x20; "models": \[

&#x20;   {

&#x20;     "id": "MODEL\_HIGH\_CAPABILITY",

&#x20;     "providerModel": "resolved-at-runtime",

&#x20;     "capabilities": \[

&#x20;       "code",

&#x20;       "architecture",

&#x20;       "security",

&#x20;       "long-context"

&#x20;     ],

&#x20;     "allowedReasoningEfforts": \[

&#x20;       "low",

&#x20;       "medium",

&#x20;       "high"

&#x20;     ],

&#x20;     "enabled": true

&#x20;   }

&#x20; ]

}

```



Le nom réel du modèle est résolu par configuration locale.



\### 10.4 Reasoning Policy Engine



Niveaux logiques CEREBRAU :



```text

FAST

STANDARD

DEEP

CRITICAL

```



Mapping initial :



```text

FAST      -> low

STANDARD  -> medium

DEEP      -> high

CRITICAL  -> niveau maximal supporté localement

```



Le moteur doit refuser un niveau non supporté par la version de Codex détectée.



\### 10.5 Sandbox Policy Engine



Modes initiaux :



```text

read-only

workspace-write

```



Le mode dangereux ou sans restriction ne doit pas être disponible en V1.



\### 10.6 Approval Policy Engine



Politiques initiales :



```text

on-request

never

```



Règles :



\- `never` uniquement pour les tâches explicitement classées sûres ;

\- `on-request` par défaut ;

\- toute opération Git destructive exige une approbation ;

\- toute migration exige une approbation ;

\- toute commande hors dépôt exige une approbation.



\### 10.7 Prompt Compiler



Le prompt final doit être construit à partir de blocs :



```text

IDENTITY

PROGRAM\_CONTEXT

MISSION

SCOPE

AUTHORIZED\_FILES

PROTECTED\_FILES

MANDATORY\_GATES

EXECUTION\_RULES

EXPECTED\_OUTPUT

STOP\_CONDITIONS

```



Le prompt final doit contenir un hash et une version.



\### 10.8 Execution Manifest Builder



Produit le descripteur d’exécution signé ou hashé.



\---



\## 11. Profils d’exécution initiaux



\### 11.1 FAST



Usage :



\- lecture ;

\- traduction ;

\- Git status ;

\- correction CSS isolée ;

\- inspection locale.



Configuration :



```text

Reasoning : low

Sandbox   : read-only ou workspace-write selon mission

Approval  : on-request

```



\### 11.2 BUILD



Usage :



\- composant React ;

\- route simple ;

\- test local ;

\- correction backend ciblée.



Configuration :



```text

Reasoning : medium

Sandbox   : workspace-write

Approval  : on-request

```



\### 11.3 ARCHITECTURE



Usage :



\- workflow métier ;

\- API ;

\- base de données ;

\- événements ;

\- refonte modulaire.



Configuration :



```text

Reasoning : high

Sandbox   : workspace-write

Approval  : on-request

```



\### 11.4 CRITICAL



Usage :



\- migration ;

\- sécurité ;

\- authentification ;

\- incident ;

\- données sensibles ;

\- architecture transverse.



Configuration :



```text

Reasoning : niveau maximal supporté

Sandbox   : workspace-write

Approval  : on-request

Gates     : renforcés

```



\---



\## 12. Contrat de mission



Fichier :



```text

.cerebrau/runtime/current/mission.json

```



Schéma logique :



```json

{

&#x20; "schemaVersion": "1.0.0",

&#x20; "missionId": "uuid",

&#x20; "programId": "PROGRAM-006",

&#x20; "lotId": "LOT-004",

&#x20; "title": "QF Operational Decisions",

&#x20; "objective": "Construire le workflow décisionnel QF",

&#x20; "repository": {

&#x20;   "path": "C:\\\\DEV\\\\veedda-cseV7-core",

&#x20;   "expectedBranch": "fix/simulation-star"

&#x20; },

&#x20; "scope": {

&#x20;   "authorizedPaths": \[

&#x20;     "server/qf/\*\*",

&#x20;     "server/moteur-qf/\*\*",

&#x20;     "server/routes/\*\*"

&#x20;   ],

&#x20;   "protectedPaths": \[

&#x20;     "client/\*\*",

&#x20;     "Docs/19\_PROGRAMS/PROGRAM-016\_PLATFORM\_API\_PERSISTENCE\_IDENTITY/\*\*"

&#x20;   ]

&#x20; },

&#x20; "classification": {

&#x20;   "taskType": "WORKFLOW\_ARCHITECTURE",

&#x20;   "risk": "CRITICAL"

&#x20; },

&#x20; "constraints": \[

&#x20;   "ONE\_ACTION\_PER\_RESPONSE",

&#x20;   "NO\_HISTORICAL\_MIGRATION\_EDIT",

&#x20;   "AUDIT\_ACTIVE\_IMPLEMENTATION\_FIRST"

&#x20; ],

&#x20; "expiresAt": "2026-07-12T18:00:00+02:00"

}

```



\---



\## 13. Contrat d’exécution



Fichier :



```text

.cerebrau/runtime/current/execution.json

```



Schéma logique :



```json

{

&#x20; "schemaVersion": "1.0.0",

&#x20; "executionId": "uuid",

&#x20; "missionId": "uuid",

&#x20; "agent": "codex-cli",

&#x20; "profile": "CRITICAL",

&#x20; "modelPolicyId": "MODEL\_HIGH\_CAPABILITY",

&#x20; "resolvedModel": "local-config-value",

&#x20; "reasoningEffort": "high",

&#x20; "sandboxMode": "workspace-write",

&#x20; "approvalPolicy": "on-request",

&#x20; "workingDirectory": "C:\\\\DEV\\\\veedda-cseV7-core",

&#x20; "promptFile": ".cerebrau/runtime/current/prompt.md",

&#x20; "promptSha256": "sha256",

&#x20; "policySnapshotFile": ".cerebrau/runtime/current/policy.snapshot.json",

&#x20; "createdAt": "2026-07-11T10:30:00+02:00",

&#x20; "expiresAt": "2026-07-12T18:00:00+02:00"

}

```



\---



\## 14. Contrat de résultat



Fichier :



```text

.cerebrau/runtime/history/{executionId}/result.json

```



```json

{

&#x20; "schemaVersion": "1.0.0",

&#x20; "executionId": "uuid",

&#x20; "missionId": "uuid",

&#x20; "status": "SUCCESS",

&#x20; "startedAt": "2026-07-11T10:32:00+02:00",

&#x20; "finishedAt": "2026-07-11T10:46:00+02:00",

&#x20; "exitCode": 0,

&#x20; "repository": {

&#x20;   "path": "C:\\\\DEV\\\\veedda-cseV7-core",

&#x20;   "branchBefore": "fix/simulation-star",

&#x20;   "branchAfter": "fix/simulation-star",

&#x20;   "commitBefore": "63dc2dd",

&#x20;   "commitAfter": "63dc2dd"

&#x20; },

&#x20; "execution": {

&#x20;   "agent": "codex-cli",

&#x20;   "model": "resolved-model",

&#x20;   "reasoningEffort": "high",

&#x20;   "sandboxMode": "workspace-write",

&#x20;   "approvalPolicy": "on-request"

&#x20; },

&#x20; "artifacts": {

&#x20;   "transcriptFile": "transcript.txt",

&#x20;   "stdoutFile": "stdout.log",

&#x20;   "stderrFile": "stderr.log",

&#x20;   "changedFilesFile": "changed-files.txt"

&#x20; }

}

```



\---



\## 15. Arborescence proposée



```text

tools/

&#x20; cerebrau/

&#x20;   Invoke-CerebrauMission.ps1

&#x20;   Test-CerebrauMission.ps1

&#x20;   Get-CodexCapabilities.ps1

&#x20;   Resolve-CerebrauExecution.ps1

&#x20;   Write-CerebrauResult.ps1

&#x20;   schemas/

&#x20;     mission.schema.json

&#x20;     execution.schema.json

&#x20;     result.schema.json



.cerebrau/

&#x20; config/

&#x20;   ai-execution-policy.json

&#x20;   model-registry.local.json

&#x20;   repository-registry.json

&#x20; runtime/

&#x20;   current/

&#x20;     mission.json

&#x20;     execution.json

&#x20;     prompt.md

&#x20;     policy.snapshot.json

&#x20;   history/

&#x20;     {executionId}/

&#x20;       result.json

&#x20;       transcript.txt

&#x20;       stdout.log

&#x20;       stderr.log

&#x20;       changed-files.txt



Docs/

&#x20; 09\_CEREBRAU OPERATING SYSTEM/

&#x20;   02\_AI\_EXECUTION\_DIRECTOR/

&#x20;     PDS-001\_CEREBRAU\_AI\_EXECUTION\_DIRECTOR.md

&#x20;     FDS-001\_AI\_EXECUTION\_DIRECTOR.md

&#x20;     TDS-001\_AI\_EXECUTION\_DIRECTOR.md

&#x20;     SECURITY\_MODEL.md

&#x20;     TEST\_SPECIFICATION.md

```



\---



\## 16. PowerShell Execution Adapter



\### 16.1 Responsabilités



Le script principal doit :



1\. localiser la mission active ;

2\. valider le schéma ;

3\. vérifier l’expiration ;

4\. vérifier le dépôt ;

5\. vérifier la branche ;

6\. vérifier le modèle dans le registre ;

7\. détecter les capacités Codex locales ;

8\. vérifier le niveau de raisonnement ;

9\. vérifier le mode sandbox ;

10\. vérifier la politique d’approbation ;

11\. vérifier le hash du prompt ;

12\. créer le dossier de résultat ;

13\. lancer Codex ;

14\. capturer le code retour ;

15\. capturer Git avant et après ;

16\. écrire le résultat final.



\### 16.2 Commande utilisateur



```powershell

.\\tools\\cerebrau\\Invoke-CerebrauMission.ps1

```



\### 16.3 Mode audit sans exécution



```powershell

.\\tools\\cerebrau\\Invoke-CerebrauMission.ps1 -WhatIf

```



\### 16.4 Mission explicite



```powershell

.\\tools\\cerebrau\\Invoke-CerebrauMission.ps1 `

&#x20; -MissionPath ".\\.cerebrau\\runtime\\current\\mission.json"

```



\---



\## 17. Construction de la commande Codex



Le script ne doit jamais concaténer une commande shell non contrôlée.



Il doit construire un tableau d’arguments.



Pseudo-code PowerShell :



```powershell

$arguments = @(

&#x20;   "--model", $execution.resolvedModel,

&#x20;   "--config", "model\_reasoning\_effort=`"$($execution.reasoningEffort)`"",

&#x20;   "--sandbox", $execution.sandboxMode

)



$prompt = Get-Content $execution.promptFile -Raw



\& codex @arguments $prompt

```



Les options exactes doivent être détectées et validées contre la version de Codex installée.



Le système doit échouer en mode fermé si une option demandée n’est pas supportée.



\---



\## 18. Détection des capacités Codex



Le composant `Get-CodexCapabilities.ps1` doit collecter :



\- version Codex ;

\- présence de la commande ;

\- options disponibles ;

\- modèles disponibles lorsque détectables ;

\- niveaux de raisonnement disponibles ;

\- modes sandbox disponibles ;

\- politiques d’approbation disponibles.



Résultat :



```json

{

&#x20; "codexVersion": "detected",

&#x20; "supportsModelFlag": true,

&#x20; "supportsReasoningConfig": true,

&#x20; "supportsSandboxFlag": true,

&#x20; "supportedReasoningEfforts": \[

&#x20;   "low",

&#x20;   "medium",

&#x20;   "high"

&#x20; ]

}

```



Aucune mission ne doit être lancée si son profil n’est pas compatible avec les capacités détectées.



\---



\## 19. Sécurité



\### 19.1 Secrets



Les fichiers de mission ne doivent jamais contenir :



\- clé API ;

\- service-role ;

\- token Supabase ;

\- mot de passe ;

\- cookie ;

\- secret GitHub.



\### 19.2 Répertoires



Le chemin du dépôt doit être présent dans un registre local autorisé.



Exemple :



```json

{

&#x20; "repositories": \[

&#x20;   {

&#x20;     "id": "veedda-cse-v7",

&#x20;     "path": "C:\\\\DEV\\\\veedda-cseV7-core",

&#x20;     "enabled": true

&#x20;   }

&#x20; ]

}

```



\### 19.3 Branches



Une mission peut déclarer une branche attendue.



En cas de divergence :



```text

MISSION\_BRANCH\_MISMATCH

```



\### 19.4 Fichiers protégés



Le prompt doit inclure les chemins protégés.



Le résultat doit comparer les fichiers modifiés aux chemins autorisés.



Toute modification hors périmètre doit produire :



```text

OUT\_OF\_SCOPE\_CHANGE\_DETECTED

```



\### 19.5 Git Guardian



Avant toute opération Git de commit ou de push dans les projets gouvernés :



```powershell

.\\tools\\git-guardian\\cerebrau-commit.ps1

```



Le système ne doit jamais contourner ce gate.



\---



\## 20. Observabilité et audit



Chaque exécution doit disposer d’un identifiant unique.



Les événements minimaux sont :



```text

CEREBRAU\_MISSION\_LOADED

CEREBRAU\_MISSION\_VALIDATED

CEREBRAU\_EXECUTION\_RESOLVED

CODEX\_CAPABILITIES\_DETECTED

CODEX\_EXECUTION\_STARTED

CODEX\_EXECUTION\_COMPLETED

CODEX\_EXECUTION\_FAILED

OUT\_OF\_SCOPE\_CHANGE\_DETECTED

CEREBRAU\_EXECUTION\_RESULT\_WRITTEN

```



Chaque événement doit inclure :



\- `executionId` ;

\- `missionId` ;

\- `programId` ;

\- `lotId` ;

\- horodatage ;

\- statut ;

\- correlationId.



\---



\## 21. Gestion des erreurs



Codes initiaux :



```text

MISSION\_FILE\_NOT\_FOUND

MISSION\_SCHEMA\_INVALID

MISSION\_EXPIRED

REPOSITORY\_NOT\_ALLOWED

REPOSITORY\_NOT\_FOUND

MISSION\_BRANCH\_MISMATCH

PROMPT\_FILE\_NOT\_FOUND

PROMPT\_HASH\_MISMATCH

MODEL\_NOT\_ALLOWED

MODEL\_NOT\_AVAILABLE

REASONING\_LEVEL\_UNSUPPORTED

SANDBOX\_MODE\_UNSUPPORTED

APPROVAL\_POLICY\_UNSUPPORTED

CODEX\_NOT\_INSTALLED

CODEX\_EXECUTION\_FAILED

OUT\_OF\_SCOPE\_CHANGE\_DETECTED

RESULT\_WRITE\_FAILED

```



Le système doit échouer en mode fermé.



\---



\## 22. Idempotence



Une même mission peut être rejouée avec un nouvel `executionId`.



Une exécution déjà clôturée ne doit jamais être réécrite.



Le dossier :



```text

.cerebrau/runtime/history/{executionId}

```



est immuable après clôture.



\---



\## 23. Compatibilité avec le mode PS / Notepad



Le système doit supporter les règles utilisateur suivantes :



\- une action par réponse ;

\- fichier exact ;

\- repère exact avant ;

\- repère exact après ;

\- ligne exacte à remplacer ;

\- ligne exacte de remplacement ;

\- éléments à ne pas toucher ;

\- aucune supposition ;

\- audit de l’implémentation active avant modification.



Ces règles doivent être injectées dans le prompt par le `Prompt Compiler` lorsque le profil de projet les active.



\---



\## 24. Critères GO



Le lot est GO si :



\- une mission valide est chargée ;

\- le profil est calculé de manière déterministe ;

\- le modèle est résolu depuis un registre ;

\- le niveau de raisonnement est supporté ;

\- le dépôt est validé ;

\- la branche est validée ;

\- le prompt est hashé ;

\- Codex est lancé avec les paramètres attendus ;

\- le résultat est journalisé ;

\- les fichiers modifiés sont comparés au périmètre ;

\- aucun secret n’est stocké ;

\- Git Guardian reste obligatoire avant commit ou push.



\---



\## 25. Critères NO GO



Le lot est NO GO si :



\- le choix du modèle repose uniquement sur le texte libre du prompt ;

\- le modèle est codé en dur dans le script ;

\- la mission peut viser n’importe quel répertoire ;

\- les secrets sont présents dans les artefacts ;

\- la branche n’est pas contrôlée ;

\- le prompt exécuté n’est pas conservé ;

\- le résultat n’est pas corrélé ;

\- les modifications hors périmètre ne sont pas détectées ;

\- Codex est lancé avec des options non validées ;

\- l’échec de validation n’empêche pas l’exécution.



\---



\## 26. Stratégie de test



\### 26.1 Tests unitaires



\- classification ;

\- résolution de profil ;

\- résolution de modèle ;

\- mapping du raisonnement ;

\- validation du registre ;

\- validation du dépôt ;

\- validation de branche ;

\- validation du hash ;

\- détection d’expiration.



\### 26.2 Tests PowerShell



\- Codex absent ;

\- modèle absent ;

\- option non supportée ;

\- mauvais dépôt ;

\- mauvaise branche ;

\- prompt modifié ;

\- mission expirée ;

\- exécution réussie ;

\- exécution échouée ;

\- fichiers hors périmètre.



\### 26.3 Tests d’intégration



Scénarios :



1\. Correction CSS locale.

2\. Composant React.

3\. Audit backend.

4\. Migration SQL simulée.

5\. Workflow QF.

6\. Refus d’un dépôt non autorisé.

7\. Refus d’une branche incorrecte.

8\. Refus d’un modèle non enregistré.



\### 26.4 Tests de non-régression



\- workflow Git Guardian ;

\- règles PS / Notepad ;

\- conservation des fichiers runtime ;

\- compatibilité avec les dépôts VEEDDA et NOVA.



\---



\## 27. Roadmap d’implémentation



\### LOT-AIEX-001 — Documentation et architecture



Livrables :



\- PDS ;

\- FDS ;

\- TDS ;

\- modèle de sécurité ;

\- spécification des tests.



\### LOT-AIEX-002 — Schémas et registres



Livrables :



\- schéma mission ;

\- schéma exécution ;

\- schéma résultat ;

\- registre modèles ;

\- registre dépôts ;

\- matrice de profils.



\### LOT-AIEX-003 — Validateur PowerShell



Livrables :



\- validation mission ;

\- validation dépôt ;

\- validation branche ;

\- validation prompt ;

\- validation politique.



\### LOT-AIEX-004 — Détection Codex



Livrables :



\- version ;

\- capacités ;

\- compatibilité options ;

\- gestion des erreurs.



\### LOT-AIEX-005 — Lanceur Codex



Livrables :



\- construction sécurisée de la commande ;

\- lancement ;

\- capture stdout/stderr ;

\- code retour.



\### LOT-AIEX-006 — Audit et résultats



Livrables :



\- Git avant/après ;

\- fichiers modifiés ;

\- transcript ;

\- résultat JSON ;

\- historique immuable.



\### LOT-AIEX-007 — Intégration CEREBRAU



Livrables :



\- branchement Program Director ;

\- branchement Mission Director ;

\- gate registry ;

\- journal d’événements.



\### LOT-AIEX-008 — Certification



Livrables :



\- tests ;

\- revue sécurité ;

\- test réel VEEDDA ;

\- test réel NOVA ;

\- décision GO / NO GO.



\---



\## 28. Ordre de développement obligatoire



```text

PDS

&#x20; ↓

FDS

&#x20; ↓

TDS

&#x20; ↓

SECURITY MODEL

&#x20; ↓

TEST SPECIFICATION

&#x20; ↓

SCHEMAS

&#x20; ↓

REGISTRIES

&#x20; ↓

VALIDATOR

&#x20; ↓

CAPABILITY DETECTOR

&#x20; ↓

CODEX LAUNCHER

&#x20; ↓

AUDIT

&#x20; ↓

CEREBRAU INTEGRATION

&#x20; ↓

CERTIFICATION

```



Aucun lanceur Codex ne doit être développé avant validation :



\- des schémas ;

\- du modèle de sécurité ;

\- de la matrice de profils ;

\- du registre de dépôts.



\---



\## 29. Décisions d’architecture gelées



1\. CEREBRAU reste l’unique orchestrateur.

2\. Le choix du modèle appartient à CEREBRAU.

3\. PowerShell ne décide pas du profil.

4\. PowerShell valide et exécute.

5\. Codex ne choisit pas son propre profil.

6\. Les noms réels de modèles sont externalisés.

7\. Les missions sont versionnées.

8\. Les prompts exécutés sont conservés.

9\. Les exécutions sont corrélées.

10\. Les résultats sont auditables.

11\. Le système échoue en mode fermé.

12\. Les opérations Git restent soumises à Git Guardian.

13\. Les secrets sont interdits dans les artefacts.

14\. Les modifications hors périmètre sont détectées.

15\. La première plateforme supportée est Windows PowerShell.



\---



\## 30. Première implémentation recommandée



Le premier incrément doit rester minimal.



Il doit uniquement :



1\. lire un `mission.json` ;

2\. lire une politique locale ;

3\. résoudre un profil ;

4\. valider un dépôt ;

5\. valider une branche ;

6\. vérifier Codex ;

7\. afficher la commande qui serait exécutée ;

8\. ne rien exécuter réellement.



Commande cible :



```powershell

.\\tools\\cerebrau\\Invoke-CerebrauMission.ps1 -WhatIf

```



Le passage à l’exécution réelle ne doit être autorisé qu’après certification de ce mode simulation.



\---



\## 31. Définition de terminé



La capacité est terminée lorsque l’utilisateur peut :



1\. produire une mission CEREBRAU ;

2\. déposer cette mission dans le runtime local ;

3\. exécuter une seule commande PowerShell ;

4\. laisser CEREBRAU choisir le profil ;

5\. laisser PowerShell valider l’environnement ;

6\. lancer Codex avec la configuration décidée ;

7\. récupérer un résultat auditable ;

8\. constater qu’aucune modification hors périmètre n’a été réalisée.



\---



\## 32. Point de départ opérationnel



\### Fichier cible canonique



```text

Docs/09\_CEREBRAU OPERATING SYSTEM/02\_AI\_EXECUTION\_DIRECTOR/PDS-001\_CEREBRAU\_AI\_EXECUTION\_DIRECTOR.md

```



\### Première action de développement



Créer uniquement le dossier documentaire et y déposer cette PDS.



\### Ce qu’il ne faut pas encore créer



\- aucun script PowerShell ;

\- aucun fichier runtime ;

\- aucun registre de modèle ;

\- aucun lanceur Codex ;

\- aucune modification des composants CEREBRAU existants.



La PDS doit d’abord être revue, corrigée et gelée.

