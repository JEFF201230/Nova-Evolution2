# PROGRAM WAVE ORCHESTRATION

Version : 1.0

Statut : Reference

---

# 1. Objet

Le present document definit la gouvernance officielle d'orchestration des Programmes CEREBRAU.

Il s'applique a tous les Programmes presentes et futurs, notamment VEEDDA, NOVA, LIFEHUB, GDBCSE et tout programme ajoute ultérieurement.

Il formalise le vocabulaire, les responsabilites, les etats, les dependances, les verrous et les regles de certification applicables a l'echelle Programme, Wave, Squad Opening Order, Squad et Mission Order.

Il ne remplace pas les documents specifiques a un programme.

Il encadre leur execution.

---

# 2. Definitions officielles

## 2.1 Program

Un Program est une unite strategique complete de delivery.

Il regroupe une ou plusieurs Waves, un objectif de resultat, des criteres de certification et une autorite de gouvernance unique.

Un Program possede :

- un identifiant unique ;
- un nom ;
- un objectif ;
- une portee ;
- un Director responsable ;
- un cycle de vie ;
- un etat de certification final.

## 2.2 Wave

Une Wave est une tranche d'execution d'un Program.

Elle regroupe un ensemble de Squads et de Mission Orders compatibles entre eux.

Une Wave existe pour:

- structurer l'execution ;
- coordonner les dependances ;
- limiter les collisions ;
- organiser les synchronisations ;
- preparer la certification par lot.

## 2.3 Squad

Une Squad est une unite d'execution specialisee.

Une Squad porte un perimetre technique, documentaire ou produit clairement delimite.

Une Squad :

- execute des Mission Orders ;
- respecte les locks de ressources ;
- respecte la matrice d'ownership ;
- respecte le graphe de dependances ;
- publie des livrables traces ;
- ne depasse pas son perimetre.

## 2.4 Mission Order

Une Mission Order est l'unite minimale de travail gouvernee.

Elle definit :

- un objectif unique ;
- un perimetre unique ;
- des fichiers ou ressources autorises ;
- des interdictions ;
- des livrables ;
- des criteres de sortie ;
- un statut d'execution.

Une Mission Order ne doit pas contenir plusieurs objectifs sans autorisation explicite.

## 2.5 Entry Gate

Un Entry Gate est un point de controle obligatoire avant ouverture d'une entite de travail.

Il valide que les prerequis sont reunis avant le demarrage d'un Program, d'une Wave, d'une Squad Opening Order, d'une Squad ou d'une Mission Order.

## 2.6 Exit Gate

Un Exit Gate est un point de controle obligatoire avant fermeture d'une entite de travail.

Il valide que les livrables, preuves et dependances sont conformes avant le passage a l'etape suivante.

## 2.7 Synchronization Gate

Un Synchronization Gate est un point de controle collectif de convergence.

Il sert a:

- synchroniser plusieurs Squads ;
- verifier les divergences ;
- integrer les livrables ;
- garantir la cohérence inter-squads ;
- preparer une Merge Window ou une certification.

## 2.8 Wave Lifecycle

Une Wave suit les etats suivants :

- `PLANNED` ;
- `OPEN` ;
- `IN_PROGRESS` ;
- `SYNC` ;
- `MERGE_WINDOW` ;
- `CERTIFICATION` ;
- `CLOSED`.

## 2.9 Squad Lifecycle

Une Squad suit les etats suivants :

- `PLANNED` ;
- `WAITING_DEPENDENCY` ;
- `READY` ;
- `RUNNING` ;
- `BLOCKED` ;
- `SYNC_REQUIRED` ;
- `MERGE_LOCKED` ;
- `DONE`.

## 2.10 Mission Lifecycle

Une Mission Order suit les etats suivants :

- `PLANNED` ;
- `READY` ;
- `RUNNING` ;
- `BLOCKED` ;
- `WAITING_DEPENDENCY` ;
- `REVIEW` ;
- `DONE` ;
- `REWORK`.

---

# 3. Program Director Authority

Le Program Director detient l'autorite finale sur le Program.

Il decide :

- de l'ouverture d'un Program ;
- de l'ouverture d'une Wave ;
- de la fermeture d'une Wave ;
- de l'ouverture de la Wave suivante ;
- de l'activation d'une Merge Window ;
- de la declaration d'un Program Freeze ;
- de la reprise apres Freeze ;
- de la certification finale ;
- du passage a `COMPLETE` ou `REWORK`.

Le Program Director ne doit pas recalculeer le metier applicatif.

Le Program Director arbitre la gouvernance, non la logique produit.

---

# 4. Conditions d'ouverture d'un Program

Un Program peut s'ouvrir si tous les elements suivants sont presentes :

- objectif programme explicite ;
- portee documentee ;
- Director identifie ;
- Wave initiale definie ;
- dependencies externes connues ;
- criteres de certification definis ;
- proprietes de ressources definies ;
- risques majeurs identifies ;
- voie d'escalade documentee.

Si un de ces elements manque, le Program reste `PLANNED`.

---

# 5. Conditions d'ouverture d'une Wave

Une Wave peut s'ouvrir si :

- le Program est ouvert ;
- les dependances critiques de la Wave precedente sont soldees ou isolees ;
- les Entry Gates sont passes ;
- les Squads concernees sont disponibles ;
- les locks de ressources sont definis ;
- les zones d'ownership sont connues ;
- le plan de synchronisation est disponible.

Si une dependance critique reste ouverte, la Wave ne peut pas passer a `OPEN`.

---

# Wave Activation Rule

Une Wave ne peut etre declaree `RUNNING` que si toutes les conditions suivantes sont satisfaites :

- toutes les Squads prevues pour la Wave possedent une Mission Order emise ;
- chaque Squad possede un statut valide :
  - `READY`
  - `RUNNING`
  - `WAITING_DEPENDENCY`
- tous les Resource Locks initiaux sont attribues ;
- les dependances declarees sont coherentes ;
- aucune Squad prevue n'est dans l'etat `PLANNED`.

Si une seule Squad prevue pour la Wave ne possede pas de Mission Order officielle, la Wave conserve le statut :

`STATUS = OPEN`

Le passage a :

`STATUS = RUNNING`

est interdit.

---

# 6. Conditions de fermeture d'une Wave

Une Wave peut etre fermee si :

- les Mission Orders de la Wave sont terminees ou explicitement reworkees ;
- les Exit Gates sont valides ;
- les Synchronization Gates sont valides ;
- aucune ressource critique n'est encore lockee ;
- aucune regression bloquante n'est detectee ;
- les livrables attendus sont traces ;
- les dependances de sortie sont preparees.

Une Wave ne peut pas etre fermee si une Squad reste `BLOCKED` sur une ressource critique.

---

# Mandatory Wave Closure Process

Une Wave ne peut pas etre declaree `COMPLETE` tant que :

- toutes les Squads sont `COMPLETE` ;
- toutes les Mission Orders sont cloturees ;
- tous les `Execution Reports` existent ;
- tous les `Verification Reports` existent ;
- tous les `Certification Reports` existent ;
- tous les `Result Reports` existent ;
- tous les `Resource Locks` sont liberes ;
- tous les `Synchronization Gates` sont `GO`.

Le Program Director est le seul habilite a declarer :

`WAVE COMPLETE`

La Wave suivante ne peut jamais etre ouverte tant que :

`Mandatory Wave Closure Process != COMPLETE`

En cas d'echec :

`STATUS = REWORK`

Retour des Missions concernees.

Nouvelle Certification.

Nouvelle Synchronization Gate.

---

# 7. Conditions d'ouverture de la Wave suivante

La Wave suivante ne peut s'ouvrir que si :

- la Wave precedente est fermee ;
- les risques bloquants ont ete leves ou scopes ;
- les dependances inter-squads sont resolues ;
- les locks critiques sont liberes ;
- les merges autorises ont ete effectues ;
- les rapports de certification intermediaires sont disponibles ;
- le Program Director a donne son accord.

Une Wave suivante ne peut pas contourner une Wave precedente en `REWORK`.

---

# Squad Opening Order

Le Squad Opening Order est la couche officielle qui ouvre une Squad avant tout travail operationnel.

Une Squad ne peut jamais passer directement de `READY` a `RUNNING`.

Le cycle officiel devient :

- `PLANNED` ;
- `READY` ;
- `SQUAD OPENING ORDER` ;
- `RUNNING` ;
- `WAITING REVIEW` ;
- `CERTIFICATION` ;
- `COMPLETE`.

Le Squad Opening Order est obligatoire pour toute Squad CEREBRAU, presente ou future.

Il doit contenir au minimum :

- Squad ID ;
- Squad Name ;
- Program ID ;
- Wave ID ;
- Scope ;
- Responsibilities ;
- Authorized Files ;
- Forbidden Files ;
- Resource Locks ;
- Dependencies ;
- Entry Gate ;
- Opening Decision ;
- Program Director Approval.

Regles officielles :

- une Squad ne peut recevoir aucune Mission Order tant que son Squad Opening Order n'a pas ete officiellement emis ;
- une Squad ne peut prendre aucun Resource Lock avant son ouverture officielle ;
- une Squad sans Squad Opening Order conserve le statut `READY`.

Schema d'orchestration mis a jour :

```text
Program
  ↓
Wave
  ↓
Squad Opening Order
  ↓
Mission Orders
  ↓
Reports
  ↓
Certification
  ↓
Complete
```

Le Squad Opening Order est une regle generique applicable a tous les Programmes CEREBRAU.

---

# 8. Mission Order Governance

## 8.1 Entry Gate d'une Mission Order

Avant le demarrage d'une Mission Order :

- le perimetre doit etre explicite ;
- les fichiers autorises doivent etre identifies ;
- la Squad responsable doit etre connue ;
- les dependances doivent etre visibles ;
- les locks eventuels doivent etre prepares ;
- le statut cible doit etre possible.

## 8.2 Exit Gate d'une Mission Order

Avant la fermeture d'une Mission Order :

- le livrable attendu doit exister ;
- les fichiers modifies doivent rester dans le perimetre ;
- les conflits doivent etre resolus ;
- le resultat doit etre verifier ;
- les preuves doivent etre disponibles.

## 8.3 Mission Lifecycle

Le statut `WAITING_DEPENDENCY` bloque automatiquement le demarrage d'une Mission Order tant que la dependance requise n'est pas en etat compatible.

Le statut `BLOCKED` bloque automatiquement la progression tant qu'une ressource, une validation ou une dependance demeure indisponible.

Le statut `REWORK` indique que la Mission Order ne peut pas passer a `DONE` sans correction.

---

# 9. Inter-Squad Dependencies

Les Squads ne sont pas autonomes de facon absolue.

Une Squad peut depender d'une autre Squad.

Exemple :

- Billetterie depend de Document Core ;
- Communication depend de Workflow ;
- Notifications depend de Communication ;
- LifeHub depend de ses sources officielles de donnees.

Regle :

- si la Squad amont est `REWORK`, la Squad dependante passe automatiquement a `WAITING_DEPENDENCY` ;
- si la Squad amont n'est pas disponible, la Squad dependante ne peut pas demarrer ;
- si la dependance est critique, le Program Director peut geler la Wave.

---

# 10. Resource Lock

Un Resource Lock protege une ressource sensible pendant l'execution d'une Mission Order.

Le lock suit le cycle suivant :

- `LOCK` ;
- execution ;
- `RELEASE`.

Regle :

- deux Squads ne doivent jamais modifier simultanement une ressource lockee ;
- si une ressource lockee est sollicitee par une autre Squad, cette Squad passe a `BLOCKED` ;
- la liberation du lock est obligatoire a la fin de la Mission Order ou de la session autorisee.

Exemple de ressource critique :

- `client/src/lifehub/hooks/useLifeHubDashboardData.ts`

---

# 11. Ownership Matrix

Chaque dossier ou zone de code possède un owner principal.

Regle :

- la Squad owner est la seule Squad en mode `WRITE` par defaut ;
- les autres Squads sont `READ ONLY` ;
- une ecriture croisee n'est possible que sur autorisation explicite du Program Director ;
- l'ownership couvre les sous-dossiers et les fichiers relies.

Exemples :

- `client/src/lifehub/` -> Squad LifeHub ;
- `client/src/gdbcse/` -> Squad GDBCSE ;
- `server/document-core/` -> Squad Document Core ;
- `client/src/bridge-qf/` -> Squad Bridge QF.

---

# 12. Merge Window

Le Program Director peut ouvrir une Merge Window.

Pendant la Merge Window :

- les Squads autorisees peuvent fusionner leurs livrables ;
- les collisions doivent etre resolues immediatement ;
- les conflits doivent rester traces ;
- les commits hors fenetre restent interdits pour les Squads soumises a cette regle.

Regle standard :

- duree de Merge Window : 2 heures ;
- etat pendant ouverture : `MERGE_WINDOW` ;
- etat apres fermeture : `MERGE_CLOSED`.

En dehors de cette fenetre, les merges sensibles sont suspendus.

---

# 13. Dependency Graph

Chaque Program doit disposer d'un graphe de dependances officiel.

Le graphe indique :

- les blocs amont ;
- les blocs intermediaires ;
- les blocs aval ;
- les dependances bloquantes ;
- les dependances non bloquantes ;
- les chemins d'escalade.

Regle :

- un bloc amont en `REWORK` empeche un bloc aval critique de demarrer ;
- un bloc amont en `BLOCKED` transmet son blocage aux blocs dependants ;
- le graphe fait autorite sur les ordres implicites de lancement.

Exemple de chaine :

- Document Core ;
- Workflow ;
- LifeHub ;
- Communication ;
- Notifications.

Si `Workflow` est en `REWORK`, `Communication` ne peut pas etre lance.

---

# 14. Health Score

Chaque Squad possede un Health Score officiel.

Il est compose au minimum de :

- Architecture ;
- Documentation ;
- Tests ;
- Dette technique.

Le Health Score est exprime en pourcentage ou en niveau equivalente.

Usage :

- identifier les Squads en difficulte ;
- prioriser les arbitrages ;
- declencher une revue obligatoire si la degradation persiste ;
- alimenter le tableau de commandement du Program Director.

---

# 15. Escalation automatique

Si une Squad accumule plus de 3 Missions en `REWORK`, une escalade automatique est declenchee.

Effet :

- revue obligatoire du Program Director ;
- examen des dependances ;
- verification des locks ;
- arbitrage sur la suite du cycle.

---

# 16. Freeze Program

Le Program Director peut declarer un `PROGRAM FREEZE`.

Pendant le Freeze :

- aucune Squad ne peut merger ;
- aucune Squad ne peut modifier une ressource critique ;
- aucune Mission Order ne peut demarrer ;
- aucune Wave ne peut s'ouvrir ;
- la certification est suspendue.

La reprise ne peut intervenir qu'apres `FREEZE LIFTED`.

---

# 17. Release Candidate

Avant `PROGRAM COMPLETE`, le Program peut passer par des etats de Release Candidate :

- `RC1` ;
- `RC2` ;
- `RC3` si necessaire.

Chaque RC doit :

- etre auditée ;
- etre comparee au referentiel ;
- etre corrigee si besoin ;
- etre recommencee si le Gate echoue.

Une RC ne vaut pas certification finale.

---

# 18. Tableau de Commandement

Le Program Director doit disposer d'un tableau de commandement officiel affichant au minimum :

- le Program ;
- la Wave active ;
- le nombre de Squads ;
- les Squads running ;
- les Squads blocked ;
- les Squads waiting dependency ;
- l'etat de certification ;
- le Health global ;
- les statuts Architecture ;
- Documentation ;
- Runtime ;
- les freezes actifs ;
- les merge windows ouvertes.

Exemple de lecture :

- `PROGRAM`
- `LifeHub`
- `Wave 2`
- `91 %`
- `Squads : 10`
- `Running : 4`
- `Blocked : 1`
- `Waiting Dependency : 2`
- `Certification : 3`
- `Health : 97 %`
- `Architecture : GO`
- `Documentation : GO`
- `Runtime : GO`

Le tableau de commandement est un instrument de gouvernance, pas un moteur de calcul applicatif.

---

# 19. Certification finale du Program

Un Program ne peut etre declare `COMPLETE` que si :

- toutes les Waves prevues sont terminees ;
- tous les Entry Gates et Exit Gates obligatoires sont passes ;
- tous les Synchronization Gates requis sont passes ;
- les dependances critiques sont soldees ;
- les locks sont liberes ;
- les conflicts sont resolus ;
- les Release Candidates ont ete auditees ;
- le Health Score global est acceptable ;
- la documentation est coherente avec l'implementation ;
- le Program Director a emet un verdict explicite.

Si un de ces criteres echoue, le Program reste `REWORK`.

---

# 20. Regles de priorite

En cas de conflit, l'ordre de priorite est le suivant :

1. Security and governance constraints ;
2. Program Director Authority ;
3. Dependency Graph ;
4. Resource Lock ;
5. Ownership Matrix ;
6. Wave lifecycle ;
7. Squad lifecycle ;
8. Mission lifecycle.

Une regle inferieure ne peut pas annuler une regle superieure.

---

# 21. Applicabilite

Cette gouvernance s'applique a :

- tous les programmes CEREBRAU existants ;
- toutes les futures Waves ;
- toutes les Squads ;
- toutes les Mission Orders ;
- tous les documents de certification ;
- tous les tableaux de commandement ;
- tous les futurs programmes de la plateforme.

Toute gouvernance specifique a un programme doit rester compatible avec le present document.

---

# 22. Live Wave Register

Le present registre consigne un etat operationnel officiel lorsque le Program Director publie une decision de Wave.

## LIFEHUB-PROGRAM-V2 / WAVE-01

Status Wave : `RUNNING`

Squads :

| Squad | Status | Mission | Resource Lock |
|---|---|---|---|
| SQUAD-01 - LIFEHUB-KPI | `RUNNING` provisoire | Supprimer les derniers calculs herites et raccorder les KPI a la source officielle | `client/src/lifehub/hooks/useLifeHubDashboardData.ts` |
| SQUAD-02 - LIFEHUB-ACTIONS | `WAITING_DEPENDENCY` | Reconnecter les Actions prioritaires au Workflow et au Document Core | En attente de `SQUAD-01` |
| SQUAD-03 - LIFEHUB-MESSAGING | `READY` | Finaliser l'alimentation de la messagerie par les evenements metier | Widgets messagerie |
| SQUAD-04 - LIFEHUB-DOCUMENTS | `READY` | Finaliser le raccordement Document Core -> LifeHub | Integration Document Core |

Verification note :

- `Execution Report`, `Verification Report`, `Certification Report` et `Result Report` sont maintenant presentes pour `SQUAD-01` ;
- la verification repository-level reste bloquee par des erreurs TypeScript preexistantes hors perimetre SQUAD-01 ;
- le verrou sur `client/src/lifehub/hooks/useLifeHubDashboardData.ts` reste actif tant que la verification globale n'est pas revenue a un etat certifiable ;
- `SQUAD-02` reste en `WAITING_DEPENDENCY` jusqu'a la liberation officielle du verrou de `SQUAD-01`.
