# Flux d'upload documentaire

MISSION_ID : DOCUMENT-UPLOAD-DOC-001

PROGRAMME : DOCUMENT UPLOAD

MODE : DESIGN

---

## 1. Flux nominal

1. La UI identifie un besoin d'upload dans un contexte DMS ou dossier metier.
2. La UI construit un `DocumentUploadContext`.
3. La UI appelle `DocumentUploadService.upload(context)`.
4. `DocumentUploadService` delegue a `DocumentCoreUploadAdapter.createDocument(context)`.
5. L'adapter prepare une requete compatible `POST /documents`.
6. `POST /documents` valide la requete.
7. Document Core transforme la requete en commande d'upload documentaire.
8. Document Core cree le Document et sa Version initiale selon ses invariants.
9. L'API retourne un DTO documentaire.
10. L'adapter traduit le DTO en `DocumentUploadResult`.
11. Le service retourne le resultat a la UI.
12. Le DMS ou le Business Dossier exploite le resultat pour mettre a jour vue, statut, completude ou workflow.

---

## 2. Flux de validation

La validation est repartie :

| Niveau | Validation |
|---|---|
| UI | Champs requis pour guider l'utilisateur avant appel. |
| DocumentUploadService | Coherence du contexte d'upload avant delegation. |
| DocumentCoreUploadAdapter | Mapping vers le contrat `CreateDocumentRequest`. |
| `POST /documents` | Validation HTTP du corps de requete. |
| Document Core | Validation des invariants, type, owner, subjects et politique d'upload. |
| DMS | Interpretation fonctionnelle du resultat dans le dossier metier. |

---

## 3. Flux d'erreur

| Situation | Comportement attendu |
|---|---|
| Contexte incomplet cote UI | Ne pas appeler l'API ; demander correction utilisateur. |
| Requete invalide `POST /documents` | Retour problem details `400`. |
| Upload rejete par Document Core | Retour problem details `422`. |
| Erreur transport | Resultat upload `failed` cote service. |
| Resultat non exploitable par DMS | Le DMS conserve la trace d'echec ou demande correction selon son workflow. |

---

## 4. Etats fonctionnels

Le contrat frontend reconnait les etats :

- `idle` ;
- `selected` ;
- `uploading` ;
- `uploaded` ;
- `rejected` ;
- `failed`.

Ces etats servent l'experience d'upload. Ils ne remplacent pas les statuts Document Core ni les statuts DMS.

---

## 5. Retour vers DMS

Le DMS consomme le resultat pour :

- rattacher le Document au Business Dossier ;
- mettre a jour la completude ;
- afficher le statut ;
- ouvrir une validation ;
- alimenter l'historique ;
- declencher une notification ;
- rendre l'action auditable.

