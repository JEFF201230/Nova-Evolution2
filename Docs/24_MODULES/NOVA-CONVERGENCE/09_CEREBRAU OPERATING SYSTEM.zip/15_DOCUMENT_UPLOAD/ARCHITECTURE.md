# Architecture du module Document Upload

MISSION_ID : DOCUMENT-UPLOAD-DOC-001

PROGRAMME : DOCUMENT UPLOAD

MODE : DESIGN

---

## 1. Vue d'ensemble

Le module Document Upload est une couche d'integration entre l'interface utilisateur, les usages DMS et l'API Document Core.

Il se positionne entre :

- les ecrans ou parcours qui collectent l'intention d'upload ;
- le service applicatif frontend `DocumentUploadService` ;
- l'adapter `DocumentCoreUploadAdapter` ;
- l'endpoint `POST /documents` ;
- Document Core ;
- le DMS qui exploite le resultat dans un dossier metier.

---

## 2. Chaine cible

```text
UI
  -> DocumentUploadService
    -> DocumentCoreUploadAdapter
      -> POST /documents
        -> Document Core
          -> DMS
```

---

## 3. Responsabilites par couche

| Couche | Responsabilite |
|---|---|
| UI | Collecter l'intention utilisateur, le contexte metier, les pieces attendues et afficher le resultat. |
| DocumentUploadService | Porter le cas d'usage frontend d'upload documentaire et orchestrer l'appel adapter. |
| DocumentCoreUploadAdapter | Traduire le contexte d'upload en requete `POST /documents` et traduire la reponse en resultat upload. |
| `POST /documents` | Point d'entree HTTP existant pour creer un document via Document Core. |
| Document Core | Garantir l'identite documentaire, les invariants, la Version initiale, la validation et le DTO retour. |
| DMS | Exploiter le document cree dans un dossier, un workflow, une vue, une recherche ou une gouvernance documentaire. |

---

## 4. Dependances autorisees

| Depuis | Vers | Regle |
|---|---|---|
| UI | DocumentUploadService | Autorise. La UI ne parle pas directement a Document Core. |
| DocumentUploadService | DocumentCoreUploadAdapter | Autorise. Le service depend d'une abstraction d'adapter. |
| DocumentCoreUploadAdapter | `POST /documents` | Autorise. C'est la seule API HTTP Document Core ciblee. |
| Document Core | DMS | Interdit comme dependance directe. Document Core ne connait pas le DMS. |
| DMS | Document Upload | Autorise comme usage d'integration ou d'orchestration. |

La fleche `Document Core -> DMS` dans la chaine fonctionnelle signifie retour d'information exploitable par le DMS, pas dependance interne de Document Core vers DMS.

---

## 5. Non-objectifs

Le module ne definit pas :

- upload binaire reel ;
- stockage direct ;
- pre-signed URL ;
- bus d'evenements ;
- nouvelle route HTTP ;
- schema de base ;
- implementation de service ;
- composant UI.

