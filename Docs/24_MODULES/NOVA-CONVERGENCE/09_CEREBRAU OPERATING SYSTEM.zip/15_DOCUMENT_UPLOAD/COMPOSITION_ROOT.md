# Composition Root du Document Upload

MISSION_ID : DOCUMENT-UPLOAD-DOC-001

PROGRAMME : DOCUMENT UPLOAD

MODE : DESIGN

---

## 1. Objet

Ce document decrit le point de composition attendu pour assembler le module Document Upload.

Il s'agit d'une description de responsabilites, pas d'une implementation.

---

## 2. Role du Composition Root

Le Composition Root connecte :

- la UI ;
- `DocumentUploadService` ;
- `DocumentCoreUploadAdapter` ;
- la configuration HTTP cible ;
- les conventions DMS de mapping ;
- le contexte de dossier metier.

Il doit assembler les dependances sans deplacer les responsabilites metier.

---

## 3. Composition conceptuelle

```text
DocumentUploadCompositionRoot
  -> configure DocumentCoreUploadAdapter
      endpoint: POST /documents
      mapping: DocumentUploadContext -> CreateDocumentRequest
  -> configure DocumentUploadService
      adapter: DocumentCoreUploadAdapter
  -> expose DocumentUploadService to UI / DMS screens
```

---

## 4. Responsabilites de configuration

Le Composition Root peut fournir :

- base URL de l'API existante ;
- strategie d'authentification deja disponible dans l'application ;
- mapping de confidentialite DMS vers Document Core ;
- mapping de requirement vers type documentaire ;
- gestion de correlation ;
- conventions d'erreur ;
- instrumentation d'audit applicative si deja disponible.

---

## 5. Responsabilites interdites

Le Composition Root ne doit pas :

- valider les invariants Document Core ;
- decider un statut DMS ;
- creer une nouvelle API ;
- contenir une logique de workflow ;
- acceder directement au stockage ;
- modifier un Business Dossier ;
- masquer une erreur Document Core sans traduction explicite.

---

## 6. Relation avec DMS

Le DMS consomme le `DocumentUploadService` comme capacite d'entree documentaire.

Le DMS reste responsable de :

- declarer le contexte ;
- fournir les subjects ;
- indiquer l'exigence documentaire ;
- appliquer les politiques fonctionnelles ;
- exploiter le resultat dans le dossier metier.

Le service d'upload ne devient pas le DMS.

