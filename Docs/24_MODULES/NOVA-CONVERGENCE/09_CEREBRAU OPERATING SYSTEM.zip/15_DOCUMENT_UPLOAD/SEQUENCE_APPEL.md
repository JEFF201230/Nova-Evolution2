# Sequence d'appel

MISSION_ID : DOCUMENT-UPLOAD-DOC-001

PROGRAMME : DOCUMENT UPLOAD

MODE : DESIGN

---

## 1. Sequence nominale

```text
UI
  -> DocumentUploadService.upload(context)
DocumentUploadService
  -> DocumentCoreUploadAdapter.createDocument(context)
DocumentCoreUploadAdapter
  -> POST /documents(CreateDocumentRequest)
POST /documents
  -> Document Core UploadDocumentApplicationService
Document Core
  -> DocumentResponse
DocumentCoreUploadAdapter
  -> DocumentUploadResult
DocumentUploadService
  -> UI
UI / DMS
  -> mise a jour de la vue, du dossier ou du workflow
```

---

## 2. Sequence detaillee

1. L'utilisateur initie un upload depuis une vue DMS ou Business Dossier.
2. La UI collecte le contexte fonctionnel.
3. La UI appelle `DocumentUploadService.upload`.
4. Le service place l'upload en etat `uploading`.
5. Le service appelle `DocumentCoreUploadAdapter.createDocument`.
6. L'adapter mappe le contexte en `CreateDocumentRequest`.
7. L'adapter appelle `POST /documents`.
8. L'API valide les champs requis.
9. Document Core cree le Document et la Version initiale selon ses invariants.
10. L'API retourne un `DocumentResponse`.
11. L'adapter produit un `DocumentUploadResult` en etat `uploaded`.
12. Le service retourne le resultat.
13. La UI affiche le resultat.
14. Le DMS rattache le Document au contexte metier ou met a jour la completude.

---

## 3. Sequence d'erreur

```text
UI
  -> DocumentUploadService.upload(context)
DocumentUploadService
  -> DocumentCoreUploadAdapter.createDocument(context)
DocumentCoreUploadAdapter
  -> POST /documents
POST /documents
  -> 400 ProblemDetails ou 422 ProblemDetails
DocumentCoreUploadAdapter
  -> DocumentUploadResult(status: rejected | failed)
DocumentUploadService
  -> UI
UI / DMS
  -> afficher correction attendue ou conserver trace d'echec
```

---

## 4. Points de controle

| Etape | Controle |
|---|---|
| UI | Contexte utilisateur et champs visibles. |
| Service | Etat d'upload et coherence de l'intention. |
| Adapter | Mapping contractuel vers `POST /documents`. |
| API | Validation du corps de requete. |
| Document Core | Invariants documentaires et creation de Version. |
| DMS | Interpretation du resultat dans le dossier metier. |

---

## 5. Garantie d'architecture

La sequence doit conserver les frontieres :

- la UI ne cree pas directement de Document Core command ;
- l'adapter ne porte pas la logique metier DMS ;
- `POST /documents` reste l'unique API cible ;
- Document Core ne connait pas le DMS ;
- le DMS consomme le resultat sans modifier les invariants Document Core.

