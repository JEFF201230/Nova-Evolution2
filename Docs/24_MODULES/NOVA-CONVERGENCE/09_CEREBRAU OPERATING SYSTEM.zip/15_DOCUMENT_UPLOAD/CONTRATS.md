# Contrats du module Document Upload

MISSION_ID : DOCUMENT-UPLOAD-DOC-001

PROGRAMME : DOCUMENT UPLOAD

MODE : DESIGN

---

## 1. Objet

Ce document decrit les contrats existants ou attendus par la documentation du module Document Upload.

Il ne cree aucun nouveau contrat executable.

---

## 2. Contrat frontend d'intention

Le contrat frontend d'upload est porte par `DocumentUploadContext`.

Il contient conceptuellement :

- module source ;
- processus metier ;
- action metier ;
- owner fonctionnel ;
- role fonctionnel ;
- subjects metier ;
- exigence documentaire eventuelle ;
- confidentialite ;
- correlation.

Ce contrat exprime l'intention DMS ou Business Dossier avant traduction vers Document Core.

---

## 3. Contrat de service

`DocumentUploadService` expose conceptuellement :

```text
upload(DocumentUploadContext) -> DocumentUploadResult
```

Responsabilites :

- recevoir le contexte d'upload ;
- appliquer les controles frontend transverses ;
- deleguer la creation documentaire a l'adapter ;
- retourner un resultat stable a la UI.

Il ne doit pas connaitre les details internes de Document Core.

---

## 4. Contrat adapter

`DocumentCoreUploadAdapter` expose conceptuellement :

```text
createDocument(DocumentUploadContext) -> DocumentUploadResult
```

Responsabilites :

- mapper le contexte d'upload vers `CreateDocumentRequest` ;
- appeler `POST /documents` ;
- transformer la reponse `DocumentResponse` ou `ProblemDetails` en `DocumentUploadResult` ;
- conserver la frontiere entre UI/DMS et API Document Core.

---

## 5. Contrat API existant

L'API cible est exclusivement :

```text
POST /documents
```

Le corps conceptuel correspond a `CreateDocumentRequest` :

- `id` optionnel ;
- `type` ;
- `tenantId` ;
- `functionalOwnerId` ;
- `functionalOwnerRole` ;
- `metadata` ;
- `subjects` ;
- `family` optionnel ;
- `category` optionnel ;
- `confidentialityLevel` optionnel ;
- `retentionPolicy` optionnel ;
- `tags` optionnel ;
- `labels` optionnel.

La reponse de succes correspond a `DocumentResponse`.

Les erreurs documentees sont :

- `400` pour requete invalide ;
- `422` pour upload rejete par Document Core.

---

## 6. Mapping conceptuel

| DocumentUploadContext | CreateDocumentRequest |
|---|---|
| `sourceModule` | `metadata.businessLabel` ou label fonctionnel selon convention DMS |
| `businessProcess` | `metadata.period`, `metadata.businessLabel` ou tag selon convention DMS |
| `businessAction` | `metadata.businessLabel`, tag ou label selon convention DMS |
| `functionalOwnerId` | `functionalOwnerId` |
| `functionalOwnerRole` | `functionalOwnerRole` |
| `subjects` | `subjects` |
| `requirement.documentType` | `type` |
| `requirement.label` | `metadata.title` |
| `confidentiality` | `confidentialityLevel` apres mapping DMS vers Document Core |
| `correlationId` | `metadata.correlationId` |

Le mapping final appartient a l'adapter et doit rester explicite.

---

## 7. Interdiction

Le contrat d'upload ne doit pas introduire :

- route alternative ;
- champ obligatoire non present dans l'API cible ;
- dependance directe UI vers Document Core ;
- decision metier DMS dans Document Core ;
- stockage binaire direct.

