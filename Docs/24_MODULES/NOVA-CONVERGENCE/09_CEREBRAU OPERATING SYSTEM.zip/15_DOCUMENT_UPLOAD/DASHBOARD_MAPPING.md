# Mapping DashboardSalarie -> DocumentUploadContext

MISSION_ID : DOCUMENT-UPLOAD-MAPPING-001

PROGRAMME : DOCUMENT UPLOAD

MODE : DESIGN

STATUT : DRAFT_VALIDABLE

---

## 1. Objet

Ce document definit le mapping officiel entre les donnees du `DashboardSalarie` et le contrat `DocumentUploadContext`.

Il ne contient aucun code et ne definit aucune implementation.

---

## 2. Source

Source fonctionnelle : `client/src/pages/DashboardSalarie.tsx`

Contrat cible : `client/src/document-upload/DocumentUploadContract.ts`

Contrat cible :

```text
DocumentUploadContext
  sourceModule
  businessProcess
  businessAction
  functionalOwnerId
  functionalOwnerRole
  subjects
  requirement
  confidentiality
  correlationId
```

---

## 3. Mapping principal

| Champ DashboardSalarie | Champ DocumentUploadContext | Regle de mapping |
| --- | --- | --- |
| `DashboardSalarie` | `sourceModule` | Valeur constante : `DASHBOARD_SALARIE` |
| Onglet `nouvelle` / route `/dashboard-salarie/nouvelle-demande` | `businessProcess` | Valeur constante : `SUBVENTION_REQUEST` |
| Action de creation d'une demande | `businessAction` | Valeur constante : `CREATE_SUBVENTION_REQUEST` |
| `user.id` | `functionalOwnerId` | Identifiant fonctionnel du salarie demandeur |
| Role utilisateur salarie | `functionalOwnerRole` | Valeur fonctionnelle : `SALARIE` |
| Demande de subvention en cours | `subjects[]` | Cree le sujet metier principal du contexte d'upload |
| `form.category` | `requirement.documentType` | Type documentaire attendu selon la categorie de subvention |
| `categoryLabels[form.category]` | `requirement.label` | Libelle lisible de l'exigence documentaire |
| Categorie de subvention selectionnee | `requirement.requirementId` | Identifiant fonctionnel recommande : `SUBVENTION_<category>_JUSTIFICATIF` |
| Contraintes de justificatif par categorie | `requirement.mandatory` | `true` si la piece est obligatoire pour la categorie ou le parcours |
| Contraintes de format attendues | `requirement.acceptedMimeTypes` | Liste fonctionnelle des types MIME acceptes |
| Contraintes d'extension attendues | `requirement.acceptedExtensions` | Liste fonctionnelle des extensions acceptees |
| Taille maximale autorisee | `requirement.maxFileSizeBytes` | Taille maximale documentaire autorisee par le parcours |
| Periode de la demande si disponible | `requirement.expectedPeriod` | Periode attendue du justificatif |
| Date limite de depot si disponible | `requirement.dueDate` | Date limite fonctionnelle de depot |
| Nature subvention / justificatif | `confidentiality` | Mapping vers `confidential` par defaut ; `restricted` si document sensible |
| Identifiant de demande ou draft si disponible | `correlationId` | Correlation entre upload, demande et panier |

---

## 4. Mapping des subjects

### 4.1 Sujet principal

| Champ DashboardSalarie | Champ `DocumentUploadSubject` | Regle de mapping |
| --- | --- | --- |
| Domaine de la demande | `businessDomain` | Valeur constante : `SUBVENTION` |
| Objet metier cree ou en cours | `businessObjectType` | `DEMANDE_SUBVENTION` |
| `subvention.id` apres creation | `businessObjectId` | Identifiant de la demande creee |
| `draftRequest.id` avant creation | `businessObjectId` | Identifiant temporaire de draft si la demande n'est pas encore creee |
| `form.description` ou `draft.description` | `label` | Libelle fonctionnel du sujet |

### 4.2 Sujet beneficiaire

| Champ DashboardSalarie | Champ `DocumentUploadSubject` | Regle de mapping |
| --- | --- | --- |
| `user.id` | `businessObjectId` | Identifiant du salarie beneficiaire |
| Domaine beneficiaire | `businessDomain` | Valeur constante : `RH` |
| Type beneficiaire | `businessObjectType` | `SALARIE` |
| Nom salarie si disponible | `label` | Libelle utilisateur optionnel |

---

## 5. Mapping par champs du formulaire

| Champ DashboardSalarie | Usage dans DocumentUploadContext |
| --- | --- |
| `form.category` | Determine `requirement.documentType`, `requirement.requirementId`, `requirement.label` et parfois `confidentiality` |
| `form.montant` | Ne mappe pas directement vers `DocumentUploadContext` ; peut contribuer au `correlationId` ou a une metadata future via adapter |
| `form.description` | Alimente le `label` du sujet principal et la comprehension fonctionnelle du contexte |
| `uploadedFileURLs[]` | Ne mappe pas directement vers `DocumentUploadContext` ; represente les fichiers deja uploades dans le flux legacy |
| `requestCart[]` | Sert a produire un contexte par `DraftRequest` |
| `draftRequest.id` | Alimente `correlationId` et `subjects[].businessObjectId` avant creation effective |
| `draftRequest.category` | Meme mapping que `form.category` |
| `draftRequest.description` | Meme mapping que `form.description` |
| `draftRequest.uploadedFileURLs[]` | Ne mappe pas directement ; rattachement legacy hors `DocumentUploadContext` |

---

## 6. Mapping des categories vers requirement

| `form.category` | `requirement.documentType` | `requirement.label` | Confidentialite |
| --- | --- | --- | --- |
| `vacances` | `DOCUMENT_JUSTIFICATIF` | `Justificatif vacances` | `confidential` |
| `sport` | `DOCUMENT_JUSTIFICATIF` | `Justificatif sport et loisirs` | `confidential` |
| `culture` | `DOCUMENT_JUSTIFICATIF` | `Justificatif culture et spectacles` | `confidential` |
| `enfants` | `DOCUMENT_JUSTIFICATIF` | `Justificatif garde d'enfants` | `restricted` |
| `bien_etre` | `DOCUMENT_JUSTIFICATIF` | `Justificatif bien-etre` | `confidential` |
| `autre` | `DOCUMENT_JUSTIFICATIF` | `Justificatif autre avantage` | `confidential` |

---

## 7. Mapping des actions Dashboard

| Action DashboardSalarie | `businessAction` | Commentaire |
| --- | --- | --- |
| Soumission directe du formulaire | `CREATE_SUBVENTION_REQUEST` | Creation immediate d'une demande |
| Ajout au panier | `PREPARE_SUBVENTION_REQUEST` | Contexte rattache a un draft |
| Envoi du panier | `SUBMIT_SUBVENTION_REQUEST_BATCH` | Un contexte par demande du panier |
| Ajout de piece jointe | `ATTACH_SUBVENTION_DOCUMENT` | Action documentaire principale |
| Remplacement de piece jointe | `REPLACE_SUBVENTION_DOCUMENT` | Si une piece existante est remplacee |

---

## 8. Exemple conceptuel

```text
DashboardSalarie
  user.id = salarie_001
  form.category = enfants
  form.description = Frais de creche janvier
  draftRequest.id = draft_001

DocumentUploadContext
  sourceModule = DASHBOARD_SALARIE
  businessProcess = SUBVENTION_REQUEST
  businessAction = ATTACH_SUBVENTION_DOCUMENT
  functionalOwnerId = salarie_001
  functionalOwnerRole = SALARIE
  subjects[0].businessDomain = SUBVENTION
  subjects[0].businessObjectType = DEMANDE_SUBVENTION
  subjects[0].businessObjectId = draft_001
  subjects[0].label = Frais de creche janvier
  subjects[1].businessDomain = RH
  subjects[1].businessObjectType = SALARIE
  subjects[1].businessObjectId = salarie_001
  requirement.documentType = DOCUMENT_JUSTIFICATIF
  requirement.label = Justificatif garde d'enfants
  requirement.mandatory = true
  confidentiality = restricted
  correlationId = draft_001
```

---

## 9. Regles de mapping

- `DocumentUploadContext` exprime l'intention documentaire, pas le contenu binaire.
- Le mapping doit produire un contexte par document a rattacher.
- Les fichiers deja uploades par le flux legacy ne doivent pas etre confondus avec le contexte DMS.
- Les documents lies aux enfants ou a la situation familiale doivent etre `restricted`.
- `functionalOwnerId` doit rester l'identifiant du salarie demandeur pour un upload depuis `DashboardSalarie`.
- La demande de subvention doit toujours apparaitre comme sujet principal.
- Le salarie doit apparaitre comme sujet beneficiaire lorsque l'identite est disponible.

---

## 10. Non-mapping explicite

| Champ DashboardSalarie | Raison |
| --- | --- |
| `filterStatus` | Filtre UI de consultation, pas une intention d'upload |
| `filterCategory` | Filtre UI de consultation, pas le contexte de la demande courante |
| `searchQuery` | Recherche UI, pas une intention documentaire |
| `selectedPeriod` | Filtre UI sauf si explicitement repris comme periode attendue |
| `visibleDemandesCount` | Etat UI uniquement |
| KPIs et statistiques | Donnees de consultation, pas contexte d'upload |

---

## 11. Critere de validation

Le mapping est validable lorsque :

- chaque champ de `DocumentUploadContext` a une source DashboardSalarie identifiee ;
- les champs Dashboard sans mapping sont explicitement exclus ;
- le mapping reste documentaire et ne decrit aucune implementation ;
- aucune route, service ou composant n'est introduit.

