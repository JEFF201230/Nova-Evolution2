# Document Upload

MISSION_ID : DOCUMENT-UPLOAD-DOC-001

PROGRAMME : DOCUMENT UPLOAD

MODE : DESIGN

STATUT : DOCUMENTATION_TECHNIQUE

---

## 1. Objet

Cette documentation decrit le module d'upload documentaire VEEDDA.

Elle formalise le chemin technique et fonctionnel suivant :

```text
UI
  -> DocumentUploadService
    -> DocumentCoreUploadAdapter
      -> POST /documents
        -> Document Core
          -> DMS
```

Cette documentation ne cree aucune API supplementaire, aucun composant d'implementation et aucun nouveau contrat executable.

---

## 2. Documents

- [Architecture](./ARCHITECTURE.md)
- [Flux](./FLUX.md)
- [Contrats](./CONTRATS.md)
- [Composition Root](./COMPOSITION_ROOT.md)
- [Sequence d'appel](./SEQUENCE_APPEL.md)

---

## 3. Frontieres

Le module Document Upload sert a relier une intention d'upload issue de l'interface ou d'un dossier metier avec le noyau Document Core.

Il ne remplace pas :

- le DMS ;
- Document Core ;
- les Business Dossiers ;
- les politiques de validation ;
- le stockage binaire ;
- les workflows metier.

Il ne doit pas introduire de route autre que l'utilisation de `POST /documents`.

---

## 4. Responsabilite principale

Document Upload transforme une intention d'upload contextualisee en demande compatible avec `POST /documents`, puis restitue le resultat documentaire au contexte DMS consommateur.

