# Cerebrau Mission Context Assembly — protocole de benchmark apparié

## 1. Statut

`READY — NOT EXECUTED`

Ce document prépare le benchmark sans en tirer de conclusion. Le lancement est interdit si une condition d'arrêt de la section 6 est vraie.

## 2. Question expérimentale

Comparer, à environnement et entrées identiques, le runtime Campaign historique et le même runtime avec `Cerebrau Mission Context Assembly`. La seule variable autorisée est :

```text
ContextAssemblyEnabled = false / true
```

Condition A :

```text
Campaign Runner -> runtime Mission historique -> Codex
```

Condition B :

```text
Campaign Runner -> Context Assembly Brick -> runtime Mission compatible -> Codex
```

## 3. Objet et séquence

- Campaign : `tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json` ;
- Mission : celle sélectionnée par ce Manifest ;
- minimum : trois paires contrebalancées ;
- ordre : `AB`, `BA`, `AB`, soit `A B | B A | A B` ;
- chaque run repart de l'instantané restaurable `S0` ;
- le benchmark réel utilise le même exécutable Codex, pas le fake Codex des tests.

## 4. Instantané S0 obligatoire

`S0` doit être capturé une fois, après succès de toutes les suites, avant le premier run. Il comprend :

- chemin et SHA-256 du Campaign Manifest ;
- chemin et SHA-256 de la Mission Order et du prompt ;
- SHA-256 de `profiles.json`, `certified-facts.json`, du runtime Mission, du Runner et du module de contexte ;
- branche et HEAD ;
- sortie exacte, ordonnée, de `git status --porcelain=v1` ;
- hashes de l'autorité, des baselines et de chaque shared evidence ;
- Campaign evidence index attendu après preflight ;
- version Codex ;
- profil résolu : modèle, reasoning effort, sandbox et approval policy ;
- absence de state Campaign et de rapports unitaires qui rendraient `Start` non reproductible ;
- contenu et hashes des éventuels livrables préexistants.

Le worktree peut être dirty seulement si cet état est intentionnel, capturé dans `S0`, restaurable et strictement identique avant les six runs. Un worktree simplement « similaire » invalide la paire.

## 5. Préflight

Exécuter une fois avant de figer `S0` :

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauSyntax.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauMission.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauReporting.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauExceptionCapture.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauRuntimeE2E.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauCampaign.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauContextAssembly.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauContextRuntime.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauCampaign.ps1 -CampaignFile tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json -Action Validate
codex --version
git branch --show-current
git rev-parse HEAD
git status --porcelain=v1
```

La restauration de `S0` est une opération de laboratoire autorisée et vérifiée, pas une nouvelle étape du flux opérateur normal. Le protocole ne prescrit aucune commande destructive générique : le mécanisme de restauration doit être préparé et validé sur une copie ou un worktree jetable avant le benchmark.

## 6. Conditions d'arrêt

Ne pas lancer, ou invalider immédiatement la paire, si :

- une suite existante ou nouvelle échoue ;
- le prompt historique sans switch n'est plus exact ;
- A produit un artefact ou une propriété `ContextAssembly` ;
- A et B ne partent pas du même `S0` ;
- branche, HEAD, worktree, Codex, modèle, effort, sandbox, approval policy, profil, Mission, prompt, Manifest ou preuves diffèrent ;
- le state Campaign empêche un `Start` neuf ;
- l'état Git n'est pas restaurable ;
- les sorties fonctionnelles divergent ;
- le verdict, les livrables attendus ou les validations requises divergent ;
- une autre variable que le switch change.

## 7. Commandes A et B

Depuis un `S0` restauré et vérifié :

```powershell
# A — ContextAssemblyEnabled = false, valeur par défaut
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauCampaign.ps1 -CampaignFile tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json -Action Start
```

Restaurer et revérifier `S0`, puis :

```powershell
# B — seule différence autorisée
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauCampaign.ps1 -CampaignFile tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json -Action Start -ContextAssemblyEnabled
```

Ordre des six exécutions :

| Paire | Run 1 | restauration S0 | Run 2 |
|---:|---|---|---|
| 1 | A | obligatoire | B |
| 2 | B | obligatoire | A |
| 3 | A | obligatoire | B |

Une restauration et une vérification `S0` sont également obligatoires avant le premier run de chaque paire.

## 8. Matrice de constance

| Variable | A | B | Contrôle |
|---|---|---|---|
| Mission Order | identique | identique | chemin + SHA-256 |
| Prompt source | identique | identique | chemin + SHA-256 |
| Campaign Manifest | identique | identique | chemin + SHA-256 |
| Repository / branche / HEAD | identique | identique | Git |
| Worktree | identique | identique | porcelain exact + snapshot de fichiers |
| Codex et version | identique | identique | `codex --version` |
| Modèle / reasoning effort | identique | identique | profil résolu |
| Sandbox / approval policy | identique | identique | profil résolu |
| Preuves et authority | identiques | identiques | hashes déclarés et courants |
| Runtime / Runner | identiques | identiques | SHA-256 |
| Context Assembly | absent | actif | unique variable |

La présence du module sur disque est identique dans A et B ; seul son appel est conditionnel.

## 9. Collecte

Pour chaque run, conserver sous un répertoire de benchmark externe aux entrées restaurées :

- commande exacte et position dans la séquence ;
- empreinte complète `S0` avant run ;
- Campaign report, metrics et evidence index ;
- Official Report, journal, snapshots et mission delta ;
- en B, `mission-context-assembly.json` et `context-assembly-metrics.json` ;
- code retour du Runner ;
- heure de début et de fin de l'observation externe.

Mesures autoritatives :

| Mesure | Source A | Source B |
|---|---|---|
| `ContextAssemblyEnabled` | constante `false` déduite de la commande et absence d'artefact | métriques de contexte |
| `ContextAssemblyDurationMs` | `0` / non exécuté | métriques de contexte |
| Sources, bytes, duplications, rejets | non applicable | artefact et métriques de contexte |
| durée commune de l'étape Codex | différence entre `CODEX_EXECUTION_STARTED` et `CODEX_EXECUTION_FINISHED` dans le journal | même source ; contrôle supplémentaire par `ContextAssembly.Metrics.CodexDurationMs` |
| fenêtre historique `OfficialReport.Codex.DurationMs` | Official Report | Official Report ; comparable à définition inchangée mais inclut le snapshot avant Codex |
| `TotalDurationMs` | mesure externe commune | métriques B + mesure externe commune |
| Tokens | `UNAVAILABLE` si Codex ne les expose pas autoritativement | même règle |
| Verdict | Official Report | Official Report / métriques |
| Livrables | Mission delta + expected files | mêmes sources |
| Diagnostics | Official Report | Official Report / métriques |
| Git delta | Mission delta | Mission delta / métriques |
| Régressions | validations + comparaison fonctionnelle | validations + métriques + comparaison fonctionnelle |

Ne pas remplacer `UNAVAILABLE` par une estimation.

## 10. Équivalence fonctionnelle

Une paire est comparable uniquement si A et B ont :

- même `OfficialStatus` et même ExitCode ;
- mêmes livrables attendus présents/absents ;
- mêmes hashes de livrables lorsque le contenu doit être déterministe, ou même validation sémantique documentée lorsque des timestamps sont attendus ;
- mêmes validations requises ;
- aucun changement de branche ou HEAD ;
- aucun delta hors scope ;
- aucune régression supplémentaire.

Les timestamps, run IDs, chemins de répertoires temporaires et durées sont exclus de l'identité fonctionnelle. `functionalPayloadSha256` doit rester identique entre les trois runs B si les entrées `S0` sont identiques.

## 11. Analyse après les six runs

Pour la durée commune de l'étape Codex, la fenêtre historique de l'Official Report et la durée externe totale :

- publier chaque différence appariée `A - B` ;
- publier moyenne, médiane, minimum et maximum par condition ;
- publier le gain relatif `(moyenne A - moyenne B) / moyenne A * 100` ;
- présenter les résultats dans l'ordre chronologique et par paire ;
- ne pas conclure à un effet causal si l'équivalence fonctionnelle échoue ou si l'effet ne dépasse pas la variabilité observée.

Les métriques de sélection B servent à expliquer le coût de la brique ; elles n'ont pas d'équivalent A et ne doivent pas être interprétées comme un gain.

## 12. État de préparation

- Switch binaire : `READY` ;
- chemin A historique : `TESTED` ;
- chemin B direct : `TESTED` ;
- chemin B Campaign : `TESTED` ;
- ordre AB/BA/AB : `DEFINED` ;
- contrôles d'arrêt : `DEFINED` ;
- méthode de restauration S0 : `DEFINED — DISPOSABLE RESTORABLE WORKSPACE` ;
- capture réelle S0 : `NOT EXECUTED — FIRST BENCHMARK OPERATION` ;
- tokens autoritatifs : `UNAVAILABLE` ;
- benchmark réel : `NOT EXECUTED` ;
- conclusion de performance : `NOT AVAILABLE`.
