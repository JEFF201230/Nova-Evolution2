# PROGRAM GOVERNANCE CERTIFICATION DOCTRINE

## Statut du document

| Champ | Valeur |
|---|---|
| Programme | `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001` |
| Nature | Référentiel normatif de certification |
| Portée | Toutes les Gates et tous les LOTS du PROGRAM |
| Décisions normalisées | `GO`, `GO_WITH_DEROGATION`, `NO_GO` |
| Mode d'application | Gouvernance, lecture seule, sans développement |

### Base probatoire de la doctrine

La doctrine consolide les enseignements de gouvernance déjà établis, notamment le cas `LOT-003` : une perte historique peut être prouvée alors que le contenu perdu reste inconnu ; une compatibilité courante peut être démontrée sans prouver l'histoire ; une dérogation peut circonscrire ce déficit sans fabriquer de preuve.

Les dispositions ci-dessous sont des règles normatives. Elles ne requalifient aucun fait technique et ne remplacent pas les preuves propres à chaque Gate.

---

## 1. Objet

Le présent document est le référentiel unique de décision pour l'ouverture des Gates du `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001`.

Il définit :

- un vocabulaire commun ;
- une typologie fermée des dérogations ;
- les exigences probatoires ;
- les règles déterministes de décision ;
- la propagation `Gate → LOT → PROGRAM` ;
- les autorités de décision et de révision ;
- une méthode de mutualisation des preuves existantes.

Une décision certifie uniquement les affirmations comprises dans son périmètre. Elle ne certifie ni un élément hors périmètre, ni un historique absent, ni une compatibilité comme preuve d'exécution.

Toute Gate doit produire une décision explicite. L'absence de décision n'équivaut jamais à `GO`.

---

## 2. Principes directeurs

### P1 — Primauté de la preuve

Toute conclusion doit être reliée à une preuve identifiée, accessible et datée. Une préférence, une intuition, une habitude ou une déclaration non traçable n'est pas une preuve.

### P2 — Séparation des statuts probatoires

Chaque affirmation est classée :

- `PROUVÉ` : directement établie par une preuve recevable ;
- `COMPATIBLE MAIS NON PROUVÉ` : cohérente avec les preuves sans être démontrée ;
- `INCONNU` : non déterminable avec les preuves disponibles.

Une affirmation ne change de classe que sur production d'une nouvelle preuve recevable ou correction formelle d'une erreur de qualification.

### P3 — Non-substitution

La preuve d'un état courant ne remplace pas la preuve de son histoire. La preuve d'une suppression ne remplace pas la preuve du contenu supprimé. La compatibilité ne remplace pas la preuve d'exécution.

### P4 — Périmètre borné

Toute décision identifie au minimum : PROGRAM, LOT, Gate, objets concernés, exigences évaluées, preuves utilisées, inconnues, risques, autorité, date et condition de révision.

### P5 — Décision par le risque le plus contraignant

Les décisions ne sont ni moyennées ni compensées par le nombre de résultats favorables. Une condition de `NO_GO` applicable à une exigence obligatoire prévaut sur les autres résultats.

### P6 — Conservation des inconnues

Une dérogation accepte un déficit probatoire défini ; elle ne le supprime pas. Les éléments `INCONNU` restent `INCONNU` dans le registre de certification.

### P7 — Absence de contradiction

Deux décisions portant sur la même affirmation et le même périmètre ne peuvent coexister avec des statuts incompatibles. La décision la plus récente ne remplace l'ancienne qu'au moyen d'une révision formelle et traçable.

### P8 — Mutualisation sans extrapolation

Une preuve peut être réutilisée par plusieurs Gates si son objet, sa période, son environnement et sa portée couvrent chacune d'elles. Sa réutilisation ne peut étendre sa portée initiale.

### P9 — Réversibilité de la certification

Une décision est révisable lorsque sa preuve, son périmètre, son risque ou sa dépendance change. Une décision antérieure reste dans l'historique et n'est jamais effacée.

### P10 — Doctrine fermée

Toute anomalie doit être classée dans une famille officielle de la section 4. Une anomalie non classifiable entraîne `NO_GO` administratif jusqu'à décision du comité sur son classement ; elle ne peut recevoir une dérogation locale ad hoc.

---

## 3. Niveaux de certification

### 3.1 `GO`

`GO` signifie que toutes les exigences obligatoires du périmètre sont `PROUVÉ`, qu'aucune preuve incompatible n'est ouverte, qu'aucune inconnue n'affecte une exigence obligatoire et qu'aucune dérogation active n'est nécessaire.

`GO` ne peut pas être obtenu par compensation ou par acceptation tacite d'une anomalie.

### 3.2 `GO_WITH_DEROGATION`

`GO_WITH_DEROGATION` signifie :

- le déficit est identifié et borné ;
- les faits disponibles et les inconnues sont séparés ;
- aucune preuve ne démontre une incompatibilité bloquante ;
- le risque résiduel est explicitement accepté par l'autorité compétente ;
- la dérogation possède un identifiant, une portée, une autorité, une date et une condition de révision ;
- les exigences non couvertes par la dérogation restent satisfaites.

Cette décision ne vaut que pour le périmètre nommé. Elle ne devient jamais `GO` par ancienneté.

### 3.3 `NO_GO`

`NO_GO` signifie qu'au moins une condition bloquante est présente : preuve incompatible, exigence obligatoire non satisfaite sans dérogation recevable, risque critique non accepté, périmètre indéterminé, conflit de décisions non résolu ou preuve minimale absente.

`NO_GO` peut être technique, probatoire ou administratif. La cause doit être enregistrée.

### 3.4 Criticité normalisée

| Niveau | Définition normative | Autorisation maximale |
|---|---|---|
| `C1 — Faible` | Écart documentaire ou traçabilité locale, sans effet démontré sur une exigence obligatoire | `GO_WITH_DEROGATION` |
| `C2 — Modérée` | Écart borné affectant une preuve obligatoire, avec état courant cohérent démontré | `GO_WITH_DEROGATION` |
| `C3 — Majeure` | Écart transversal, historique perdu, dépendance structurante ou risque non quantifiable affectant plusieurs Gates | `GO_WITH_DEROGATION` par autorité PROGRAM, sinon `NO_GO` |
| `C4 — Critique` | Incompatibilité démontrée ou risque non maîtrisé de sécurité, légalité, intégrité, disponibilité ou fonctionnement essentiel | `NO_GO` |

La criticité est fondée sur l'impact démontré. Un impact inconnu sur une exigence critique est traité comme bloquant jusqu'à qualification ; il n'est pas déclaré faible par défaut.

---

## 4. Typologie officielle des dérogations

### 4.1 Règles communes d'entrée

Une demande de dérogation est recevable uniquement si elle contient :

1. l'exigence affectée ;
2. la famille officielle ;
3. le périmètre exact ;
4. les faits `PROUVÉ` ;
5. les éléments `COMPATIBLE MAIS NON PROUVÉ` ;
6. les éléments `INCONNU` ;
7. la preuve de l'impossibilité ou du coût de résolution, lorsque cette justification est invoquée ;
8. l'impact MVP, production et certification ;
9. le niveau de criticité ;
10. l'autorité sollicitée ;
11. la condition de révision.

### 4.2 Preuves recevables et interdites

Les preuves obligatoires dépendent de la famille, mais doivent toujours posséder une source, une date, un objet et une portée.

Sont interdites comme fondement unique d'une décision :

- intuition ou préférence ;
- témoignage oral non consigné ;
- absence supposée d'incident ;
- action future non réalisée ;
- document sans origine ou version ;
- capture sans contexte vérifiable ;
- preuve d'un autre environnement sans démonstration d'identité de périmètre ;
- artefact reconstruit présenté comme original ;
- compatibilité présentée comme preuve d'exécution ;
- absence d'une preuve présentée comme preuve du contraire ;
- total agrégé présenté comme attribution individuelle ;
- décision antérieure utilisée hors de son périmètre.

### 4.3 Familles officielles

#### F01 — Preuve incomplète

- **Entrée :** une partie de la preuve obligatoire existe, une autre manque.
- **Minimum :** inventaire des pièces disponibles et manquantes, exigence affectée, portée du manque.
- **Obligatoire :** preuve que les éléments présents couvrent la partie déclarée `PROUVÉ`.
- **Interdit :** déduire la partie manquante de la partie présente.
- **Décision :** `GO_WITH_DEROGATION` en `C1–C2`; `NO_GO` si le manque affecte une exigence critique.

#### F02 — Historique perdu ou détruit

- **Entrée :** disparition historique démontrée et contenu non reconstituable.
- **Minimum :** preuve de la disparition, inventaire des mécanismes de récupération, résultat de leur indisponibilité.
- **Obligatoire :** état courant et limite exacte de reconstitution.
- **Interdit :** reconstruire puis qualifier la reconstruction d'historique original.
- **Décision :** `GO_WITH_DEROGATION` en `C2–C3` si l'état courant requis est prouvé et aucune incompatibilité n'existe ; sinon `NO_GO`.

#### F03 — Runtime cohérent, historique non prouvé

- **Entrée :** état courant compatible avec l'exigence, exécution historique non démontrée.
- **Minimum :** preuve de compatibilité du runtime et liste des affirmations historiques inconnues.
- **Obligatoire :** séparation explicite entre compatibilité et exécution.
- **Interdit :** certifier l'exécution à partir de la seule compatibilité.
- **Décision :** `GO_WITH_DEROGATION` en `C2`; `NO_GO` si l'histoire constitue elle-même l'exigence obligatoire.

#### F04 — Documentation manquante ou incomplète

- **Entrée :** comportement ou artefact prouvé, documentation exigée absente ou insuffisante.
- **Minimum :** référence de l'exigence documentaire et inventaire de l'existant.
- **Obligatoire :** preuve indépendante de l'état réel lorsque la documentation est secondaire.
- **Interdit :** utiliser une documentation obsolète comme état courant.
- **Décision :** `GO_WITH_DEROGATION` en `C1–C2`; `NO_GO` si le document est la preuve réglementaire ou opérationnelle obligatoire.

#### F05 — Legacy ou antériorité normative

- **Entrée :** élément antérieur à la norme courante, existence et périmètre démontrés.
- **Minimum :** date, version, règle actuelle non satisfaite et impact courant.
- **Obligatoire :** preuve que l'écart est borné au legacy identifié.
- **Interdit :** étendre la qualification legacy à de nouveaux éléments.
- **Décision :** `GO_WITH_DEROGATION` en `C1–C3` par autorité adaptée ; `NO_GO` si incompatibilité critique.

#### F06 — Artefact supprimé ou inaccessible

- **Entrée :** artefact requis absent, suppression ou inaccessibilité démontrée.
- **Minimum :** identité de l'artefact, rôle attendu, recherches déjà certifiées, état courant.
- **Obligatoire :** impact de l'absence sur la vérification.
- **Interdit :** traiter l'absence comme preuve du contenu.
- **Décision :** `GO_WITH_DEROGATION` si la fonction ou l'état requis est prouvé autrement ; sinon `NO_GO`.

#### F07 — Preuves incompatibles ou contradictoires

- **Entrée :** au moins deux preuves recevables concluent différemment sur la même affirmation.
- **Minimum :** pièces contradictoires, dates, sources et périmètres.
- **Obligatoire :** analyse formelle de priorité, fraîcheur et portée.
- **Interdit :** choisir la preuve favorable sans résoudre la contradiction.
- **Décision :** `NO_GO` jusqu'à résolution. Aucune dérogation ne peut déclarer `GO` une contradiction active.

#### F08 — Risque juridique, réglementaire ou contractuel

- **Entrée :** exigence applicable identifiée ou traçabilité légalement requise affectée.
- **Minimum :** texte ou obligation applicable et fait concerné.
- **Obligatoire :** avis de l'autorité juridique désignée.
- **Interdit :** qualifier juridiquement sans règle applicable identifiée.
- **Décision :** `GO_WITH_DEROGATION` uniquement si l'autorité juridique confirme sa recevabilité ; sinon `NO_GO`.

#### F09 — Sécurité et contrôle d'accès

- **Entrée :** écart affectant confidentialité, intégrité, authentification, autorisation ou secrets.
- **Minimum :** actif, menace ou exigence, exposition et contrôles présents.
- **Obligatoire :** avis de l'autorité sécurité et preuve des contrôles courants.
- **Interdit :** considérer l'absence d'incident connu comme preuve de sécurité.
- **Décision :** `GO_WITH_DEROGATION` seulement pour un risque résiduel borné et accepté ; `NO_GO` pour exposition critique ou inconnue critique.

#### F10 — Régression ou couverture de validation insuffisante

- **Entrée :** régression démontrée ou preuve de non-régression obligatoire insuffisante.
- **Minimum :** exigence, périmètre validé, résultat disponible et manque identifié.
- **Obligatoire :** état des fonctions critiques concernées.
- **Interdit :** extrapoler un test partiel à un périmètre complet.
- **Décision :** `GO_WITH_DEROGATION` si le manque est non critique et borné ; `NO_GO` pour régression démontrée ou fonction critique non vérifiée.

#### F11 — Cartographie, ownership ou responsabilité absente

- **Entrée :** composant, flux, décision ou preuve sans propriétaire ou cartographie exigée.
- **Minimum :** objets non couverts et décision affectée.
- **Obligatoire :** autorité temporaire de décision pour toute dérogation.
- **Interdit :** attribuer un propriétaire sans mandat.
- **Décision :** `GO_WITH_DEROGATION` pour une lacune bornée sans effet critique ; `NO_GO` si aucune autorité ne peut accepter le risque.

#### F12 — Dépendance externe

- **Entrée :** preuve ou fonctionnement dépendant d'un tiers hors contrôle du PROGRAM.
- **Minimum :** dépendance, contrat ou interface, état connu, impact et responsabilité.
- **Obligatoire :** preuve de l'état courant et condition de révision.
- **Interdit :** considérer un engagement futur du tiers comme fait réalisé.
- **Décision :** `GO_WITH_DEROGATION` si l'état requis est démontré et le risque accepté ; `NO_GO` si dépendance critique indisponible ou inconnue.

#### F13 — Intégrité ou cohérence des données

- **Entrée :** divergence, perte, corruption ou cohérence non démontrée sur des données requises.
- **Minimum :** périmètre de données, contrôles d'intégrité et anomalies constatées.
- **Obligatoire :** preuve que les données critiques ne sont pas affectées pour autoriser une dérogation.
- **Interdit :** inférer l'intégrité globale d'un échantillon non représentatif.
- **Décision :** `GO_WITH_DEROGATION` pour un écart non critique isolé ; `NO_GO` si intégrité critique incompatible ou inconnue.

#### F14 — Disponibilité, continuité, sauvegarde ou restauration

- **Entrée :** exigence de disponibilité ou récupération non satisfaite ou non prouvée.
- **Minimum :** exigence de service, mécanismes actuels, portée temporelle et état vérifié.
- **Obligatoire :** capacité démontrée correspondant à l'exigence pour `GO`.
- **Interdit :** confondre configuration déclarée et restauration réussie.
- **Décision :** `GO_WITH_DEROGATION` seulement si l'exigence n'est pas critique pour le périmètre ; sinon `NO_GO`.

#### F15 — Protection des données et confidentialité

- **Entrée :** traitement, conservation, accès ou traçabilité de données protégées affecté.
- **Minimum :** catégories de données, exigence applicable et exposition démontrée.
- **Obligatoire :** avis de l'autorité compétente et contrôles présents.
- **Interdit :** conclure à l'absence de données protégées sans inventaire recevable.
- **Décision :** `GO_WITH_DEROGATION` uniquement avec acceptation formelle autorisée ; `NO_GO` en cas d'exposition critique ou de légalité inconnue.

#### F16 — Observabilité ou auditabilité insuffisante

- **Entrée :** logs, métriques, audit trail ou attribution requis absents ou incomplets.
- **Minimum :** événements attendus, sources disponibles, rétention et lacune.
- **Obligatoire :** impact sur certification, sécurité et exploitation.
- **Interdit :** reconstituer une attribution à partir d'une simple corrélation temporelle.
- **Décision :** `GO_WITH_DEROGATION` pour une lacune historique bornée ; `NO_GO` si l'auditabilité courante obligatoire reste absente.

#### F17 — Divergence de configuration ou d'environnement

- **Entrée :** différences entre environnements, référentiels ou configurations.
- **Minimum :** configurations comparées, date et périmètre.
- **Obligatoire :** preuve de la configuration de l'environnement certifié.
- **Interdit :** utiliser la preuve d'un environnement comme preuve d'un autre.
- **Décision :** `GO_WITH_DEROGATION` si divergence sans impact obligatoire démontré ; `NO_GO` si l'environnement cible est incompatible ou non déterminé.

#### F18 — Dépendance de certification ou périmètre incomplet

- **Entrée :** une Gate dépend d'une autre décision, d'un autre LOT ou d'une preuve non clôturée.
- **Minimum :** dépendance, sens de propagation, caractère obligatoire et décision source.
- **Obligatoire :** statut courant de la dépendance.
- **Interdit :** ouvrir la Gate comme si la dépendance n'existait pas.
- **Décision :** identique ou plus restrictive que la dépendance obligatoire : `GO_WITH_DEROGATION` ou `NO_GO`.

---

## 5. Matrice de décision

| Famille | Criticité | Impact | Preuves minimales | Décision possible | Autorité décisionnelle | Propagation | Révision nécessaire |
|---|---|---|---|---|---|---|---|
| F01 Preuve incomplète | C1–C4 | Certification | Inventaire présent/manquant, portée | GWD ou NG | Gate; PROGRAM si C3–C4 | Gate → LOT | Nouvelle preuve ou changement de portée |
| F02 Historique perdu | C2–C3 | Traçabilité, certification | Perte, récupération indisponible, état courant | GWD ou NG | Comité PROGRAM | Gate → LOT → PROGRAM | Réapparition d'une source ou changement d'exigence |
| F03 Runtime cohérent/histoire inconnue | C2–C3 | Certification, reproductibilité | Compatibilité courante, inconnues historiques | GWD ou NG | LOT; PROGRAM si transversal | Gate → LOT | Changement runtime ou nouvelle preuve historique |
| F04 Documentation manquante | C1–C3 | Exploitation, certification | Exigence documentaire, état réel | GWD ou NG | Gate; spécialiste si réglementaire | Gate → LOT | Document produit ou exigence modifiée |
| F05 Legacy | C1–C4 | Maintenance, évolution | Antériorité, règle, périmètre | GWD ou NG | LOT; PROGRAM si C3–C4 | Gate → LOT → PROGRAM si partagé | Modification du legacy ou de la norme |
| F06 Artefact supprimé | C1–C4 | Preuve, exploitation | Identité, absence, impact, alternative | GWD ou NG | LOT; PROGRAM si transversal | Gate → LOT | Artefact retrouvé ou portée modifiée |
| F07 Preuves incompatibles | C4 | Toute certification | Preuves contradictoires contextualisées | NG | Comité PROGRAM | Bloque le périmètre dépendant | Résolution formelle obligatoire |
| F08 Juridique/contractuel | C2–C4 | Légalité, responsabilité | Obligation applicable, avis compétent | GWD ou NG | Autorité juridique + PROGRAM | Jusqu'au PROGRAM si applicable | Évolution règle, avis ou périmètre |
| F09 Sécurité/accès | C2–C4 | Confidentialité, intégrité | Actif, exposition, contrôles | GWD ou NG | Sécurité + PROGRAM pour C3–C4 | Selon actifs dépendants | Changement exposition ou contrôle |
| F10 Régression/validation | C1–C4 | Fonctionnel, technique | Exigence, couverture, résultats | GWD ou NG | Gate/LOT; PROGRAM si critique | Gate → LOT | Nouveau résultat ou changement produit |
| F11 Cartographie/ownership | C1–C3 | Responsabilité, décision | Objets non couverts, autorité temporaire | GWD ou NG | LOT ou PROGRAM | Gate → LOT; PROGRAM si transversal | Attribution formelle ou cartographie |
| F12 Dépendance externe | C1–C4 | Planning, service | Dépendance, état, responsabilité | GWD ou NG | LOT; PROGRAM si critique | Dépendances consommatrices | Changement tiers ou contrat |
| F13 Intégrité des données | C2–C4 | Données, fonctionnel | Périmètre, contrôles, anomalies | GWD ou NG | Data owner + PROGRAM si critique | Toutes Gates consommatrices | Changement données ou contrôle |
| F14 Disponibilité/recovery | C2–C4 | Continuité, production | Exigence, mécanismes, capacité prouvée | GWD ou NG | Exploitation + PROGRAM si critique | LOT et consommateurs | Test ou configuration modifiés |
| F15 Protection des données | C2–C4 | Confidentialité, légalité | Données, exigence, exposition | GWD ou NG | Autorité compétente + PROGRAM | Jusqu'au PROGRAM si applicable | Changement traitement ou règle |
| F16 Observabilité/audit | C1–C4 | Exploitation, traçabilité | Événements, sources, rétention, lacune | GWD ou NG | LOT; sécurité/juridique si concerné | Selon portée de la trace | Changement de traces ou exigence |
| F17 Divergence environnement | C1–C4 | Déploiement, reproductibilité | Comparaison datée, cible identifiée | GWD ou NG | LOT; PROGRAM si partagé | Gates de l'environnement cible | Changement de configuration |
| F18 Dépendance de certification | Criticité source | Planning, certification | Dépendance et décision source | GWD ou NG | Niveau receveur | Suit la dépendance obligatoire | Révision de la décision source |

`GWD` signifie `GO_WITH_DEROGATION`; `NG` signifie `NO_GO`. Aucune famille ne permet `GO` tant que l'écart qualifiant la dérogation demeure actif.

---

## 6. Matrice de propagation Gate → LOT → PROGRAM

### 6.1 Règle de consolidation

La consolidation s'applique uniquement aux Gates et LOTS déclarés obligatoires dans le périmètre de certification. Un élément hors périmètre doit être explicitement marqué comme tel ; il ne disparaît pas silencieusement du calcul.

| Niveau source | Conditions | Niveau receveur | Décision propagée |
|---|---|---|---|
| Toutes les Gates obligatoires | Toutes `GO` | LOT | `GO` |
| Au moins une Gate obligatoire | `GO_WITH_DEROGATION`, aucune `NO_GO` | LOT | `GO_WITH_DEROGATION` |
| Au moins une Gate obligatoire | `NO_GO` | LOT | `NO_GO` |
| Toutes les LOTS obligatoires | Toutes `GO` | PROGRAM | `GO` |
| Au moins un LOT obligatoire | `GO_WITH_DEROGATION`, aucun `NO_GO` | PROGRAM | `GO_WITH_DEROGATION` |
| Au moins un LOT obligatoire | `NO_GO` | PROGRAM | `NO_GO` |
| Source obligatoire | Décision absente, expirée ou conflictuelle | Niveau receveur | `NO_GO` administratif |

### 6.2 Dérogations multiples

Plusieurs dérogations sont consolidées selon les règles suivantes :

1. elles conservent chacune leur identifiant et leur portée ;
2. une cause commune peut utiliser un dossier de preuve mutualisé, mais chaque impact Gate reste enregistré ;
3. une preuve commune n'est comptée qu'une fois comme source, jamais comme plusieurs preuves indépendantes ;
4. les risques ne sont pas moyennés ;
5. les interactions entre dérogations sont examinées explicitement ;
6. une interaction produisant une incompatibilité ou un impact critique entraîne `NO_GO` ;
7. sans interaction bloquante, plusieurs `GO_WITH_DEROGATION` se propagent en un `GO_WITH_DEROGATION` consolidé ;
8. une dérogation de niveau PROGRAM couvre uniquement les Gates énumérées ; elle ne s'étend pas automatiquement aux futures Gates ;
9. une dérogation expirée vaut décision absente jusqu'à révision ;
10. un `NO_GO` obligatoire ne peut être neutralisé par plusieurs `GO`.

### 6.3 Prévention des contradictions

Pour chaque affirmation certifiée, le registre conserve une clé unique :

`PROGRAM / LOT / Gate / Exigence / Objet / Environnement / Période`

Avant décision, le comité vérifie les décisions actives portant la même clé ou une clé parente. En cas de contradiction :

- la Gate reste `NO_GO` administratif ;
- aucune décision n'est écrasée ;
- une révision identifie la preuve nouvelle, la décision remplacée et la date d'effet ;
- les décisions dépendantes sont réévaluées.

---

## 7. Critères `GO`

Une Gate reçoit `GO` si et seulement si :

1. son périmètre est complet et approuvé ;
2. toutes ses exigences obligatoires sont identifiées ;
3. chaque exigence obligatoire est `PROUVÉ` par une preuve recevable ;
4. toutes les preuves sont rattachées à leur source, date, objet, environnement et portée ;
5. aucune preuve incompatible n'est active ;
6. aucune inconnue n'affecte une exigence obligatoire ;
7. aucune dérogation n'est active sur le périmètre ;
8. toutes les dépendances obligatoires sont `GO` ;
9. l'autorité compétente a signé la décision ;
10. la décision et ses preuves sont enregistrées.

Le non-respect d'un seul critère interdit `GO`.

---

## 8. Critères `GO_WITH_DEROGATION`

Une Gate reçoit `GO_WITH_DEROGATION` si et seulement si :

1. les critères `GO` sont satisfaits hors exigences explicitement couvertes ;
2. chaque écart appartient à une famille officielle ;
3. la portée de chaque écart est bornée ;
4. les preuves minimales et obligatoires de la famille sont présentes ;
5. les faits, compatibilités et inconnues sont séparés ;
6. aucune preuve incompatible bloquante n'est active ;
7. aucun risque `C4` non maîtrisé n'est présent ;
8. l'impact MVP, production et certification est enregistré ;
9. l'autorité requise accepte explicitement le risque ;
10. une condition de révision est définie ;
11. la propagation aux Gates, LOTS et PROGRAM dépendants est calculée ;
12. la dérogation ne prétend pas prouver l'élément manquant.

Une dérogation bloque le PROGRAM lorsqu'elle :

- porte sur une exigence critique sans preuve minimale ;
- contient une preuve incompatible ;
- possède une portée indéterminée ;
- n'a pas d'autorité habilitée ;
- rend critique l'interaction avec une autre dérogation ;
- dépend d'une décision `NO_GO` ;
- est expirée ou privée de condition de révision ;
- affecte une obligation juridique ou de sécurité pour laquelle l'autorité compétente refuse ou ne peut donner son acceptation.

Dans ces cas, la décision applicable est `NO_GO`, non `GO_WITH_DEROGATION`.

---

## 9. Critères `NO_GO`

Une Gate reçoit `NO_GO` si au moins une condition suivante est satisfaite :

1. preuve incompatible non résolue ;
2. incompatibilité technique ou fonctionnelle démontrée sur une exigence obligatoire ;
3. preuve minimale absente pour une dérogation ;
4. risque critique non maîtrisé ou non accepté ;
5. impact critique inconnu ;
6. périmètre, objet ou environnement indéterminé ;
7. dépendance obligatoire `NO_GO`, absente, expirée ou contradictoire ;
8. autorité décisionnelle absente ;
9. dérogation hors typologie officielle ;
10. utilisation d'une preuve interdite comme fondement nécessaire ;
11. conflit entre décisions actives ;
12. tentative de présenter une reconstruction comme preuve historique ;
13. condition réglementaire, juridique, sécurité, intégrité ou continuité obligatoire non satisfaite ;
14. impossibilité de distinguer ce qui est prouvé de ce qui est inconnu.

Le dossier `NO_GO` doit identifier la condition bloquante et la condition objective de réouverture. Si aucune condition de réouverture n'est connue, cette inconnue est enregistrée ; aucune date arbitraire n'est fixée.

---

## 10. Gouvernance du comité

### 10.1 Rôles fonctionnels

| Rôle | Responsabilité | Ne peut pas |
|---|---|---|
| Responsable de Gate | Définit le périmètre, rassemble les exigences et présente le dossier | S'auto-accorder seul une dérogation |
| Gardien des preuves | Indexe les preuves, contrôle origine, date, portée et intégrité documentaire | Requalifier seul une décision |
| Responsable de LOT | Consolide les Gates et leurs dépendances | Transformer un `NO_GO` obligatoire en `GO` |
| Responsable architecture PROGRAM | Contrôle cohérence transverse, dépendances et propagation | Étendre une preuve hors de sa portée |
| Autorité sécurité | Statue sur F09 et les dimensions sécurité des autres familles | Remplacer l'autorité juridique |
| Autorité juridique/conformité | Statue sur F08, F15 et les obligations applicables | Qualifier un état technique sans preuve technique |
| Autorité exploitation/données | Statue sur disponibilité, récupération et intégrité selon le périmètre | Certifier un périmètre non examiné |
| Comité de certification | Prononce `GO`, `GO_WITH_DEROGATION` ou `NO_GO` | Inventer une quatrième valeur de décision |
| Secrétaire de décision | Enregistre décision, votes, réserves, propagation et révisions | Modifier rétroactivement un procès-verbal |
| Program Director | Autorité finale pour les dérogations `C3` transversales et la décision PROGRAM | Annuler la conservation des inconnues |

Ces rôles sont fonctionnels. Leur affectation nominative relève du registre d'autorité du PROGRAM et doit précéder toute décision.

### 10.2 Entrées obligatoires

- fiche d'identification Gate ;
- liste des exigences obligatoires ;
- index des preuves ;
- matrice `affirmation → preuve → classification` ;
- décisions des dépendances ;
- liste des écarts et familles ;
- analyse de risque ;
- calcul de propagation ;
- demandes de dérogation ;
- historique des décisions antérieures sur le même périmètre.

### 10.3 Sorties obligatoires

- une valeur unique : `GO`, `GO_WITH_DEROGATION` ou `NO_GO` ;
- le périmètre exact ;
- les faits retenus et leur classification ;
- les preuves utilisées ;
- les inconnues conservées ;
- les dérogations et autorités ;
- les conditions de révision ;
- la propagation Gate, LOT et PROGRAM ;
- la date et les signataires ;
- le lien vers la décision remplacée, le cas échéant.

### 10.4 Autorité minimale

| Cas | Autorité minimale |
|---|---|
| `GO` Gate sans écart | Responsable de Gate + gardien des preuves + comité |
| Dérogation C1 | Comité de Gate et responsable de LOT |
| Dérogation C2 | Comité de LOT |
| Dérogation C3 ou transverse | Comité PROGRAM et Program Director |
| Sécurité, juridique, données ou disponibilité | Autorité spécialisée correspondante, en plus du niveau requis |
| C4 | `NO_GO`; réouverture par comité PROGRAM après nouvelle preuve |
| Décision PROGRAM | Comité PROGRAM et Program Director |

---

## 11. Processus de révision

### 11.1 Déclencheurs

Une décision est révisée si :

- une nouvelle preuve recevable apparaît ;
- une preuve utilisée est invalidée ;
- le périmètre, l'environnement ou l'exigence change ;
- une dépendance change de décision ;
- une dérogation atteint sa date ou condition de révision ;
- une contradiction est détectée ;
- une interaction nouvelle entre dérogations est établie ;
- une obligation juridique, contractuelle ou sécurité applicable change ;
- un incident démontre une incompatibilité avec une affirmation certifiée.

### 11.2 Procédure

1. conserver la décision existante sans la modifier ;
2. ouvrir un dossier de révision lié ;
3. identifier le déclencheur et les preuves nouvelles ;
4. réévaluer uniquement les affirmations affectées, puis leurs dépendances ;
5. recalculer la propagation ;
6. prononcer une nouvelle valeur ;
7. relier l'ancienne et la nouvelle décision ;
8. notifier les responsables des périmètres dépendants.

### 11.3 Effets

- Une nouvelle preuve peut réduire une inconnue, confirmer une dérogation ou imposer `NO_GO`.
- L'expiration ne transforme jamais automatiquement une dérogation en `GO`.
- L'absence de révision à l'échéance rend la décision non active et entraîne `NO_GO` administratif pour les dépendances obligatoires.
- Une révision locale ne modifie pas une décision parente sans recalcul formel de propagation.

---

## 12. Industrialisation de l'ouverture des Gates

### 12.1 Paquet standard de certification

Chaque Gate utilise le même paquet documentaire :

1. identité et périmètre ;
2. exigences ;
3. index des preuves existantes ;
4. matrice de classification ;
5. dépendances ;
6. écarts par famille ;
7. analyse de risque ;
8. décision calculée ;
9. procès-verbal ;
10. propagation et révision.

Aucun format local ne peut ajouter une valeur de décision ou supprimer une donnée obligatoire.

### 12.2 Séquence déterministe d'ouverture

Pour chaque Gate :

1. figer le périmètre décisionnel ;
2. importer les exigences applicables ;
3. rechercher d'abord les preuves déjà indexées ;
4. vérifier leur portée et leur fraîcheur ;
5. classer chaque affirmation ;
6. identifier les écarts ;
7. affecter une famille officielle ;
8. vérifier les preuves minimales ;
9. déterminer la criticité ;
10. appliquer les critères des sections 7 à 9 ;
11. consolider les dépendances ;
12. prononcer et enregistrer la décision ;
13. propager au LOT puis au PROGRAM.

Cette séquence ne requiert aucun développement. Elle organise les preuves et décisions existantes.

### 12.3 Mutualisation des preuves

Une preuve mutualisée reçoit un identifiant unique et les métadonnées suivantes : source, date, objet, environnement, période, intégrité, statut, propriétaire et Gates consommatrices.

Règles de réutilisation :

- une preuve est lue une fois, référencée plusieurs fois ;
- chaque Gate justifie que la portée la couvre ;
- une invalidation notifie toutes les Gates consommatrices ;
- une preuve agrégée reste agrégée ;
- un dossier de cause commune peut porter plusieurs dérogations sans fusionner leurs impacts ;
- les inconnues communes sont mutualisées comme inconnues, non converties en faits.

### 12.4 Réduction des audits répétitifs

Un nouvel audit n'est requis que si une exigence obligatoire ne peut être évaluée à partir du registre existant et si le comité autorise explicitement l'acquisition de nouvelles preuves. La simple réutilisation, classification ou propagation d'une preuve existante n'est pas un nouvel audit.

Une Gate ne redemande pas une preuve déjà certifiée lorsque :

- l'objet est identique ;
- l'environnement est identique ;
- la période requise est couverte ;
- la preuve n'est ni expirée ni invalidée ;
- aucune modification affectant sa portée n'est enregistrée.

### 12.5 Reproductibilité

Deux comités recevant le même périmètre, les mêmes exigences, les mêmes preuves et les mêmes dépendances doivent obtenir la même décision par application des sections 7 à 9.

Toute divergence doit être enregistrée comme contradiction de décision et entraîne `NO_GO` administratif jusqu'à résolution.

---

## 13. Annexes

### Annexe A — Algorithme décisionnel normatif

```text
SI périmètre incomplet OU autorité absente
  ALORS NO_GO
SINON SI preuve incompatible active
  ALORS NO_GO
SINON SI dépendance obligatoire NO_GO, absente, expirée ou conflictuelle
  ALORS NO_GO
SINON SI toutes les exigences obligatoires sont PROUVÉES
        ET aucune dérogation n'est active
  ALORS GO
SINON
  POUR chaque écart
    vérifier famille officielle, preuves minimales, portée, criticité et autorité
  SI un écart est C4, non classé, non borné ou non autorisé
    ALORS NO_GO
  SINON
    GO_WITH_DEROGATION
```

### Annexe B — Modèle minimal de décision

```text
DecisionId:
ProgramId:
LotId:
GateId:
Perimetre:
Exigences:
FaitsProuves:
FaitsCompatiblesNonProuves:
Inconnues:
EvidenceIds:
DerogationIds:
Familles:
Criticite:
Dependances:
Decision: GO | GO_WITH_DEROGATION | NO_GO
Autorite:
DateDecision:
ConditionRevision:
PropagationLot:
PropagationProgram:
DecisionPrecedente:
```

### Annexe C — Modèle minimal de dérogation

```text
DerogationId:
Famille:
Objet:
ExigenceAffectee:
Perimetre:
FaitsProuves:
ElementsCompatiblesNonProuves:
InconnuesConservees:
PreuvesMinimales:
PreuvesObligatoires:
PreuvesInterditesEcartees:
Criticite:
ImpactMVP:
ImpactProduction:
ImpactCertification:
RisqueResiduel:
AutoriteAcceptation:
DateDecision:
ConditionRevision:
GatesAffectees:
LotsAffectes:
PropagationProgram:
```

### Annexe D — Application de référence : `LOT-003`

| Élément | Qualification selon la doctrine |
|---|---|
| 29 migrations absentes du ledger | `PROUVÉ` |
| Compatibilité runtime de 28 migrations | `PROUVÉ` pour la compatibilité, non pour l'histoire |
| État de suppression compatible pour une migration | `COMPATIBLE MAIS NON PROUVÉ` quant à l'histoire |
| 34 suppressions en huit opérations | `PROUVÉ` |
| Rattachement des 34 suppressions aux 29 migrations | `INCONNU` |
| Historique récupérable | Non : PITR désactivé, aucun backup ou WAL exploitable |
| Familles | F02, F03 et F16 |
| Criticité | C3, déficit probatoire transversal au dossier de migrations |
| Décision de référence | `GO_WITH_DEROGATION` |

Cette application démontre le mécanisme de la doctrine : conserver les inconnues, certifier uniquement la compatibilité établie et porter la rupture historique dans une dérogation explicite.

### Annexe E — Règles absolues

1. Une preuve incompatible interdit `GO`.
2. Une preuve absente n'autorise jamais `GO` sur l'exigence concernée.
3. Une preuve absente peut autoriser `GO_WITH_DEROGATION` si la famille, la portée, le risque et l'autorité le permettent.
4. Une destruction objectivement démontrée peut ouvrir une dérogation ; elle ne prouve pas le contenu détruit.
5. Une compatibilité peut soutenir une dérogation ; elle ne prouve pas l'exécution historique.
6. Une inconnue critique bloque la certification.
7. Une dérogation sans propriétaire, autorité ou condition de révision est invalide.
8. Une dérogation locale ne neutralise pas une décision parentale plus restrictive.
9. Un `NO_GO` obligatoire se propage.
10. Un `GO_WITH_DEROGATION` obligatoire se propage au minimum comme `GO_WITH_DEROGATION`.
11. `GO` ne peut absorber ni masquer une dérogation active.
12. Les preuves communes sont mutualisées sans extension de portée.
13. Les décisions contradictoires provoquent `NO_GO` jusqu'à révision.
14. Une reconstruction est certifiée comme reconstruction, jamais comme histoire originale.
15. Toute décision est traçable, versionnée et révisable.

