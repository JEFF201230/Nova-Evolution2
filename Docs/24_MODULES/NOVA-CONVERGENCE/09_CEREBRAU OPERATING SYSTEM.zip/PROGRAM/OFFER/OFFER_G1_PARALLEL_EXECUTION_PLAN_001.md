# CEREBRAU — Plan d’exécution parallèle Offer G1

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-G1-EXECUTION-ORCHESTRATION-001
MISSION_TYPE        : EXECUTION_PLANNING
EXECUTION_MODE      : READ_ONLY
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
CURRENT_GATE_STATUS : NO_GO
```

Ce plan décrit le parallélisme autorisable dans la future exécution. Il ne
lance aucune correction et n’autorise aucune mutation.

## 2. Principe de concurrence

Le parallélisme est permis seulement si :

- tous les prérequis de chaque lane sont `PASS` ;
- les chemins exacts sont résolus par le manifeste ;
- les destinations `AF-EVIDENCE` sont distinctes ;
- aucun couple de lanes n’écrit le même fichier, objet, jeu de test ou
  environnement ;
- toute lecture partageant un artefact observe une version/hash/commit figé ;
- un responsable de synchronisation clôt la vague avant la vague suivante.

Le partage en lecture de `AF-RUNTIME-CONFIG`, `AF-BASELINE` ou
`AF-CONSUMERS` est admissible. Toute écriture sur DEV est exclusive.

## 3. Vagues parallèles officielles

| Vague | Lanes exécutables | Ressources | Prérequis | Jonction |
|---|---|---|---|---|
| `PAR-0` | Résolution du manifeste uniquement | WAVE, tous `AF-*` | WAVE officielle | Manifeste gelé |
| `PAR-1` | Sûreté DEV | DEV, sauvegarde, rollback | Manifeste gelé | LOT-01 `PASS` |
| `PAR-2` | PA-07 isolée ; capture QF/Rights ; capture consommateurs ; identité runtime | Environnement isolé, DEV read-only, consommateurs, exploitation | LOT-01 `PASS` | LOT-02 `PASS` |
| `PAR-3A` | Remédiation QF/Rights | DEV exclusif | PA-07 `PASS`, état initial QF/Rights | PA-06 `PASS`, verrou libéré |
| `PAR-3B` | Baseline Offer | DEV exclusif | PA-07 `PASS`, état consommateurs avant, verrou libéré | PA-01 `PASS`, verrou libéré |
| `PAR-4` | Historique ; inventaire ; comparaison consommateurs | Historique/DEV read-only, consommateurs | PA-01 `PASS` | PA-02, PA-03, PA-08 selon lane |
| `PAR-5` | Audit/tests sécurité Offer puis tests backend ; les revues PA-02/08 peuvent finir en parallèle | DEV/PostgREST, backend/runtime figé | PA-03 et PA-09 selon étape | PA-02/03/04/05/08 `PASS` |
| `PAR-6` | Revues spécialisées du replay, sous assemblage unique | Tous `AF-*` read-only, dossier final | PA-01 à PA-09 `PASS` | PA-10 `PASS` |

`PAR-3A` et `PAR-3B` ne sont pas parallèles entre elles. Elles sont deux
fenêtres successives du même verrou DEV.

## 4. Topologie interne de LOT-02

```mermaid
flowchart LR
    S[LOT-01 PASS] --> A1[PA-07-01]
    A1 --> A2[PA-07-02]
    A2 --> A3[PA-07-03]
    S --> B[PA-06 état avant]
    S --> C[PA-08 état avant]
    S --> D1[PA-09 identité]
    D1 --> D2[PA-09 lien contrat]
    A3 --> J{{LOT-02 PASS}}
    B --> J
    C --> J
    D2 --> J
```

| Lane | Écritures permises | Lectures partagées | Collision évitée | Critère terminal |
|---|---|---|---|---|
| PA-07 | Environnement isolé et destination de preuve dédiée | Baseline, sécurité Offer, QF/Rights, consommateurs | Jamais d’écriture DEV | PA-07 `PASS` |
| PA-06 état avant | Destination de preuve dédiée | QF/Rights live | Aucune remédiation dans cette lane | État initial complet |
| PA-08 état avant | Destination de preuve dédiée | Consommateurs et runtime config | Aucun flag/statut modifié | Référence des quatre familles datée |
| PA-09 | Destination de preuve dédiée | Backend et runtime config | Aucun redéploiement/configuration | Runtime–contrat relié |

L’observation des consommateurs par PA-07 et la capture PA-08 peuvent partager
la même source en lecture. Elles doivent conserver des résultats séparés :
PA-07 démontre la non-activation du dry-run isolé ; PA-08 établit la référence
avant application DEV.

## 5. Topologie interne de LOT-05

```mermaid
flowchart TD
    S[PA-01 PASS] --> H[PA-02 historique]
    S --> I[PA-03 inventaire]
    S --> C[PA-08 comparaison]
    I --> A1[PA-04 audit]
    A1 --> A2[PA-04 tests]
    A2 --> B1[PA-05 préparation]
    R[PA-09 PASS] --> B1
    B1 --> B2[PA-05 exécution]
    H --> J{{LOT-05 PASS}}
    C --> J
    B2 --> J
```

| Sous-vague | Travail | Concurrence autorisée | Barrière |
|---|---|---|---|
| `POST-A` | PA-02, PA-03, PA-08 post-baseline | Trois lanes en lecture sur ressources distinctes ou partagées en lecture | PA-03 `PASS` pour PA-04 |
| `POST-B` | PA-04 audit puis tests | Séquentiel sur le même schéma et les mêmes jeux de sécurité | PA-04 `PASS` et PA-09 `PASS` |
| `POST-C` | PA-05 préparation puis exécution | Séquentiel sur le même runtime et les mêmes jeux de test | Six scénarios conformes |
| `POST-JOIN` | Revues terminales PA-02/03/04/05/08 | Revues parallèles par responsables, preuves immuables | Tous les verdicts `PASS` |

PA-04 et PA-05 ne s’exécutent pas simultanément sur les mêmes jeux de test.
Le commit et la configuration capturés par PA-09 restent immuables jusqu’à la
fin de PA-05.

## 6. Verrous de ressources et fichiers communs

| Verrou | Portée | Utilisateurs | Politique |
|---|---|---|---|
| `LOCK-MANIFEST` | Chemins, versions/hash, modes et destinations | Toutes les micro-missions | Gel après LOT-01 ; toute divergence arrête |
| `LOCK-DEV-MUTATION` | Base DEV et rollback associé | LOT-03, LOT-04 | Exclusif ; LOT-03 puis LOT-04 ; libération après verdict et preuve |
| `LOCK-ISOLATED-DB` | Environnement isolé PA-07 | Lane PA-07 | Exclusif à la lane ; aucune donnée de production |
| `LOCK-RUNTIME-ID` | Commit/configuration/contrat | PA-09 puis PA-05 | Figé après PA-09 ; aucun redéploiement |
| `LOCK-CONSUMER-BASELINE` | État avant des consommateurs | PA-08 avant/après | Capture avant obligatoire avant baseline |
| `LOCK-EVIDENCE-PATH` | Une destination de preuve | Chaque producteur | Un seul writer ; lecteurs après clôture |
| `LOCK-FINAL-DOSSIER` | Dossier PA-10 | LOT-06 | Assemblage unique ; contributions revues en lecture |

| Référence commune | Lots concernés | Mode permis | Risque contrôlé |
|---|---|---|---|
| `AF-BASELINE` | LOT-01, LOT-02, LOT-04, LOT-05, LOT-06 | Lecture partout ; application seulement LOT-04 | Hash divergent, double application, historique réécrit |
| `AF-QF-RIGHTS` | LOT-01, LOT-02, LOT-03, LOT-06 | Lecture ; mutation seulement LOT-03 | Droits excessifs/perdus, collision avec baseline |
| `AF-OFFER-SECURITY` | LOT-01, LOT-02, LOT-05, LOT-06 | Lecture/test ; aucune mutation créée par ce plan | RLS/ACL incohérentes |
| `AF-BACKEND` | LOT-02, LOT-05, LOT-06 | Lecture/test uniquement | Test sur mauvais commit |
| `AF-RUNTIME-CONFIG` | LOT-01, LOT-02, LOT-04, LOT-05, LOT-06 | Lecture expurgée uniquement | Secret ou dérive de configuration |
| `AF-CONSUMERS` | LOT-02, LOT-05, LOT-06 | Lecture uniquement | Activation ou disponibilité implicite |
| `AF-EVIDENCE` | Tous les lots | Destination distincte par producteur | Écrasement, mélange ou altération de preuve |

## 7. Capacité et affectation logique

Le corpus ne fournit ni effectif ni durée. Le plan n’impose donc aucun nombre
de personnes ni calendrier. Il impose seulement la séparation des rôles
logiques déjà définis :

| Lane | Responsable logique principal |
|---|---|
| Manifeste et sûreté | Pilotage WAVE, Data/DB, Offer, Sécurité, Exploitation |
| Migration isolée et baseline | Data/DB + Offer, avec Exploitation pour DEV |
| QF/Rights | Sécurité + Data |
| Consommateurs | Offer + Integration |
| Runtime | Exploitation + Offer/API |
| Sécurité Offer/backend | Sécurité + Data puis Sécurité/API Offer |
| Certification | Mission de certification, autorités spécialisées, Program Director et Certification Board |

Deux lanes ne peuvent être confiées à la même ressource humaine au même
instant que si cette ressource peut réellement tenir les deux revues sans
retarder leur jonction. Le plan reste valide en exécution séquentielle ; le
parallélisme est une optimisation, jamais un prérequis de conformité.

## 8. Conditions de non-régression du parallélisme

Une vague parallèle est `PASS` seulement si :

- chaque lane possède ses propres journaux et destinations de preuve ;
- les versions/hash/commit observés sont identiques à ceux du manifeste ;
- aucune lane n’a modifié une ressource déclarée read-only ;
- aucun test concurrent n’a partagé des données mutables ;
- les contrôles positifs autorisés restent conformes ;
- aucune activation, fuite tenant, permission excessive ou dérive de schéma
  n’est détectée ;
- la jonction attend toutes les lanes obligatoires, sans héritage de succès.
