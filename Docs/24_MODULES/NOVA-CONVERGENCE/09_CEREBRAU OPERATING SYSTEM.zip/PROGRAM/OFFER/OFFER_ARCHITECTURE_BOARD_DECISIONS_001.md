# CEREBRAU — Décisions Architecture Board du domaine Offer

## 1. Identification et autorité

| Champ | Valeur |
|---|---|
| Program | `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001` |
| Lot documentaire | `OFFER` |
| MissionId | `OFFER-ARCHITECTURE-BOARD-DECISION-001` |
| MissionType | `ARCHITECTURE_BOARD_DECISION` |
| ExecutionMode | `ONE_SHOT` |
| Autorité | `PROGRAM_DIRECTOR / CERTIFICATION_BOARD` |
| Date de décision | `2026-07-23` — Europe/Paris |
| Source unique d'entrée | `Docs/PROGRAM/OFFER/OFFER_AUTHORITY_RECONCILIATION_REPORT_001.md` |
| Périmètre d'écriture | ce document uniquement |
| Décisions examinées | `D01` à `D10` |
| Décisions rendues | **10** |
| Décisions principales restantes | **0** |
| Verdict de décision | **APPROUVÉES** |
| Verdict de mise en œuvre | **NO_GO — arrêt au seuil de G1** |

### 1.1 Faits certifiés applicables

Les faits certifiés reçus avec la mission sont maintenus sans modification :

- l'objet officiel de gouvernance est `WAVE` ;
- les work packages et les lots proposés dans le rapport ne sont pas des objets de gouvernance officiels ;
- la fondation est prête ;
- le Wave Model est canonique ;
- le contrat MM L01-03 est canonique.

Les séquences de mise en œuvre décrites dans le présent document sont un ordre technique MVP subordonné aux Waves officielles. Elles ne créent ni lot officiel ni nouvel objet de gouvernance.

### 1.2 Portée de la présente décision

Le présent document :

- rend une décision finale unique pour chacune des dix décisions `D01` à `D10` ;
- ne modifie ni code, ni migration, ni test, ni schéma, ni Runtime, ni domaine métier ;
- ne prouve pas l'état live de DEV/Supabase ;
- ne vaut pas autorisation d'implémenter avant franchissement des Gates applicables.

La décision `D01` **supersède explicitement**, sur le seul point de la distribution, toute formulation canonique antérieure assimilant `PUBLISHED` à « distribuable ». Les autres éléments du corpus canonique Offer restent applicables tant qu'ils ne contredisent pas les décisions ci-dessous.

## 2. Principes exécutoires consolidés

1. `PublishOffer`, `ActivateOffer` et `OpenOperation` sont trois actes distincts.
2. `PUBLISHED` atteste une publication administrative ; seul `ACTIVE` autorise la distribution métier.
3. Aucun booléen, compteur ou statut souverain fourni par un client ne vaut preuve métier.
4. `OfferVersion` fige le contrat produit ; Rights dérive l'éligibilité ; Dotation gouverne l'attribution et les paramètres financiers relevant de son périmètre.
5. EBS consolide et distribue. Il ne recalcule ni Offer, ni Rights, ni Dotation et ne porte aucun catalogue parallèle.
6. Le Dashboard opérateur commande exclusivement l'API Offer.
7. LifeHub et le Dashboard salarié n'affichent une disponibilité que depuis une projection EBS sourcée et traçable.
8. Toute nouvelle demande et tout nouveau mouvement financier portent une origine immuable Offer/Version/Budget.
9. `budget_ledger` est la cible souveraine des nouveaux mouvements financiers ; `ledger_entries` est legacy jusqu'à qualification et retrait contrôlé.
10. Aucun producteur legacy n'est supprimé avant remplacement prouvé de chacun de ses consommateurs.

## 3. Décisions détaillées

### D01 — Sémantique de `PUBLISHED`

**Identifiant**

`D01`

**Sujet**

Superséder ou maintenir le modèle `PUBLISHED = distribuable`.

**Contexte**

Le modèle actuel fait de `PUBLISHED` une publication administrative et, simultanément, la condition technique immédiate de distribution et d'ouverture d'une Operation. La doctrine cible certifiée exige une activation distincte.

**Faits prouvés**

- F01, F06, F07 et F08 : aucun état `ACTIVE`, aucune commande `ActivateOffer`, aucun événement `OfferActivated` et aucune persistance compatible n'existent.
- F05 : `PublishOffer` publie atomiquement l'Offer et sa Version.
- F10 : le read model distribue toute Offer/Version `PUBLISHED`.
- F11 : `effectiveAt` est enregistré, mais n'empêche pas la visibilité immédiate.
- K01 et K02 : publication, distribution et date d'effet sont contradictoires.
- L'architecture cible déjà décidée impose « publication → activation distincte ».

**Options possibles**

1. Maintenir `PUBLISHED = distribuable`.
2. Conserver `PUBLISHED`, mais ajouter seulement un filtre temporel.
3. Distinguer formellement publication administrative et activation métier.

**Avantages**

- L'option 1 minimise le changement, mais maintient l'ambiguïté critique.
- L'option 2 corrige la visibilité future, mais ne crée aucune preuve d'activation.
- L'option 3 rend la décision métier explicite, persistable, auditable et propagable.

**Risques**

- L'option retenue exige une évolution additive des quatre couches Offer et du schéma.
- Les consommateurs legacy fondés sur `PUBLISHED` devront coexister temporairement.
- Toute modification avant réconciliation G1 risquerait d'accentuer le drift dépôt/runtime.

**Décision retenue**

L'option 3 est retenue. `PUBLISHED` signifie exclusivement **publication administrative d'une OfferVersion validée**. Il n'autorise ni distribution EBS, ni exposition salarié, ni dérivation Rights disponible, ni ouverture d'Operation. La distribution métier exige une activation explicite et auditable.

Cette décision supersède toute règle antérieure déclarant une Offer simplement `PUBLISHED` comme distribuable.

**Justification**

Elle est la seule option compatible avec la doctrine cible, l'absence prouvée d'activation et le besoin de causalité de bout en bout. Un filtre temporel seul ne distingue pas une date atteinte d'une décision métier d'activation.

**Impacts**

- futur automate Offer enrichi d'un état opérationnel `ACTIVE` ;
- futur contrat API enrichi d'une commande d'activation ;
- projections de distribution filtrées sur l'activation ;
- consommateurs aval interdits de déduire la disponibilité de `PUBLISHED` ;
- documentation canonique antérieure supersédée sur ce point précis.

**Préconditions**

- G1 : état live et historique de migration Offer certifiés ;
- migration additive et stratégie de compatibilité approuvées ;
- tests de transitions, dates, persistance, audit et non-régression définis avant implémentation.

**Dépendances**

Aucune décision préalable. D01 gouverne D02, D05, D06 et D07.

**Gate concernée**

`G0 Autorité`, puis `G1 Données` et `G2 Cycle sécurisé`.

**Priorité MVP**

`P0 — bloquante`.

### D02 — Automate Offer/Version/Operation et `effectiveAt`

**Identifiant**

`D02`

**Sujet**

Définir la sémantique de `effectiveAt`, de l'activation, de la suspension et de l'ouverture d'Operation.

**Contexte**

Le cycle actuel publie immédiatement, `effectiveAt` n'est pas appliqué par les projections et l'ouverture d'Operation repose sur un simple booléen `offerPublished`. L'Operation possède déjà une fenêtre propre, mais elle ne constitue pas une activation Offer.

**Faits prouvés**

- F02 à F06 : la validation porte sur la Version ; la publication fait passer Offer et Version à `PUBLISHED`.
- F10 et F11 : la projection ignore la date d'effet.
- F12 : `Operation OPEN` est un concept distinct porté par une fenêtre.
- Le cycle réel prouve `PUBLISHED → SUSPENDED → PUBLISHED`, sans activation.
- K01 et K02 : la sémantique actuelle est surchargée.
- U04 : la relation finale entre activation et ouverture nécessitait cette décision.

**Options possibles**

1. Faire de la publication l'activation.
2. Activer automatiquement à l'horloge dès `effectiveAt`.
3. Exiger une commande d'activation explicite, autorisée seulement lorsque la date d'effet est atteinte.

**Avantages**

- L'option 1 conserve l'existant, mais ne répond pas à D01.
- L'option 2 respecte la date, mais rend la transition dépendante d'un ordonnanceur et ne matérialise pas nécessairement l'acte métier.
- L'option 3 sépare la décision, le temps d'effet et la fenêtre d'exécution tout en conservant une preuve explicite.

**Risques**

- La commande explicite impose une action opérateur ou une automatisation qui émet la même commande auditée.
- Une activation sans contrôles transactionnels recréerait la vulnérabilité K03-K04.
- La suspension doit converger rapidement vers tous les consommateurs aval.

**Décision retenue**

L'option 3 est retenue.

- `PublishOffer` fait passer l'Offer et la Version validée à `PUBLISHED`.
- `effectiveAt` est la **date la plus ancienne à laquelle l'activation est autorisée** ; elle n'active rien par elle-même.
- `ActivateOffer` est une commande explicite et idempotente. Elle exige une Offer et une Version `PUBLISHED`, `now >= effectiveAt`, des références autoritatives utilisables et aucune incompatibilité opérationnelle.
- `OfferActivated` est l'événement causal de passage à `ACTIVE`.
- `SuspendOffer` rend immédiatement l'Offer non distribuable et suspend l'ouverture de nouvelles opérations.
- `ResumeOffer` réactive vers `ACTIVE` après résolution serveur des blocages ; il ne revient pas à `PUBLISHED`.
- `OpenOperation` reste une transition propre à Operation et exige cumulativement : Offer `ACTIVE`, Version activée correspondante, fenêtre ouverte et références autoritatives valides.
- La fermeture et l'archivage conservent leur ordre terminal ; aucune réactivation n'est permise après fermeture.

**Justification**

Ce modèle distingue clairement approbation administrative, effet temporel, disponibilité métier et exécution opérationnelle. Il supprime les ambiguïtés K01-K02 sans confondre Offer et Operation.

**Impacts**

- automate, commandes, événements, validation HTTP, persistance et OpenAPI à faire évoluer après GO ;
- read models et projections aval à filtrer sur `ACTIVE` ;
- événements de suspension/reprise à rendre consommables et rejouables ;
- UI opérateur à exposer les actes séparés.

**Préconditions**

- D01 approuvée ;
- G1 franchie ;
- matrice complète des transitions, refus, rôles et effets aval certifiée ;
- migration additive compatible avec les données existantes.

**Dépendances**

D01 et D04. D02 précède D03, D05, D06 et D07.

**Gate concernée**

`G0 Autorité`, `G1 Données`, `G2 Cycle sécurisé`.

**Priorité MVP**

`P0 — bloquante`.

### D03 — Contrat typé `OfferVersion v2`

**Identifiant**

`D03`

**Sujet**

Typer les familles, avantages, périodes, règles et références Budget d'une OfferVersion.

**Contexte**

La Version actuelle porte une `family` libre et des `parameters` JSON non typés. Rights utilise une configuration indépendante ; Budget, TKR, CHDV et CESU n'ont aucune référence canonique dans Offer.

**Faits prouvés**

- La section 8 établit une double vérité entre `OfferVersion.parameters` et `rights_config.rules`.
- F22 : Rights est calculé sans Offer.
- K09 : la configuration Rights n'a aucun lineage OfferVersion.
- K10 : Offer ne porte aucune référence Budget ni origine financière aval.
- K12 : plusieurs catalogues et règles frontend coexistent.
- U05 : le mapping produit exact reste inconnu.
- L'architecture cible certifiée attribue à Offer le produit/catalogue et à Dotation les paramètres financiers de son périmètre.

**Options possibles**

1. Conserver un JSON libre.
2. Fermer entièrement le schéma dans Offer, y compris tous les calculs financiers.
3. Créer un contrat Version v2 typé qui fige le produit et référence les autorités Rights/Budget/Dotation sans absorber leurs calculs.

**Avantages**

- L'option 1 reste flexible, mais ne permet ni validation forte ni reproductibilité.
- L'option 2 centralise, mais créerait un second moteur financier dans Offer.
- L'option 3 fournit une configuration reproductible tout en respectant les frontières de contexte.

**Risques**

- Un catalogue fermé sans gouvernance Produit pourrait figer de mauvais codes.
- Des références non versionnées recréeraient une divergence temporelle.
- Une extension JSON utilisée comme règle souveraine contournerait le contrat typé.

**Décision retenue**

L'option 3 est retenue. Toute OfferVersion v2 doit figer au minimum :

- un `familyCode` issu d'un catalogue produit gouverné ;
- un ou plusieurs `benefitCode` gouvernés, incluant les mappings approuvés pour `TKR`, `CHDV`, `CESU` et les autres avantages ;
- une période de validité produit distincte de la fenêtre d'Operation ;
- des références de règles d'éligibilité versionnées, évaluées par Rights ;
- une référence Budget typée et versionnée lorsque l'offre engage une enveloppe ;
- les références nécessaires au handoff Dotation ;
- une version de schéma et un lineage vers la Version précédente.

Un espace d'extension peut subsister, mais il est non souverain : aucune activation, éligibilité, disponibilité, attribution ou écriture financière ne peut dépendre d'une clé non typée et non validée.

Offer reste propriétaire de l'identité produit et du contrat publié. Rights reste propriétaire de l'évaluation d'éligibilité. Dotation/Budget restent propriétaires des montants, plafonds, consommations et paramètres financiers qui leur appartiennent.

**Justification**

Le contrat typé est nécessaire pour supprimer K09 et K12, assurer la reproductibilité d'une Version et propager une origine stable sans déplacer les responsabilités certifiées.

**Impacts**

- futur schéma Version v2 et validations Domain/API ;
- catalogue produit à faire approuver ;
- références versionnées vers Rights, Budget et Dotation ;
- catalogues frontend ramenés à du contenu éditorial non autoritatif ;
- compatibilité explicite à prévoir pour les Versions v1 existantes.

**Préconditions**

- D01-D02 approuvées ;
- catalogue et mapping `TKR/CHDV/CESU/autre` approuvés par Produit ;
- contrats d'identifiants Budget, Rights et Dotation approuvés ;
- G1 franchie avant toute migration.

**Dépendances**

D01, D02, D07, D08 et D09 pour les contrats de référence.

**Gate concernée**

`G0 Autorité`, `G2 Cycle sécurisé`, puis `G4 Distribution`, `G5 LifeHub` et `G6 Finance`.

**Priorité MVP**

`P0 — bloquante pour l'activation et les consommateurs aval`.

### D04 — Préconditions serveur autoritatives

**Identifiant**

`D04`

**Sujet**

Déplacer les préconditions déclaratives vers des lectures serveur autoritatives.

**Contexte**

Plusieurs invariants sont actuellement transmis par le client HTTP sous forme de booléens ou de compteurs. Des repositories capables de résoudre certaines preuves existent, mais ne sont pas utilisés par le service d'exécution.

**Faits prouvés**

- K03 : `dispositifUsable`, `definitionComplete`, `requiredReferencesUsable`, `reviewComplete`, `offerPublished` et autres valeurs sont fournies par l'appelant.
- K04 : `codeExists` et `countNonTerminalByOffer` existent, mais ne sont pas appelés.
- F15 : commande, audit, outbox et idempotence sont déjà conçus dans une transaction.
- Le risque MVP qualifie ces préconditions falsifiables de critique.

**Options possibles**

1. Faire confiance aux valeurs du client.
2. Revalider seulement les actions critiques.
3. Résoudre toutes les preuves souveraines côté serveur dans la transaction de commande.

**Avantages**

- L'option 1 est simple, mais permet le contournement.
- L'option 2 réduit le travail, mais laisse une frontière de confiance ambiguë.
- L'option 3 rend les invariants cohérents, auditables et non falsifiables.

**Risques**

- Davantage de lectures et de verrouillages transactionnels seront nécessaires.
- Une matrice incomplète pourrait laisser subsister des entrées déclaratives déguisées.
- Les erreurs de concurrence doivent être exposées proprement au client.

**Décision retenue**

L'option 3 est retenue. Le client ne transmet que l'intention, les identifiants, les données éditables et les preuves externes explicitement vérifiables. Toute décision sur l'existence, l'unicité, l'état, la complétude, la séparation des tâches, les références, les opérations non terminales, les fenêtres et les blocages est résolue par l'Application depuis des repositories autoritatifs, dans la même transaction que la mutation.

Les booléens souverains présents dans les payloads actuels sont dépréciés puis supprimés du contrat public. Tant qu'ils subsistent pour compatibilité, le serveur les ignore pour décider.

**Justification**

Cette décision exploite la transaction existante et ferme directement K03-K04. Elle est indispensable avant d'ajouter une activation, faute de quoi la nouvelle transition resterait falsifiable.

**Impacts**

- matrice `invariant → source autoritative → repository → verrouillage → erreur` obligatoire ;
- évolution Application/API et tests de concurrence après GO ;
- maintien de l'idempotence et de l'audit dans la transaction ;
- aucun calcul métier souverain dans Dashboard.

**Préconditions**

- inventaire complet des invariants de chaque commande ;
- sources autoritatives accessibles avec isolation et tenant corrects ;
- stratégie de concurrence et d'erreurs approuvée.

**Dépendances**

Aucune décision préalable ; D04 conditionne D02 et D06.

**Gate concernée**

`G0 Autorité`, puis `G2 Cycle sécurisé`.

**Priorité MVP**

`P0 — sécurité bloquante`.

### D05 — Diffusion Offer vers EBS et exploitation de l'outbox

**Identifiant**

`D05`

**Sujet**

Choisir entre requête, événement ou combinaison pour alimenter EBS et opérer l'outbox.

**Contexte**

Offer écrit une outbox et fournit `ListOfferDistributionFacts`, mais aucun dispatcher, publisher ou connecteur EBS n'est monté. EBS lit actuellement Rights et Subvention sans Offer.

**Faits prouvés**

- F10 : une projection de distribution existe.
- F15 : outbox et audit sont écrits transactionnellement.
- F16 : aucun dispatcher ou publisher métier n'est composé au runtime.
- F17 : EBS ne lit aucune source Offer.
- K05 et K06 : événements sans consommateur et contrat EBS sans intégration.
- U03 : d'éventuels consommateurs externes restent inconnus.

**Options possibles**

1. Requête synchrone uniquement.
2. Événements outbox uniquement.
3. Événements pour les changements, requête autoritative pour bootstrap et réconciliation.

**Avantages**

- L'option 1 est simple à relire, mais couple EBS à la disponibilité d'Offer et ne pousse pas les suspensions.
- L'option 2 découple, mais rend bootstrap et réparation difficiles.
- L'option 3 combine propagation réactive et convergence vérifiable.

**Risques**

- L'option hybride exige idempotence, ordre, reprise, supervision et réconciliation.
- Un double traitement non protégé pourrait dupliquer les projections.
- Les consommateurs externes inconnus doivent être recensés avant changement de contrat.

**Décision retenue**

L'option 3 est retenue.

- L'outbox Offer est le mécanisme de notification des changements de cycle.
- Un dispatcher supervisé publie au minimum les événements de publication, activation, suspension, reprise, fermeture et supersession de Version.
- La livraison est `at-least-once`; chaque enveloppe porte `eventId`, `tenantId`, `offerId`, `offerVersionId`, type, version de schéma, ordre d'agrégat et horodatage.
- Rights consomme ou déclenche le recalcul ; EBS consomme la projection résultante, sans réimplémenter les règles.
- Une query autoritative remplace le bootstrap, le replay incomplet et la réconciliation.
- Le SLO MVP est : persistance outbox atomique avec la commande (`RPO = 0` pour l'événement accepté), convergence nominale EBS en moins de 60 secondes au p95, alerte si un événement reste non distribué plus de 5 minutes.

**Justification**

Le modèle hybride utilise les deux amorces déjà prouvées dans le dépôt et permet de corriger K05-K06 sans faire d'EBS une seconde source de vérité.

**Impacts**

- futur montage du dispatcher et supervision runtime ;
- contrat d'événement versionné ;
- stockage d'idempotence et contrôle d'ordre chez les consommateurs ;
- endpoint/query de réconciliation ;
- tests de replay, retry, suspension et multi-tenant.

**Préconditions**

- D01-D04 et D07 approuvées ;
- G1 et G2 franchies ;
- registre des consommateurs externes U03 levé ;
- capacité de mesure du SLO disponible avant G4.

**Dépendances**

D01, D02, D04 et D07.

**Gate concernée**

`G4 Distribution`.

**Priorité MVP**

`P1 — nécessaire avant toute valeur salarié`.

### D06 — Workbench Dashboard et habilitations

**Identifiant**

`D06`

**Sujet**

Définir le workbench Dashboard Offer et les rôles habilités.

**Contexte**

L'API Offer est montée et expose les commandes/requêtes du modèle actuel, mais aucune UI opérateur ne la consomme. Le Dashboard salarié écrit directement dans des sources legacy.

**Faits prouvés**

- F13-F14 : backend et surface HTTP Offer sont montés.
- F21 : Dashboard salarié utilise catalogue, Budget et Subvention sans Offer.
- K07 : aucune UI ne consomme l'API Offer.
- L'architecture cible impose que Dashboard commande les cas d'usage serveur sans recalcul métier.
- Le rapport exige une séparation des tâches pour la validation.

**Options possibles**

1. Accès direct aux tables Supabase.
2. UI unique donnant toutes les actions à un rôle administrateur.
3. Workbench sur API Offer, avec capacités séparées et séparation auteur/validateur.

**Avantages**

- L'option 1 est rapide, mais contourne Domain, audit et idempotence.
- L'option 2 est opérable, mais affaiblit la séparation des tâches.
- L'option 3 conserve l'autorité serveur, l'audit et le contrôle des responsabilités.

**Risques**

- Une UI qui recopie l'automate divergera du serveur.
- Des rôles trop larges recréeront un contournement de validation.
- Une gestion incorrecte des ETag/idempotency keys produira des conflits ou doublons.

**Décision retenue**

L'option 3 est retenue. Le workbench couvre : créer, modifier une Version brouillon, soumettre, demander des changements, valider, publier, activer, suspendre, reprendre, fermer, archiver, créer/versionner et piloter les Operations.

Les capacités normatives sont :

- `OFFER_EDITOR` : créer et modifier, sans valider ni publier sa propre Version ;
- `OFFER_VALIDATOR` : demander des changements ou valider, avec séparation auteur/validateur ;
- `OFFER_PUBLISHER` : publier une Version validée ;
- `OFFER_OPERATOR` : activer, suspendre, reprendre et piloter les Operations ;
- `OFFER_AUDITOR` : lecture, historique et audit uniquement.

Le cumul de capacités reste soumis à la séparation auteur/validateur. Chaque action passe par l'API Offer avec authentification, tenant, idempotency key et contrôle de concurrence. Aucune mutation directe de table n'est autorisée.

**Justification**

La décision rend le backend existant opérable sans créer de seconde logique métier dans le client et résout normativement K07.

**Impacts**

- futur workbench GDBCSE/Dashboard ;
- matrice RBAC à lier aux identifiants de rôles de la plateforme ;
- gestion explicite des états, refus, conflits et rechargement de projection ;
- aucune autorité métier conservée dans les catalogues ou plafonds frontend.

**Préconditions**

- D01-D04 implémentées et G2 franchie ;
- mapping des capacités vers le référentiel d'identité approuvé ;
- tests d'accessibilité, de séparation des tâches, de concurrence et de parcours par rôle.

**Dépendances**

D01, D02, D03 et D04.

**Gate concernée**

`G3 Dashboard`.

**Priorité MVP**

`P1 — opérabilité`.

### D07 — Rights comme dérivation d'une OfferVersion autorisée

**Identifiant**

`D07`

**Sujet**

Faire de Rights une dérivation traçable d'OfferVersion.

**Contexte**

Rights calcule depuis QF et `rights_config`, sans Offer. EBS convertit chaque item en benefit avec `available: true`, ce qui permet une disponibilité sans publication/activation Offer.

**Faits prouvés**

- F17-F18 : EBS lit Rights, puis force la disponibilité.
- F22 : Compute Rights ne lit pas Offer.
- K08 : LifeHub peut afficher une disponibilité non autoritative.
- K09 : Rights et OfferVersion portent deux configurations sans lineage.
- La migration repository de `rights_config` et de la projection Rights est absente.

**Options possibles**

1. Maintenir Rights autonome.
2. Déplacer le calcul d'éligibilité dans Offer.
3. Maintenir Rights comme moteur d'éligibilité, mais exiger une OfferVersion activée et un lineage complet.

**Avantages**

- L'option 1 évite le changement, mais conserve la double vérité.
- L'option 2 centralise, mais viole la séparation de responsabilités.
- L'option 3 conserve la spécialisation Rights tout en plaçant le produit et sa Version à l'origine.

**Risques**

- Une référence non versionnée vers les règles rendrait les recalculs non reproductibles.
- Les suspensions et supersessions peuvent créer des droits périmés si la propagation échoue.
- L'historique existant sans origine devra être identifié comme legacy.

**Décision retenue**

L'option 3 est retenue. Aucun nouveau droit disponible ne peut être produit sans :

- `tenantId`, `offerId`, `offerVersionId` ;
- preuve que la Version est celle activée ;
- référence versionnée à la règle d'éligibilité ;
- identité de la source QF/données évaluées et instant de calcul ;
- décision `eligible/available` explicite et motif ;
- identifiant causal de l'événement ou de la commande d'origine.

Rights reste le moteur d'éligibilité. Offer ne calcule pas les droits. EBS ne force jamais `available=true` : il distribue le résultat Rights seulement si l'OfferVersion reste active. Une suspension, fermeture ou supersession invalide la disponibilité selon une transition idempotente et auditée.

**Justification**

Cette solution résout K08-K09, respecte les frontières certifiées et rend le parcours jusqu'à LifeHub reproductible.

**Impacts**

- contrat de lineage Rights ;
- recalcul/invalidation piloté par les événements Offer ;
- projection EBS enrichie de la provenance ;
- données historiques sans OfferVersion marquées legacy et non utilisées pour créer de nouvelles disponibilités.

**Préconditions**

- D01-D05 et contrat Version v2 approuvés ;
- schéma Rights reproductible et versionné dans le dépôt ;
- règles d'invalidation et de replay certifiées.

**Dépendances**

D01, D02, D03 et D05.

**Gate concernée**

`G4 Distribution`, puis `G5 LifeHub`.

**Priorité MVP**

`P1 — bloquante pour LifeHub et Dashboard salarié`.

### D08 — Budget/Ledger souverain et causalité financière

**Identifiant**

`D08`

**Sujet**

Choisir le Budget/Ledger souverain et propager l'origine Offer.

**Contexte**

Le dépôt versionne `budgets` et `budget_ledger`, tandis qu'un `ledger_entries` non versionné a été observé au runtime. Subvention, Budget, Ledger et Cockpit ne portent aucune origine Offer/Version.

**Faits prouvés**

- F23 : le Cockpit lit Budget, Subvention et Ledger sans Offer.
- K10 : la finance est orpheline d'Offer.
- K11 : dépôt et photographie runtime divergent.
- Le legacy inventorié qualifie `budget_ledger` de ledger principal versionné.
- U07 : le ledger souverain et le calendrier de retrait de `ledger_entries` devaient être décidés.

**Options possibles**

1. Conserver deux ledgers mutables.
2. Faire de `ledger_entries` la cible souveraine.
3. Faire de `budget_ledger` la cible souveraine des nouveaux mouvements et traiter `ledger_entries` comme legacy en extinction.

**Avantages**

- L'option 1 évite une migration immédiate, mais maintient deux vérités.
- L'option 2 adopte l'état runtime observé, mais sans migration repository reproductible.
- L'option 3 choisit la structure versionnée et permet une migration contrôlée du runtime.

**Risques**

- L'état live actuel reste inconnu avant G1.
- Les historiques sans origine ne peuvent pas être enrichis sans preuve.
- Une double écriture non contrôlée pourrait créer des écarts comptables.

**Décision retenue**

L'option 3 est retenue sous réserve de confirmation G1.

- `budgets` est l'autorité des enveloppes, avec un état souverain unique à normaliser.
- `budget_ledger` est la cible souveraine de tous les nouveaux mouvements financiers Offer.
- `ledger_entries` est classé legacy : aucune nouvelle dépendance ne doit être créée ; sa production est neutralisée seulement après rapprochement et remplacement certifiés.
- Toute nouvelle Subvention, réservation, libération, paiement ou remboursement porte au minimum `tenantId`, `offerId`, `offerVersionId`, `budgetId`, le cas échéant `operationId` et `rightDecisionId`, ainsi qu'une clé causale/idempotente.
- Le Cockpit lit les engagements et consommations depuis les autorités ci-dessus et expose le lineage.
- Les historiques sans origine sont conservés, marqués `legacy/unattributed` et ne reçoivent aucune origine reconstruite sans preuve.

**Justification**

Le choix favorise la seule cible principale versionnée dans le dépôt et évite de certifier une table live dont la reproductibilité est inconnue. La réserve G1 empêche toute action prématurée.

**Impacts**

- futur modèle causal financier et migrations additives ;
- normalisation de l'état Budget ;
- handoff backend obligatoire pour Subvention ;
- rapprochement puis retrait du producteur `ledger_entries` ;
- Cockpit enrichi de l'origine Offer.

**Préconditions**

- G1 franchie et présence/structure live des deux ledgers qualifiée ;
- D03 et D09 approuvées ;
- règles Finance de réservation, libération, paiement et remboursement approuvées ;
- stratégie de rapprochement sans double écriture ambiguë.

**Dépendances**

D03, D07 et D09.

**Gate concernée**

`G1 Données`, puis `G6 Finance`.

**Priorité MVP**

`P2 — nécessaire avant exécution financière certifiée`.

### D09 — Propriétaire et périmètre MVP Dotation

**Identifiant**

`D09`

**Sujet**

Définir le propriétaire et le périmètre MVP de Dotation.

**Contexte**

La doctrine documentaire attribue déjà à Dotation budgets d'attribution, montants, plafonds, consommations, calculs et paramètres financiers relevant de son périmètre, mais aucun domaine Dotation exécutable ni propriétaire runtime n'existe.

**Faits prouvés**

- La connexion Offer → Dotation est absente.
- Aucun agrégat, table, API, événement, projection ou test Dotation exécutable n'a été trouvé.
- U06 : le futur propriétaire du moteur était inconnu.
- L'architecture cible certifiée distingue Offer, Dotation, Rights et EBS.

**Options possibles**

1. Intégrer Dotation dans Offer.
2. Intégrer Dotation dans Rights ou EBS.
3. Créer un bounded context Dotation souverain distinct, gouverné par le Domain Board avec responsabilité Finance/Dotation.

**Avantages**

- L'option 1 simplifie le flux, mais mélange produit et attribution financière.
- L'option 2 réutilise des moteurs aval, mais ferait de Rights/EBS une autorité financière.
- L'option 3 respecte la séparation certifiée et évite un second catalogue ou ledger.

**Risques**

- Le contexte n'existe pas encore : aucune implémentation n'est autorisée par cette décision seule.
- Un périmètre trop large dupliquerait Budget/Ledger.
- Un handoff insuffisamment versionné casserait la causalité.

**Décision retenue**

L'option 3 est retenue. Dotation devient le bounded context souverain de l'**attribution et de la délivrance** d'un avantage autorisé :

- il consomme une OfferVersion active, une décision Rights éligible et une référence Budget valide ;
- il applique les paramètres d'attribution, montants et plafonds relevant de Dotation ;
- il produit une décision d'attribution/délivrance idempotente et traçable ;
- il demande les mouvements à Budget/Ledger sans tenir de ledger parallèle ;
- il ne définit ni le catalogue produit, ni l'éligibilité, ni la présentation EBS.

La responsabilité d'architecture et de données est portée par le `Domain Board Dotation/Finance`; l'exploitation doit avoir un owner nommé avant entrée en G7. Le handoff canonique part de l'activation d'OfferVersion et de la décision Rights, puis conserve leurs identifiants causaux.

**Justification**

Ce découpage applique exactement la doctrine certifiée et ferme l'absence de propriétaire architectural sans inventer un second moteur dans Offer, Rights ou EBS.

**Impacts**

- context map officiel à produire avant implémentation ;
- contrat de handoff versionné ;
- aucune table ou logique Dotation dans CEREBRAU Runtime ;
- extension Dotation placée après le noyau MVP Offer/Rights/EBS/Finance.

**Préconditions**

- D01-D03, D07 et D08 approuvées ;
- owner d'exploitation nominativement désigné ;
- context map, contrats d'identifiants et responsabilités de données signés ;
- G1 à G6 franchies avant implémentation Dotation.

**Dépendances**

D03, D07 et D08.

**Gate concernée**

`G7 Legacy/Dotation`.

**Priorité MVP**

`P3 — extension après le noyau MVP, aucune implémentation avant G7`.

### D10 — Coexistence et retrait du legacy

**Identifiant**

`D10`

**Sujet**

Définir la stratégie de coexistence et de retrait des producteurs legacy.

**Contexte**

Deux catalogues salarié, des plafonds frontend, Rights autonome, des demandes Subvention directes, plusieurs indicateurs Budget, deux ledgers potentiels, des règles de simulation et des benefits EBS transitoires restent exécutés. Un retrait prématuré créerait des consommateurs orphelins.

**Faits prouvés**

- K12 : plusieurs catalogues et règles coexistent.
- Les sections 10 et 13 qualifient le risque de retrait prématuré d'élevé.
- Le rapport décide déjà qu'aucun legacy ne doit être supprimé avant remplacement, coexistence et non-régression certifiés.
- U08 : la stratégie et l'échéance de retrait des catalogues/plafonds frontend restaient inconnues.

**Options possibles**

1. Bascule globale immédiate.
2. Double écriture permanente.
3. Remplacement progressif par consommateur, avec lecture comparée, preuve, bascule et retrait borné.

**Avantages**

- L'option 1 est rapide, mais sans rollback ni preuve E2E.
- L'option 2 facilite la coexistence, mais institutionnalise deux vérités mutables.
- L'option 3 réduit le risque et permet de fermer chaque source legacy avec une preuve ciblée.

**Risques**

- Une coexistence sans date relative ni métrique peut devenir permanente.
- Une comparaison non causale peut masquer des divergences.
- La suppression physique avant expiration du rollback détruirait la capacité de reprise.

**Décision retenue**

L'option 3 est retenue selon le protocole obligatoire suivant :

1. inventorier producteur, consommateurs, données et métriques ;
2. livrer la source cible et son lineage ;
3. exécuter une lecture comparée sans donner d'autorité au legacy ;
4. corriger les écarts et certifier la non-régression ;
5. basculer un consommateur par feature flag ou configuration réversible ;
6. geler les nouvelles écritures legacy ;
7. observer au minimum un cycle de release complet sans rollback ;
8. retirer le producteur, puis sa structure seulement après décision de Gate.

Les échéances sont liées aux Gates, car G1 est encore inconnu :

- après `G4 GO` : Rights/EBS ne créent plus de disponibilité sans lineage OfferVersion ;
- après `G5 GO` : LifeHub et Dashboard salarié ne prennent plus de décision depuis les catalogues/plafonds frontend ;
- après `G6 GO` : aucune nouvelle Subvention ou écriture financière n'est créée sans origine Offer ;
- à `G7 GO` : les producteurs legacy qualifiés peuvent être retirés après le cycle de rollback.

Les catalogues frontend peuvent rester comme contenu éditorial, mais ne portent plus disponibilité, plafond, éligibilité ou décision financière. La simulation reste strictement prévisionnelle et ne devient jamais source d'exécution.

**Justification**

Cette stratégie respecte l'interdiction de suppression prématurée, empêche la double écriture permanente et donne un ordre de sortie vérifiable sans inventer une date calendaire impossible à garantir avant G1.

**Impacts**

- registre de coexistence par consommateur ;
- métriques de divergence et feature flags réversibles ;
- marquage explicite des historiques legacy ;
- retrait séquencé par G4 à G7.

**Préconditions**

- source cible et tests E2E disponibles pour chaque consommateur ;
- métriques, rollback et owner du retrait définis ;
- Gate du domaine consommateur atteinte.

**Dépendances**

D03, D05-D09.

**Gate concernée**

`G4`, `G5`, `G6` et `G7`.

**Priorité MVP**

`P2 continu — retrait final après preuve, jamais avant remplacement`.

## 4. Architecture cible consolidée

### 4.1 Responsabilités

| Contexte | Responsabilité souveraine | Interdiction |
|---|---|---|
| Offer | identité économique, catalogue produit, OfferVersion typée, validation, publication, activation et cycle fonctionnel | calculer Rights, tenir les attributions ou le ledger |
| Operation Offer | fenêtre d'exécution d'une Version activée | servir de substitut à l'activation Offer |
| Rights | évaluer l'éligibilité et produire une décision versionnée sourcée OfferVersion | définir le produit ou forcer une disponibilité sans activation |
| Dotation | attribuer/délivrer selon Rights, OfferVersion et Budget ; appliquer ses paramètres financiers | définir le catalogue, l'éligibilité ou un ledger parallèle |
| Budget | gouverner les enveloppes et leur état souverain | accepter une nouvelle consommation sans origine |
| Ledger | enregistrer les mouvements causaux et idempotents dans `budget_ledger` | maintenir deux ledgers souverains |
| EBS | consolider et distribuer les faits Offer/Rights/Dotation | recalculer le métier ou porter un catalogue parallèle |
| Dashboard opérateur | commander les cas d'usage Offer via API | muter directement les tables ou dupliquer l'automate |
| LifeHub / Dashboard salarié | présenter les offres et droits réellement disponibles depuis EBS | décider depuis des constantes ou catalogues locaux |
| Cockpit financier | lire engagements, consommations et lineage | devenir producteur de décisions financières |
| CEREBRAU Runtime | orchestrer missions, preuves et gouvernance WAVE | contenir de la logique métier Offer/Dotation |

### 4.2 Flux cible

```text
Dashboard opérateur
  → commande API Offer
  → OfferVersion DRAFT → IN_REVIEW → VALIDATED → PUBLISHED
  → ActivateOffer à/au-delà de effectiveAt
  → OfferVersion ACTIVE
  → événement Outbox supervisé
  → Rights : décision éligible/non éligible avec lineage
  → EBS : projection consolidée, sans recalcul
  → LifeHub / Dashboard salarié
  → Dotation : attribution/délivrance
  → Subvention / Budget / budget_ledger
  → Cockpit financier
```

En parallèle, `Operation DRAFT → SCHEDULED → OPEN` reste un cycle distinct. `OPEN` exige une OfferVersion `ACTIVE` et une fenêtre valide.

### 4.3 Invariants transverses

- tenant, identifiants, état, références et séparation des tâches sont vérifiés côté serveur ;
- toutes les mutations sont idempotentes et auditables ;
- publication, activation, décision Rights, attribution et mouvement financier conservent une chaîne causale ;
- suspension et fermeture rendent la disponibilité aval invalide de manière idempotente ;
- bootstrap et réconciliation utilisent une query autoritative ; les changements transitent par l'outbox ;
- aucun historique sans preuve n'est réécrit comme s'il avait toujours eu un lineage Offer.

## 5. Contradictions résolues par décision

| Contradiction | Décision(s) | Résolution normative |
|---|---|---|
| K01 — `PUBLISHED` distribuable vs activation distincte | D01, D02 | `PUBLISHED` devient administratif ; `ACTIVE` est requis pour distribuer |
| K02 — `effectiveAt` sans effet | D02 | date minimale d'autorisation ; activation explicite seulement à/au-delà |
| K03 — invariants fournis par le client | D04 | preuves résolues côté serveur dans la transaction |
| K04 — repositories disponibles mais inutilisés | D04 | matrice invariant→repository obligatoire |
| K05 — outbox sans dispatcher | D05 | dispatcher supervisé et contrat idempotent obligatoires |
| K06 — EBS désigné mais non raccordé | D05, D07 | événements + query, Rights sourcé, EBS consolidateur |
| K07 — Dashboard sans UI Offer | D06 | workbench API-only et RBAC séparé |
| K08 — EBS force `available=true` | D07 | disponibilité issue de Rights et conditionnée par l'activation |
| K09 — OfferVersion et `rights_config` sans lineage | D03, D07 | références versionnées et lineage obligatoire |
| K10 — finance sans origine Offer | D03, D08, D09 | références Budget, handoff Dotation et causalité financière |
| K12 — catalogues et règles concurrents | D03, D06, D07, D10 | OfferVersion autoritative ; frontend éditorial ; retrait par consommateur |

**Nombre de contradictions résolues par décision : 11.**

Ces contradictions sont résolues **normativement**. Leur matérialisation dans le code reste interdite tant que les Gates correspondantes ne sont pas franchies.

## 6. Contradictions restant ouvertes

| Contradiction | Motif d'ouverture | Condition de clôture |
|---|---|---|
| K11 — migration Offer présente dans le dépôt, tables `offer_*` absentes de la photographie runtime du 19 juillet | l'état live au 23 juillet et l'historique distant n'ont pas été observés ; aucune nouvelle exploration n'était autorisée | inventaire live read-only, historique/hashes de migrations, présence des vues/tables, validation RLS et rapprochement dépôt/runtime à G1 |

**Nombre de contradictions ouvertes : 1.**

K11 n'est pas arbitrable par doctrine : elle nécessite une preuve d'état externe. Aucune conclusion de présence ou d'absence actuelle n'est prononcée.

## 7. Décisions différées

Aucune des décisions principales `D01` à `D10` n'est différée. Les précisions d'exécution suivantes restent subordonnées aux preuves et Gates :

| Élément différé | Motif | Autorité / Gate |
|---|---|---|
| état live exact des tables/vues Offer et historique de migration | U01-U02, K11 | Data/DB — G1 |
| consommateurs externes de l'API/outbox | U03 | Integration — avant G4 |
| mapping métier détaillé `TKR/CHDV/CESU/autre` | U05 ; le contrat typé est décidé, le contenu du catalogue doit être approuvé | Product/Offer — avant G2/G5 |
| identifiants réels du référentiel IAM correspondant aux capacités D06 | le rapport ne les établit pas | Security — avant G3 |
| owner d'exploitation nominatif de Dotation | l'owner architectural est décidé, l'organisation nominative ne figure pas dans les preuves | Domain Board — avant G7 |
| date calendaire de retrait de chaque legacy | dépend des dates réelles de franchissement G4-G7 | Program Director — à chaque Gate |

Ces différés ne rouvrent pas l'architecture retenue et n'autorisent aucune option concurrente.

## 8. Gates G0 puis G1

### G0 — Autorité

| Critère | État après présente décision |
|---|---|
| D01-D04 rendues | satisfait |
| distinction Publish / Activate / Open | satisfaite |
| supersession explicite de `PUBLISHED = distribuable` | satisfaite dans ce document officiel |
| décision unique pour chaque sujet | satisfaite |

**Verdict G0 : `GO`.**

Le présent document atteint G0 sur le plan documentaire. Il n'autorise encore aucune modification technique.

### G1 — Données

| Critère | État |
|---|---|
| schéma live Offer présent et inventorié | inconnu |
| historique et hashes des migrations alignés | inconnu |
| CHECK, vues, contraintes et RLS concordants | inconnu |
| stratégie additive compatible avec les données live | non établie |

**Verdict G1 : `NO_GO`.**

Le programme reste arrêté avant implémentation. Le prochain acte autorisé est une mission distincte de preuve read-only du schéma DEV/Supabase et de l'historique de migrations.

## 9. Ordre de mise en œuvre MVP

Cet ordre est technique et ne constitue pas des work packages officiels.

| Ordre | Séquence | Décisions appliquées | Gate de sortie | Résultat exigé |
|---:|---|---|---|---|
| 0 | autorité documentaire | D01-D04 | G0 | présent document approuvé |
| 1 | réconciliation live dépôt/runtime | D01-D04, D08 | G1 | schéma, migrations et RLS certifiés |
| 2 | automate sécurisé et Version v2 | D01-D04 | G2 | publication non distribuable, activation auditée, invariants serveur |
| 3 | workbench opérateur | D06 | G3 | parcours create→activate via API, RBAC et SOD |
| 4 | outbox, Rights lineage et EBS | D05, D07 | G4 | propagation mesurée, disponibilité déterministe |
| 5 | LifeHub et Dashboard salarié | D03, D07, D10 | G5 | avantages sourcés, aucune autorité frontend |
| 6 | Subvention, Budget, Ledger et Cockpit | D08-D10 | G6 | origine Offer/Version sur tout nouveau flux financier |
| 7 | Dotation et retrait final du legacy | D09-D10 | G7 | owner opérationnel, attribution unique, producteurs parallèles retirés |

Règle de séquencement : aucune séquence ne commence avant le `GO` de la Gate précédente. En particulier, aucun code, schéma ou Runtime ne doit être modifié à la suite de cette mission tant que G1 reste `NO_GO`.

## 10. Verdict officiel

```text
MissionId: OFFER-ARCHITECTURE-BOARD-DECISION-001
Verdict: NO_GO — 10 décisions d'architecture approuvées, mise en œuvre interdite avant G1 GO
Décisions traitées: 10/10
Décisions restantes: 0
Contradictions résolues: 11/12 — K01 à K10 et K12
Contradictions ouvertes: 1/12 — K11
Gate atteinte: G0 Autorité — GO
Point de reprise exact: G1 Données — mission read-only d'inventaire du schéma DEV/Supabase Offer, rapprochement de l'historique et des hashes de migrations, puis validation des contraintes, vues et RLS avant toute implémentation
```
