# CEREBRAU — étude d'impact de la configuration de mission

| Champ | Valeur |
|---|---|
| Mission d'audit | `CEREBRAU-MISSION-CONFIG-IMPACT-001` |
| Programme déclaré | `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001` |
| Type | `AUDIT_READ_ONLY` |
| Mode | `MVP` |
| Date de constat | `2026-07-23` |
| Décision | **GO AVEC CONDITIONS** |

## 1. Résumé exécutif

### Décision

**GO AVEC CONDITIONS** : `tools/cerebrau/mission.json` ne doit pas être remplacé pour lancer `MO-OFFER-001`. La méthode sûre est de préparer un manifeste de mission dédié, avec un prompt et un répertoire de rapports dédiés, puis de transmettre explicitement ce manifeste au runtime avec `-MissionFile`.

### Qualification factuelle de `mission.json`

| Qualification étudiée | Conclusion |
|---|---|
| Configuration permanente du runtime | **NON.** Le fichier n'est que la valeur par défaut du paramètre `MissionFile`. Les paramètres de modèle, reasoning, sandbox et approval viennent du profil résolu. |
| Modèle de mission réutilisable | **NON.** Son contenu est une instance concrète `ORCH-001`, avec programme, lot, prompt, branche et chemins absolus. |
| Fichier temporaire remplacé à chaque mission | **NON AUTOMATIQUEMENT.** Aucun script de production analysé ne l'écrit ou ne le remplace. Son état Git montre toutefois qu'il a été réaffecté manuellement dans le working tree. |
| Source de vérité CEREBRAU | **OUI, MAIS SEULEMENT POUR UNE EXÉCUTION QUI LE SÉLECTIONNE.** Sans `-MissionFile`, il fournit l'identité et le contrat de mission au runtime. Il n'est ni l'unique manifeste du dépôt, ni la source de vérité des campagnes. |

### Risque principal

`tools/cerebrau/mission.json` est actuellement une modification non commitée : le `HEAD` contient `LOCAL-DEVELOPMENT / PROGRAM-006 / LOT-004`, tandis que le working tree contient `ORCH-001 / PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001 / LOT-001`. Le remplacer par `MO-OFFER-001` ferait disparaître du working tree le manifeste concret d'`ORCH-001`. Les rapports existants resteraient physiquement présents, mais la reproduction exacte d'`ORCH-001` serait dégradée, car le rapport officiel n'archive pas le manifeste complet ni le contenu du prompt.

Un inventaire en lecture seule des rapports directement placés sous `tools/cerebrau/reports/bootstrap-*` a trouvé **58 rapports officiels portant `ORCH-001`** entre `bootstrap-20260719T141948835` et `bootstrap-20260723T094336872`. Un rapport Offer existant constate déjà que des runs Offer ont été journalisés sous l'identité obsolète `ORCH-001` et précise que cette incohérence historique n'a pas été réécrite.

## 2. Périmètre analysé

### Fichiers principaux

- `tools/cerebrau/mission.json`
- `tools/cerebrau/Invoke-CerebrauMission.ps1`
- `tools/cerebrau/Test-CerebrauMission.ps1`
- `tools/cerebrau/Resolve-CerebrauProfile.ps1`
- `tools/cerebrau/Invoke-CerebrauCampaign.ps1`
- `tools/cerebrau/Cerebrau.Campaign.psm1`
- `tools/cerebrau/Cerebrau.Reporting.psm1`
- `tools/cerebrau/campaign-manifest.schema.json`
- `tools/cerebrau/campaign-report.schema.json`
- `tools/cerebrau/campaign-state.schema.json`

### Contexte strictement nécessaire

- appels à `Invoke-CerebrauMission.ps1` dans les scripts et tests ;
- lecture optionnelle du manifeste par `tools/cerebrau/Cerebrau.ContextAssembly.psm1` ;
- manifestes de mission et de campagne nécessaires pour prouver l'usage de `MissionFile`, `missionId`, `program` et `lot` ;
- rapports CEREBRAU existants nécessaires pour prouver la traçabilité d'`ORCH-001` ;
- état Git et historique du seul fichier `tools/cerebrau/mission.json`.

### Recherches effectuées

Les recherches ont couvert, avec lecture du contexte des résultats : `mission.json`, `MissionFile`, `missionId`, `program`, `lot`, `missionType`, `Invoke-CerebrauMission.ps1`, `Test-CerebrauMission.ps1`, `reportDirectory`, `CampaignFile` et `ResumeReportPath`.

Commandes de contrôle représentatives :

```powershell
rg -n -C 3 "mission\.json|MissionFile|missionId|program|lot|missionType|reportDirectory|CampaignFile|ResumeReportPath" tools/cerebrau
rg -n -C 2 --glob "*.ps1" --glob "*.psm1" "Invoke-CerebrauMission\.ps1" .
git status --short -- tools/cerebrau/mission.json tools/cerebrau/prompt.md
git diff -- tools/cerebrau/mission.json
```

Le validateur courant a également été exécuté en lecture seule avec le manifeste existant :

```powershell
& ".\tools\cerebrau\Test-CerebrauMission.ps1" -MissionFile ".\tools\cerebrau\mission.json"
```

Résultat observé : `Status = VALID`, `MissionId = ORCH-001`, branche `fix/simulation-star`. Aucune mission CEREBRAU n'a été lancée.

### Vérification du répertoire documentaire

`Docs/PROGRAM/OFFER` existait au début de la présente vérification. Aucun répertoire n'a été créé. Aucun `AGENTS.md` n'a été trouvé dans le dépôt.

## 3. Consommateurs de `mission.json`

### Consommateurs directs et conditionnels

| Fichier exact | Bloc / extrait probant | Effet constaté | Risque | Conclusion factuelle |
|---|---|---|---|---|
| `tools/cerebrau/Invoke-CerebrauMission.ps1:1-7` | `[string]$MissionFile = "$PSScriptRoot\mission.json"` | Sélectionne le fichier par défaut uniquement si l'appelant ne fournit pas `-MissionFile`. | Élevé pour les appels implicites | `mission.json` est une entrée par défaut, pas une constante obligatoire. |
| `tools/cerebrau/Invoke-CerebrauMission.ps1:31-47` | `Get-Content $MissionFile`; `reportDirectory`; création d'un `runDirectory` | Lit le manifeste sélectionné avant validation et choisit la racine des rapports. | Élevé | Un changement du fichier par défaut change l'identité et la destination des futurs runs implicites. |
| `tools/cerebrau/Invoke-CerebrauMission.ps1:155-168` | `& $missionValidator -MissionFile $MissionFile`; `Get-Content $MissionFile`; affectation de `missionId`, `program`, `lot` | Valide et relit exactement le chemin transmis. | Élevé | Un fichier dédié est pris en charge nativement sans copie vers le fichier par défaut. |
| `tools/cerebrau/Test-CerebrauMission.ps1:1-12` | même valeur par défaut, puis `Get-Content $MissionFile -Raw` | Valide le fichier fourni ou, à défaut, `mission.json`. | Moyen | Le validateur n'impose aucun remplacement du manifeste par défaut. |
| `tools/cerebrau/Cerebrau.ContextAssembly.psm1:67-84` | paramètre obligatoire `MissionFile`; `ReadAllText($missionPath)` | Relit le même manifeste lorsque l'assemblage de contexte est activé. | Moyen | C'est un consommateur conditionnel du manifeste sélectionné, pas spécifiquement du fichier par défaut. |
| `tools/cerebrau/Cerebrau.Campaign.psm1:335-366` | résolution de `entry.missionFile`, lecture JSON, validation avec `-MissionFile $missionFile` | Chaque unité de campagne possède son propre manifeste. | Élevé en campagne | La campagne ne copie pas l'unité dans `tools/cerebrau/mission.json`. |
| `tools/cerebrau/Cerebrau.Campaign.psm1:729-752` | appel `Invoke-CerebrauMission.ps1 -MissionFile $missionValidation.MissionFile` | Le dispatcher passe explicitement le fichier dédié. | Faible si manifeste dédié | Le chemin dédié est le mode de fonctionnement normal des campagnes. |

### Non-consommateurs du fichier

- `Resolve-CerebrauProfile.ps1` ne lit pas le manifeste : il reçoit seulement `ProfileName` et lit le registre de profils.
- `Cerebrau.Reporting.psm1` ne lit pas `mission.json` : il reçoit l'objet mission déjà chargé.
- `Invoke-CerebrauCampaign.ps1` ne lit pas directement un manifeste de mission : il délègue au module Campaign.
- Les rapports et snapshots existants contiennent des projections ou des hashes ; ils ne pilotent pas automatiquement le runtime de mission.

### Appels de production et appels de test

L'appel de production direct identifié est dans `Cerebrau.Campaign.psm1:749-751`. Les autres appels exécutables trouvés sont des tests :

- `tools/cerebrau/Test-CerebrauContextRuntime.ps1:64,74,95`
- `tools/cerebrau/Test-CerebrauRuntimeE2E.ps1:43,140`
- `tools/cerebrau/tests/campaign/Test-CampaignResume.ps1:25`
- `tools/cerebrau/Test-CerebrauExceptionCapture.ps1` référence le runtime dans son fixture.

Les guides et rapports qui montrent `Invoke-CerebrauMission.ps1 -MissionFile <manifest>` sont documentaires, pas des producteurs de configuration.

## 4. Producteurs ou scripts de remplacement

### Faits prouvés

1. Aucun chemin d'écriture vers le paramètre `$MissionFile` n'existe dans le runtime, le validateur, le resolver, le reporting ou le module Campaign analysés.
2. Les écritures du runtime ciblent les répertoires de rapports : journal, transcript, snapshots, delta et rapports officiels (`Invoke-CerebrauMission.ps1:41-47, 243-245, 335-350, 419-420`).
3. Les écritures Campaign ciblent l'état, le journal, les rapports, l'index de preuve, les métriques et les bundles (`Cerebrau.Campaign.psm1:396-435, 537-559, 777-811`).
4. `Test-CerebrauContextRuntime.ps1:5-6,52-56` crée un fichier nommé `mission.json` dans un répertoire temporaire propre au test. Il n'écrit pas `C:\DEV\veedda-cseV7-core\tools\cerebrau\mission.json`.
5. L'état Git prouve une modification manuelle ou externe au commit courant, mais ne permet pas d'identifier son auteur ou son mécanisme :

```diff
-  "missionId": "LOCAL-DEVELOPMENT",
-  "program": "PROGRAM-006",
-  "lot": "LOT-004",
+  "missionId": "ORCH-001",
+  "program": "PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001",
+  "lot": "LOT-001",
+  "missionType": "PROGRAM_ORCHESTRATION",
```

### Conclusion

Il n'existe **aucun producteur automatique de production identifié** qui remplace le fichier par défaut à chaque mission. Le fichier est un artefact versionné mais actuellement modifié dans le working tree. Toute réaffectation à `MO-OFFER-001` serait donc une modification explicite, non une étape requise par CEREBRAU.

## 5. Validation des champs

### Contrat du validateur de mission

`Test-CerebrauMission.ps1:14-25` exige seulement :

```text
schemaVersion, missionId, program, lot, title, profile, repository,
expectedBranch, promptFile, workingDirectory, enabled
```

Le script ne contrôle ni le type, ni la non-vacuité, ni une expression régulière pour `missionId`, `program` ou `lot`. Il ne vérifie pas non plus la valeur de `schemaVersion`. Il vérifie en revanche :

- l'activation (`enabled`) ;
- l'existence du repository, du working directory et du prompt ;
- l'égalité repository / working directory ;
- la résolution du profil ;
- les types de validations autorisés ;
- la sécurité des chemins de scope ;
- le confinement de `reportDirectory` dans le repository ;
- la branche Git attendue.

### `missionType`

Une recherche sur les scripts sélectionnés et les trois schémas a retourné **zéro occurrence** de `missionType`. Le champ n'est ni requis, ni lu, ni reporté, ni contraint.

**Réponse factuelle à la question 8 : NON**, `missionType` n'est pas soumis à une liste de valeurs autorisées dans le validateur ou les schémas actuels.

**Réponse factuelle à la question 9 : `IMPLEMENTATION` est accepté de fait**, car le validateur ignore entièrement le champ. Cela ne constitue pas une certification sémantique : CEREBRAU ne distingue actuellement pas `IMPLEMENTATION` d'une autre chaîne arbitraire.

### Valeurs proposées

| Valeur | Validation technique actuelle | Convention observée | Conclusion |
|---|---|---|---|
| `MO-OFFER-001` comme `missionId` | Acceptée par le validateur autonome ; non-vide exigé seulement en campagne. | Majuscules et segments séparés par tirets, cohérents avec les identifiants existants. | **Conforme techniquement et stylistiquement**, mais doit rester unique dans toute campagne. |
| `IMPLEMENTATION` comme `missionType` | Ignorée, donc non rejetée. | Non observée dans les manifestes de mission inventoriés. | **Autorisée techniquement, non gouvernée sémantiquement.** |
| `PROGRAM OFFER` comme `program` | Le validateur autonome l'accepterait ; une campagne exige seulement une chaîne non vide et l'égalité avec `programId`. | Les identifiants CEREBRAU de programme observés sont hyphénés (`PROGRAM-VEEDDA-...`, `PROGRAM-CEREBRAU-...`). `PROGRAM OFFER` apparaît comme titre documentaire, pas comme identifiant CEREBRAU prouvé. | **Non recommandé.** Techniquement accepté, mais non conforme à la convention d'identifiant observée et non rattaché à un registre prouvé. |
| `LOT-OFFER-001` comme `lot` | Accepté par le validateur ; la campagne exige l'égalité avec `lotId`. | Forme majuscule hyphénée compatible avec des lots thématiques existants. | **Conforme techniquement et stylistiquement, gouvernance inconnue.** Son existence officielle n'est prouvée par aucun registre du périmètre. |

### Schémas

- `campaign-manifest.schema.json:82-94` contraint les **entrées de campagne**, pas les fichiers de mission unitaires.
- `missionId` et `lotId` n'y ont qu'une contrainte `minLength: 1`.
- `executionMode`, distinct de `missionType`, est limité à `READ_ONLY_EVIDENCE`, `DOCUMENTARY_WRITE` ou `RUNTIME_MUTATION`.
- Aucun fichier `mission.schema.json` n'existe sous `tools/cerebrau`.

## 6. Utilisation de `MissionFile`

### Réponse

**OUI.** Le paramètre permet d'utiliser un fichier distinct sans remplacer le fichier par défaut.

Preuves :

- `Invoke-CerebrauMission.ps1:2` définit seulement une valeur par défaut ;
- `Invoke-CerebrauMission.ps1:32,156,164,251` propage toujours la variable `$MissionFile` ;
- `Test-CerebrauMission.ps1:2,8,12` valide le même chemin ;
- `Cerebrau.Campaign.psm1:749-751` utilise explicitement un manifeste dédié.

### Plusieurs fichiers de mission

Un inventaire structurel des JSON possédant les onze propriétés requises a trouvé **14 manifestes de mission persistés** :

- `tools/cerebrau/mission.json` ;
- huit manifestes `tools/cerebrau/missions/veedda/MM-L*.json` ;
- trois manifestes de démonstration `tools/cerebrau/campaigns/demo/demo-*.json` ;
- `Docs/AUDITS/VEEDDA_AUDIT_001/cerebrau-mission.json` ;
- `Docs/VEEDDA_FULL_SYSTEM_CARTOGRAPHY/cerebrau-mission.json`.

Les manifestes `MM-L*` définissent chacun un prompt et un `reportDirectory` dédiés. Cette structure est la preuve la plus forte de la convention réutilisable actuelle.

## 7. Impact sur `ORCH-001`

### Preuves existantes

`tools/cerebrau/reports/bootstrap-20260721T115225170/official-report.json:3-7` contient :

```json
"Mission": {
  "MissionId": "ORCH-001",
  "Program": "PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001",
  "Lot": "LOT-001",
  "Title": "Correction d'orchestration - declaration du PROGRAM actif"
}
```

Le même rapport, lignes 37-53, rattache à ce run la création de `Docs/PROGRAM/PROGRAM_DIRECTOR_STATUS_REPORT.md`. Son journal, lignes 9-18, répète `missionId`, `program` et `lot` à chaque étape après lecture de la mission.

`Docs/04_MODULES/OFFERS/OFFER_CANONICAL_RECONCILIATION_RESUME_REPORT.md:95-100` constate explicitement que le manifeste et les journaux portent encore `ORCH-001` alors que le prompt exécuté porte une mission Offer, et conserve cette incohérence comme preuve historique.

### Effets d'un remplacement

| Effet | Niveau de risque | Conclusion |
|---|---|---|
| Les rapports historiques existants seraient-ils supprimés ? | Faible | Non. Les runs ont des sous-répertoires horodatés distincts. |
| Les futurs appels sans `-MissionFile` changeraient-ils d'identité ? | Critique | Oui. Ils seraient journalisés et reportés sous `MO-OFFER-001`. |
| Le manifeste concret `ORCH-001` resterait-il disponible ? | Critique | Non garanti. Il n'est pas dans le `HEAD` et serait masqué par une nouvelle modification du même fichier. |
| Les rapports suffisent-ils à rejouer exactement `ORCH-001` ? | Élevé | Non. Le rapport officiel ne contient que quatre champs Mission et n'archive pas le manifeste complet ni le prompt. |
| Remplacer le manifeste corrigerait-il les anciens runs Offer mal étiquetés ? | Élevé | Non. Les preuves historiques ne doivent pas être réécrites ; le remplacement ne ferait que changer les runs futurs. |

### Réponse à la question 12

**OUI.** Modifier le fichier par défaut peut masquer ou rendre non reproductible la configuration `ORCH-001`. Le mot « détruire » est factuellement applicable au contenu courant du working tree si aucune copie distincte n'est créée avant remplacement ; il ne s'applique pas aux rapports historiques déjà persistés.

## 8. Impact sur les campagnes

### Frontière de programme et de lot

`Cerebrau.Campaign.psm1:335-343` vérifie que :

```text
unit.missionId == entry.missionId
unit.program   == manifest.programId
unit.lot       == entry.lotId
unit.expectedBranch == manifest.expectedBranch
```

Le manifeste `tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json:4-15` déclare :

- `programId = PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001` ;
- une autorité `MASTER_GATES_MATRIX` avec chemin et SHA-256 ;
- `programDecision = NO_GO`.

Ses lignes 50-68 référencent le fichier dédié `tools/cerebrau/missions/veedda/MM-L01-03.json`, et non le manifeste par défaut.

### Reprise

La reprise Campaign ne repose pas sur le seul `missionId` :

- `campaignFingerprint` doit rester identique (`Cerebrau.Campaign.psm1:462-493`) ;
- l'empreinte d'entrée combine fingerprint de campagne, hash du manifeste de mission, hash du prompt et hashes des preuves requises (`:563-569`) ;
- l'état et le journal persistent `missionId`, tentatives et résultats (`:422-445`) ;
- un rapport récupérable n'est importé que si son `Mission.MissionId` correspond (`:689-724`) ;
- `ResumeReportPath` n'est fourni au runtime que lors d'une reprise gouvernée (`:729-751`).

### Impact du fichier par défaut

Les campagnes actuelles qui référencent des manifestes `MM-L*` dédiés ne dépendent pas directement de `tools/cerebrau/mission.json`. Si une campagne externe ou future le référence, toute modification de son hash peut rendre une reprise obsolète ou interdite. Aucun appel externe au dépôt ne peut être exclu par cette étude locale.

## 9. Impact sur le reporting et les preuves

### Usage de `missionId`

`missionId` a plusieurs rôles :

1. **Métadonnée runtime** : journal d'exécution (`Invoke-CerebrauMission.ps1:49-61`).
2. **Clé de reporting** : objet `Mission` et `ResumePoint` (`Cerebrau.Reporting.psm1:299-327`).
3. **Identifiant fonctionnel de campagne** : unicité, dépendances, evidence consumers, ready-set et revue (`Cerebrau.Campaign.psm1:195-211, 312-340, 572-595, 929-940`).
4. **Clé de reprise et d'intégrité** : état, tentatives, récupération de rapport et fingerprints (`:439-501, 563-569, 689-765`).

Il n'est donc **pas une simple métadonnée** dans le fonctionnement Campaign. Pour une mission autonome, son rôle de reprise est limité au `ResumePoint` reporté ; aucun moteur de reprise autonome n'a été trouvé.

### Usage de `program`

- Le runtime autonome le copie dans le journal et le rapport.
- Le resolver de profil ne le consulte pas.
- Le validateur autonome ne consulte aucune constitution, campagne ou registre de programme.
- En campagne, il est contrôlé par égalité avec `programId`, puis la campagne lie son exécution à une source d'autorité hashée, un rapport de certification et une `programDecision`.
- L'état de campagne refuse une frontière `programId/programDecision` incohérente (`Cerebrau.Campaign.psm1:471-485`).
- Les faits certifiés fournis à la mission déclarent `WAVE` comme objet de gouvernance officiel et `WORK_PACKAGES = NOT_OFFICIAL`. Un champ `program` ou `lot` dans un manifeste ne peut donc pas, à lui seul, créer un nouvel objet de gouvernance officiel ni transformer Offer en PROGRAM, LOT ou Work Package officiel.

Conclusion : `program` est **faiblement gouverné en exécution autonome** et **borné par le manifeste et l'autorité de campagne en exécution Campaign**. Aucun registre global de PROGRAM n'est interrogé par les scripts analysés.

### Usage de `lot`

- Le runtime le journalise et le reporte.
- Le reporting n'utilise pas `lot` pour construire le chemin du rapport.
- Les preuves partagées Campaign sont rattachées à leurs `consumers` par `missionId`, pas par `lot`.
- La campagne vérifie toutefois `unit.lot == entry.lotId`, ce qui rattache fonctionnellement la mission à son lot déclaré.
- Les décisions Campaign restent des projections d'orchestration ; le disclaimer du schéma et du rapport interdit de les interpréter comme création ou modification d'une décision Gate, LOT ou PROGRAM.

Conclusion : `lot` est un attribut de traçabilité et une frontière de cohérence Campaign, mais **pas la clé directe de stockage des preuves, des rapports ou des décisions**.

### Préservation des preuves

`Cerebrau.Campaign.psm1:777-811` lie les rapports unitaires par chemin et SHA-256 et déclare qu'ils ne sont pas réécrits. Le remplacement du manifeste par défaut ne supprimerait donc pas les preuves existantes, mais il affaiblirait le lien reproductible entre les preuves `ORCH-001` et leur manifeste source complet.

## 10. Risques de régression

| Domaine d'impact | Modification du fichier par défaut | Fichier dédié avec `-MissionFile` | Risque résiduel |
|---|---|---|---|
| Runtime CEREBRAU | Change tous les appels implicites | Isole l'appel explicite | Existence du manifeste et du prompt dédiés |
| Validation de mission | Valide une nouvelle identité à la place d'`ORCH-001` | Valide le fichier ciblé | Faiblesse des contraintes sur les identifiants et `missionType` |
| Résolution du profil | Profil du nouveau contenu appliqué à tous les appels implicites | Profil résolu seulement pour la mission dédiée | Le profil doit exister dans le registre |
| Reporting officiel | Les futurs rapports du répertoire par défaut changent d'identité | Répertoire de rapports dédié | Les rapports n'archivent pas le manifeste complet |
| Journal d'exécution | Les événements futurs portent la nouvelle identité | Identité correcte et isolée | Les toutes premières étapes ont des identifiants nuls avant lecture |
| Campagnes | Risque si une campagne référence le fichier par défaut | Convention normale des unités Campaign | Programme, lot et branche doivent correspondre au manifeste Campaign |
| Reprise de campagne | Hash/fingerprint potentiellement invalidé | Fichier stable et hashable | Toute modification ultérieure du manifeste ou prompt affecte la reprise |
| Preuves existantes | Non supprimées, mais source historique masquée | Inchangées | Incohérences historiques déjà présentes |
| Traçabilité `ORCH-001` | Critique : working-tree source remplacée | Préservée | `ORCH-001` n'est pas encore figé dans le `HEAD` courant |
| Gouvernance du PROGRAM | Alias `PROGRAM OFFER` non prouvé | Programme canonique existant recommandé | Identifiant canonique d'un éventuel programme Offer séparé inconnu |
| Conventions de nommage | Mélange possible d'un titre et d'un identifiant | Identifiants hyphénés | Pas de schéma de mission pour imposer la convention |
| Reproductibilité | Dégradée | Améliorée par manifeste, prompt et reports dédiés | Versionnement ultérieur nécessaire |
| Non-régression | Surface globale partagée | Surface isolée | Scopes et validations Offer restent à définir |
| Sécurité | Risque de scopes absents ou trop larges | Scopes explicites possibles | `allowedPaths` vide signifie actuellement « tout autoriser » dans le reporting |
| Stabilité de production | Risque élevé sur tous les appels sans paramètre | Faible impact sur le runtime existant | Dépendances externes au dépôt inconnues |

## 11. Méthode recommandée pour `MO-OFFER-001`

1. Ne pas modifier `tools/cerebrau/mission.json`.
2. Ne pas réutiliser `tools/cerebrau/prompt.md`.
3. Préparer ultérieurement :
   - `tools/cerebrau/missions/veedda/MO-OFFER-001.json` ;
   - `tools/cerebrau/missions/veedda/MO-OFFER-001.prompt.md` ;
   - un `reportDirectory` dédié à `MO-OFFER-001`.
4. Conserver `program = PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001` tant qu'aucun identifiant canonique distinct de programme Offer n'est prouvé.
5. N'utiliser `lot = LOT-OFFER-001` qu'après confirmation de son rattachement de gouvernance. La chaîne est techniquement valide, mais son enregistrement officiel est inconnu.
6. Définir des `allowedPaths` non vides, des `forbiddenPaths`, des livrables et des validations exactes avant tout lancement.
7. Exécuter le validateur sur le fichier dédié.
8. Lancer le runtime avec `-MissionFile` explicite.
9. Si la mission entre dans une campagne, la déclarer dans un `CampaignFile` dont `programId`, `lotId`, branche, autorité, scopes et review correspondent exactement.

## 12. Contenu JSON recommandé, sans l'appliquer

Le contenu ci-dessous est un **gabarit conditionnel non exécutable en l'état**. Les marqueurs `<...>` doivent être remplacés par des chemins et validations approuvés. Ils sont laissés volontairement non résolus parce que le périmètre d'implémentation Offer n'était pas autorisé dans cette mission.

```json
{
  "schemaVersion": "1.0.0",
  "missionId": "MO-OFFER-001",
  "program": "PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001",
  "lot": "LOT-OFFER-001",
  "title": "Implementation Offer - perimetre a approuver",
  "missionType": "IMPLEMENTATION",
  "executionMode": "RUNTIME_MUTATION",
  "profile": "ARCHITECTURE",
  "repository": "C:\\DEV\\veedda-cseV7-core",
  "expectedBranch": "fix/simulation-star",
  "promptFile": "C:\\DEV\\veedda-cseV7-core\\tools\\cerebrau\\missions\\veedda\\MO-OFFER-001.prompt.md",
  "workingDirectory": "C:\\DEV\\veedda-cseV7-core",
  "reportDirectory": "C:\\DEV\\veedda-cseV7-core\\tools\\cerebrau\\reports\\missions\\veedda\\MO-OFFER-001",
  "changesExpected": true,
  "humanReviewRequired": true,
  "reviewRequired": true,
  "enabled": true,
  "resourceScopes": [
    "<CHEMIN_OFFER_RELATIF_AUTORISE/**>"
  ],
  "allowedPaths": [
    "<CHEMIN_OFFER_RELATIF_AUTORISE/**>"
  ],
  "forbiddenPaths": [
    ".git/**",
    "tools/cerebrau/mission.json",
    "tools/cerebrau/prompt.md",
    "tools/cerebrau/*.ps1",
    "tools/cerebrau/*.psm1"
  ],
  "expectedFiles": [
    "<LIVRABLE_OFFER_RELATIF>"
  ],
  "validations": [
    {
      "name": "mission-manifest-json",
      "type": "json",
      "path": "tools/cerebrau/missions/veedda/MO-OFFER-001.json",
      "required": true
    },
    {
      "name": "offer-deliverable-exists",
      "type": "fileExists",
      "path": "<LIVRABLE_OFFER_RELATIF>",
      "required": true
    },
    {
      "name": "repository-diff-clean",
      "type": "gitDiffCheck",
      "required": true
    }
  ]
}
```

Notes :

- `IMPLEMENTATION` sera accepté mais seulement comme métadonnée non gouvernée.
- `RUNTIME_MUTATION` est la valeur Campaign correspondant sémantiquement à une implémentation ; le validateur de mission autonome ne la contrôle pas.
- Le profil `ARCHITECTURE` permet au resolver de choisir modèle, reasoning, sandbox et approval ; aucun de ces quatre paramètres ne doit être injecté manuellement dans la commande.
- La branche doit être réévaluée au moment de la future préparation si le contexte Git a changé.
- Le gabarit ne confère aucun statut de gouvernance à `LOT-OFFER-001` : conformément aux faits certifiés, seule la `WAVE` est l'objet officiel prouvé dans cette mission.

## 13. Commande PowerShell exacte recommandée, sans la lancer

### Préflight du fichier dédié

```powershell
& "C:\DEV\veedda-cseV7-core\tools\cerebrau\Test-CerebrauMission.ps1" -MissionFile "C:\DEV\veedda-cseV7-core\tools\cerebrau\missions\veedda\MO-OFFER-001.json"
```

### Lancement

```powershell
& "C:\DEV\veedda-cseV7-core\tools\cerebrau\Invoke-CerebrauMission.ps1" -MissionFile "C:\DEV\veedda-cseV7-core\tools\cerebrau\missions\veedda\MO-OFFER-001.json"
```

Cette commande est exacte pour le chemin dédié recommandé et ne remplace pas `tools/cerebrau/mission.json`. Elle ne doit être lancée qu'après création, complétion et validation du manifeste et du prompt dédiés.

## 14. Éléments qui ne doivent pas être modifiés

- `tools/cerebrau/mission.json`
- `tools/cerebrau/prompt.md`
- `tools/cerebrau/Invoke-CerebrauMission.ps1`
- `tools/cerebrau/Test-CerebrauMission.ps1`
- `tools/cerebrau/Resolve-CerebrauProfile.ps1`
- `tools/cerebrau/Invoke-CerebrauCampaign.ps1`
- `tools/cerebrau/Cerebrau.Campaign.psm1`
- `tools/cerebrau/Cerebrau.Reporting.psm1`
- `tools/cerebrau/*.schema.json`
- tout rapport, journal, état, index de preuve ou snapshot CEREBRAU existant ;
- tout fichier du domaine Offer pendant la présente mission ;
- toute configuration du modèle, du reasoning level, du sandbox ou de l'approval policy hors du resolver de profil.

## 15. Décision finale

### Faits prouvés

1. `mission.json` est le **manifeste concret par défaut** du runtime, pas une configuration permanente ni un template.
2. `MissionFile` permet nativement de sélectionner un autre fichier sans remplacer le défaut.
3. Plusieurs manifestes dédiés existent et les campagnes les utilisent explicitement.
4. Aucun script de production analysé n'écrit le manifeste d'entrée.
5. `missionId` est une clé fonctionnelle, de reporting et de reprise en campagne.
6. `program` et `lot` sont faiblement validés en autonome, mais contrôlés par cohérence dans une campagne.
7. `missionType` n'est pas gouverné ; `IMPLEMENTATION` n'est pas rejeté.
8. `PROGRAM OFFER` n'est pas un identifiant CEREBRAU canonique prouvé.
9. `LOT-OFFER-001` est techniquement et stylistiquement admissible, mais son enregistrement de gouvernance est inconnu.
10. Le remplacement du fichier par défaut présente un risque critique pour la reproductibilité et la traçabilité d'`ORCH-001`.

### Hypothèses

- `MO-OFFER-001` appartient au programme existant `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001`. Cette hypothèse est utilisée dans le gabarit pour éviter d'inventer `PROGRAM OFFER` comme identifiant.
- Le répertoire `tools/cerebrau/missions/veedda` reste l'emplacement conventionnel des nouvelles missions VEEDDA.
- Une future implémentation Offer nécessitera `executionMode = RUNTIME_MUTATION` si elle est orchestrée par Campaign.

### Inconnues

- Identifiant canonique d'un éventuel programme Offer distinct.
- Enregistrement officiel et rattachement de `LOT-OFFER-001`.
- Scopes, livrables et validations exacts de la future implémentation Offer.
- Appels externes au dépôt susceptibles d'invoquer le runtime sans `-MissionFile`.
- Existence d'une archive externe contenant le manifeste complet et chaque version du prompt d'`ORCH-001`.

### Verdict

**GO AVEC CONDITIONS**

La condition impérative est : **créer ultérieurement un manifeste et un prompt dédiés, compléter leurs contrôles, puis utiliser explicitement `-MissionFile`**. Toute proposition consistant à remplacer directement `tools/cerebrau/mission.json` est **NO GO** au regard des preuves actuelles.

## Annexe A — matrice synthétique des 14 questions obligatoires

| # | Réponse |
|---:|---|
| 1 | Lecteurs directs : runtime et validateur ; lecteur conditionnel : Context Assembly ; lecteur indirect : Campaign via le chemin d'unité. |
| 2 | Aucun writer de production identifié ; un test écrit uniquement un fixture temporaire ; la modification courante du working tree a un producteur inconnu. |
| 3 | Oui, `-MissionFile` sélectionne un fichier distinct sans remplacement. |
| 4 | Oui, 14 manifestes structurellement valides ont été inventoriés hors rapports et fixtures temporaires. |
| 5 | Métadonnée en autonome ; clé fonctionnelle, de reporting, d'état, de revue et de reprise en campagne. |
| 6 | Pas de contrôle de gouvernance en autonome ; contrôle par `programId`, autorité hashée et frontière d'état en campagne ; pas de registre global consulté. |
| 7 | Reporté et journalisé ; contrôlé contre `lotId` en campagne ; pas une clé directe de stockage des preuves ou décisions. |
| 8 | Non. |
| 9 | Oui techniquement, parce qu'ignorée ; non certifiée sémantiquement. |
| 10 | Techniquement acceptée, mais non conforme à la convention d'identifiant observée et non prouvée par une autorité. |
| 11 | Techniquement et stylistiquement conforme ; gouvernance inconnue. |
| 12 | Oui, risque critique de masquage et de non-reproductibilité du manifeste courant `ORCH-001`. |
| 13 | Créer un JSON dédié et l'utiliser avec `-MissionFile`. |
| 14 | `& "C:\DEV\veedda-cseV7-core\tools\cerebrau\Invoke-CerebrauMission.ps1" -MissionFile "C:\DEV\veedda-cseV7-core\tools\cerebrau\missions\veedda\MO-OFFER-001.json"` |

## Annexe B — preuves de non-modification

Avant la rédaction, les hashes SHA-256 ont été relevés pour `mission.json`, `prompt.md`, les six scripts/modules principaux et les trois schémas. La vérification finale a confirmé les onze hashes à l'identique.

Le dépôt possédait et possède un état Git non propre sur plusieurs fichiers CEREBRAU. L'audit n'attribue pas ces changements préexistants et ne les a pas modifiés. Le seul nouveau fichier produit par cette mission est :

```text
Docs/PROGRAM/OFFER/CEREBRAU_MISSION_CONFIG_IMPACT_001_REPORT.md
```

Hashes sensibles confirmés après rédaction :

| Fichier | SHA-256 inchangé |
|---|---|
| `tools/cerebrau/mission.json` | `E5F5A7AC8AE1CA7D4BA2FBABB867A14F5640012904A382EEA5ECECFF0419C44B` |
| `tools/cerebrau/prompt.md` | `6ED2DFD0844151B5118CDB9C631567144AD4CC115A32D895E4E51DF1F052B59E` |
| `tools/cerebrau/Invoke-CerebrauMission.ps1` | `1707D60706F630CCEC3B464DE3A7687029CA7A73C3E9ED1D887D1D2CD9784FF3` |
| `tools/cerebrau/Test-CerebrauMission.ps1` | `9E68B728A8BBEBD82195A722DA689762B28489F3A7AB66D3CF3505E587C1D3EF` |
| `tools/cerebrau/Resolve-CerebrauProfile.ps1` | `704B2F70D16448EDFF3F6D8C833DBB152DBF1F0C66F9021E25C83F9C52BAA389` |
| `tools/cerebrau/Invoke-CerebrauCampaign.ps1` | `A6ABB87C8B1DC21E059009BEB4CBF35B57756497D6DD5C8BE79909A9322AD060` |
| `tools/cerebrau/Cerebrau.Campaign.psm1` | `3EB017DB77183A324B2D8B2F6AE6BF400D33CCC18F834AE024F710A366DAAFED` |
| `tools/cerebrau/Cerebrau.Reporting.psm1` | `1166C1D0EBD6B20EDC1F055B9131AF51A48AB2414BF905E988E52568DFE78F31` |
| `tools/cerebrau/campaign-manifest.schema.json` | `AC2C35063E22458219F55674851AC02A40464933A302D3DBF466ED9E123988CE` |
| `tools/cerebrau/campaign-report.schema.json` | `459C59646A00E3AD5478712E19508C90D4DE56A1CBA79AB1AE0B04C2DC4078FF` |
| `tools/cerebrau/campaign-state.schema.json` | `3C00F93620D342733DA510326CC33ED72496502F30B9D0F625406D248FD25592` |
