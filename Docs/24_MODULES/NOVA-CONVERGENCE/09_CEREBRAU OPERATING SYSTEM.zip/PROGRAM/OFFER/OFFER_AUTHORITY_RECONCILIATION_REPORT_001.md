# CEREBRAU — Réconciliation autoritative du domaine Offer

## 1. Identification

| Champ | Valeur |
|---|---|
| Program | `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001` |
| Lot documentaire | `OFFER` |
| MissionId | `OFFER-AUTHORITY-RECONCILIATION-001` |
| Type | `AUDIT_ARCHITECTURE_RECONCILIATION` |
| Mode | `ONE_SHOT` |
| Autorité | `PROGRAM_DIRECTOR / CERTIFICATION_BOARD` |
| Date d'observation | `2026-07-23` — Europe/Paris |
| Dépôt | `C:\DEV\veedda-cseV7-core` |
| HEAD observé | `706bf1fae540e1798e3b827fbb162cac20b3b019` |
| Périmètre d'écriture | ce rapport uniquement |
| Verdict | **NO_GO** |

`DÉCISION_EXISTANTE` — Les faits certifiés reçus avec la mission sont retenus tels quels : l'objet officiel de gouvernance est `WAVE`, les work packages ne sont pas officiels, la fondation est prête, le Wave Model est canonique et le contrat MM L01-03 est canonique. Les « lots » proposés en section 18 sont donc des unités d'exécution candidates, non des objets de gouvernance officiels.

`DÉCISION_EXISTANTE` — La mission est documentaire. Aucun code métier, test, migration, table, CEREBRAU Runtime, commit, push, merge ou déploiement n'a été modifié.

## 2. Périmètre analysé

`FAIT_PROUVÉ` — Le périmètre a couvert les sources exécutables et documentaires suivantes :

- les quatre couches Offer : `server/offer-domain`, `server/offer-application`, `server/offer-api`, `server/offer-infrastructure` ;
- le montage runtime dans `server/routes.ts` ;
- les migrations et SQL sous `supabase/migrations`, notamment `20260717000000_create_offer_infrastructure.sql` ;
- les tests Domain, Application, API, Infrastructure et PostgreSQL conditionnels ;
- EBS sous `server/employee-business-state` ;
- LifeHub, Dashboard salarié, Dashboard admin, GDBCSE et Cockpit financier sous `client/src` ;
- `compute-rights`, Subvention, Budget, Ledger, Simulation et les catalogues frontend ;
- les documents canoniques Offer, les rapports de certification et les rapports de rapprochement préexistants ;
- CEREBRAU Runtime et ses outils, uniquement pour rechercher une éventuelle logique métier Offer/Dotation.

`FAIT_PROUVÉ` — Les recherches globales ont exclu les artefacts générés `dist`, `server/dist` et `node_modules` lorsque l'objectif était d'identifier la source maintenue. Les sorties compilées ont été reconnues comme copies, jamais comme seconde source de vérité.

`INCONNU` — La base DEV/Supabase liée n'a pas été interrogée en direct pendant cette mission. La dernière photographie disponible dans le dépôt est datée du 19 juillet 2026 ; elle ne vaut pas preuve de l'état déployé au 23 juillet.

## 3. Sources consultées

| Source | Repères | Nature | Qualification |
|---|---|---|---|
| `server/offer-domain/types/states.ts` | 1-11 | états des trois agrégats | `FAIT_PROUVÉ` |
| `server/offer-domain/aggregate/OfferAggregate.ts` | 17-112 | agrégat, invariants, mutations, événements | `FAIT_PROUVÉ` |
| `server/offer-domain/value-object/OfferVersion.ts` | 7-38 | contrat de version | `FAIT_PROUVÉ` |
| `server/offer-domain/state-machine/OfferStateMachine.ts` | 4-22 | automates Offer et Version | `FAIT_PROUVÉ` |
| `server/offer-domain/aggregate/OperationAggregate.ts` | 19-70 | fenêtre opérationnelle distincte | `FAIT_PROUVÉ` |
| `server/offer-domain/command/*.ts` | fichiers complets | commandes | `FAIT_PROUVÉ` |
| `server/offer-domain/event/offer-events.ts` | 3-32 | événements | `FAIT_PROUVÉ` |
| `server/offer-application/application/CommandExecutionService.ts` | 24-101 | dispatch et persistance | `FAIT_PROUVÉ` |
| `server/offer-application/queries/OfferQueries.ts` | 7-33 | 15 requêtes | `FAIT_PROUVÉ` |
| `server/offer-api/routes/OfferRouter.ts` | 10-22 | routes HTTP génériques | `FAIT_PROUVÉ` |
| `server/offer-api/validation/OfferHttpValidation.ts` | 18-50, 94-109 | payloads et requêtes HTTP | `FAIT_PROUVÉ` |
| `server/offer-api/openapi/OfferOpenApi.ts` | 5-15, 44-85 | 25 commandes + 15 requêtes | `FAIT_PROUVÉ` |
| `server/routes.ts` | 536-571, 1717-1764 | montage Offer et endpoint EBS/LifeHub | `FAIT_PROUVÉ` |
| `server/offer-infrastructure/repositories/PostgresRepositories.ts` | 9-26 | repositories PostgreSQL | `FAIT_PROUVÉ` |
| `server/offer-infrastructure/projections/PostgresOfferReadModel.ts` | 230-260, 336-354 | distribution et administration | `FAIT_PROUVÉ` |
| `server/offer-infrastructure/outbox/PostgresOutbox.ts` | 1-7 | écriture outbox | `FAIT_PROUVÉ` |
| `server/offer-infrastructure/events/OutboxDispatcher.ts` | 5-14 | dispatcher disponible mais non composé | `FAIT_PROUVÉ` |
| `supabase/migrations/20260717000000_create_offer_infrastructure.sql` | 1-229 | tables, vues, RLS, audit, outbox | `FAIT_PROUVÉ` dans le dépôt |
| `server/employee-business-state/lifehub-bridge.ts` | 64-226 | sources réelles de l'EBS LifeHub | `FAIT_PROUVÉ` |
| `server/employee-business-state/projections/lifehub.helpers.ts` | 76-103, 173-195 | conversion Rights vers benefits | `FAIT_PROUVÉ` |
| `client/src/lifehub/hooks/useLifeHubDashboardData.ts` | 373-465, 618-733 | consommation EBS par LifeHub | `FAIT_PROUVÉ` |
| `supabase/functions/compute-rights/index.ts` | 137-205, 269-384, 497-556 | QF + Rights config, histoire et projection | `FAIT_PROUVÉ` |
| `client/src/pages/DashboardSalarie.tsx` | 123-230, 393-463, 609-649, 1184-1224, 1573-1613 | catalogues, calculs et écritures frontend | `FAIT_PROUVÉ` |
| `client/src/config/avantages.ts` | 24-270 | catalogue éditorial statique concurrent | `FAIT_PROUVÉ` |
| `client/src/config/budgets.ts` | 15-22 | plafonds frontend | `FAIT_PROUVÉ` |
| `client/src/gdbcse/pages/GdbcseFinancialCockpit.tsx` | 475-645 | sources Budget/Subvention/Ledger | `FAIT_PROUVÉ` |
| migrations Budget/Subvention/Ledger | fichiers cités en section 10 | legacy financier | `FAIT_PROUVÉ` |
| `Docs/21_DOMAIN_MODELS/CANONICAL_OFFER_*.md` | corpus certifié | décisions antérieures | `DÉCISION_EXISTANTE` avec contradictions signalées |
| `Docs/21_DOMAIN_MODELS/OFFER_DOTATION_TAXONOMY.md` | 5-21, 121-141 | doctrine Dotation sans moteur | `DÉCISION_EXISTANTE` |
| `Docs/PROGRAMS/.../DPDS_000A_RUNTIME_OBSERVATION_REPORT.md` | 1-12, 44-60, 62-113, 171-179 | photographie Supabase du 19 juillet | `FAIT_PROUVÉ` documentaire daté |
| commandes de test de cette mission | section 4, F19-F20 | exécution locale | `FAIT_PROUVÉ` |

## 4. Faits prouvés

Chaque fait de cette section contient le fichier, le symbole ou la table, le repère, la preuve et la conséquence.

| Id | Classification | Fichier | Symbole ou table | Repère exact | Preuve observée | Conséquence |
|---|---|---|---|---|---|---|
| F01 | `FAIT_PROUVÉ` | `server/offer-domain/types/states.ts` | `OFFER_STATES` | 4-5 | `DRAFT`, `PUBLISHED`, `SUSPENDED`, `CLOSED`, `ARCHIVED` uniquement | aucun état Offer `ACTIVE` |
| F02 | `FAIT_PROUVÉ` | même fichier | `OFFER_VERSION_STATES` | 7-8 | `DRAFT`, `IN_REVIEW`, `VALIDATED`, `PUBLISHED`, `SUPERSEDED` | validation et publication portent d'abord sur la Version |
| F03 | `FAIT_PROUVÉ` | `OfferAggregate.ts` | `create` | 30-37 | création d'un Offer `DRAFT` avec Version 1 `DRAFT` et `OfferCreated` | cycle initial confirmé |
| F04 | `FAIT_PROUVÉ` | `OfferAggregate.ts` | `validate` | 87-89 | seule la Version passe `IN_REVIEW → VALIDATED`; l'état de l'agrégat est conservé par `versionResult` | après validation, Offer reste `DRAFT` lors de la première version |
| F05 | `FAIT_PROUVÉ` | `OfferAggregate.ts` | `publish` | 91-100 | Version `VALIDATED → PUBLISHED`, Offer `DRAFT → PUBLISHED`, événement `OfferPublished` | publication et changement d'état sont atomiques |
| F06 | `FAIT_PROUVÉ` | `OfferStateMachine.ts` | `OFFER_MACHINE`, `VERSION_MACHINE` | 4-22 | aucune transition `ActivateOffer` | activation Offer inexistante |
| F07 | `FAIT_PROUVÉ` | `types/catalog.ts`, `offer-events.ts` | catalogues commande/événement | 1-15 ; 10-22 | 25 commandes et 25 événements sans `ActivateOffer` ni `OfferActivated` | absence dans Domain, Application et API générée |
| F08 | `FAIT_PROUVÉ` | migration Offer | `offer_offer.state` | 19-32 | CHECK excluant `ACTIVE` | une activation ne peut pas être persistée dans le schéma versionné |
| F09 | `FAIT_PROUVÉ` | migration Offer | `offer_offer_version` | 37-62 | une seule version ouverte et une seule publiée par Offer | source persistante des versions clairement séparée |
| F10 | `FAIT_PROUVÉ` | `PostgresOfferReadModel.ts` | `ListOfferDistributionFacts` | 230-260 | sélection de toute Offer/Version `PUBLISHED`, sans test de date d'effet, avec Operation `OPEN` optionnelle | `PUBLISHED` vaut immédiatement « distribuable » dans le read model |
| F11 | `FAIT_PROUVÉ` | `OfferAggregate.ts` | `publish` | 98-99 | `effectiveAt` devient `lastTransitionAt` et payload événement, mais aucun état planifié n'existe | une date future n'empêche pas la visibilité immédiate |
| F12 | `FAIT_PROUVÉ` | `OperationAggregate.ts` | `open` | 58-61 | `Operation` possède `OPEN`, contrôlé par fenêtre et booléens | ouverture opérationnelle existe, mais ce n'est pas une activation Offer |
| F13 | `FAIT_PROUVÉ` | `server/routes.ts` | `registerRoutes` | 536-571 | infrastructure composée et API montée sous `/api/v1/offer` | backend Offer réellement branché au monolithe |
| F14 | `FAIT_PROUVÉ` | `OfferRouter.ts` | `createOfferRouter` | 16-20 | OpenAPI, 25 POST commandes et 15 GET requêtes | surface HTTP complète pour le modèle actuel |
| F15 | `FAIT_PROUVÉ` | `CommandExecutionService.ts` | `execute` | 30-42 | repository, audit, outbox et idempotence dans une transaction | traçabilité technique conçue atomiquement |
| F16 | `FAIT_PROUVÉ` | `CompositionRoot.ts`, `server/routes.ts` | `createOfferInfrastructure` | 9 ; 537-571 | aucun `OutboxDispatcher` ni publisher métier n'est construit ou démarré | événements persistés, mais aucun consommateur runtime prouvé |
| F17 | `FAIT_PROUVÉ` | `lifehub-bridge.ts` | `readLifeHubSources` | 64-140 | EBS lit `profiles`, `qf_history`, `user_rights_projection`, `subventions` | aucune source Offer dans l'EBS réellement exposé à LifeHub |
| F18 | `FAIT_PROUVÉ` | `lifehub.helpers.ts` | `buildRightsBenefits` | 173-195 | chaque item Rights est transformé avec `available: true` | disponibilité salarié non gouvernée par Offer |
| F19 | `FAIT_PROUVÉ` | exécution locale | Vitest ciblé | 2026-07-23 | 7 fichiers PASS, 1 fichier SKIP ; 38 tests PASS, 2 PostgreSQL SKIP | socle unitaire/contractuel positif, base réelle non retestée |
| F20 | `FAIT_PROUVÉ` | exécution locale | Node test runner API | 2026-07-23 | 9/9 tests PASS | contrat HTTP actuel cohérent |
| F21 | `FAIT_PROUVÉ` | `DashboardSalarie.tsx` | `CATALOGUE_AVANTAGES`, mutations | 123-230, 430-463, 1573-1613 | catalogue local, sélection Budget et insertion directe Subvention | Dashboard salarié contourne Offer |
| F22 | `FAIT_PROUVÉ` | `compute-rights/index.ts` | `calculateRights` et lectures | 161-205, 269-384 | calcul depuis dernier QF et `rights_config` active | éligibilité/droits non dérivés d'Offer |
| F23 | `FAIT_PROUVÉ` | `GdbcseFinancialCockpit.tsx` | chargeurs | 475-645 | lectures `/api/budgets/latest`, `/api/subventions`, grand livre ASC | Cockpit financier sans Offer/Version |
| F24 | `FAIT_PROUVÉ` | `server/cerebrau-runtime`, `tools/cerebrau` | recherche métier | dépôt observé | aucune classe/agrégat/table Offer dans Runtime ; les seules occurrences détaillées sont le texte de mission | CEREBRAU ne contient pas de logique Offer/Dotation prouvée |
| F25 | `FAIT_PROUVÉ` | rapport DPDS runtime | inventaire `public` | 44-60, 62-113 | 46 tables et 9 vues le 19 juillet ; Rights/Budget/Ledger/Subvention présents, aucune relation `offer_*` listée | migration Offer non observée sur ce runtime à cette date |

## 5. Architecture actuelle

### 5.1 Q1 — Où se trouve le domaine Offer ?

`FAIT_PROUVÉ` — Le bounded context exécutable est réparti dans quatre dossiers racines et une migration. L'API est montée par le monolithe ; aucune interface Offer n'est présente côté client.

### 5.2 Inventaire Offer

Le comptage final utilise une unité simple : une ligne `Cxx` du tableau ci-dessous vaut un composant recensé.

| Composant | Chemin | Type | Statut | Source de vérité | Consommateurs | Preuve |
|---|---|---|---|---|---|---|
| C01 `OfferAggregate` | `server/offer-domain/aggregate/OfferAggregate.ts` | agrégat | `FAIT_PROUVÉ` actif | Domain | Application | 23-112 |
| C02 `DispositifAggregate` | `server/offer-domain/aggregate/DispositifAggregate.ts` | agrégat | `FAIT_PROUVÉ` actif | Domain | Application | classe et mutations |
| C03 `OperationAggregate` | `server/offer-domain/aggregate/OperationAggregate.ts` | agrégat | `FAIT_PROUVÉ` actif | Domain | Application | 27-70 |
| C04 `OfferVersion` | `server/offer-domain/value-object/OfferVersion.ts` | entité interne immuable | `FAIT_PROUVÉ` actif | Domain | OfferAggregate, mappers | 7-38 |
| C05 `OfferVersionEntity` | `server/offer-domain/entity/OfferVersionEntity.ts` | alias d'entité | `FAIT_PROUVÉ` actif | alias de C04 | imports Domain | 1-4 |
| C06 Identifiants | `server/offer-domain/value-object/Identifiers.ts` | value objects | `FAIT_PROUVÉ` actif | Domain | toutes couches | fichier |
| C07 `AggregateVersion` | `server/offer-domain/value-object/AggregateVersion.ts` | value object | `FAIT_PROUVÉ` actif | Domain | locking | fichier |
| C08 `TargetPopulation` | `server/offer-domain/value-object/TargetPopulation.ts` | value object | `FAIT_PROUVÉ` actif | Domain | Version, Operation | fichier |
| C09 `ExternalReference` | `server/offer-domain/value-object/ExternalReference.ts` | value object | `FAIT_PROUVÉ` actif | Domain | Version | fichier |
| C10 `OpeningWindow` | `server/offer-domain/value-object/OpeningWindow.ts` | value object | `FAIT_PROUVÉ` actif | Domain | Operation | 4-21 |
| C11 catalogues d'états | `server/offer-domain/types/states.ts` | enums TS | `FAIT_PROUVÉ` actif | Domain | toutes couches | 1-11 |
| C12 catalogues commandes/événements | `server/offer-domain/types/catalog.ts` | catalogues | `FAIT_PROUVÉ` actif | Domain | Application/API/tests | 1-18 |
| C13 commandes Offer | `server/offer-domain/command/offer.commands.ts` | commandes | `FAIT_PROUVÉ` actif | Domain | Application/API | 5-17 |
| C14 commandes Dispositif | `server/offer-domain/command/dispositif.commands.ts` | commandes | `FAIT_PROUVÉ` actif | Domain | Application/API | fichier |
| C15 commandes Operation | `server/offer-domain/command/operation.commands.ts` | commandes | `FAIT_PROUVÉ` actif | Domain | Application/API | 7-15 |
| C16 événements | `server/offer-domain/event/offer-events.ts` | événements | `FAIT_PROUVÉ` actif | Domain | outbox | 3-32 |
| C17 automate Offer/Version | `server/offer-domain/state-machine/OfferStateMachine.ts` | state machine | `FAIT_PROUVÉ` actif | Domain | agrégat | 4-22 |
| C18 automate Dispositif | `server/offer-domain/state-machine/DispositifStateMachine.ts` | state machine | `FAIT_PROUVÉ` actif | Domain | agrégat | 4-11 |
| C19 automate Operation | `server/offer-domain/state-machine/OperationStateMachine.ts` | state machine | `FAIT_PROUVÉ` actif | Domain | agrégat | 4-13 |
| C20 politiques Offer | `server/offer-domain/policy/OfferPolicies.ts` | policies | `FAIT_PROUVÉ` actif | Domain | OfferAggregate | 5-16 |
| C21 politique d'ouverture | `server/offer-domain/policy/OperationOpeningPolicy.ts` | policy | `FAIT_PROUVÉ` actif | Domain | Operation | 5-9 |
| C22 autorisation de rôles | `server/offer-domain/policy/RoleAuthorizationPolicy.ts` | policy | `FAIT_PROUVÉ` actif | Domain | agrégats | fichier |
| C23 validateurs métier | `server/offer-domain/validator/DomainValidators.ts` | validators | `FAIT_PROUVÉ` partiel | Domain | agrégats | 4-15 |
| C24 repository Offer | `server/offer-domain/repository/OfferRepository.ts` | port | `FAIT_PROUVÉ` actif | Domain | Infrastructure | 5-9 |
| C25 repository Dispositif | `server/offer-domain/repository/DispositifRepository.ts` | port | `FAIT_PROUVÉ` actif | Domain | Infrastructure | fichier |
| C26 repository Operation | `server/offer-domain/repository/OperationRepository.ts` | port | `FAIT_PROUVÉ` actif | Domain | Infrastructure | fichier |
| C27 UoW Domain | `server/offer-domain/contracts/OfferDomainUnitOfWork.ts` | contrat | `FAIT_PROUVÉ` actif | Domain | Application/Infrastructure | 5-9 |
| C28 exécution commandes | `server/offer-application/application/CommandExecutionService.ts` | service | `FAIT_PROUVÉ` actif | Application | API | 24-101 |
| C29 exécution requêtes | `server/offer-application/application/QueryExecutionService.ts` | service | `FAIT_PROUVÉ` actif | Application | API | fichier |
| C30 handlers commandes | `server/offer-application/handlers/CommandHandlers.ts` | handlers | `FAIT_PROUVÉ` actif | Application | use cases/API | 15-39 |
| C31 requêtes et handlers | `server/offer-application/queries/OfferQueries.ts`; `handlers/QueryHandlers.ts` | query model | `FAIT_PROUVÉ` actif | Application | API/read model | 7-33 ; 9-23 |
| C32 DTO Application | `server/offer-application/dto/ApplicationDtos.ts` | DTO | `FAIT_PROUVÉ` actif | Application | API/EBS candidat | 3-15 |
| C33 ports de publication | `server/offer-application/ports/ApplicationPorts.ts` | ports | `FAIT_PROUVÉ` actif | Application | Infrastructure | 25-32 |
| C34 audit/idempotence/transaction | `server/offer-application/{audit,idempotency,transaction,authorization}` | services | `FAIT_PROUVÉ` actif | Application | exécution commandes | tests Application |
| C35 contrats HTTP | `server/offer-api/contracts/OfferHttpContracts.ts` | contrat | `FAIT_PROUVÉ` actif | API | clients | 4-13 |
| C36 contrôleur HTTP | `server/offer-api/controllers/OfferController.ts` | controller | `FAIT_PROUVÉ` actif | API | Express | 8-41 |
| C37 routeur HTTP | `server/offer-api/routes/OfferRouter.ts` | routes | `FAIT_PROUVÉ` actif | API | monolithe | 10-22 |
| C38 validation et mapper HTTP | `server/offer-api/validation/OfferHttpValidation.ts`; `mapper/OfferHttpMapper.ts` | adapters | `FAIT_PROUVÉ` actif | API | contrôleur | 18-50 ; mapper 54-105 |
| C39 authentification Offer | `server/offer-api/authentication/OfferAuthenticator.ts` | auth adapter | `FAIT_PROUVÉ` actif | API | middleware/runtime | fichier |
| C40 OpenAPI | `server/offer-api/openapi/OfferOpenApi.ts` | contrat | `FAIT_PROUVÉ` actif | API | clients/tests | 44-85 |
| C41 composition API runtime | `server/offer-api/bootstrap/OfferApiCompositionRoot.ts`; `server/routes.ts` | composition | `FAIT_PROUVÉ` actif | runtime | Express | 14-17 ; 536-571 |
| C42 repositories PostgreSQL | `server/offer-infrastructure/repositories/PostgresRepositories.ts` | adapters | `FAIT_PROUVÉ` actif | Infrastructure | Application | 9-26 |
| C43 rows et mappers | `server/offer-infrastructure/persistence/Rows.ts`; `mapper/PersistenceMappers.ts` | persistence mapping | `FAIT_PROUVÉ` actif | Infrastructure | repositories | Rows 1-5 ; mappers 5-13 |
| C44 read model | `server/offer-infrastructure/projections/PostgresOfferReadModel.ts` | projection | `FAIT_PROUVÉ` actif | tables Offer | 15 queries HTTP | 230-354 |
| C45 outbox transactionnelle | `server/offer-infrastructure/outbox/PostgresOutbox.ts` | outbox | `FAIT_PROUVÉ` actif en écriture | `offer_outbox` | dispatcher potentiel | 6-7 |
| C46 dispatcher/publishers | `server/offer-infrastructure/events/{OutboxDispatcher,Publishers}.ts` | event adapters | `FAIT_PROUVÉ` non monté | outbox | aucun runtime prouvé | dispatcher 6-14 |
| C47 audit/idempotence PG | `server/offer-infrastructure/{audit,idempotency}` | adapters | `FAIT_PROUVÉ` actif | tables techniques Offer | Application | tests |
| C48 transaction/composition PG | `server/offer-infrastructure/{database,transaction}/`; `database/CompositionRoot.ts` | infrastructure | `FAIT_PROUVÉ` actif | PostgreSQL | runtime | Postgres 9-29 ; root 9 |
| C49 RLS/config/validation migration | `server/offer-infrastructure/{rls,security,config,validation}` | sécurité/config | `FAIT_PROUVÉ` présent | migration/catalogues | certification | fichiers |
| C50 migration Offer | `supabase/migrations/20260717000000_create_offer_infrastructure.sql` | migration | `FAIT_PROUVÉ` dépôt ; runtime actuel `INCONNU` | dépôt | PostgreSQL | 1-229 |
| C51 `offer_dispositif` | migration Offer | table | `FAIT_PROUVÉ` définition | Dispositif persistant | repositories/projections | 1-17 |
| C52 `offer_offer` | migration Offer | table | `FAIT_PROUVÉ` définition | Offer persistant | repositories/projections | 19-35 |
| C53 `offer_offer_version` | migration Offer | table | `FAIT_PROUVÉ` définition | Version/catalogue/config | repositories/projections | 37-62 |
| C54 `offer_operation` | migration Offer | table | `FAIT_PROUVÉ` définition | périodes/ouvertures | repositories/projections | 64-88 |
| C55 `offer_idempotency` | migration Offer | table | `FAIT_PROUVÉ` définition | idempotence | Application | 90-103 |
| C56 `offer_audit_entry` | migration Offer | table | `FAIT_PROUVÉ` définition | audit | requêtes audit | 105-128 |
| C57 `offer_outbox` | migration Offer | table | `FAIT_PROUVÉ` définition | événements | dispatcher non monté | 130-154 |
| C58 `offer_dispositif_projection` | migration Offer | vue | `FAIT_PROUVÉ` définition | table C51 | read model potentiel | 211-213 |
| C59 `offer_offer_projection` | migration Offer | vue | `FAIT_PROUVÉ` définition | C52+C53 | read model | 215-221 |
| C60 `offer_operation_projection` | migration Offer | vue | `FAIT_PROUVÉ` définition | C54 | read model | 223-226 |
| C61 fonctions/triggers SQL Offer | migration Offer | fonctions sécurité + trigger audit | `FAIT_PROUVÉ` définition | PostgreSQL | RLS/audit | 156-180, 163-209 |
| C62 tests Domain | `server/offer-domain/test/{domain-foundation.test.ts,fixtures.ts}` | tests | `FAIT_PROUVÉ` PASS | modèle actuel | certification | 8 tests dans run |
| C63 tests Application | `server/offer-application/test/` | tests | `FAIT_PROUVÉ` PASS | orchestration | certification | 13 tests cumulés Domain/Application |
| C64 tests Infrastructure | `server/offer-infrastructure/test/` | tests | `FAIT_PROUVÉ` 17 PASS, 2 SKIP dans run global | adapters/migration | certification | run du 23 juillet |
| C65 tests API | `server/offer-api/test/` | tests | `FAIT_PROUVÉ` 9 PASS ; test PG non lancé | HTTP | certification | run du 23 juillet |
| C66 interface Offer opérationnelle | `client/src` | UI | `FAIT_PROUVÉ` ABSENTE | aucune | aucun opérateur | aucune occurrence `/api/v1/offer` ou commande Offer |
| C67 corpus documentaire | `Docs/21_DOMAIN_MODELS/CANONICAL_OFFER_*.md`; `Docs/04_MODULES/OFFERS/`; `Docs/PROGRAM/VEEDDA_OFFER_ROOT_RECONCILIATION_REPORT.md` | documentation | `DÉCISION_EXISTANTE` + `CONTRADICTION` | gouvernance documentaire | équipes | états `CERTIFIED`, mais sémantique d'activation divergente |

### 5.3 Chemins exacts demandés

`FAIT_PROUVÉ` — Agrégats : C01-C03. Entité : C04-C05. Value objects : C06-C10. Commandes : C12-C15. Événements : C16. Services : C20-C23 et C28-C34. Repositories : C24-C27 et C42. Contrôleur : C36. Routes : C37 et C41. RPC Offer : aucun RPC métier ; seulement quatre fonctions SQL de sécurité/audit C61. Migration : C50. Tables : C51-C57. Tests : C62-C65. Interface utilisateur : C66 absente. Documentation : C67.

### 5.4 Flux actuel

```mermaid
flowchart LR
  UIX[Pas d'UI Offer] -. aucun appel .-> API
  API[/api/v1/offer] --> APP[Application]
  APP --> DOM[Domain Offer]
  DOM --> PG[(offer_* selon migration)]
  APP --> AUDIT[(offer_audit_entry)]
  APP --> OUT[(offer_outbox)]
  OUT -. dispatcher non monté .-> NONE[Aucun consommateur prouvé]
  PG --> DIST[ListOfferDistributionFacts]
  DIST -. non consommé .-> EBS
  RIGHTS[user_rights_projection] --> EBS[EBS LifeHub]
  EBS --> LH[LifeHub / Dashboard salarié]
  LH --> SUB[(subventions)]
  SUB --> BUD[(budgets / budget_ledger)]
  BUD --> COCKPIT[Cockpit financier]
```

## 6. Cycle de vie réel

### 6.1 Q3 — Cycle réellement implémenté

`FAIT_PROUVÉ` — Le cycle de la première version est :

`CreateOffer → Offer DRAFT + Version DRAFT → SubmitOfferForReview → Version IN_REVIEW → ValidateOffer → Version VALIDATED, Offer toujours DRAFT → PublishOffer → Version PUBLISHED + Offer PUBLISHED`.

`FAIT_PROUVÉ` — Les suites sont `PUBLISHED → SUSPENDED → PUBLISHED`, puis `PUBLISHED|SUSPENDED → CLOSED → ARCHIVED`. Une Offer `PUBLISHED|SUSPENDED` peut recevoir une nouvelle Version `DRAFT`; sa publication supersède l'ancienne Version.

`FAIT_PROUVÉ` — Le cycle `Operation DRAFT → SCHEDULED → OPEN → SUSPENDED/CLOSED → ARCHIVED` porte une fenêtre et une référence Offer/Version. `OPEN` est l'ouverture d'une opération, pas un état d'activation de l'Offer.

### 6.2 Q4 — Existe-t-il une activation réelle ?

`FAIT_PROUVÉ` — **Non.** Aucun `OfferStatus.ACTIVE`, `ActivateOffer`, `OfferActivated`, `activationDate`, `validFrom`, workflow ou persistance d'activation Offer n'existe. Les occurrences `ACTIVE` du bounded context concernent `Dispositif`. Les occurrences de date concernent `PublishOffer.effectiveAt` et `Operation.openingWindow`.

`CONTRADICTION` — Le produit exige une capacité « activer » distincte, tandis que le modèle certifié antérieur et le code font de `PUBLISHED` la condition de distribution et d'ouverture.

### 6.3 Q5 — Que signifie `PUBLISHED` ?

| Interprétation | Réponse | Classification | Preuve |
|---|---|---|---|
| publication administrative | oui | `FAIT_PROUVÉ` | commande et événement `PublishOffer/OfferPublished`, `OfferAggregate.ts:91-100` |
| disponibilité immédiate dans le read model Offer | oui | `FAIT_PROUVÉ` | filtre `o.state='PUBLISHED'`, `PostgresOfferReadModel.ts:237-244` |
| visibilité catalogue salarié | non prouvée | `INCONNU` | aucun consommateur EBS/LifeHub/Dashboard |
| activation technique | oui, de fait dans Offer | `CONTRADICTION` | création/ouverture Operation contrôlée par `offerPublished` |
| activation métier distincte | non | `FAIT_PROUVÉ` | aucun état/commande/événement |
| date d'effet respectée | non | `CONTRADICTION` | `effectiveAt` n'est pas filtré par les projections |

`CONTRADICTION` — `PUBLISHED` est surchargé : il décrit une décision administrative, mais il sert aussi de condition technique immédiate de distribution et d'ouverture. Il ne constitue pas une activation métier explicite et auditable.

## 7. Machine d'état

| État source | Commande | Précondition | État cible | Événement | Persistance | Consommateur | Preuve |
|---|---|---|---|---|---|---|---|
| absent | `CreateOffer` | rôle autorisé, `dispositifUsable=true`, définition minimale | Offer `DRAFT`, V1 `DRAFT` | `OfferCreated` | `offer_offer`, `offer_offer_version`, audit, outbox | API seulement | `OfferAggregate.ts:30-37` |
| Version `DRAFT` | `UpdateOfferDraft` | version/tenant attendus | Version `DRAFT` | `OfferDraftUpdated` | mêmes tables | queries Offer | `OfferAggregate.ts:57-63` |
| Offer `PUBLISHED|SUSPENDED` | `CreateOfferVersion` | aucune version ouverte, source trouvée | nouvelle Version `DRAFT` | `OfferVersionCreated` | version | queries Offer | 65-74 |
| Version `DRAFT` | `SubmitOfferForReview` | complétude et références déclarées vraies | `IN_REVIEW` | `OfferValidationRequested` | version + audit/outbox | aucun consommateur métier | 76-81 |
| Version `IN_REVIEW` | `RequestOfferChanges` | motif | `DRAFT` | `OfferChangesRequested` | version + audit/outbox | aucun consommateur métier | 83-85 |
| Version `IN_REVIEW` | `ValidateOffer` | revue/références vraies, auteur ≠ validateur | `VALIDATED` | `OfferValidated` | version + audit/outbox | aucun consommateur métier | 87-89 ; policy 5-10 |
| Offer `DRAFT`, Version `VALIDATED` | `PublishOffer` | références déclarées vraies | Offer + Version `PUBLISHED` | `OfferPublished` | Offer/version + audit/outbox | DistributionFacts, mais aucun aval réel | 91-100 |
| Offer `PUBLISHED`, Version `VALIDATED` | `PublishOffer` | mêmes contrôles | Offer `PUBLISHED`, nouvelle Version `PUBLISHED`, ancienne `SUPERSEDED` | un seul `OfferPublished` | versions + audit/outbox | idem | 95-99 |
| Offer `PUBLISHED` | `SuspendOffer` | motif + portée | `SUSPENDED` | `OfferSuspended` | Offer + audit/outbox | query admin seulement | 102 |
| Offer `SUSPENDED` | `ResumeOffer` | motif, blocage déclaré levé | `PUBLISHED` | `OfferResumed` | Offer + audit/outbox | DistributionFacts | 103 |
| Offer `PUBLISHED|SUSPENDED` | `CloseOffer` | `nonTerminalOperationCount=0` fourni par appelant | `CLOSED` | `OfferClosed` | Offer + audit/outbox | query admin | 104 |
| Offer `CLOSED` | `ArchiveOffer` | rétention déclarée satisfaite | `ARCHIVED` | `OfferArchived` | Offer + audit/outbox | historique | 105 |
| source lisible | `CloneOffer` | source et dispositif cible déclarés utilisables | nouvel Offer/Version `DRAFT` | `OfferCloned` | nouvelles lignes | API/query | 45-54 |
| absent | `CreateOperation` | Offer et Version déclarées `PUBLISHED` | Operation `DRAFT` | `OperationCreated` | `offer_operation` + audit/outbox | query admin | `OperationAggregate.ts:34-40` |
| Operation `DRAFT` | `ScheduleOperation` | complétude/version publiée déclarées | `SCHEDULED` | `OperationScheduled` | Operation + audit/outbox | upcoming query | 53-57 |
| Operation `SCHEDULED` | `OpenOperation` | date dans fenêtre, Offer publiée et références utilisables déclarées | `OPEN` | `OperationOpened` | Operation + audit/outbox | DistributionFacts | 58-62 |
| Operation `OPEN` | `SuspendOperation` | motif | `SUSPENDED` | `OperationSuspended` | Operation + audit/outbox | admin | 63 |
| Operation `SUSPENDED` | `ResumeOperation` | fenêtre valide, Offer publiée déclarée | `OPEN` | `OperationResumed` | Operation + audit/outbox | DistributionFacts | 64 |
| Operation `SCHEDULED|OPEN|SUSPENDED` | `CloseOperation` | motif si fermeture anticipée | `CLOSED` | `OperationClosed` | Operation + audit/outbox | completed query | 65 |
| Operation `CLOSED` | `ArchiveOperation` | rétention déclarée satisfaite | `ARCHIVED` | `OperationArchived` | Operation + audit/outbox | historique | 66 |

`CONTRADICTION` — Plusieurs préconditions souveraines sont fournies comme booléens ou compteurs par le client HTTP (`dispositifUsable`, `definitionComplete`, `requiredReferencesUsable`, `reviewComplete`, `offerPublished`, `nonTerminalOperationCount`, etc.) au lieu d'être résolues depuis les repositories. Les méthodes `codeExists` et `countNonTerminalByOffer` existent, mais ne sont pas appelées dans `CommandExecutionService`.

## 8. Source de vérité

### 8.1 Q2 — Sources actuelles

| Objet | Source de vérité actuelle | Classification | Double vérité / réserve |
|---|---|---|---|
| Offer identité/code | `OfferAggregate` ↔ `offer_offer` | `FAIT_PROUVÉ` de conception ; données runtime `INCONNU` | unicité DB, mais `codeExists` non appelé par Application |
| OfferVersion | `OfferVersion` ↔ `offer_offer_version` | `FAIT_PROUVÉ` | aucune activation/version active |
| catalogue Offer | `family`, `title`, `parameters`, références de Version | `FAIT_PROUVÉ` partiel | `family` libre et `parameters` JSON non typé |
| avantage salarié | `user_rights_projection` puis catalogues frontend | `LEGACY` | aucune origine Offer |
| configuration | `OfferVersion.parameters` pour Offer ; `rights_config.rules` pour Rights | `CONTRADICTION` | deux configurations sans lineage |
| période | `offer_operation.opening_*` | `FAIT_PROUVÉ` | aucune période d'activation Offer/Version |
| statut Offer | `OfferAggregate.state` / `offer_offer.state` | `FAIT_PROUVÉ` | runtime déployé actuel inconnu |
| statut Version | `OfferVersion.state` / `offer_offer_version.state` | `FAIT_PROUVÉ` | cohérent dans le dépôt |
| publication | mutation + `offer_offer`, Version, audit, outbox | `FAIT_PROUVÉ` | aucun dispatcher/consommateur aval |
| activation | aucune | `FAIT_PROUVÉ` ABSENTE | `PUBLISHED` sert de substitut |
| archivage | `OfferAggregate.archive` / `offer_offer.state=ARCHIVED` | `FAIT_PROUVÉ` | rétention fournie par appelant |
| droits disponibles | `user_rights_projection` | `LEGACY` actif | EBS force `available=true` |
| budget | `budgets` avec `status`, `vote_status`, `is_active` selon consommateurs | `CONTRADICTION` | non référencé par OfferVersion |
| finance | `budget_ledger`, plus `ledger_entries` observé au runtime | `CONTRADICTION` | aucune origine Offer/Version |

`FAIT_PROUVÉ` — La source de vérité Offer dans le code est nette. La source de vérité produit ne l'est pas : les interfaces salarié et finance utilisent des chaînes indépendantes.

## 9. Connexions inter-domaines

### 9.1 Tableau des connexions

| Domaine source | Domaine cible | Mécanisme | Statut | Preuve | Risque |
|---|---|---|---|---|---|
| Offer | Operation Offer | FK + agrégat + commandes | `PROUVÉE` | migration 64-85 ; `OperationAggregate.ts` | Operation peut être ouverte sur simple `PUBLISHED` |
| Offer | Dotation | aucun identifiant, événement, table, projection ou test | `ABSENTE` | taxonomie 134-141 ; recherches code | aucune attribution/délivrance autoritative |
| Offer | EBS | query `ListOfferDistributionFacts` disponible, aucun provider/adapter consommateur | `PARTIELLE` | `PostgresOfferReadModel.ts:230-260`; absence dans EBS | fin de chaîne au read model |
| EBS | LifeHub | `/api/mes/vigile` + hook | `PROUVÉE` | `server/routes.ts:1717-1764`; hook 618-733 | cette chaîne ne contient pas Offer |
| Offer | Dashboard opérateur | query administration + commandes HTTP, aucune UI/appel | `PARTIELLE` | API 40 opérations ; aucune occurrence client | capacité backend non opérable |
| Offer | Dashboard salarié | aucun appel ; catalogues/écritures directs | `LEGACY` | `DashboardSalarie.tsx:123-230,393-463` | double vérité |
| Offer | LifeHub | aucun appel direct ni fait Offer dans EBS | `ABSENTE` | `lifehub-bridge.ts:64-140` | avantages non gouvernés par cycle Offer |
| Offer | Cockpit financier | projection admin disponible, non consommée ; Cockpit lit Budget/Subvention/Ledger | `PARTIELLE` | DTO admin ; Cockpit 475-645 | aucune lineage financière |
| Offer | Budget | aucune FK, référence typée, commande ou événement | `ABSENTE` | Version 7-14 ; migration Offer 37-56 | règle/budget non figés |
| Offer | Ledger | aucun `offer_id`/`offer_version_id` dans le ledger versionné | `ABSENTE` | migration `budget_ledger:1-16` | écritures Offer-orphelines |
| Offer | Subvention | aucun identifiant ou handoff | `ABSENTE` | migration `subventions:1-19` | demande créée sans Offer |
| Offer | éligibilité/Compute Rights | aucune lecture Offer | `ABSENTE` | `compute-rights:269-384` | Rights indépendant de publication/activation |
| Offer | catalogue salarié | catalogues frontend statiques | `LEGACY` | `DashboardSalarie.tsx:123-230`; `config/avantages.ts` | divergence des offres |
| Offer | droits disponibles | Rights → EBS, sans Offer | `ABSENTE` | `lifehub.helpers.ts:173-195` | tous les items sont disponibles |
| Offer | CEREBRAU Runtime | aucune logique métier, uniquement orchestration de mission | `ABSENTE` conforme | recherche runtime | aucun risque de second moteur Offer observé |

### 9.2 Q6 — Offer est-il connecté à Dotation ?

`FAIT_PROUVÉ` — **Non. Statut `ABSENTE`.** Aucun bounded context, agrégat, table, API, événement, projection ou test Dotation exécutable n'a été trouvé. La taxonomie documentaire annonce explicitement cette absence.

### 9.3 Q7 — Offer est-il connecté à l'EBS ?

`FAIT_PROUVÉ` — **Partiellement au niveau du contrat, absent au runtime.** Offer produit une projection interrogeable, mais aucun provider, mapper, connector, registry ou DistributionLayer EBS ne la consomme. L'EBS LifeHub prend ses benefits dans `user_rights_projection`.

### 9.4 Q8 — Offer est-il connecté au Dashboard ?

| Action | Backend | Interface opérationnelle | Conclusion |
|---|---|---|---|
| créer | `CreateOffer` | absente | `PARTIELLE` |
| modifier | `UpdateOfferDraft` | absente | `PARTIELLE` |
| versionner | `CreateOfferVersion` | absente | `PARTIELLE` |
| valider | `ValidateOffer` | absente | `PARTIELLE` |
| publier | `PublishOffer` | absente | `PARTIELLE` |
| activer | absent | absente | `ABSENTE` |
| suspendre | `SuspendOffer` | absente | `PARTIELLE` |
| archiver | `ArchiveOffer` | absente | `PARTIELLE` |

`FAIT_PROUVÉ` — Le Dashboard admin/GDBCSE ne contient aucun appel `/api/v1/offer`, aucune commande Offer et aucun écran de workbench Offer.

### 9.5 Q9 — Offer est-il connecté à LifeHub et aux quatre avantages ?

| Avantage attendu | Source autoritative Offer trouvée | Ce qui existe | Verdict |
|---|---|---|---|
| `TKR` | non | règles de simulation « Tickets restaurant » | `ABSENTE` |
| `CHDV` | non | règles de simulation « Chèques vacances » et catalogue frontend | `LEGACY` |
| `CESU` | non | simulation/config frontend | `LEGACY` |
| autre avantage configuré | non | `family` libre, `parameters` JSON et catalogues statiques | `INCONNU` |

`FAIT_PROUVÉ` — Aucun code canonique `TKR`, `CHDV` ou `CESU` n'est défini dans Offer. LifeHub ne peut donc pas dériver ces quatre avantages d'une Version Offer publiée/active.

## 10. Legacy actif

### 10.1 Q10 — Inventaire

| Élément legacy | Chemin | Encore exécuté | Consommateur | Risque | Décision proposée |
|---|---|---|---|---|---|
| catalogue salarié local A | `client/src/pages/DashboardSalarie.tsx:123-230,1573-1613` | oui | Dashboard salarié | offres/plafonds indépendants d'Offer | rendre éditorial puis remplacer la disponibilité par EBS |
| catalogue salarié local B | `client/src/config/avantages.ts:24-270` | oui | `AvantageDetailPage` | second catalogue divergent | conserver contenu éditorial, supprimer toute autorité métier |
| plafonds frontend | `client/src/config/budgets.ts:15-22` | oui | Dashboard salarié | calcul navigateur d'un droit restant | remplacer par projection Rights/EBS sourcée Offer |
| calcul Rights autonome | `supabase/functions/compute-rights/index.ts:269-556` | oui | Mon Espace, EBS | droits sans Offer/Version/Budget | rattacher chaque résultat à une Version autorisée |
| projection Rights | table runtime `user_rights_projection`; lecteur `lifehub-bridge.ts:95-107` | oui | EBS/LifeHub | `available=true` inconditionnel | enrichir lineage et disponibilité gouvernée |
| demandes Subvention directes | `DashboardSalarie.tsx:430-463,609-649`; table `subventions` | oui | salarié, admin, EBS, Cockpit | création sans Offer/Version | handoff backend obligatoire et origine immuable |
| Budget multi-indicateurs | `budgets`; `DashboardSalarie.tsx:434-441`; routes Budget | oui | Dashboard/Cockpit | `status`, `vote_status`, `is_active` divergent | décider un état souverain et référencer le Budget dans la Version |
| double définition de table Budget | migrations `20260101000000_create_budgets.sql:12-29` et `20260326000100_create_budgets.sql:1-8` | appliquabilité inconnue | runtime migrations | drift par `create table if not exists` | consolider par migration additive certifiée |
| ledger financier principal | `20260222000000_create_budget_ledger.sql:1-16` | oui | RPC finance, Cockpit | aucune origine Offer/Version | ajouter lineage sur nouveaux mouvements |
| ledger runtime non versionné | `ledger_entries`, observé dans DPDS runtime 62-113 | oui au 19 juillet ; actuel inconnu | trigger `subventions` observé | seconde vérité financière | qualifier puis neutraliser comme producteur |
| simulation TKR/CHDV/CESU | `client/src/gdbcse/config/deviceBusinessRules.ts:1-54`; `GdbcseSimulation.tsx` | oui | GDBCSE simulation | simulation confondable avec catalogue/exécution | maintenir strictement prévisionnel |
| EBS benefits transitoires | `lifehub.helpers.ts:173-195` | oui | LifeHub/Dashboard salarié | disponibilité inventée par transformation | exiger source Offer + Rights, ne plus forcer `true` |

`DÉCISION_À_PRENDRE` — Aucun legacy ne doit être supprimé avant qu'un consommateur de remplacement, une stratégie de coexistence et une preuve de non-régression soient certifiés.

## 11. Contradictions

### 11.1 Q11 — Contradictions recensées

| Id | Classification | Contradiction | Preuves | Impact |
|---|---|---|---|---|
| K01 | `CONTRADICTION` | doctrine de mission : publication ≠ activation ; code/doc canonique antérieur : `PUBLISHED` distribuable | mission ; `CANONICAL_OFFER_STATE_MACHINE.md:47,59,80`; code | racine MVP ambiguë |
| K02 | `CONTRADICTION` | `effectiveAt` annoncé, mais état/projection changent immédiatement | `OfferAggregate.ts:98-99`; read model 237-244 | offre future visible trop tôt |
| K03 | `CONTRADICTION` | invariants revendiqués par Domain, mais valeurs de contrôle fournies par le client | validation HTTP 31-50 ; commandes ; Application 69-96 | contournement de règles |
| K04 | `CONTRADICTION` | repositories exposent `codeExists` et `countNonTerminalByOffer`, Application ne les utilise pas | repositories 16-25 ; Application 69-96 | unicité/fermeture décidées hors autorité |
| K05 | `CONTRADICTION` | événements Outbox produits, aucun dispatcher/publisher runtime monté | outbox ; composition root ; routes | événements sans consommateur |
| K06 | `CONTRADICTION` | EBS est désigné consommateur Offer dans les docs, mais lit Rights/Subvention sans Offer | context map 33-39 ; `lifehub-bridge.ts:64-140` | contrat sans intégration |
| K07 | `CONTRADICTION` | Dashboard doit piloter Offer, mais aucune UI ne consomme l'API | API montée ; recherche client vide | runtime sans interface |
| K08 | `CONTRADICTION` | LifeHub doit afficher les offres réellement disponibles, mais EBS marque tous les rights items disponibles | helper 173-195 | disponibilité non autoritative |
| K09 | `CONTRADICTION` | Version Offer devrait figer la configuration, mais Rights lit `rights_config` indépendante | Version 7-14 ; compute-rights 332-384 | double vérité de règles |
| K10 | `CONTRADICTION` | Offer n'a pas de Budget, Subvention ni Ledger lineage, alors que les UI exécutent ces flux | migrations + Dashboard/Cockpit | finance orpheline d'Offer |
| K11 | `CONTRADICTION` | migration Offer présente/certifiée localement, aucune table `offer_*` dans la photographie Supabase du 19 juillet | migration ; rapports ICCMS/DPDS | dépôt ≠ runtime observé |
| K12 | `CONTRADICTION` | deux catalogues salarié, un catalogue Dashboard et des règles de simulation coexistent | fichiers frontend | catalogue et avantages divergents |

`FAIT_PROUVÉ` — Nombre de contradictions : **12**.

## 12. Éléments absents

| Élément | Classification | Preuve d'absence | Conséquence |
|---|---|---|---|
| `OfferStatus.ACTIVE` | `FAIT_PROUVÉ` ABSENT | états TS + CHECK SQL | activation impossible |
| `ActivateOffer` | `FAIT_PROUVÉ` ABSENT | catalogue 25 commandes | aucun endpoint |
| `OfferActivated` | `FAIT_PROUVÉ` ABSENT | catalogue 25 événements | aucune preuve auditable |
| date/période d'activation Offer | `FAIT_PROUVÉ` ABSENT | modèle et migration | `effectiveAt` surchargé |
| UI Offer admin | `FAIT_PROUVÉ` ABSENT | aucune consommation client | cycle non opérable |
| connecteur Offer→EBS | `FAIT_PROUVÉ` ABSENT | EBS providers/connectors | projection inutilisée |
| worker Outbox Offer runtime | `FAIT_PROUVÉ` ABSENT | composition root/routes | événements non diffusés |
| domaine Dotation exécutable | `FAIT_PROUVÉ` ABSENT | code/migrations/tests | pas d'attribution |
| codes canoniques TKR/CHDV/CESU | `FAIT_PROUVÉ` ABSENT | recherche Offer | quatre avantages non dérivables |
| `budgetId` typé/versionné dans Offer | `FAIT_PROUVÉ` ABSENT | `OfferVersionDefinition` | finance non reproductible |
| `offer_id`/`offer_version_id` dans Subvention/Ledger | `FAIT_PROUVÉ` ABSENT | migrations | pas de traçabilité métier |
| tests E2E Offer→EBS→LifeHub→finance | `FAIT_PROUVÉ` ABSENT | suites recensées | MVP non certifiable |
| migrations repository pour `rights_config` et projection Rights | `FAIT_PROUVÉ` ABSENT | recherche globale hors docs | schéma Rights non reproductible depuis le dépôt |

### Inconnues

| Id | Classification | Inconnue | Point de levée |
|---|---|---|---|
| U01 | `INCONNU` | tables/vues Offer présentes aujourd'hui sur DEV/Supabase | inventaire catalogue live read-only |
| U02 | `INCONNU` | migration Offer enregistrée dans l'historique distant actuel | `migration list` lié + hash |
| U03 | `INCONNU` | consommateurs externes hors dépôt de l'API ou de l'outbox | registre d'intégration + logs |
| U04 | `INCONNU` | sémantique officielle finale entre activation Offer et ouverture Operation | décision Architecture Board |
| U05 | `INCONNU` | mapping officiel `TKR/CHDV/CESU/autre` vers `family` et règles | catalogue produit approuvé |
| U06 | `INCONNU` | futur propriétaire du moteur Dotation | décision de contexte |
| U07 | `INCONNU` | ledger souverain et calendrier de retrait de `ledger_entries` | décision Finance/Data |
| U08 | `INCONNU` | stratégie et échéance de retrait des catalogues/plafonds frontend | décision Produit/UI |

`FAIT_PROUVÉ` — Nombre d'inconnues : **8**.

## 13. Risques MVP

| Risque | Classification | Gravité | Déclencheur actuel | Mesure de maîtrise |
|---|---|---:|---|---|
| publication assimilée à activation | `CONTRADICTION` | critique | K01-K02 | décision explicite avant code |
| préconditions falsifiables | `CONTRADICTION` | critique | K03-K04 | résoudre côté serveur dans la transaction |
| schéma DEV divergent | `INCONNU` | critique | U01-U02/K11 | gate DB avant implémentation |
| droits non sourcés Offer | `FAIT_PROUVÉ` | critique | F22 | lineage OfferVersion obligatoire |
| événements sans diffusion | `FAIT_PROUVÉ` | élevé | F16 | worker/publisher supervisé |
| UI opérateur absente | `FAIT_PROUVÉ` | élevé | C66 | workbench sur API, jamais Supabase direct |
| double catalogue salarié | `FAIT_PROUVÉ` | élevé | K12 | contenu éditorial séparé de la disponibilité |
| finance sans origine | `FAIT_PROUVÉ` | critique | K10 | clés et causalité immuables |
| aucun E2E | `FAIT_PROUVÉ` | élevé | section 12 | parcours certifiant |
| legacy retiré trop tôt | `HYPOTHÈSE` | élevé | remplacement incomplet | coexistence bornée et métriques |

## 14. Architecture cible déjà décidée

`DÉCISION_EXISTANTE` — La doctrine reçue fixe les responsabilités :

- Offer porte identité économique, produit, catalogue de prestations, Versions, cycle de vie, publication et gouvernance fonctionnelle ;
- Dotation porte budgets d'attribution, montants, plafonds, consommations, calculs et paramètres financiers qui lui appartiennent ;
- EBS consolide et distribue sans devenir moteur Offer/Dotation ni catalogue parallèle ;
- Dashboard commande les cas d'usage serveur sans recalculer le métier ;
- LifeHub consomme exclusivement les offres/droits réellement disponibles ;
- Cockpit financier lit les engagements/consommations des autorités métier ;
- CEREBRAU Runtime orchestre missions, preuves et gouvernance, sans logique Offer/Dotation.

`DÉCISION_EXISTANTE` — Le flux cible minimal est :

`Dashboard opérateur → Offer/Version → validation → publication → activation distincte → éligibilité/rights → EBS → LifeHub/Dashboard salarié → exécution → Budget/Ledger/Cockpit`, avec audit et causalité de bout en bout.

`CONTRADICTION` — Le corpus canonique antérieur certifie `PUBLISHED` comme distribuable et ne définit pas l'activation distincte. Une décision de supersession documentaire est nécessaire avant toute modification du modèle.

## 15. Écarts entre actuel et cible

### 15.1 Q12 — Minimum nécessaire au MVP

| Capacité MVP | État actuel | Écart | Risque | Dépendance | Lot proposé | Gate |
|---|---|---|---|---|---|---|
| création | backend/API présents | aucune UI ; dispositif déclaré utilisable par client | élevé | décision trust boundary | L03 | G3 |
| configuration | Version avec JSON libre | contrat avantages/périodes/Budget non typé | critique | catalogue + Budget | L02 | G2 |
| validation | présente | contrôles booléens déclaratifs | critique | repositories de contrôle | L02 | G2 |
| publication | présente | `effectiveAt` non respecté | critique | décision sémantique | L01-L02 | G1-G2 |
| activation | absente | état/commande/événement/DB/API/UI manquants | critique | décision de cycle | L01-L02 | G1-G2 |
| distribution EBS | projection Offer présente | connecteur et worker absents | critique | cycle + Rights | L04 | G4 |
| affichage LifeHub | EBS consommé | benefits non sourcés Offer | critique | L04 | L05 | G5 |
| pilotage Dashboard | API disponible | workbench absent | élevé | L02 | L03 | G3 |
| traçabilité | audit/outbox Offer présents | aucune causalité aval/finance | critique | L04-L06 | L06 | G6 |
| Dotation | absente | moteur/propriétaire/contrat absents | élevé | décision contexte | hors noyau, L07 | G7 |
| sécurité des données | tenant/idempotence présents | invariants client-supplied | critique | L01 | L02 | G2 |
| stabilité production | tests locaux positifs | runtime DB actuel inconnu, E2E absent | critique | L01-L06 | tous | G0-G6 |

`DÉCISION_À_PRENDRE` — Le chemin le plus court n'est pas « brancher l'UI sur `PUBLISHED` ». Il faut d'abord figer la sémantique, la migration réelle et les préconditions serveur ; seulement ensuite exposer activation, distribution et interfaces.

## 16. Décisions à prendre

| Id | Classification | Décision | Autorité attendue | Sortie exigée |
|---|---|---|---|---|
| D01 | `DÉCISION_À_PRENDRE` | superséder ou maintenir le modèle `PUBLISHED=distribuable` | Architecture Board | ADR de cycle Offer |
| D02 | `DÉCISION_À_PRENDRE` | définir `effectiveAt`, activation, suspension et ouverture Operation | Offer/Product | automate approuvé |
| D03 | `DÉCISION_À_PRENDRE` | typer le contrat Version : familles, avantages, périodes, règles, références Budget | Offer + Dotation/Budget | schéma de Version v2 |
| D04 | `DÉCISION_À_PRENDRE` | déplacer les préconditions déclaratives vers des lectures serveur autoritatives | Security/Data | matrice invariant→repository |
| D05 | `DÉCISION_À_PRENDRE` | choisir diffusion EBS par query, événement ou combinaison et opérer l'outbox | Integration/EBS | contrat + SLO + idempotence |
| D06 | `DÉCISION_À_PRENDRE` | définir le workbench Dashboard et les rôles habilités | Product/Security | parcours et matrice RBAC |
| D07 | `DÉCISION_À_PRENDRE` | faire de Rights une dérivation d'OfferVersion autorisée | Rights/Offer | contrat de lineage |
| D08 | `DÉCISION_À_PRENDRE` | choisir le Budget/Ledger souverain et propager l'origine Offer | Finance/Data | modèle causal financier |
| D09 | `DÉCISION_À_PRENDRE` | propriétaire et périmètre MVP Dotation | Domain Board | context map et événement de handoff |
| D10 | `DÉCISION_À_PRENDRE` | stratégie de coexistence/retrait du legacy | Program Director | plan de migration avec dates/gates |

`FAIT_PROUVÉ` — Nombre de décisions à prendre : **10**.

## 17. Backlog minimal ordonné

| Ordre | Élément | Classification | Résultat attendu | Bloque |
|---:|---|---|---|---|
| 1 | rendre D01-D04 et certifier le schéma DEV actuel | `DÉCISION_À_PRENDRE` | autorité et base réconciliées | tout développement |
| 2 | formaliser l'automate Offer/Version/Operation et le contrat Version | `DÉCISION_À_PRENDRE` | aucune ambiguïté Publish/Activate/Open | UI/EBS/Rights |
| 3 | sécuriser les invariants dans l'Application transactionnelle | `DÉCISION_À_PRENDRE` | aucun booléen souverain accepté du client | production |
| 4 | compléter le cycle d'activation décidé dans les quatre couches | `DÉCISION_À_PRENDRE` | preuve persistée et auditée | aval |
| 5 | livrer le workbench Dashboard sur l'API Offer | `DÉCISION_À_PRENDRE` | opérabilité create→activate | exploitation |
| 6 | raccorder Rights et EBS à OfferVersion avec lineage | `DÉCISION_À_PRENDRE` | disponibilité déterministe | LifeHub |
| 7 | basculer LifeHub/Dashboard salarié sur EBS autoritatif | `DÉCISION_À_PRENDRE` | aucune constante ne décide un droit | valeur salarié |
| 8 | propager Offer/Version vers Subvention/Budget/Ledger/Cockpit | `DÉCISION_À_PRENDRE` | traçabilité financière | certification finance |
| 9 | implémenter Dotation seulement après décision D09 | `DÉCISION_À_PRENDRE` | pas de second moteur | extension MVP |
| 10 | retirer le legacy par consommateur, après preuves | `DÉCISION_À_PRENDRE` | source unique | clôture programme |

## 18. Proposition de lots

Les lots ci-dessous sont des propositions d'exécution non officielles. Ils respectent l'ordre : cohérence fonctionnelle, sécurité des données, source unique, stabilité, valeur client, gain opérationnel, réduction du legacy, vitesse MVP.

### L01 — Autorité et baseline de données

| Champ | Valeur |
|---|---|
| objectif | rendre D01-D04, inventorier le schéma live, fixer les supersessions documentaires |
| périmètre | ADR, contrats, catalogues DB read-only, matrice de migration |
| dépendances | aucune |
| fichiers probables | `Docs/21_DOMAIN_MODELS/CANONICAL_OFFER_*`, future migration additive seulement après GO |
| risques | décision ambiguë, environnement non reproductible |
| tests | comparaison repo/live, hashes migration, tests PostgreSQL isolés |
| preuve de réussite | un automate officiel et un schéma live concordant |
| gate | G0-G1 |
| ordre d'exécution | 1 |

### L02 — Cycle Offer sécurisé et contrat Version

| Champ | Valeur |
|---|---|
| objectif | implémenter uniquement l'automate décidé, typer Version et résoudre les invariants côté serveur |
| périmètre | Domain, Application, API, Infrastructure, migration additive, tests |
| dépendances | L01 GO |
| fichiers probables | `server/offer-domain/**`, `server/offer-application/**`, `server/offer-api/**`, `server/offer-infrastructure/**`, migration nouvelle |
| risques | incompatibilité legacy `PUBLISHED`, migration CHECK |
| tests | transitions, dates, SOD, rôles, concurrence, idempotence, PostgreSQL, OpenAPI |
| preuve de réussite | publication seule n'active pas ; activation décidée est persistée/auditée ; contrôles non falsifiables |
| gate | G2 |
| ordre d'exécution | 2 |

### L03 — Workbench Dashboard Offer

| Champ | Valeur |
|---|---|
| objectif | rendre création, configuration, validation, publication, activation, suspension et archivage opérables |
| périmètre | GDBCSE/Dashboard, client API Offer, gestion ETag/idempotence/erreurs |
| dépendances | L02 GO |
| fichiers probables | `client/src/gdbcse/**`, routes `App.tsx`, nouveaux hooks/services/tests |
| risques | duplication d'automate, mutation Supabase directe |
| tests | React, parcours par rôle, concurrence ETag, accessibilité |
| preuve de réussite | chaque action produit la commande et recharge la projection serveur |
| gate | G3 |
| ordre d'exécution | 3 |

### L04 — Rights, Outbox et distribution EBS

| Champ | Valeur |
|---|---|
| objectif | propager Offer/Version autorisée vers Rights puis EBS, sans logique Offer dans EBS |
| périmètre | outbox worker/publisher ou query contract décidé, Rights lineage, provider EBS |
| dépendances | L02 GO |
| fichiers probables | `offer-infrastructure/events`, composition runtime, `compute-rights`, `employee-business-state/**` |
| risques | double calcul, ordre d'événements, retry |
| tests | idempotence, replay, suspension, activation, tenant, provenance |
| preuve de réussite | aucun benefit sans OfferVersion admissible ; provenance complète |
| gate | G4 |
| ordre d'exécution | 4 |

### L05 — LifeHub et Dashboard salarié autoritatifs

| Champ | Valeur |
|---|---|
| objectif | afficher TKR, CHDV, CESU et autre uniquement depuis EBS sourcé |
| périmètre | hooks/pages LifeHub, Dashboard salarié, catalogues éditoriaux |
| dépendances | L04 GO, mapping D03 approuvé |
| fichiers probables | `client/src/lifehub/**`, `DashboardSalarie.tsx`, `config/avantages.ts`, `config/budgets.ts` |
| risques | régression UX, perte de contenu éditorial |
| tests | mêmes offres/version sur interfaces, indisponibilité/suspension, zéro calcul local |
| preuve de réussite | quatre avantages dérivés, absence d'autorité frontend |
| gate | G5 |
| ordre d'exécution | 5 |

### L06 — Lineage Subvention/Budget/Ledger/Cockpit

| Champ | Valeur |
|---|---|
| objectif | préserver Offer/Version/Budget de la demande jusqu'au mouvement financier |
| périmètre | handoff Subvention, schéma additif, RPC, ledger souverain, Cockpit |
| dépendances | L02, L04, D08 |
| fichiers probables | migrations nouvelles, routes/services Subvention/Budget, RPC Ledger, Cockpit |
| risques | double ledger, données historiques sans origine |
| tests | FK tenant, idempotence, reserve/release/pay/refund, rapprochement Cockpit |
| preuve de réussite | aucune nouvelle demande/écriture sans origine ; legacy explicitement marqué |
| gate | G6 |
| ordre d'exécution | 6 |

### L07 — Dotation et réduction du legacy

| Champ | Valeur |
|---|---|
| objectif | introduire le propriétaire Dotation décidé et retirer les producteurs parallèles |
| périmètre | contexte Dotation, attribution/délivrance, migrations de consommateurs |
| dépendances | L01-L06 GO, D09-D10 |
| fichiers probables | à déterminer par context map ; catalogues/simulation frontend en migration |
| risques | création d'un second catalogue ou second moteur financier |
| tests | lineage complet, unicité attribution, non-régression legacy |
| preuve de réussite | une seule autorité par donnée et aucun consommateur orphelin |
| gate | G7 |
| ordre d'exécution | 7 |

## 19. Gates de certification

| Gate | Critère GO | État au 23 juillet | Verdict |
|---|---|---|---|
| G0 Autorité | D01-D04 signées, document canonique supersédé explicitement | non | `NO_GO` |
| G1 Données | schéma live Offer présent, migrations alignées et RLS testée | inconnu ; photographie antérieure divergente | `NO_GO` |
| G2 Cycle sécurisé | automate décidé, activation explicite si retenue, invariants serveur, tests PG | absent | `NO_GO` |
| G3 Dashboard | toutes actions opérables via API, aucun accès table direct | absent | `NO_GO` |
| G4 Distribution | outbox/query opérée, Rights lineage, EBS déterministe | absent/partiel | `NO_GO` |
| G5 LifeHub | quatre avantages sourcés Offer/Version/rights, aucune constante autoritative | absent | `NO_GO` |
| G6 Finance | Subvention/Budget/Ledger/Cockpit portent l'origine | absent | `NO_GO` |
| G7 Legacy/Dotation | propriétaire décidé, remplacement mesuré, aucune double vérité mutable | absent | `NO_GO` |

`FAIT_PROUVÉ` — Les tests locaux valident le modèle actuel, pas le MVP cible. Ils ne lèvent aucun des gates G0-G7.

## 20. Verdict

`NO_GO`

`FAIT_PROUVÉ` — Le référentiel du dépôt permet de localiser et comprendre Offer avec précision. Le cycle observé dans la mission est confirmé : création en `DRAFT`, validation de Version sans changement d'état Offer, puis publication simultanée de Version et Offer en `PUBLISHED`.

`FAIT_PROUVÉ` — L'activation Offer est absente. `PUBLISHED` est une publication administrative qui agit aussi comme disponibilité technique immédiate dans le read model et comme condition d'ouverture Operation. Il ne faut pas la déclarer équivalente à une activation métier.

`FAIT_PROUVÉ` — Offer n'est pas réellement relié à Dotation, Rights, EBS, Dashboard opérateur, LifeHub, Budget, Ledger ou Subvention. Les projections backend constituent des amorces, pas des connexions opérationnelles.

`CONTRADICTION` — Le code, les documents canoniques antérieurs, les interfaces legacy et la photographie runtime ne forment pas encore une autorité unique. La présence live actuelle des tables Offer est inconnue et une observation datée les donnait absentes.

`DÉCISION_À_PRENDRE` — Le prochain point de reprise exact est le gate **G0 Autorité** : réunion Architecture Board pour rendre D01-D04, publier l'ADR qui distingue précisément `PublishOffer`, l'éventuelle `ActivateOffer` et `OpenOperation`, puis enchaîner immédiatement sur G1 avec un inventaire read-only du schéma DEV et de l'historique des migrations.

```text
MissionId: OFFER-AUTHORITY-RECONCILIATION-001
Verdict: NO_GO
Fichier créé: Docs/PROGRAM/OFFER/OFFER_AUTHORITY_RECONCILIATION_REPORT_001.md
Nombre de composants recensés: 67
Nombre de contradictions: 12
Nombre d'inconnues: 8
Nombre de décisions à prendre: 10
Prochain point de reprise exact: Gate G0 — décision Architecture Board D01-D04, puis Gate G1 — inventaire read-only du schéma DEV et de l'historique des migrations Offer
```
