# OFFER — vérification de la migration `20260717000000`

```text
PROGRAM          : PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001
LOT              : OFFER
MISSION_ID       : OFFER-MIGRATION-20260717000000-VERIFY-001
MISSION_TYPE     : MICRO_VERIFICATION
EXECUTION_MODE   : ONE_SHOT
EXPECTED_CHANGES : DOCUMENTATION_ONLY
```

## Périmètre

Cette vérification porte exclusivement sur l'existence dans le dépôt de la migration préfixée `20260717000000` et sur la justification de son absence dans l'historique live telle que consignée par `OFFER_G1_DATA_INVENTORY_REPORT_001.md`.

Aucune nouvelle inspection de la base, aucun test et aucune exécution de migration n'ont été réalisés.

## Q1 — Existence de la migration dans le dépôt Git

**OUI**

| Élément | Valeur vérifiée |
|---|---|
| Chemin exact | `supabase/migrations/20260717000000_create_offer_infrastructure.sql` |
| Nom exact | `20260717000000_create_offer_infrastructure.sql` |
| Suivi Git | oui — entrée `git ls-files --stage` : mode `100644`, blob `e6c04c34dc987f07e7c25d6456e4afb29d3dbbe2` |
| Taille | 13 411 octets |
| Nombre de lignes consigné par G1 | 229 |
| SHA-256 | `BA39DAD5BF03D03CC91833B2B1DF6497648E16EE6EFF3E04DAA6B5E4E3DB0F4D` |
| Premier commentaire | aucun commentaire SQL n'est présent ; la première ligne est `create table if not exists public.offer_dispositif (` |

### Objets SQL créés

#### Tables

1. `public.offer_dispositif`
2. `public.offer_offer`
3. `public.offer_offer_version`
4. `public.offer_operation`
5. `public.offer_idempotency`
6. `public.offer_audit_entry`
7. `public.offer_outbox`

#### Index explicites

1. `offer_dispositif_org_state_idx`
2. `offer_dispositif_org_category_idx`
3. `offer_offer_org_state_transition_idx`
4. `offer_offer_org_dispositif_idx`
5. `offer_offer_version_one_open_uidx`
6. `offer_offer_version_one_published_uidx`
7. `offer_offer_version_org_offer_number_idx`
8. `offer_operation_org_offer_window_idx`
9. `offer_operation_org_state_window_idx`
10. `offer_idempotency_org_status_created_idx`
11. `offer_audit_org_aggregate_idx`
12. `offer_audit_org_occurred_idx`
13. `offer_audit_correlation_idx`
14. `offer_outbox_pending_idx`
15. `offer_outbox_aggregate_order_idx`

Les quinze noms ci-dessus correspondent à treize instructions `CREATE INDEX` au sens du comptage lexical lorsque les deux instructions `CREATE UNIQUE INDEX` sont recherchées séparément, soit quinze index explicites au total.

#### Fonctions

1. `public.offer_reject_audit_mutation()`
2. `public.offer_current_organization_id()`
3. `public.offer_current_business_role()`
4. `public.offer_has_tenant_access(uuid)`

#### Trigger

1. `offer_audit_append_only`

#### Policies

1. `offer_dispositif_tenant_select`
2. `offer_offer_tenant_select`
3. `offer_offer_version_tenant_select`
4. `offer_operation_tenant_select`

#### Vues

1. `public.offer_dispositif_projection`
2. `public.offer_offer_projection`
3. `public.offer_operation_projection`

### Preuves

- migration, lignes 1-229 ;
- déclaration des sept tables : lignes 1, 19, 37, 64, 90, 105 et 130 ;
- fonctions et trigger : lignes 156-177 ;
- policies : lignes 192-198 ;
- vues : lignes 211-223 ;
- `OFFER_G1_DATA_INVENTORY_REPORT_001.md`, lignes 61-64, 106-110 et 361-363.

## Q2 — Qualification de la migration

**déjà attendue en DEV**

### Justification

`OFFER_G1_DATA_INVENTORY_REPORT_001.md`, ligne 110, qualifie exactement la migration comme :

> schéma Offer complet ; attendu appliqué en DEV ; `LIVE_ABSENT`

Le même rapport démontre simultanément :

- sa présence dans le dépôt et son suivi par Git, lignes 110 et 363 ;
- l'absence de la version `20260717000000` dans l'historique DEV visible, lignes 87 et 361.

`PROGRAM_OFFER_MIGRATION_GUIDE.md`, ligne 367, la qualifie aussi de migration historique « déjà destinée à être appliquée ».

## Q3 — Fondement de l'affirmation « migration absente du live »

**OUI**

### Justification

L'affirmation porte sur l'historique live, et non sur le dépôt :

- `OFFER_G1_DATA_INVENTORY_REPORT_001.md`, ligne 87 : trois lignes visibles seulement dans `supabase_migrations.schema_migrations`, sans version `20260717000000` ;
- ligne 290 : migration présente dans le dépôt, mais aucune ligne visible dans l'historique live ;
- lignes 361-363 : distinction explicite entre `K11_LIVE_EVIDENCE` et `K11_MIGRATION_EVIDENCE`.

La causalité historique reste inconnue selon les lignes 91 et 342 : ces preuves ne permettent pas de déterminer si la migration n'a jamais été appliquée ou si des traces ont été retirées. Elles démontrent néanmoins son absence de l'historique visible au moment du constat G1.

## Q4 — Nature de l'absence

**une anomalie**

### Justification

Le statut documentaire démontré n'est pas celui d'un développement simplement non prévu ou non réalisé : la migration existe, est complète, est suivie par Git et est explicitement qualifiée « attendu appliqué en DEV » par G1 à la ligne 110. L'écart constaté est donc entre un état attendu en DEV et l'état live observé.

## Q5 — Reformulation de K11

**NON**

### Justification

La conclusion K11 existante distingue déjà sans ambiguïté :

- la migration présente et suivie dans le dépôt ;
- la version absente de l'historique live visible ;
- les objets Offer absents de DEV ;
- la causalité passée maintenue inconnue.

Cette formulation figure dans `OFFER_G1_DATA_INVENTORY_REPORT_001.md`, lignes 359-367. Elle ne confond pas absence du fichier local et absence de la migration dans l'historique live.

## Verdict

```text
MissionId : OFFER-MIGRATION-20260717000000-VERIFY-001
Migration trouvée : OUI
Chemin exact : supabase/migrations/20260717000000_create_offer_infrastructure.sql
Conclusion : migration suivie par Git, complète et déjà attendue en DEV ; absence démontrée uniquement dans l'historique live visible et dans les objets DEV observés par G1
K11 à modifier : NON
Verdict : VÉRIFICATION CONFIRMÉE
```
