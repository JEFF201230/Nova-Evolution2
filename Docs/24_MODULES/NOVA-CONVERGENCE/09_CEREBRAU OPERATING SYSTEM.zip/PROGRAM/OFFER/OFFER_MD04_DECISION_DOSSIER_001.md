# CEREBRAU — DOSSIER DE PRÉPARATION DE LA DÉCISION MD-04

## 1. Identité

```text
PROGRAM            : VEEDDA
DOMAIN             : OFFER
MISSION_ID         : OFFER-MD04-PREPARATION-001
MISSION_TYPE       : GOVERNANCE_EVIDENCE
EXECUTION_MODE     : ONE_SHOT
EXPECTED_CHANGES   : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
```

## 2. Objet et limite

Ce dossier rassemble les preuves nécessaires au `PROGRAM_DIRECTOR` et au
`CERTIFICATION_BOARD` pour rendre ultérieurement MD-04.

Il ne rend pas MD-04, ne recommande aucune option et ne crée aucune
autorisation de migration, de déploiement, de modification du ledger, du
schéma, du Runtime, d'une matrice ou d'une décision historique.

Les termes « migration », « Gate », « LOT » et « Offer » sont utilisés comme
références documentaires. Les work packages ne sont pas des objets officiels de
gouvernance ; l'objet officiel applicable est la `WAVE`.

## 3. Conclusion probatoire exécutive

| Question | Conclusion établie par les pièces | Classe probatoire |
|---|---|---|
| `20260717000000` appartient-elle aux 29 migrations couvertes par `LOT-003_LEDGER_GOVERNANCE_DECISION.md` ? | La migration n'est jamais nommée dans cette décision et la décision ne contient aucune liste nominative. Son appartenance officielle ne peut donc pas être établie. Le rapprochement des caractéristiques documentées fait correspondre les « 28 compatibles + 1 suppression compatible » aux 29 migrations sans correspondant distant autres que la migration Offer ; cette concordance soutient une exclusion factuelle, mais ne constitue pas une décision nominative. | `INCONNU` pour l'appartenance officielle ; concordance documentaire d'exclusion, non décisionnelle |
| Pourquoi porte-t-elle `NO_REMOTE_MATCH` ? | Le snapshot DPDS compte 33 migrations locales valides, trois versions présentes des deux côtés et 30 versions locales sans version distante. `20260717000000` est nommément dans ces 30. Le registre MM-L03-01 lui affecte donc `NO_REMOTE_MATCH`. | `PROUVÉ` |
| Si elle est hors des 29, pourquoi ? | Elle est la seule des 30 lignes `NO_REMOTE_MATCH` dont tous les objets cités sont absents du Runtime (`REPOSITORY_ONLY`). Les 29 autres se décomposent exactement en 28 lignes avec objets runtime compatibles/communs et une ligne de suppression compatible. La décision LOT-003 décrit précisément ce profil `28 + 1`, sans toutefois enregistrer les versions. | correspondance `PROUVÉE`; exclusion officielle non enregistrée |
| Une décision ultérieure modifie-t-elle son statut ? | Aucune décision nominative ultérieure ne modifie `NO_REMOTE_MATCH`, `UNKNOWN`, `NONE`, `PENDING`. La Master Gates Matrix et le registre de Gates portent `L03-G04` à `GO_WITH_DEROGATION`, mais sans liste des 29 et sans réviser la ligne Offer. Les décisions Offer maintiennent G1 à `NO_GO` et interdisent toute mise en œuvre. | `PROUVÉ` |
| Existe-t-il des contradictions ? | Oui : le rapport source MM-L03-01 conclut `L03-G04 = NO GO`, tandis que les matrices ultérieures portent `GO_WITH_DEROGATION`; le registre de provenance conserve parallèlement `DerogationStatus = NONE` et `ReviewStatus = PENDING`. Une seconde contradiction documentaire oppose la qualification « anomalie / déjà attendue en DEV » à l'absence prouvée d'un ordre autoritatif antérieur de déploiement. | `PROUVÉ` |

La preuve permet donc de fixer l'état technique et documentaire de la migration,
mais pas de substituer une décision implicite à la décision nominative MD-04.

## 4. Corpus probatoire et références exactes

### 4.1 Sources primaires de repository et de Runtime

| Id | Source | Références exactes | Fait utilisé |
|---|---|---|---|
| P01 | `supabase/migrations/20260717000000_create_offer_infrastructure.sql` | lignes 1-229 ; commit Git `706bf1fae540e1798e3b827fbb162cac20b3b019` | fichier suivi, migration Offer complète |
| P02 | `Docs/PROGRAMS/PROGRAM-VEEDDA-DPDS/DPDS-000A/DPDS_000A_RUNTIME_REPOSITORY_DIFF.md` | lignes 3, 20, 38, 42-44, 101 | observation du 19 juillet 2026 ; 33 locales, 3 distantes communes, 30 sans correspondant ; objets Offer absents |
| P03 | `Docs/PROGRAMS/PROGRAM-VEEDDA-DPDS/DPDS-000A/DPDS_000A_RUNTIME_DEPLOYMENT_REPORT.md` | lignes 78-79 et 87 | version Offer et objets Offer absents ; écart qualifié bloquant G-000 |
| P04 | `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/EVIDENCE/MM-L03-01/MM_L03_01_MIGRATION_RUNTIME_PROVENANCE_REGISTER.csv` | ligne 34 | statut nominatif de `20260717000000` |
| P05 | `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/EVIDENCE/MM-L03-01/MM_L03_01_MIGRATION_RECONCILIATION_REPORT.md` | lignes 10-13, 28-34, 36-47, 54-68, 87-115 | méthode, comptes, absence de dérogation, provenance inconnue et conclusion `NO GO` |
| P06 | `SUPABASE_FORENSIC_AUDIT_REPORT.md` | lignes 83-116, 167-189, 367-371 | 34 suppressions en huit appels ; paramètres et versions supprimées indisponibles ; trois entrées courantes |

### 4.2 Décisions et référentiels de gouvernance

| Id | Source | Références exactes | Fait utilisé |
|---|---|---|---|
| P07 | `LOT-003_LEDGER_GOVERNANCE_DECISION.md` | lignes 8-23, 27-49, 206-231 | périmètre agrégé de 29 ; profil 28 compatibles + 1 suppression compatible ; `GO_WITH_DEROGATION`; aucune liste nominative |
| P08 | `Docs/PROGRAM/PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md` | lignes 35-37, 43-59, 61-83, 149-166 | décision bornée, conservation des inconnues, révision formelle, interdiction d'extrapoler ou d'attribuer un total agrégé |
| P09 | `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md` | lignes 219-231, 304-311, 358-371 | `L03-G04 = GO_WITH_DEROGATION`; Offer repository-only reste à décider sous `L09-G04`; MM-L03-01 déclarée terminée |
| P10 | `Docs/PROGRAM/PROGRAM_MASTER_GATES_REGISTER.md` | lignes 25-35 et 94-103 | enregistrement courant de `L03-G04 = GO_WITH_DEROGATION` et `L09-G04 = NO_GO` |

### 4.3 Preuves et décisions Offer

| Id | Source | Références exactes | Fait utilisé |
|---|---|---|---|
| P11 | `Docs/PROGRAM/OFFER/OFFER_ARCHITECTURE_BOARD_DECISIONS_001.md` | lignes 951-1002 et 1004-1031 | K11 initialement ouverte ; G0 `GO`; G1 `NO_GO`; aucune implémentation avant G1 |
| P12 | `Docs/PROGRAM/OFFER/OFFER_G1_DATA_INVENTORY_REPORT_001.md` | lignes 13, 87, 106-110, 340-342, 359-405 | observation live du 23 juillet 2026 ; migration locale présente ; version et objets Offer absents ; causalité historique inconnue ; G1 `NO_GO` |
| P13 | `Docs/PROGRAM/OFFER/OFFER_MIGRATION_20260717000000_VERIFICATION_001.md` | Q1 à Q5, notamment lignes 22-30, 93-126 et 141-160 | fichier et hash confirmés ; qualification « déjà attendue en DEV » et « anomalie » |
| P14 | `Docs/PROGRAM/OFFER/OFFER_DEPLOYMENT_AUTHORITY_VERIFICATION_001.md` | lignes 123-177 | aucun ordre autoritatif antérieur de déploiement retrouvé ; K11 reformulée |
| P15 | `Docs/PROGRAM/OFFER/OFFER_G1_NO_GO_REPORT_001.md` | lignes 35-49, 68-87, 106-123, 210-223 | décision Offer G1 du 23 juillet ; dérogation LOT-003 non extensible à Offer ; MD-04 identifiée comme décision manquante |

## 5. Chronologie complète des faits et décisions utiles

### 5.1 État repository

1. La migration `20260717000000_create_offer_infrastructure.sql` est une
   migration locale suivie par Git. Son SHA-256 est
   `BA39DAD5BF03D03CC91833B2B1DF6497648E16EE6EFF3E04DAA6B5E4E3DB0F4D`.
   Elle définit sept tables Offer, quinze index explicites, quatre fonctions,
   un trigger, quatre policies et trois vues (P01, P13).
2. Le fichier appartient à la baseline du commit
   `706bf1fae540e1798e3b827fbb162cac20b3b019`, utilisé par le diff DPDS et
   MM-L03-01 (P02, P05).

### 5.2 Observation DPDS du 19 juillet 2026

3. Le Runtime est observé le `2026-07-19 16:47:13 UTC` (P02, ligne 3).
4. DPDS dénombre 33 migrations locales valides et seulement trois versions
   présentes dans le ledger distant. Les 30 autres sont énumérées ; la liste
   comprend explicitement `20260717000000` (P02, lignes 42-44).
5. Les objets créés par la migration Offer sont absents du Runtime observé
   (P02, lignes 26-38).
6. Le rapport de déploiement qualifie la version Offer de « non appliquée » et
   l'écart de bloquant G-000 (P03, lignes 78-79). Cette qualification décrit
   l'état observé ; elle ne prouve pas une obligation antérieure de déploiement
   (P14, lignes 123-131).

### 5.3 Réconciliation MM-L03-01 du 20 juillet 2026

7. MM-L03-01 est générée le `2026-07-20T14:26:27Z` sur la même baseline
   (P05, lignes 10-13).
8. Le contrôle confirme `33` migrations locales, `3` correspondances de
   version, `30` migrations sans correspondance et `0` dérogation explicite
   (P05, lignes 36-45).
9. Le registre nominatif porte pour `20260717000000` :

   ```text
   RemoteLedgerStatus = NO_REMOTE_MATCH
   RuntimeObjects      = NONE; all cited Offer objects are REPOSITORY_ONLY
   ProvenanceStatus    = UNKNOWN
   DerogationStatus    = NONE
   OwningGate          = L03-G04
   ReviewStatus        = PENDING
   ```

   Source : P04, ligne 34.
10. Le rapport conclut `L03-G04 = NO GO` parce que les 30 versions ne sont ni
    appliquées ni explicitement dérogées et que la provenance runtime demeure
    inconnue (P05, lignes 99-115).

### 5.4 Audit forensique et décision LOT-003 du 21 juillet 2026

11. L'audit forensique, observé le 21 juillet, prouve 34 suppressions du ledger
    en huit appels sous le rôle PostgreSQL `postgres`. Il ne retrouve ni les
    versions supprimées ni leur rattachement aux migrations locales (P06).
12. La décision `GOV-DEROGATION-LEDGER-001` définit son périmètre comme
    « 29 migrations classées `UNKNOWN` » (P07, lignes 8-17).
13. Elle décrit 28 migrations dont l'état runtime est compatible et une
    vingt-neuvième dont l'état de suppression est compatible. Elle ne fournit
    aucun identifiant de version pour ces 29 migrations (P07, lignes 27-49).
14. Elle rend `GO_WITH_DEROGATION`, conserve le statut historique `UNKNOWN` et
    interdit toute réparation, modification Supabase, réécriture du ledger ou
    requalification en fait prouvé (P07, lignes 206-231).

### 5.5 Enregistrement ultérieur dans les matrices

15. La Master Gates Matrix et le Master Gates Register enregistrent ensuite
    `L03-G04 = GO_WITH_DEROGATION`, avec la formule « historique couvert par la
    dérogation ; inconnues conservées » (P09, P10).
16. Aucun de ces deux documents ne donne la liste des 29 migrations couvertes
    et aucun ne modifie la ligne `20260717000000` du registre de provenance.
17. La même Master Gates Matrix maintient `L09-G04 = NO GO` jusqu'à une décision
    de déployer ou d'abandonner les objets repository-only, « dont Offer »
    (P09, lignes 304-311). Le Master Gates Register confirme ce `NO_GO` (P10,
    lignes 94-103).

### 5.6 Décisions Offer du 23 juillet 2026

18. L'Architecture Board approuve D01 à D10 et G0, mais maintient G1 à
    `NO_GO`. Elle autorise uniquement une inspection read-only avant toute
    implémentation (P11).
19. L'inventaire live du `2026-07-23 15:55:05 UTC` prouve que la version
    `20260717000000` n'est pas dans les trois lignes visibles du ledger et
    qu'aucun objet Offer attendu n'existe. Il maintient la causalité historique
    `INCONNU` et G1 à `NO_GO` (P12).
20. La micro-vérification de la migration confirme le fichier, son contenu et
    son hash. Elle reprend toutefois l'attendu documentaire « déjà attendue en
    DEV » et qualifie l'absence d'« anomalie » (P13).
21. La vérification d'autorité postérieure constate qu'aucune décision
    autoritative antérieure n'imposait le déploiement de cette migration en DEV
    avant G1. Elle conserve la divergence factuelle, mais retire l'implication
    d'un manquement à un ordre de déploiement (P14).
22. La décision Offer G1 du 23 juillet maintient `NO_GO`, refuse d'étendre
    implicitement la dérogation LOT-003 à Offer et enregistre MD-04 comme
    décision manquante devant produire la liste nominative des 29 et inclure ou
    exclure explicitement `20260717000000` (P15, lignes 106-119 et 210-223).

## 6. Réconciliation nominative des ensembles

### 6.1 Ensemble DPDS certain

L'ensemble certain est celui des 30 versions locales `NO_REMOTE_MATCH` de P02
et P04 :

```text
20260101000000  20260101000010  20260222000000  20260222000001
20260222173757  20260222181344  20260222183223  20260222184447
20260222191528  20260222191655  20260222192258  20260222193508
20260222194550  20260222195145  20260222195900  20260222201000
20260222202000  20260222203000  20260222204500  20260222205500
20260222211000  20260326000100  20260528120000  20260612000100
20260615        20260617_0001   20260617_0002   20260622000200
20260712000000  20260717000000
```

### 6.2 Correspondance avec la description des 29

| Groupe observable dans P04 | Nombre | Correspondance avec P07 |
|---|---:|---|
| Versions `NO_REMOTE_MATCH`, hors `20260222203000` et `20260717000000`, ayant des objets communs par nom ou une identité structurelle QF | 28 | « runtime compatible avec 28 » |
| `20260222203000`, migration de suppression de trois index, avec `RuntimeObjects = NONE_CITED_FOR_DROPPED_INDEXES` | 1 | « état de suppression compatible » |
| `20260717000000`, avec zéro objet runtime et tous les objets Offer `REPOSITORY_ONLY` | 1 | ne correspond à aucune des deux caractéristiques de P07 |

Cette correspondance isole un ensemble de 29 versions non-Offer satisfaisant
exactement les deux caractéristiques de la décision LOT-003. Elle constitue une
preuve de cohérence entre les pièces.

Elle ne remplace pas une liste nominative autoritative :

- P07 n'enregistre aucune version ;
- P08 interdit qu'un total agrégé soit présenté comme attribution individuelle
  et interdit l'extension d'une décision hors de sa portée ;
- P15 constate expressément que cette attribution doit être rendue par MD-04.

En conséquence, le dossier ne transforme pas cette concordance en décision
d'exclusion.

## 7. Cause exacte de `NO_REMOTE_MATCH`

`NO_REMOTE_MATCH` ne signifie ni « fichier absent », ni « migration jamais
exécutée », ni « migration supprimée du ledger ».

Il signifie exclusivement :

1. la version locale existe dans l'ensemble des 33 migrations valides ;
2. le ledger distant observé contient seulement `20260101110219`,
   `20260222232545` et `20260225213235` ;
3. aucune ligne distante ne porte la version `20260717000000` ;
4. aucune empreinte distante ne permet un rapprochement de contenu ;
5. les objets Offer attendus sont en outre absents du Runtime observé.

La causalité reste inconnue : les preuves ne permettent pas de choisir entre
non-application, suppression de trace, suppression ultérieure des objets ou
succession de plusieurs événements (P12, ligne 342).

## 8. Décisions ultérieures et absence de révision nominative

### 8.1 Ce qui a changé

- Le statut de Gate `L03-G04` a été enregistré
  `NO GO → GO_WITH_DEROGATION` dans P09 et P10.
- La gouvernance Offer a fixé G0 à `GO`, puis G1 à `NO_GO`.
- K11 est passée d'une inconnue d'état live à une divergence courante prouvée.

### 8.2 Ce qui n'a pas changé

- `RemoteLedgerStatus` de la migration : `NO_REMOTE_MATCH`.
- `ProvenanceStatus` : `UNKNOWN`.
- `DerogationStatus` dans le registre nominatif : `NONE`.
- `ReviewStatus` : `PENDING`.
- l'absence d'objets Offer dans le Runtime observé ;
- l'absence d'autorisation de déployer ou de corriger ;
- `L09-G04 = NO_GO` pour la décision repository-only Offer ;
- `G1 Offer = NO_GO`.

### 8.3 Effet juridique documentaire

P08, principes P7 à P9, exige une révision formelle et traçable pour remplacer
une décision et interdit d'étendre une preuve à un objet non couvert. Aucun
document ultérieur ne contient simultanément :

- l'identifiant `20260717000000` ;
- son inclusion ou son exclusion des 29 ;
- la révision explicite de P07 ;
- l'autorité, la portée et l'effet sur le registre nominatif.

Aucune modification implicite du statut nominatif n'est donc prouvée.

## 9. Registre des contradictions

| Id | Pièces en regard | Contradiction ou écart | État |
|---|---|---|---|
| C01 | P05 vs P09/P10 | MM-L03-01 conclut `L03-G04 = NO GO`; les matrices enregistrent ensuite `GO_WITH_DEROGATION`. | active tant qu'une révision reliante et nominative n'explique pas le passage |
| C02 | P04 vs P09/P10 | Le registre nominatif conserve `DerogationStatus = NONE` et `ReviewStatus = PENDING` pour 33/33, tandis que la Gate est déclarée sous dérogation. | active |
| C03 | P02/P04 vs P07 | DPDS identifie 30 `NO_REMOTE_MATCH`; la décision couvre 29 sans les nommer. | lacune de périmètre, objet direct de MD-04 |
| C04 | P07 vs ligne Offer de P04 | P07 repose sur 28 compatibilités + 1 suppression compatible ; Offer a zéro objet runtime. P07 ne dit toutefois pas expressément qu'Offer est exclue. | concordance d'exclusion non enregistrée |
| C05 | P13 vs P14 | P13 qualifie la migration « déjà attendue en DEV » et l'absence d'« anomalie » ; P14 ne retrouve aucun ordre autoritatif antérieur et reformule K11. | contradiction normative résolue par la vérification d'autorité la plus ciblée, sans changer l'écart factuel |
| C06 | P11 vs P12 | P11 déclare l'état live inconnu ; P12 prouve ensuite l'absence. | succession chronologique, pas une contradiction active |
| C07 | P03/P04/P12 | « non appliquée », `NO_REMOTE_MATCH` et absence d'objets décrivent le même état observé, avec des portées différentes. | cohérents ; aucun ne prouve la causalité historique |
| C08 | `L03-G04 = GO_WITH_DEROGATION` vs `G1 Offer = NO_GO` | Les valeurs diffèrent, mais les Gates et exigences sont différentes : historique ledger pour L03-G04, conformité courante Offer pour G1. | pas une contradiction de décision |
| C09 | P09/P10 | `L03-G04` est sous dérogation, mais `L09-G04` reste `NO_GO` pour décider du sort des objets Offer repository-only. | cohérent ; la dérogation ledger n'est pas une décision de déploiement |

## 10. Impacts établis

### 10.1 Gouvernance

- MD-04 est nécessaire pour rendre nominatif le périmètre agrégé de P07.
- Sans MD-04, la portée de la dérogation ne peut pas être opposée à la ligne
  Offer sans extrapolation.
- Une décision MD-04 devra préserver l'historique de P05, P07, P09 et P10 ;
  elle ne pourra pas effacer les contradictions, seulement les réconcilier par
  une révision formelle.

### 10.2 Gates

- `L03-G04` porte actuellement `GO_WITH_DEROGATION` au niveau des matrices,
  avec une incohérence nominative ouverte.
- `L09-G04` reste `NO_GO` : aucune décision « déployer / superséder /
  abandonner » n'est rendue pour Offer.
- G1 Offer reste `NO_GO` sur la preuve live, indépendamment de l'option MD-04.
- Le `PROGRAM` reste `NO GO`; MD-04 seule ne lève ni G1, ni L09-G04, ni les
  risques sécurité constatés.

### 10.3 Technique

- Aucune option MD-04 ne prouve l'application historique de la migration.
- Aucune option ne crée une ligne dans le ledger ni des objets Offer.
- Aucune option n'autorise un déploiement, une correction, une réécriture du
  ledger ou une modification de schéma.
- Toute mutation éventuelle reste soumise à une décision séparée, une `WAVE`
  autorisée et une nouvelle preuve G1.

### 10.4 Certification

- Inclure une migration actuellement incompatible dans une dérogation fondée
  sur la compatibilité exige d'expliquer explicitement la différence de risque
  et de portée.
- Exclure Offer laisse son statut nominatif actuel inchangé et impose une
  décision séparée sous `L09-G04` et G1.
- Dans les deux cas, `UNKNOWN` sur la causalité historique doit être conservé.

## 11. Options possibles de décision — sans choix

### Option A — Inclure explicitement `20260717000000` dans les 29

Contenu minimal nécessaire :

- liste nominative complète des 29 incluant `20260717000000` ;
- identification explicite de la version retranchée de l'ensemble apparent
  `28 compatibles + 1 suppression compatible` ;
- révision formelle de la portée et du fondement de P07 ;
- articulation avec la criticité de l'incompatibilité Offer prouvée par P12 ;
- effet nominatif explicite sur P04.

Conséquences :

- la migration serait couverte par la dérogation historique selon la portée
  exacte décidée ;
- son exécution, sa suppression et sa provenance resteraient `UNKNOWN` ;
- `NO_REMOTE_MATCH` resterait exact tant que le ledger observé ne change pas ;
- G1 Offer et `L09-G04` resteraient `NO_GO` ;
- aucune application de migration ne serait autorisée.

### Option B — Exclure explicitement `20260717000000` des 29

Contenu minimal nécessaire :

- liste nominative des 29 correspondant aux 28 migrations avec compatibilité
  runtime et à `20260222203000` comme suppression compatible ;
- mention explicite que la 30e version `NO_REMOTE_MATCH`, Offer, n'est pas
  couverte par P07 ;
- conservation de la ligne Offer `NO_REMOTE_MATCH / UNKNOWN / NONE / PENDING` ;
- renvoi aux décisions distinctes G1 et `L09-G04`.

Conséquences :

- la portée de P07 devient cohérente avec son fondement `28 + 1` ;
- la contradiction C03 est fermée sans attribuer à Offer une dérogation ;
- le sort de la migration et des objets repository-only reste à décider
  séparément ;
- G1 Offer demeure `NO_GO` et aucune mutation n'est autorisée.

### Option C — Révoquer le bénéfice courant de la dérogation de Gate jusqu'à
une nouvelle décision exhaustive

Contenu minimal nécessaire :

- révision formelle de `L03-G04` motivée par l'absence de liste nominative ;
- état transitoire explicite des 33 lignes ;
- critères de nouvelle décision et autorité de réouverture.

Conséquences :

- `L03-G04` reviendrait à un état bloquant jusqu'à réconciliation ;
- P05 et P04 redeviendraient les états opératoires sans ambiguïté ;
- le déficit historique resterait irrécupérable sur les preuves actuelles ;
- aucun effet technique ni aucune autorisation Offer ne serait créé.

### Option D — Conserver la dérogation des 29 sous réserve, sans statuer sur
Offer

Contenu minimal nécessaire :

- confirmer que MD-04 ne rend pas encore l'inclusion/exclusion ;
- enregistrer une condition et une échéance de révision ;
- interdire expressément toute extrapolation à `20260717000000`.

Conséquences :

- la contradiction nominative demeure ouverte ;
- la Gate conserve son statut agrégé mais sans effet sur Offer ;
- le risque de lectures divergentes subsiste ;
- G1 et `L09-G04` restent `NO_GO`.

## 12. Matrice des conséquences

| Effet | Option A | Option B | Option C | Option D |
|---|---|---|---|---|
| Liste nominative des 29 | oui | oui | à reconstruire | non |
| Statut officiel de l'appartenance Offer | incluse | exclue | non couverte pendant révision | non décidé |
| `NO_REMOTE_MATCH` Offer | inchangé | inchangé | inchangé | inchangé |
| Provenance Offer `UNKNOWN` | inchangée | inchangée | inchangée | inchangée |
| G1 Offer | `NO_GO` | `NO_GO` | `NO_GO` | `NO_GO` |
| `L09-G04` | `NO_GO` | `NO_GO` | `NO_GO` | `NO_GO` |
| Autorisation technique | aucune | aucune | aucune | aucune |
| Contradiction C03 | fermée par inclusion | fermée par exclusion | suspendue à révision | ouverte |

## 13. Preuves absentes que MD-04 ne doit pas inventer

- liste signée des 29 jointe à P07 ;
- version des 34 lignes supprimées du ledger ;
- rattachement des suppressions à une migration locale ;
- preuve d'exécution historique de `20260717000000` ;
- preuve d'un ordre autoritatif antérieur imposant son déploiement ;
- preuve d'une décision ultérieure nominative changeant sa ligne P04 ;
- preuve de présence des objets Offer dans le Runtime observé ;
- autorisation de correction ou de déploiement.

## 14. Condition de décision

Le `PROGRAM_DIRECTOR` et le `CERTIFICATION_BOARD` disposent des preuves pour
choisir une option, à condition que la décision MD-04 :

1. nomme les 29 versions si elle conserve une dérogation sur 29 ;
2. inclue ou exclue explicitement `20260717000000` ;
3. cite P04, P05, P07, P09, P10, P12 et P15 ;
4. distingue le statut de Gate du statut nominatif de migration ;
5. conserve `UNKNOWN` pour la causalité et la provenance non prouvées ;
6. précise qu'elle ne lève ni G1 Offer ni `L09-G04` ;
7. ne crée aucune autorisation technique ;
8. soit gouvernée par une `WAVE`, objet officiel de gouvernance.

Le présent dossier s'arrête avant ce choix.
