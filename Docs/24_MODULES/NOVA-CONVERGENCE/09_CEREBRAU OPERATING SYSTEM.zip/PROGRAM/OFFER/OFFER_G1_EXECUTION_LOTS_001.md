# CEREBRAU — Lots officiels d’exécution Offer G1

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-G1-EXECUTION-ORCHESTRATION-001
MISSION_TYPE        : EXECUTION_PLANNING
EXECUTION_MODE      : READ_ONLY
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
CURRENT_GATE_STATUS : NO_GO
LOT_COUNT           : 6
MICRO_MISSION_COUNT : 24
```

Le présent document constitue le registre officiel d’affectation des
micro-missions aux lots. Il planifie une exécution future et n’autorise aucune
correction, mutation Supabase, modification de migration, de Gate, de décision
MD, de preuve PA ou de backlog.

Les Work Packages ne sont pas des objets officiels de gouvernance. Les seuls
objets d’orchestration employés ici sont la WAVE, les lots d’exécution et les
micro-missions canoniques du backlog.

## 2. Corpus exclusif et règles de construction

Le plan utilise exclusivement :

- `OFFER_G1_REMEDIATION_PLAN_001.md` ;
- `OFFER_G1_EXECUTION_BACKLOG_001.md` ;
- `OFFER_G1_DEPENDENCY_GRAPH_001.md` ;
- `OFFER_G1_CRITICAL_PATH_001.md`.

Les chemins repository exacts ne sont pas certifiés par ce corpus. Les
références `AF-*` restent donc les seules désignations de fichiers autorisées
jusqu’à leur résolution par `G1-PRE-01`.

Un fichier commun lu par plusieurs micro-missions n’est pas une collision.
Une collision existe si deux micro-missions peuvent écrire simultanément le
même fichier, la même destination de preuve, le même objet ou le même
environnement mutable. Les règles suivantes éliminent ces collisions :

1. chaque sortie `AF-EVIDENCE` reçoit une destination distincte dans le
   manifeste de `G1-PRE-01` ;
2. les applications sur DEV sont protégées par un verrou exclusif ;
3. PA-06 et PA-01 ne mutent jamais DEV simultanément ;
4. dans un lot, toute dépendance interne est satisfaite par l’ordre interne
   avant le démarrage de son consommateur ;
5. un lot ne se clôture que lorsque toutes ses micro-missions sont `PASS`.

## 3. Résultat de minimisation

Six lots sont retenus. Une fusion supplémentaire créerait au moins une des
situations interdites suivantes :

- travail lancé avant le gel du manifeste et des règles de rollback ;
- mélange d’une qualification isolée avec une mutation DEV non encore
  autorisée ;
- collision ou rollback ambigu entre les mutations QF/Rights et baseline ;
- contrôles post-baseline démarrés avant PA-01 `PASS` ;
- replay PA-10 engagé avant la synchronisation de PA-01 à PA-09.

| Lot | Objet | Micro-missions | Mode dominant | Risque | Difficulté |
|---|---|---:|---|---|---|
| `OFFER-G1-LOT-01` | Périmètre et sûreté d’exécution | 2 | Préparation, lecture seule | `ÉLEVÉ` | `L` |
| `OFFER-G1-LOT-02` | Qualification préalable et captures de référence | 7 | Parallèle contrôlé, dry-run isolé | `CRITIQUE` | `XL` |
| `OFFER-G1-LOT-03` | Remédiation QF/Rights | 2 | Mutation DEV exclusive puis tests | `CRITIQUE` | `XL` |
| `OFFER-G1-LOT-04` | Application baseline Offer | 3 | Mutation DEV exclusive puis revue | `CRITIQUE` | `L` |
| `OFFER-G1-LOT-05` | Qualification post-baseline | 7 | Contrôles parallèles puis sécurité séquentielle | `CRITIQUE` | `XL` |
| `OFFER-G1-LOT-06` | Replay et dossier final G1 | 3 | Lecture seule et certification | `CRITIQUE` agrégé | `XL` |

Les difficultés sont des estimations d’orchestration : elles reprennent la
complexité maximale des PA incluses et ajoutent la charge de synchronisation
du lot. Elles ne constituent pas des durées calendaires.

## 4. Analyse des 24 micro-missions

La colonne « parallèle » indique uniquement une possibilité sûre après
satisfaction des prérequis. Elle ne vaut pas autorisation d’exécution.

| Micro-mission | Dépendances réelles | Conflits et ressources communes | Fichiers communs | Risque de régression | Parallèle sûr |
|---|---|---|---|---|---|
| `G1-PRE-01` | WAVE officielle, décisions formalisées | Produit le manifeste consommé par tous ; aucune exécution concurrente avant gel | Tous `AF-*` | Périmètre inventé, secret copié, fichier hors scope | Aucun avant clôture |
| `G1-PRE-02` | `G1-PRE-01` | Ressources DEV, sauvegarde, rollback, fenêtre et acteurs | `AF-BASELINE`, `AF-QF-RIGHTS`, `AF-OFFER-SECURITY`, `AF-RUNTIME-CONFIG` | Mauvaise cible, rollback inutilisable, état initial non traçable | Aucun travail mutable ; prépare les lanes suivantes |
| `G1-PA07-01` | `G1-PRE-01`, `G1-PRE-02` | Environnement isolé et inventaire avant | `AF-BASELINE`, destination propre `AF-EVIDENCE` | Environnement non représentatif ou données de production introduites | Avec captures PA-06, PA-08 et PA-09 |
| `G1-PA07-02` | `G1-PA07-01` | Écriture uniquement dans l’environnement isolé | `AF-BASELINE`, `AF-OFFER-SECURITY`, `AF-QF-RIGHTS`, destination propre `AF-EVIDENCE` | Collision, FK invalide, objet hors manifeste, activation | Avec les lanes read-only, jamais avec une autre écriture isolée |
| `G1-PA07-03` | `G1-PA07-02` | Rollback isolé et observation des consommateurs | Fichiers de PA07-02, `AF-CONSUMERS` en lecture | Perte de données, dérive de schéma, effet consommateur | Avec PA-09 ; observation PA-08 coordonnée |
| `G1-PA06-01` | `G1-PRE-01`, `G1-PRE-02` | Lecture DEV des quatre tables et de la RPC | `AF-QF-RIGHTS`, destination propre `AF-EVIDENCE` | État initial incomplet ou exposition accrue | Avec toute la lane PA-07 et PA-09 |
| `G1-PA06-02` | `G1-PA06-01`, compatibilité PA-07 pour tout artefact partagé | Verrou exclusif DEV ; conflit direct avec PA-01 et toute autre mutation DB | `AF-QF-RIGHTS` | Droits légitimes perdus, objet hors cinq objets, rollback impossible | Aucun travail mutable sur DEV |
| `G1-PA06-03` | `G1-PA06-02` | Tests DEV QF/Rights ; même état que la remédiation | `AF-QF-RIGHTS`, destination propre `AF-EVIDENCE` | Nouvelle permission excessive, fuite tenant, RPC encore ouverte | Contrôles read-only hors DB possibles, mais lot garde le verrou jusqu’au verdict |
| `G1-PA01-01` | `G1-PA07-03`, `G1-PRE-02` | Préflight du verrou DEV, sauvegarde et version/hash | `AF-BASELINE`, `AF-RUNTIME-CONFIG` | Divergence de hash, mauvaise cible, sauvegarde non restaurable | Captures read-only hors DEV uniquement |
| `G1-PA01-02` | `G1-PA01-01`, `G1-PA08-01` | Verrou exclusif DEV ; conflit direct avec PA-06 et toute mutation DB | `AF-BASELINE`, destination propre `AF-EVIDENCE` | Activation implicite, historique réécrit, rollback perdu | Aucun travail mutable sur DEV |
| `G1-PA01-03` | `G1-PA01-02` | Consolidation des journaux et revue humaine | Sorties PA01-01/02 dans `AF-EVIDENCE` | Écart masqué ou nouvelle mutation pendant la revue | Captures read-only hors preuve PA-01 |
| `G1-PA02-01` | `G1-PA01-03` | Historique live en lecture et rapprochement | `AF-BASELINE`, destination propre `AF-EVIDENCE` | Ledger modifié, collision non détectée | Avec PA-03 et PA-08 post-baseline |
| `G1-PA03-01` | `G1-PA01-03` | Catalogue DEV en lecture | `AF-BASELINE`, `AF-OFFER-SECURITY`, destination propre `AF-EVIDENCE` | Objet manquant/ajouté, quantité ou FK divergente | Avec PA-02 et PA-08 ; produit l’entrée PA-04 |
| `G1-PA04-01` | `G1-PA03-01` | Audit sécurité du même schéma DEV | `AF-OFFER-SECURITY`, `AF-BASELINE`, destination propre `AF-EVIDENCE` | Droit `anon` non vu, matrice de rôles incomplète | Avec PA-02/PA-08 si l’état DEV reste figé |
| `G1-PA04-02` | `G1-PA04-01` | Tests tenant/PostgREST et jeux de test isolés | `AF-OFFER-SECURITY`, `AF-RUNTIME-CONFIG`, destination propre `AF-EVIDENCE` | Fuite cross-tenant, bypass, cas positif cassé | Avec PA-02/PA-08 ; pas avec PA-05 sur les mêmes jeux |
| `G1-PA08-01` | `G1-PRE-01`, impérativement avant `G1-PA01-02` | État des quatre familles de consommateurs | `AF-CONSUMERS`, `AF-RUNTIME-CONFIG`, destination propre `AF-EVIDENCE` | Référence absente ou état modifié par la capture | Avec PA-07, PA-06-01 et PA-09 |
| `G1-PA08-02` | `G1-PA01-03`, `G1-PA08-01` | Comparaison des mêmes consommateurs | `AF-CONSUMERS`, `AF-RUNTIME-CONFIG`, destination propre `AF-EVIDENCE` | Activation/disponibilité implicite non détectée | Avec PA-02 et PA-03 |
| `G1-PA09-01` | `G1-PRE-01` | Runtime déployé et accès d’exploitation en lecture | `AF-BACKEND`, `AF-RUNTIME-CONFIG`, destination propre `AF-EVIDENCE` | Secret exposé, mauvais runtime, redéploiement involontaire | Avec préparation DEV, PA-07 et captures read-only |
| `G1-PA09-02` | `G1-PA09-01` | Traçabilité commit–configuration–contrat | `AF-BACKEND`, `AF-RUNTIME-CONFIG`, destination propre `AF-EVIDENCE` | Correspondance artificielle ou non immutable | Avec PA-07 et captures read-only |
| `G1-PA05-01` | `G1-PA04-02`, `G1-PA09-02` | Jeux de tests backend et runtime figé | `AF-BACKEND`, `AF-RUNTIME-CONFIG`, destination propre `AF-EVIDENCE` | Scénario incomplet, commit/configuration changé | Avec PA-02/PA-08 terminant leur revue |
| `G1-PA05-02` | `G1-PA05-01` | Même runtime et mêmes jeux de test | Même périmètre que PA05-01 | Fuite cross-user/tenant, cas positif cassé, bypass accepté | Aucun test concurrent modifiant les mêmes données |
| `G1-PA10-01` | PA-01 à PA-09 `PASS` | Tous les artefacts et l’état DEV doivent être figés | Tous `AF-*` en lecture, nouveau dossier `AF-EVIDENCE` | Divergence fraîche ou preuve amont modifiée | Relectures indépendantes possibles, assemblage unique |
| `G1-PA10-02` | `G1-PA10-01` | Registre des risques et avis spécialisés | Registre et preuves `AF-EVIDENCE` | Risque supprimé sans preuve ou `C4` laissé ouvert | Revues Sécurité et Exploitation/Data coordonnées |
| `G1-PA10-03` | `G1-PA10-02` | Dossier signé et autorités requises | Dossier `AF-EVIDENCE` | Historique `NO_GO` écrasé ou autorisation déduite | Aucun assemblage concurrent du dossier final |

## 5. Définition détaillée des lots

### `OFFER-G1-LOT-01` — Périmètre et sûreté d’exécution

| Champ | Valeur |
|---|---|
| Objectif | Geler le manifeste exact des `AF-*`, borner l’exécution à DEV et rendre sauvegarde, rollback, acteurs, fenêtre et arrêts vérifiables |
| Micro-missions incluses | `G1-PRE-01`, `G1-PRE-02` |
| Ordre interne | `G1-PRE-01` puis `G1-PRE-02` |
| Fichiers concernés | Tous `AF-*`; plus précisément `AF-BASELINE`, `AF-QF-RIGHTS`, `AF-OFFER-SECURITY`, `AF-RUNTIME-CONFIG` pour les contrôles DEV |
| Dépendances satisfaites à la sortie | `D-01` périmètre fichier certifié ; `D-02` sauvegarde et rollback DEV |
| Dépendances restantes | Compatibilité PA-07, captures de référence PA-06/08/09, toutes les PA |
| Niveau de risque | `ÉLEVÉ` : une erreur de périmètre invalide toute la suite |
| Difficulté | `L` |

Ordre et unité de certification :

1. résoudre chemins, propriétaires, modes d’accès, versions/hash et destinations
   de preuve ;
2. seulement après gel du manifeste, qualifier DEV, la sauvegarde, le rollback,
   les acteurs, la fenêtre et les critères d’arrêt.

Critères `PASS` du lot :

- 100 % des `AF-*` ont un chemin exact et un propriétaire logique ;
- chaque accès est classé lecture ou écriture autorisée ;
- DEV, sauvegarde restaurable, rollback, acteurs et fenêtre sont confirmés ;
- les destinations `AF-EVIDENCE` sont distinctes ;
- production et activation sont explicitement exclues.

Critères de non-régression :

- aucun fichier, secret, environnement ou consommateur hors périmètre ;
- aucune source, migration, décision, preuve ou Gate modifiée ;
- état initial conservé et traçable.

### `OFFER-G1-LOT-02` — Qualification préalable et captures de référence

| Champ | Valeur |
|---|---|
| Objectif | Démontrer la compatibilité et le rollback en environnement isolé, tout en capturant avant mutation l’état QF/Rights, les consommateurs et l’identité runtime |
| Micro-missions incluses | `G1-PA07-01`, `G1-PA07-02`, `G1-PA07-03`, `G1-PA06-01`, `G1-PA08-01`, `G1-PA09-01`, `G1-PA09-02` |
| Ordre interne | Quatre lanes après LOT-01 : PA-07 en chaîne `01→02→03`; PA-06 capture `01`; PA-08 capture `01`; PA-09 en chaîne `01→02` |
| Fichiers concernés | `AF-BASELINE`, `AF-OFFER-SECURITY`, `AF-QF-RIGHTS`, `AF-CONSUMERS`, `AF-BACKEND`, `AF-RUNTIME-CONFIG`, destinations distinctes `AF-EVIDENCE` |
| Dépendances satisfaites à la sortie | `D-03`, `D-04` si artefact partagé, `D-05`, `D-09`; état initial requis pour PA-06 |
| Dépendances restantes | Mutations PA-06 et PA-01 ; contrôles post-baseline ; PA-05 ; PA-10 |
| Niveau de risque | `CRITIQUE` : collision, rollback, activation et attribution runtime sont bloquants |
| Difficulté | `XL` |

Les quatre lanes sont parallèles parce que PA-07 écrit uniquement dans
l’environnement isolé et que les trois autres lanes sont en lecture seule.
Elles partagent des références `AF-*`, jamais une destination de preuve
écrivable.

Critères `PASS` du lot :

- PA-07 est `PASS` : dry-run, plan avant/après, contraintes/FK, rollback et
  non-activation conformes ;
- l’état initial QF/Rights est complet et reproductible ;
- l’état avant des quatre familles de consommateurs est daté ;
- commit, environnement, identité runtime, configuration expurgée et contrat
  sont reliés de manière immutable ;
- aucune lane n’a écrit hors de sa cible autorisée.

Critères de non-régression :

- aucune mutation DEV ou production ;
- aucune donnée ou secret de production dans l’environnement isolé ;
- aucun consommateur, flag ou statut modifié ;
- aucune collision, perte de données, dérive de schéma ou activation.

### `OFFER-G1-LOT-03` — Remédiation QF/Rights

| Champ | Valeur |
|---|---|
| Objectif | Appliquer la seule remédiation QF/Rights autorisée puis certifier les quatre tables et `compute_qf(uuid)` |
| Micro-missions incluses | `G1-PA06-02`, `G1-PA06-03` |
| Ordre interne | Remédiation sous verrou DEV, puis tests et revue avant libération du verrou |
| Fichiers concernés | `AF-QF-RIGHTS`, destinations distinctes `AF-EVIDENCE` |
| Dépendances satisfaites à la sortie | PA-06 `PASS`; fermetures attendues de `R-G1-03` et `R-G1-04` disponibles pour PA-10 |
| Dépendances restantes | Baseline PA-01 et chaîne Offer ; synchronisation PA-01 à PA-09 |
| Niveau de risque | `CRITIQUE` (`C4`) |
| Difficulté | `XL` |

Critères `PASS` du lot :

- RLS effective et mutations `anon` retirées sur le périmètre autorisé ;
- RPC restreinte au rôle permis ;
- tests `anon`, cross-user et cross-tenant négatifs ;
- accès autorisés conservés ;
- exécution attribuable et rollback disponible.

Critères de non-régression :

- aucun objet hors des quatre tables et de la RPC ;
- aucun droit légitime documenté perdu ;
- aucune nouvelle permission excessive ;
- aucune mutation Offer, production ou concurrente sur DEV.

### `OFFER-G1-LOT-04` — Application baseline Offer

| Champ | Valeur |
|---|---|
| Objectif | Contrôler, appliquer sur DEV et faire revoir la baseline Offer `20260717000000` |
| Micro-missions incluses | `G1-PA01-01`, `G1-PA01-02`, `G1-PA01-03` |
| Ordre interne | Préflight final, application DEV sous verrou exclusif, consolidation/revue |
| Fichiers concernés | `AF-BASELINE`, `AF-RUNTIME-CONFIG`, destinations distinctes `AF-EVIDENCE` |
| Dépendances satisfaites à la sortie | PA-01 `PASS`; `D-06` baseline matérialisée |
| Dépendances restantes | PA-02, PA-03, PA-04, PA-05, PA-08 post-baseline et PA-10 |
| Niveau de risque | `CRITIQUE` (`C4`) |
| Difficulté | `L` |

Le lot attend la libération du verrou DEV par LOT-03. Cette contrainte est un
ordre de ressource ; les dépendances logiques de PA-01 restent PA-07 `PASS`,
`G1-PRE-02` et l’état PA-08 avant disponible.

Critères `PASS` du lot :

- version `20260717000000` et hash égaux au manifeste ;
- sauvegarde restaurable, acteur et fenêtre confirmés ;
- application réussie et journalisée sur DEV ;
- rapport complet et revu avec rollback toujours disponible.

Critères de non-régression :

- aucune cible autre que DEV ;
- aucune réécriture d’historique ;
- aucune transition `ACTIVE` ou activation implicite ;
- aucun écart masqué et aucune mutation pendant la consolidation.

### `OFFER-G1-LOT-05` — Qualification post-baseline

| Champ | Valeur |
|---|---|
| Objectif | Certifier provenance, complétude, absence d’effet inter-domaines, sécurité du schéma puis sécurité du backend sur le runtime identifié |
| Micro-missions incluses | `G1-PA02-01`, `G1-PA03-01`, `G1-PA08-02`, `G1-PA04-01`, `G1-PA04-02`, `G1-PA05-01`, `G1-PA05-02` |
| Ordre interne | Vague A parallèle PA-02/PA-03/PA-08 ; vague B PA-04 `01→02` après PA-03 ; vague C PA-05 `01→02` après PA-04 et PA-09 |
| Fichiers concernés | `AF-BASELINE`, `AF-OFFER-SECURITY`, `AF-CONSUMERS`, `AF-BACKEND`, `AF-RUNTIME-CONFIG`, historique live en lecture, destinations distinctes `AF-EVIDENCE` |
| Dépendances satisfaites à la sortie | `D-07`, `D-08`, `D-10`; PA-02, PA-03, PA-04, PA-05 et PA-08 `PASS` |
| Dépendances restantes | Point `D-11`, puis PA-10 |
| Niveau de risque | `CRITIQUE` : sécurité et cohérence G1 bloquantes |
| Difficulté | `XL` |

Critères `PASS` du lot :

- historique live rapproché sans édition du ledger ;
- inventaire exact `7/94/53/28/4/1/4/3` ;
- aucune activation ou disponibilité induite chez EBS, Rights, LifeHub ou
  finance ;
- RLS, policies, ACL/grants et tests tenant/PostgREST conformes ;
- les six scénarios backend interdits sont refusés sur le même
  commit/configuration.

Critères de non-régression :

- état DEV figé pendant les contrôles ;
- aucune donnée d’un autre tenant lisible ou mutable ;
- cas positifs autorisés conservés ;
- aucun redéploiement, changement de configuration, secret ou objet
  additionnel non expliqué.

### `OFFER-G1-LOT-06` — Replay et dossier final G1

| Champ | Valeur |
|---|---|
| Objectif | Rejouer G1 en lecture seule, fermer les risques et assembler le dossier signé recevable |
| Micro-missions incluses | `G1-PA10-01`, `G1-PA10-02`, `G1-PA10-03` |
| Ordre interne | Replay et rapprochement, fermeture des risques et avis, assemblage/signatures |
| Fichiers concernés | Tous `AF-*` en lecture ; nouveau dossier `AF-EVIDENCE` |
| Dépendances satisfaites à la sortie | `D-11`, `D-12`; PA-10 `PASS`; dossier recevable |
| Dépendances restantes | Décision G1 complémentaire du Program Director et du Certification Board, hors du plan |
| Niveau de risque | `CRITIQUE` agrégé tant qu’un risque ou avis reste ouvert |
| Difficulté | `XL` |

Critères `PASS` du lot :

- PA-01 à PA-09 sont explicitement `PASS` à l’entrée ;
- inventaire live daté et rapprochement repository/runtime sans écart
  inexpliqué ;
- `R-G1-01` à `R-G1-10` fermés avec preuve ;
- aucun `C4` ouvert ;
- avis et signatures requis présents ;
- PA-10 explicitement `PASS` et dossier recevable.

Critères de non-régression :

- aucune mutation et aucune preuve historique modifiée ;
- mêmes versions, hash et commit que les preuves amont ;
- historique `NO_GO` conservé ;
- aucune autorisation de production, activation ou `GO` déduite.

## 6. Registre canonique d’affectation

Chaque ligne ci-dessous est une affectation unique. Le total est
`2 + 7 + 2 + 3 + 7 + 3 = 24`.

| Lot | Affectation unique |
|---|---|
| `OFFER-G1-LOT-01` | `G1-PRE-01`, `G1-PRE-02` |
| `OFFER-G1-LOT-02` | `G1-PA07-01`, `G1-PA07-02`, `G1-PA07-03`, `G1-PA06-01`, `G1-PA08-01`, `G1-PA09-01`, `G1-PA09-02` |
| `OFFER-G1-LOT-03` | `G1-PA06-02`, `G1-PA06-03` |
| `OFFER-G1-LOT-04` | `G1-PA01-01`, `G1-PA01-02`, `G1-PA01-03` |
| `OFFER-G1-LOT-05` | `G1-PA02-01`, `G1-PA03-01`, `G1-PA08-02`, `G1-PA04-01`, `G1-PA04-02`, `G1-PA05-01`, `G1-PA05-02` |
| `OFFER-G1-LOT-06` | `G1-PA10-01`, `G1-PA10-02`, `G1-PA10-03` |

Aucune nouvelle micro-mission n’est créée. Aucun identifiant du backlog n’est
omis ou affecté à plusieurs lots.
