# CEREBRAU — DÉCISION D’AUTORITÉ MD-06

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-MD06-AUTHORITY-DECISION-001
MISSION_TYPE        : GOVERNANCE_FORMALIZATION
EXECUTION_MODE      : ONE_SHOT
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
DECISION_ID         : MD-06
```

Les work packages ne sont pas des objets officiels de gouvernance.

## 2. Objet et périmètre

Le présent document formalise exclusivement la décision MD-06 déjà rendue sur
l’autorité de la source de vérité Offer.

Il rattache les décisions D01 à D10 à l’autorité d’écriture, au writer unique
et aux consommateurs permis. Il ne les modifie pas.

## 3. Décision officielle

Le `PROGRAM_DIRECTOR` enregistre :

```text
OfferGovernanceAuthority : PROGRAM_DIRECTOR
OfferSourceOfTruth        : OFFER_AND_OFFER_VERSION
DistributionSource       : ACTIVE_OFFER_VERSION
UniqueWriter              : OFFER_BACKEND_SERVER_SIDE
ConcurrentProducers       : PROHIBITED
```

L’état `PUBLISHED` demeure administratif. Seule une `OfferVersion` `ACTIVE`
peut constituer la source de distribution, conformément aux décisions
d’architecture reprises dans le rapport G1.

## 4. Autorité d’écriture

Le backend Offer côté serveur est le writer applicatif unique autorisé pour les
objets Offer. Toute écriture reste soumise aux contrôles d’identité, de rôle,
d’organisation, de périmètre et de sécurité définis par MD-03.

Les écritures directes anonymes, les producteurs concurrents et les
reconstitutions autonomes d’une Offer par un autre domaine sont interdits.

## 5. Consommateurs permis

Rights, EBS, LifeHub, les dashboards, Subvention, Budget, Ledger et Dotation ne
peuvent consommer qu’un fait Offer issu de la source autoritative et selon une
interface autorisée.

Leur mention comme consommateurs permis ne vaut :

- ni preuve de consommation effective ;
- ni autorisation d’activation ;
- ni autorisation d’écriture dans Offer ;
- ni autorisation de recalcul concurrent ;
- ni validation E2E ou production.

Rights dérive d’une `OfferVersion` active. EBS consolide sans recalculer
l’autorité Offer. Les objets financiers conservent le lineage
Offer/Version/Budget décidé par l’architecture.

## 6. Effets

MD-06 enregistre l’autorité SOT, le writer unique et l’interdiction des
producteurs concurrents. L’effet sur `L04-G03` reste soumis au mécanisme de
gouvernance compétent ; le présent document ne modifie aucune Gate.

## 7. Éléments explicitement inchangés

Restent inchangés :

- D01 à D10 ;
- MD-04 et MD-05 ;
- le statut `NO_GO` du Gate Offer G1 ;
- les Gates et la Master Gates Matrix ;
- l’absence de matérialisation live prouvée ;
- l’absence de preuve de consommation effective ;
- l’interdiction d’activation métier et de production.

## 8. Enregistrement d’autorité

```text
DecisionId                    : MD-06
Authority                     : PROGRAM_DIRECTOR
GovernanceObject              : WAVE
SourceOfTruth                 : OFFER_AND_OFFER_VERSION
DistributionAuthority        : ACTIVE_OFFER_VERSION
UniqueWriter                  : OFFER_BACKEND_SERVER_SIDE
ConcurrentProducers           : PROHIBITED
ConsumerWriteAccess           : PROHIBITED
ActivationAuthorization       : NONE
ProductionAuthorization       : NONE
OfferG1Status                 : NO_GO_UNCHANGED
GateModification              : NONE
MasterGatesMatrixModification : NONE
```
