# CEREBRAU — Graphe des dépendances Offer G1

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-G1-REMEDIATION-001
DELIVERABLE         : OFFER_G1_DEPENDENCY_GRAPH_001
EXECUTION_MODE      : READ_ONLY
OFFICIAL_OBJECT     : WAVE
CURRENT_GATE_STATUS : NO_GO
```

Le graphe décrit l’ordre d’une exécution future. Il n’autorise aucune
correction. Une arête `A --> B` signifie que `B` ne démarre que lorsque `A`
est clôturée avec succès. Les identifiants renvoient au backlog
`OFFER_G1_EXECUTION_BACKLOG_001.md`.

## 2. Graphe complet des micro-missions

```mermaid
flowchart TD
    START([WAVE corrective autorisée]) --> PRE01[G1-PRE-01<br/>Résoudre fichiers et périmètre]
    PRE01 --> PRE02[G1-PRE-02<br/>DEV, sauvegarde, rollback]

    PRE01 --> P081[G1-PA08-01<br/>État consommateurs avant]
    PRE01 --> P091[G1-PA09-01<br/>Identité runtime]
    P091 --> P092[G1-PA09-02<br/>Lien runtime-contrat]

    PRE02 --> P071[G1-PA07-01<br/>Environnement isolé]
    P071 --> P072[G1-PA07-02<br/>Dry-run]
    P072 --> P073[G1-PA07-03<br/>Rollback et non-activation]

    PRE02 --> P061[G1-PA06-01<br/>État QF/Rights avant]
    P061 --> P062[G1-PA06-02<br/>Remédiation QF/Rights]
    P073 --> P062
    P062 --> P063[G1-PA06-03<br/>Tests QF/Rights]

    P073 --> P011[G1-PA01-01<br/>Préflight baseline]
    P011 --> P012[G1-PA01-02<br/>Application DEV]
    P081 --> P012
    P012 --> P013[G1-PA01-03<br/>Rapport d'exécution]

    P013 --> P021[G1-PA02-01<br/>Historique live]
    P013 --> P031[G1-PA03-01<br/>Inventaire objets]
    P013 --> P082[G1-PA08-02<br/>Contrôle consommateurs après]

    P031 --> P041[G1-PA04-01<br/>Audit RLS/ACL]
    P041 --> P042[G1-PA04-02<br/>Tests tenant/PostgREST]
    P042 --> P051[G1-PA05-01<br/>Préparer tests backend]
    P092 --> P051
    P051 --> P052[G1-PA05-02<br/>Exécuter tests backend]

    P021 --> SYNC{{PA-01 à PA-09 PASS}}
    P031 --> SYNC
    P042 --> SYNC
    P052 --> SYNC
    P063 --> SYNC
    P082 --> SYNC
    P092 --> SYNC

    SYNC --> P101[G1-PA10-01<br/>Replay read-only]
    P101 --> P102[G1-PA10-02<br/>Fermeture des risques]
    P102 --> P103[G1-PA10-03<br/>Dossier signé]
    P103 --> DECISION([Dossier recevable pour décision G1])
```

Le nœud terminal ne signifie pas `GO`. Il signifie uniquement qu’un dossier
est recevable pour une décision G1 complémentaire. La production, l’activation
et les autres Gates restent hors de portée.

## 3. Graphe consolidé par PA

```mermaid
flowchart LR
    SCOPE[Préparation<br/>périmètre et rollback] --> PA07[PA-07<br/>Compatibilité migration]
    SCOPE --> PA06A[PA-06<br/>État initial QF/Rights]
    SCOPE --> PA08A[PA-08<br/>État consommateurs avant]
    SCOPE --> PA09[PA-09<br/>Identité runtime]

    PA07 --> PA01[PA-01<br/>Baseline appliquée]
    PA07 --> PA06B[PA-06<br/>Remédiation testée]
    PA06A --> PA06B
    PA08A --> PA01

    PA01 --> PA02[PA-02<br/>Historique aligné]
    PA01 --> PA03[PA-03<br/>Objets complets]
    PA01 --> PA08B[PA-08<br/>Absence d'effet]

    PA03 --> PA04[PA-04<br/>RLS/ACL conformes]
    PA04 --> PA05[PA-05<br/>Backend sécurisé]
    PA09 --> PA05

    PA02 --> PA10[PA-10<br/>Replay G1]
    PA03 --> PA10
    PA04 --> PA10
    PA05 --> PA10
    PA06B --> PA10
    PA08B --> PA10
    PA09 --> PA10
```

## 4. Dépendances techniques

| Dépendance | Producteur | Consommateur | Nature | Condition de fermeture |
|---|---|---|---|---|
| `D-01` Périmètre fichier certifié | `G1-PRE-01` | Toutes les micro-missions | Gouvernance/configuration | Chemins, versions/hash, propriétaires et modes d’accès résolus pour tous les `AF-*` |
| `D-02` Sauvegarde et rollback DEV | `G1-PRE-02` | PA-07, PA-06, PA-01 | Exploitation/Data | Sauvegarde restaurable et procédure de rollback confirmées |
| `D-03` Compatibilité de baseline | PA-07 | PA-01 | Migration/intégrité | Dry-run, contraintes/FK, rollback et non-activation tous conformes |
| `D-04` Compatibilité de la remédiation QF/Rights | PA-07 | PA-06 | Migration/sécurité | Artefacts QF/Rights inclus dans le test isolé lorsqu’ils partagent le véhicule de migration |
| `D-05` État consommateurs avant | `G1-PA08-01` | PA-01 puis `G1-PA08-02` | Intégration | État EBS/Rights/LifeHub/finance capturé avant application |
| `D-06` Baseline matérialisée | PA-01 | PA-02, PA-03, PA-08 | Données/runtime | Rapport d’exécution DEV PA-01 complet et revu |
| `D-07` Objets Offer présents | PA-03 | PA-04 | Schéma/sécurité | Quantités exactes des huit catégories constatées |
| `D-08` Sécurité des objets Offer | PA-04 | PA-05 | Sécurité/API | RLS/ACL conformes et tests tenant/PostgREST réussis |
| `D-09` Identité runtime | PA-09 | PA-05 | Exploitation/traçabilité | Commit, configuration expurgée et contrat testés reliés |
| `D-10` Sécurité backend | PA-04 + PA-09 | PA-05 | Sécurité/runtime | Six scénarios négatifs exécutés sur le runtime identifié |
| `D-11` Ensemble des preuves | PA-01 à PA-09 | PA-10 | Certification | Les neuf PA sont explicitement `PASS` |
| `D-12` Risques et avis fermés | `G1-PA10-01/02` | `G1-PA10-03` | Certification/autorité | `R-G1-01` à `R-G1-10` fermés, avis Sécurité et Exploitation/Data présents |

## 5. Corrections bloquantes

| Blocage | Bloque directement | Pourquoi |
|---|---|---|
| `G1-PRE-01` non clôturée | Toute exécution | Le corpus ne certifie pas les chemins exacts ; agir sans résolution inventerait le périmètre |
| PA-07 non `PASS` | PA-01 et remédiation migratoire PA-06 | Compatibilité, rollback, FK et non-activation ne sont pas démontrés |
| PA-01 non `PASS` | PA-02, PA-03, PA-04, PA-08 post-contrôle | Aucun état Offer live ne peut être rapproché ou testé |
| PA-03 non `PASS` | PA-04 puis PA-05 | La sécurité Offer ne peut pas être certifiée sur des objets absents |
| PA-04 non `PASS` | PA-05 | Les écritures backend resteraient adossées à un socle RLS/ACL non conforme |
| PA-09 non `PASS` | PA-05 | Les résultats backend seraient non attribuables à un runtime certifié |
| Une PA parmi PA-01 à PA-09 non `PASS` | PA-10 | Le replay final exige le dossier complet |
| Un risque `C4` ou un avis manquant | Dossier final | La doctrine reprise par le rapport G1 impose `NO_GO` |

## 6. Corrections parallélisables

### Vague parallèle A — après `G1-PRE-01`

- capture des consommateurs `G1-PA08-01` ;
- identité runtime `G1-PA09-01/02` ;
- préparation DEV `G1-PRE-02`.

### Vague parallèle B — après `G1-PRE-02`

- lane PA-07 : qualification isolée et dry-run ;
- capture read-only PA-06 de l’état QF/Rights.

La mutation PA-06 attend toutefois la conclusion de compatibilité PA-07 si les
artefacts partagent le véhicule de migration.

### Vague parallèle C — après PA-01

- PA-02 : rapprochement d’historique ;
- PA-03 : inventaire des objets ;
- PA-08 : comparaison inter-domaines ;
- PA-09 peut se terminer si elle n’est pas déjà clôturée.

PA-04 attend PA-03. PA-05 attend simultanément PA-04 et PA-09.

### Vague parallèle D — avant PA-10

Les revues finales de PA-02, PA-03, PA-04, PA-05, PA-06, PA-08 et PA-09
peuvent être menées par leurs responsables respectifs. Le point de
synchronisation n’est franchi qu’après les neuf verdicts `PASS`.

## 7. Chemin critique logique

Le plus long enchaînement obligatoire est :

```text
G1-PRE-01
  -> G1-PRE-02
  -> G1-PA07-01
  -> G1-PA07-02
  -> G1-PA07-03
  -> G1-PA01-01
  -> G1-PA01-02
  -> G1-PA01-03
  -> G1-PA03-01
  -> G1-PA04-01
  -> G1-PA04-02
  -> G1-PA05-01
  -> G1-PA05-02
  -> G1-PA10-01
  -> G1-PA10-02
  -> G1-PA10-03
```

PA-08-01 doit être achevée avant `G1-PA01-02`, et PA-09 avant
`G1-PA05-01` ; ces deux branches rejoignent donc le chemin critique si elles
prennent du retard. PA-06 rejoint obligatoirement le point de synchronisation
avant PA-10 et devient critique si elle n’est pas clôturée à cette date.

