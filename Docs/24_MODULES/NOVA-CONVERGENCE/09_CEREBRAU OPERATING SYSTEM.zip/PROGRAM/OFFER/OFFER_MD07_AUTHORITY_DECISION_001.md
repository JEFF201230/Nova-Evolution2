# CEREBRAU — DÉCISION D’AUTORITÉ MD-07

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-MD07-AUTHORITY-DECISION-001
MISSION_TYPE        : GOVERNANCE_FORMALIZATION
EXECUTION_MODE      : ONE_SHOT
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
DECISION_ID         : MD-07
```

Les work packages ne sont pas des objets officiels de gouvernance.

## 2. Objet et périmètre

Le présent document formalise exclusivement la décision MD-07 déjà rendue :
l’ordre de gouverner la mission corrective Offer sous une `WAVE` officielle.

La publication du présent document ne réalise aucune correction technique.

## 3. Décision officielle

Le `PROGRAM_DIRECTOR` ordonne la préparation et l’exécution contrôlée de la
mission corrective Offer sous une `WAVE` dédiée, conformément au Wave Model
canonique.

```text
GovernanceObject       : WAVE
MissionScope           : OFFER_G1_DEV_CORRECTION
Environment            : DEV_ONLY
DedicatedManifest      : REQUIRED
DefaultMissionJsonReuse: PROHIBITED
HumanReview            : REQUIRED
ProductionExecution    : PROHIBITED
```

Le Mission Order et le manifeste dédiés doivent reprendre sans extension les
autorisations MD-01, la stratégie MD-02, la remédiation MD-03, la disposition
MD-05 et l’autorité SOT MD-06.

## 4. Scopes autorisés

La mission corrective peut uniquement :

- exécuter sur `DEV` la baseline arrêtée par MD-02 dans les conditions MD-01 ;
- appliquer les remédiations de sécurité MD-03 ;
- produire les contrôles et preuves PA-01 à PA-10 applicables ;
- rejouer G1 en lecture seule ;
- préparer le dossier de revue humaine préalable à MD-08.

## 5. Scopes et fichiers interdits

Sont interdits :

- tout environnement de production ;
- toute réécriture d’une migration ou d’un historique existant ;
- toute extension hors Offer et hors remédiation QF/Rights autorisée ;
- toute modification du Runtime CEREBRAU ou de sa logique métier ;
- toute réutilisation de `tools/cerebrau/mission.json` ;
- toute modification d’un Gate ou de la Master Gates Matrix ;
- toute activation métier ou activation de consommateur ;
- toute décision automatique de certification.

Le manifeste dédié doit énumérer les chemins autorisés et interdits avant
exécution. Aucun chemin implicite n’est autorisé.

## 6. Preuves de sortie et revue

La mission corrective doit produire les preuves PA-01 à PA-10 définies par le
rapport G1, avec horodatage, environnement, acteur, résultat et rollback
applicable.

Une revue humaine vérifie les preuves, les critères d’arrêt, l’absence d’effet
hors scope et les avis Sécurité et Exploitation/Données. Aucun résultat
technique ne lève automatiquement G1.

## 7. Effets

MD-07 fournit le véhicule de gouvernance exigé pour l’exécution corrective.
Elle ne constitue ni une preuve d’exécution, ni une certification, ni une
autorisation de production.

## 8. Éléments explicitement inchangés

Restent inchangés :

- MD-01 à MD-06 ;
- le manifeste CEREBRAU par défaut ;
- le statut `NO_GO` du Gate Offer G1 ;
- les Gates et la Master Gates Matrix ;
- les décisions historiques ;
- l’interdiction d’activation métier et de production.

## 9. Enregistrement d’autorité

```text
DecisionId                    : MD-07
Authority                     : PROGRAM_DIRECTOR
GovernanceObject              : WAVE
CorrectiveMissionOrder        : ORDERED
Environment                   : DEV_ONLY
DedicatedManifest             : REQUIRED
DefaultMissionJsonReuse       : PROHIBITED
OutputEvidence                : PA-01_TO_PA-10_AS_APPLICABLE
HumanReview                   : REQUIRED
AutomaticGateDecision         : PROHIBITED
ProductionAuthorization       : NONE
OfferG1Status                 : NO_GO_UNCHANGED
GateModification              : NONE
MasterGatesMatrixModification : NONE
```
