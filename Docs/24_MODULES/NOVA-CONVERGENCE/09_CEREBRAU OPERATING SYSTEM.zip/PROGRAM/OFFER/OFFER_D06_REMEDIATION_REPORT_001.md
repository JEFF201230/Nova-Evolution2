# ARCH-D06-REMEDIATION-001 — Preuve de remédiation

## Verdict

| Champ | Résultat |
|---|---|
| Décision | `PASS` |
| Runtime | `SUCCESS` |
| Non-conformité | `D06-01` |
| Périmètre | `D06-01 uniquement` |

## Écart corrigé

`CreateOffer`, `CreateOfferVersion` et `CreateOperation` produisaient leurs
identifiants métier avant l'entrée dans `CommandGate`. Ces identifiants
aléatoires participaient à l'empreinte de commande : une seconde soumission du
même formulaire était donc interprétée comme une nouvelle intention et recevait
une nouvelle clé d'idempotence.

La remédiation lie maintenant à une même intention :

- une seule clé d'idempotence ;
- le payload canonique de la première soumission ;
- les identifiants métier générés par cette première soumission.

Pour les trois commandes concernées, l'empreinte d'intention exclut uniquement
les identifiants générés :

| Commande | Identifiants exclus de l'empreinte |
|---|---|
| `CreateOffer` | `offerId`, `versionId` |
| `CreateOfferVersion` | `newVersionId` |
| `CreateOperation` | `operationId` |

Le payload transmis reste complet et inchangé vis-à-vis du contrat HTTP.

## Cycle de vie garanti

- Deux soumissions concurrentes de la même intention partagent la même
  `Promise` : le transport n'est appelé qu'une fois.
- Un échec réseau, un timeout ou une absence d'accusé conserve la clé et le
  payload canonique.
- Le stockage de session du navigateur permet à une nouvelle instance de page
  de reprendre l'intention non acquittée avec la même clé et les mêmes UUID.
- Une réponse d'échec ne libère plus implicitement la clé.
- La clé et le payload ne sont libérés qu'après succès de la commande ou après
  appel explicite à `CommandGate.cancel`.
- Une annulation est refusée tant que le transport de l'intention est encore en
  vol.

## Preuves automatisées

Les six scénarios obligatoires sont exécutés séparément :

| Scénario | Preuve |
|---|---|
| `CreateOffer` double submit | 1 appel transport, 1 clé, 1 Offer et 1 Version initiale |
| `CreateOffer` retry | 2 tentatives, même clé, mêmes `offerId`/`versionId`, aucun doublon |
| `CreateOfferVersion` double submit | 1 appel transport, 1 clé, 1 Version |
| `CreateOfferVersion` retry | 2 tentatives, même clé, même `newVersionId`, aucun doublon |
| `CreateOperation` double submit | 1 appel transport, 1 clé, 1 Operation |
| `CreateOperation` retry | 2 tentatives, même clé, même `operationId`, aucun doublon |

Deux contrôles complémentaires prouvent :

- qu'un échec ne fait pas tourner la clé et qu'une annulation explicite la fait
  tourner ;
- qu'une intention non acquittée est restaurée depuis le stockage de session
  du navigateur puis supprimée après succès.

## Résultats de validation

| Validation ciblée | Résultat |
|---|---|
| `npx.cmd vitest run client/src/gdbcse/offer-workbench/OfferWorkbenchApi.test.ts` | `PASS` — 1 fichier, 9 tests |
| `client/node_modules/.bin/tsc.cmd -p client/tsconfig.offer-workbench.json --noEmit` | `PASS` |

## Fichiers de remédiation

- `client/src/gdbcse/offer-workbench/CommandGate.ts`
- `client/src/gdbcse/offer-workbench/OfferWorkbenchApi.test.ts`
- `Docs/PROGRAM/OFFER/OFFER_D06_REMEDIATION_REPORT_001.md`

Les contrats HTTP publics ne sont pas modifiés. Aucune décision D01 à D05,
aucun élément D07 et aucun code hors D06-01 ne sont modifiés par cette
remédiation. Aucun commit ni push n'a été effectué.

