# CEREBRAU — Plan officiel de remédiation Offer G1

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-G1-REMEDIATION-001
MISSION_TYPE        : REMEDIATION_PLANNING
EXECUTION_MODE      : READ_ONLY
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
CURRENT_GATE_STATUS : NO_GO
```

Les Work Packages ne sont pas des objets officiels de gouvernance. Le présent
document planifie une exécution future ; il n’autorise ni correction technique,
ni mutation Supabase, ni modification de migration, de décision, de preuve ou
de Gate.

## 2. Corpus exclusif

Le plan utilise exclusivement :

- `OFFER_G1_NO_GO_REPORT_001.md` ;
- `OFFER_PA01_EVIDENCE_001.md` à `OFFER_PA10_EVIDENCE_001.md` ;
- `OFFER_PA_CERTIFICATION_SUMMARY_001.md`.

Les décisions MD-01 à MD-08 sont tenues pour formalisées conformément aux faits
certifiés fournis à la mission. Leurs contenus ne sont pas relus ni modifiés ;
seules les conclusions déjà reprises dans le corpus exclusif sont utilisées.

## 3. Règle de désignation des fichiers

Le corpus exclusif identifie la version de migration `20260717000000`, les
familles de composants et certains objets de base, mais ne certifie pas leurs
chemins repository exacts. Pour ne créer aucun fait nouveau, le plan emploie le
registre logique suivant.

| Référence | Artefact ou ensemble de fichiers | Règle avant exécution |
|---|---|---|
| `AF-BASELINE` | fichier de migration Offer version `20260717000000` | Résoudre le chemin exact, la version et le hash autorisé dans la WAVE avant tout test ou application ; ne pas modifier le fichier |
| `AF-QF-RIGHTS` | artefact(s) correctif(s) autorisé(s) pour `qf_active`, `qf_config`, `rights_config`, `user_rights_projection` et `compute_qf(uuid)` | Résoudre les chemins exacts et vérifier qu’ils sont couverts par l’autorisation corrective avant mutation |
| `AF-OFFER-SECURITY` | définitions RLS, policies, ACL/grants et fonctions Offer de la baseline ou de migrations additives autorisées | Résoudre les chemins exacts avant revue ; aucune réécriture de l’historique |
| `AF-BACKEND` | fichiers du backend Offer monté dans le monolithe | Résoudre le commit, les chemins et la configuration déployés avant les tests PA-05 |
| `AF-RUNTIME-CONFIG` | manifestes et configuration du runtime backend déployé, sans secret dans les preuves | Résoudre les chemins et la version déployée avant PA-09 |
| `AF-CONSUMERS` | fichiers ou configurations des consommateurs EBS, Rights, LifeHub et finance | Résoudre les chemins effectivement déployés pour contrôle ; toute nécessité de modification hors autorisation arrête la séquence |
| `AF-EVIDENCE` | rapports d’exécution, inventaires, résultats de tests, rapprochements et dossier G1 futurs | Les noms et chemins doivent être fixés par la WAVE ; le présent plan n’en crée aucun |

L’absence de chemin certifié est traitée par la micro-mission `G1-PRE-01`. Une
micro-mission technique ne peut démarrer tant que toutes ses références `AF-*`
ne sont pas résolues. Cette contrainte rend l’exécution déterministe sans
inventer de chemin hors du corpus d’autorité.

## 4. Principes d’exécution

1. Toute exécution est bornée à `DEV` et à la WAVE officielle.
2. PA-07 valide la compatibilité et le rollback avant l’application PA-01.
3. Aucune entrée d’historique n’est fabriquée ou réécrite ; PA-02 constate
   l’alignement obtenu par le mécanisme autorisé.
4. Une exposition de sécurité, une collision, un échec de rollback, une
   activation implicite ou une identité runtime non démontrée impose l’arrêt.
5. PA-03 à PA-05 et PA-09 portent sur l’état réellement déployé, pas sur le seul
   repository.
6. PA-10 ne démarre qu’après satisfaction explicite de PA-01 à PA-09.
7. Une PA n’est `PASS` que si toutes les preuves attendues de sa ligne sont
   présentes, datées, rattachées à `DEV` et revues par son responsable logique.

## 5. Tableau complet PA-01 à PA-10

Les complexités `S`, `M`, `L` et `XL` sont des estimations de planification,
pas des faits certifiés. Le risque reprend la criticité du rapport G1 lorsqu’il
existe ; `ÉLEVÉ (plan)` indique un classement opérationnel nécessaire à la
priorisation, sans créer une nouvelle criticité doctrinale.

| PA | Verdict actuel | Cause du verdict | Composants impactés | Fichiers ou artefacts impactés | Risque | Complexité | Ordre | Responsable logique | Action corrective | Preuve attendue et critère `PASS` |
|---|---|---|---|---|---|---|---:|---|---|---|
| PA-01 | `PARTIAL` | Autorisation, baseline et WAVE documentées, mais aucune application DEV certifiée, aucun rapport d’exécution, acteur, horodatage, résultat ou rollback effectif | Migration Offer, base DEV, mécanisme de sauvegarde/rollback | `AF-BASELINE`, `AF-EVIDENCE` | `C4` via divergence et absence d’invariants Offer (`R-G1-01`, `R-G1-02`) | `L` | 3 | Data/DB, avec exploitation | Après PA-07, sauvegarder DEV, vérifier version/hash, appliquer la baseline autorisée, journaliser le résultat et rendre le rollback disponible | Rapport DEV avec version `20260717000000`, hash contrôlé, horodatage, acteur, résultat, sauvegarde, rollback et revue humaine ; tous présents et cohérents |
| PA-02 | `FAIL` | Version absente du live ; statements/hash distants indisponibles ; ni alignement ni supersession applicable | Historique live des migrations, rapprochement repository/runtime | `AF-BASELINE`, historique live, `AF-EVIDENCE` ; aucun fichier d’historique à éditer | `C3` (`R-G1-06`) | `M` | 4 | Data/DB | Après PA-01, relever la ligne live et comparer version, statements/hash et collisions sans réécrire l’historique | Ligne live `20260717000000`, statements/hash comparables, absence de collision et rapprochement repository/runtime documenté |
| PA-03 | `FAIL` | Inventaire certifié nul : `0/7` tables, `0/94` colonnes, `0/53` contraintes, `0/28` index, `0/4` fonctions, `0/1` trigger, `0/4` policies, `0/3` vues | Schéma Offer live, tables, colonnes, contraintes, index, fonctions, trigger, policies, vues | `AF-BASELINE`, éventuels artefacts additifs autorisés, inventaire live `AF-EVIDENCE` | `C4` (`R-G1-01`, `R-G1-02`) | `L` | 4 | Data/DB + Offer | Matérialiser uniquement par les migrations autorisées, puis inventorier en lecture seule chaque catégorie et rapprocher les quantités | Inventaire daté montrant exactement 7 tables, 94 colonnes, 53 contraintes, 28 index physiques, 4 fonctions, 1 trigger, 4 policies et 3 vues |
| PA-04 | `FAIL` | Objets Offer absents ; RLS et privilèges live classés non satisfaits ; aucun test tenant/PostgREST ou de non-contournement `service_role` | Tables Offer, RLS, policies, ACL/grants, PostgREST, contrôle tenant | `AF-OFFER-SECURITY`, `AF-BASELINE`, `AF-EVIDENCE` | `C4` (`R-G1-05`) | `L` | 4 | Sécurité + Data | Vérifier et, dans le seul périmètre autorisé, rendre effectifs RLS/policies/ACL ; retirer tout droit `anon` interdit ; exécuter les tests négatifs | `relrowsecurity`, policies et grants conformes par rôle, absence de privilège `anon`, tests tenant, cross-user, cross-tenant, accès direct PostgREST et non-bypass `service_role` tous réussis |
| PA-05 | `NOT_PROVEN` | Aucun résultat des tests négatifs backend ; backend déployé et contrat testé non identifiés | Backend Offer, authentification, autorisation par rôle et organisation, writer `service_role` | `AF-BACKEND`, `AF-RUNTIME-CONFIG`, jeux/résultats de test `AF-EVIDENCE` | `C4` (`R-G1-05`) | `L` | 5 | Sécurité/API Offer | Après PA-04 et PA-09, exécuter sur le backend identifié tous les scénarios négatifs et vérifier l’absence de bypass | Échecs contrôlés pour token absent, token invalide, rôle insuffisant, autre organisation, identifiant usurpé et bypass `service_role`, rattachés au commit/configuration PA-09 |
| PA-06 | `FAIL` | RLS désactivée et grants excessifs sur trois tables ; `compute_qf(uuid)` est `SECURITY DEFINER`, owner `postgres`, exécutable par `anon` ; aucune remédiation live prouvée | QF, Rights, quatre tables visées, RPC `compute_qf(uuid)`, ACL/RLS | `AF-QF-RIGHTS`, `AF-EVIDENCE` | `C4` (`R-G1-03`, `R-G1-04`) | `XL` | 2 | Sécurité + Data | Capturer l’état avant, appliquer la remédiation autorisée, retirer les mutations `anon`, restreindre la RPC, puis tester cross-user/cross-tenant et rollback | État live conforme des quatre tables et de la RPC, ACL/RLS conformes, aucun droit de mutation `anon`, tests négatifs et non-régression réussis, rollback disponible |
| PA-07 | `NOT_PROVEN` | Aucun dry-run ou test isolé représentatif, plan avant/après, vérification FK, rollback testé ou preuve d’absence d’activation | Migration Offer, environnement isolé représentatif, schéma/FK, rollback | `AF-BASELINE`, `AF-OFFER-SECURITY`, `AF-QF-RIGHTS` selon ordre autorisé, `AF-EVIDENCE` | `C4` (`R-G1-09`) | `XL` | 1 | Data/DB + Offer | Qualifier un environnement isolé représentatif, exécuter le dry-run, comparer avant/après, contrôler contraintes/FK, tester rollback et non-activation | Dry-run réussi, plan avant/après complet, contraintes/FK valides, rollback exécuté avec succès, aucune activation implicite |
| PA-08 | `PARTIAL` | Interdiction normative d’activation établie, mais comportement effectif d’EBS, Rights, LifeHub et finance non contrôlé après déploiement | EBS, Rights, LifeHub, finance, état `ACTIVE_OFFER_VERSION` | `AF-CONSUMERS`, `AF-RUNTIME-CONFIG`, résultats `AF-EVIDENCE` | `ÉLEVÉ (plan)` : effet inter-domaines ou production non autorisé | `L` | 4 | Offer + Integration | Capturer l’état des consommateurs, puis démontrer après baseline qu’aucun ne traite le déploiement comme activation ou disponibilité | Contrôles runtime datés des quatre familles, aucune activation/disponibilité induite, aucune transition `ACTIVE` implicite, revue humaine hors scope |
| PA-09 | `NOT_PROVEN` | Aucun commit/version du backend déployé, aucune configuration pertinente ni correspondance au contrat testé | Backend Offer déployé, exploitation, configuration runtime | `AF-BACKEND`, `AF-RUNTIME-CONFIG`, `AF-EVIDENCE` | `ÉLEVÉ (plan)` : tests non attribuables au runtime réel | `M` | 4 | Exploitation | Capturer l’identité immutable du runtime réellement déployé et sa configuration pertinente expurgée, puis la relier au contrat testé | Version/commit, environnement, identité runtime, configuration sans secret et correspondance explicite runtime–contrat |
| PA-10 | `NOT_PROVEN` | Aucun inventaire post-correction, rapprochement, registre de risques fermé, avis ou signatures ; aucune PA validée | Ensemble du runtime Offer, registre des risques, dossier de certification G1 | Tous `AF-*`, sans nouvelle mutation technique pendant le replay | `C4` agrégé tant qu’un risque critique reste ouvert | `XL` | 6 | Mission de certification + Sécurité + Exploitation/Data ; décision Program Director/Certification Board | Rejouer G1 intégralement en lecture seule, rapprocher repository/runtime, vérifier PA-01 à PA-09, fermer les risques et recueillir les avis/signatures | Inventaire live daté, rapprochement complet, PA-01 à PA-09 `PASS`, registre `R-G1-01` à `R-G1-10` fermé, avis et signatures requis ; dossier recevable pour la décision G1 |

## 6. Priorisation

La priorisation applique les critères dans l’ordre imposé : impact sur G1,
risque de régression, impact production, sécurité, cohérence des données, puis
complexité.

Les niveaux `FAIBLE`, `MOYEN`, `ÉLEVÉ` et `CRITIQUE` ci-dessous sont des
classements de planification. La colonne production mesure la conséquence
potentielle d’une erreur ou d’une activation, pas une autorisation de toucher
la production.

| PA | Impact certification G1 | Risque de régression | Impact production potentiel | Sécurité | Cohérence des données | Complexité |
|---|---|---|---|---|---|---|
| PA-01 | `BLOQUANT` | `ÉLEVÉ` | `MOYEN` | `MOYEN` | `CRITIQUE` | `L` |
| PA-02 | `BLOQUANT` | `FAIBLE` (contrôle read-only) | `FAIBLE` | `FAIBLE` | `ÉLEVÉ` | `M` |
| PA-03 | `BLOQUANT` | `FAIBLE` (inventaire read-only) | `FAIBLE` | `MOYEN` | `CRITIQUE` | `L` |
| PA-04 | `BLOQUANT` | `ÉLEVÉ` | `ÉLEVÉ` | `CRITIQUE` | `ÉLEVÉ` | `L` |
| PA-05 | `BLOQUANT` | `ÉLEVÉ` | `ÉLEVÉ` | `CRITIQUE` | `MOYEN` | `L` |
| PA-06 | `BLOQUANT` | `ÉLEVÉ` | `CRITIQUE` | `CRITIQUE` | `ÉLEVÉ` | `XL` |
| PA-07 | `BLOQUANT` | `ÉLEVÉ` | `MOYEN` | `MOYEN` | `CRITIQUE` | `XL` |
| PA-08 | `BLOQUANT` | `MOYEN` | `CRITIQUE` | `FAIBLE` | `ÉLEVÉ` | `L` |
| PA-09 | `BLOQUANT` | `FAIBLE` (capture read-only) | `MOYEN` | `MOYEN` | `FAIBLE` | `M` |
| PA-10 | `BLOQUANT` | `FAIBLE` (replay read-only) | `FAIBLE` | `ÉLEVÉ` agrégé | `ÉLEVÉ` agrégé | `XL` |

| Priorité | PA | Justification ordonnée |
|---|---|---|
| `P0-A` | PA-07 | Bloque une application sûre ; risque de rollback et d’intégrité `C4` ; doit précéder PA-01 malgré sa complexité `XL` |
| `P0-B` | PA-06 | Expositions de sécurité live `C4` directement prouvées ; risque production et cross-tenant ; peut avancer parallèlement à la lane baseline |
| `P0-C` | PA-01 | Ferme la divergence repository/runtime et matérialise les invariants ; condition de PA-02/03/04/08 |
| `P0-D` | PA-04 | Sécurité Offer et isolation tenant ; condition de la certification des écritures backend |
| `P0-E` | PA-05 | Ferme le risque `service_role` sur le runtime réellement identifié ; dépend de PA-04 et PA-09 |
| `P1-A` | PA-02 | Cohérence et provenance de l’historique ; contrôle après PA-01, sans édition du ledger |
| `P1-B` | PA-03 | Complétude du schéma et des invariants ; contrôle après PA-01 |
| `P1-C` | PA-08 | Empêche un impact inter-domaines ou une activation non autorisée ; contrôle post-déploiement |
| `P1-D` | PA-09 | Rend les tests applicatifs attribuables au runtime ; à produire avant PA-05 |
| `P0-FINAL` | PA-10 | Condition terminale obligatoire de réexamen ; non démarrable avant neuf PA passantes |

Les codes expriment une précédence logique et non un calendrier. PA-06 et la
préparation de PA-07 sont parallélisables. Après PA-01, PA-02, PA-03, PA-04,
PA-08 et PA-09 sont parallélisables sous réserve de leurs prérequis locaux.

## 7. Dépendances et conditions d’arrêt

| PA | Prérequis de démarrage | Dépendances bloquantes | Arrêt immédiat si |
|---|---|---|---|
| PA-01 | `G1-PRE-01`, PA-07 `PASS`, sauvegarde prête | version/hash non résolus, rollback non démontré | divergence de hash, collision, échec de migration ou rollback indisponible |
| PA-02 | PA-01 `PASS` | ligne live absente après exécution | nécessité de réécrire l’historique ou statements/hash non comparables |
| PA-03 | PA-01 `PASS` | objet ou catégorie absent | quantité divergente, contrainte/FK invalide |
| PA-04 | PA-01 et PA-03 `PASS` | RLS/policies/ACL incomplètes | privilège `anon`, fuite cross-user/cross-tenant ou bypass |
| PA-05 | PA-04 et PA-09 `PASS` | runtime non identifié ou contrôle backend insuffisant | un scénario interdit réussit |
| PA-06 | `G1-PRE-01`, remédiation et rollback autorisés | exposition QF/Rights non corrigée | mutation `anon`, RPC encore ouverte, fuite tenant ou rollback impossible |
| PA-07 | `G1-PRE-01`, environnement isolé qualifié | incompatibilité migration/FK/rollback | activation implicite, collision, perte de données ou rollback en échec |
| PA-08 | PA-01 `PASS`, états avant disponibles | consommation ou activation implicite | EBS/Rights/LifeHub/finance observe une disponibilité non autorisée |
| PA-09 | `G1-PRE-01`, accès d’exploitation en lecture | version/configuration non attribuable | secret exposé ou runtime impossible à rattacher au contrat |
| PA-10 | PA-01 à PA-09 `PASS` | tout risque ou avis encore ouvert | divergence fraîche, risque `C4`, signature ou avis manquant |

## 8. Matrice de validation

| PA | Action corrective définie | Priorité | Responsable logique | Critère PASS explicite |
|---|---|---|---|---|
| PA-01 | Oui | `P0-C` | Data/DB + exploitation | Oui |
| PA-02 | Oui | `P1-A` | Data/DB | Oui |
| PA-03 | Oui | `P1-B` | Data/DB + Offer | Oui |
| PA-04 | Oui | `P0-D` | Sécurité + Data | Oui |
| PA-05 | Oui | `P0-E` | Sécurité/API Offer | Oui |
| PA-06 | Oui | `P0-B` | Sécurité + Data | Oui |
| PA-07 | Oui | `P0-A` | Data/DB + Offer | Oui |
| PA-08 | Oui | `P1-C` | Offer + Integration | Oui |
| PA-09 | Oui | `P1-D` | Exploitation | Oui |
| PA-10 | Oui | `P0-FINAL` | Certification et autorités requises | Oui |

La couverture est complète : aucune PA ne peut être déclarée `PASS` par
héritage d’une décision, par présence repository seule, par test local positif
isolé ou par acceptation de risque. Chaque verdict exige la preuve opérationnelle
explicite décrite ci-dessus.
