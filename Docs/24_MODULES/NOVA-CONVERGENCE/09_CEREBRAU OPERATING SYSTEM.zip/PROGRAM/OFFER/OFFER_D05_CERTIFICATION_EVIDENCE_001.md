# OFFER D05 — Preuves de certification

Statut : `PASS`

Périmètre : décision `D05` uniquement. Aucune modification de `D01` à `D04`
et aucun démarrage de `D06` ou `D07`.

## 1. Feature flag et rollback gouvernés par WAVE

L'identité canonique de la bascule est :

```text
GovernanceObject = WAVE
WaveId           = PROGRAM-OFFER-WAVE-02
```

Elle est définie dans `OfferDistributionWave.ts` et contrôlée par
`OutboxWorker`. Le worker refuse une identité de gouvernance différente.

La distribution est désactivée par défaut. Les bascules runtime sont :

- dispatcher : `OFFER_DISTRIBUTION_ENABLED=true` ;
- consommateur Rights : `OFFER_DISTRIBUTION_RIGHTS_ENABLED=true` ;
- consommateur EBS : `OFFER_DISTRIBUTION_EBS_ENABLED=true`.

`rollbackConsumer(waveId, consumer)` désactive un consommateur sans modifier
les livraisons durables. `rollback(waveId)` arrête le dispatcher, désactive la
WAVE runtime et retire les deux consommateurs actifs. Le redémarrage avec les
flags désactivés conserve les inboxes et les reçus ; aucune donnée de
livraison n'est supprimée.

## 2. Livraison durable at-least-once vers Rights et EBS

La migration `20260726010000_add_offer_distribution_delivery.sql` fournit :

- une inbox durable par couple `(consumer, event_id)` pour `RIGHTS` et `EBS` ;
- les états `PENDING`, `LOCKED`, `CONSUMED`, `FAILED`, les leases, tentatives
  et dates de reprise ;
- un curseur ordonné par consommateur, tenant et Offer ;
- un reçu durable idempotent par `(consumer, event_id)` ;
- RLS, révocation de `anon/authenticated` et accès `service_role`.

Le publisher insère Rights et EBS dans une même transaction PostgreSQL.
L'outbox source n'est acquittée qu'après commit de cette transaction et après
vérification de la lease. Un arrêt entre publication et acquittement provoque
un rejeu ; `ON CONFLICT (consumer,event_id) DO NOTHING` rend ce rejeu sûr et
conserve la garantie at-least-once.

## 3. Idempotence, ordre, replay et réconciliation

Le consommateur :

- claim avec `FOR UPDATE SKIP LOCKED` et lease ;
- impose l'ordre total `(aggregate_order, event_id)`, y compris lorsque deux
  enveloppes partagent le même ordre d'agrégat ;
- inscrit le reçu idempotent, avance le curseur et acquitte la livraison dans
  une même transaction ;
- classe un reçu existant `DUPLICATE` et un événement antérieur
  `STALE_REPLAY` ;
- permet le replay de `CONSUMED` ou `FAILED` sans effacer le reçu durable.

La query de réconciliation relit l'état Offer autoritatif, fabrique un
`OfferReconciled` déterministe et le réinscrit dans les inboxes Rights et EBS.
Elle ne recalcule ni Rights ni EBS.

## 4. Convergence p95

`first_consumed_at` est immuable après la première convergence. Un replay
ultérieur met à jour `consumed_at` mais ne déforme pas le SLO initial.

`OutboxSupervisor.inspect()` calcule sur 24 heures :

- p95 global de `first_consumed_at - occurred_at` ;
- p95 Rights ;
- p95 EBS ;
- backlog source et livraison ;
- éléments âgés de plus de cinq minutes.

Le worker alerte dès qu'un p95 atteint 60 secondes ou qu'un backlog dépasse
cinq minutes. Le scénario PostgreSQL ciblé vérifie séparément Rights et EBS,
l'ordre avec deux événements au même rang, le replay idempotent, l'immuabilité
de `first_consumed_at` et `p95 < 60`.

## 5. Validations exécutées

| Validation | Résultat |
|---|---|
| Tests Offer domain/application/infrastructure | `116 PASS`, `14 SKIP` PostgreSQL conditionnels |
| Tests infrastructure seuls, frontière d'architecture incluse | `39 PASS`, `14 SKIP` PostgreSQL conditionnels |
| Tests API Offer hors PostgreSQL | `18 PASS` |
| Import runtime infrastructure et composition HTTP | `PASS` |
| `git diff --check` sur le périmètre D05 | `PASS` |

`OFFER_TEST_DATABASE_URL` n'est pas fourni dans l'environnement. Les quatorze
tests PostgreSQL sont donc conditionnellement ignorés. Le scénario de
certification D05 est implémenté dans
`server/offer-infrastructure/test/integration.postgres.test.ts` et s'exécute
automatiquement sur une cible PostgreSQL isolée.

## Verdict

`D05 : PASS`
