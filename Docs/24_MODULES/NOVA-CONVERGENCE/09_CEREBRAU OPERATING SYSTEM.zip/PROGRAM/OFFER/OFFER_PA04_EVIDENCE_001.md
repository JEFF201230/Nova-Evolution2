# CEREBRAU — CERTIFICATION DE PREUVE PA-04

## 1. Identité

```text
PROGRAM          : VEEDDA
DOMAIN           : OFFER
MISSION_ID       : OFFER-PA-CONSOLIDATION-001
EVIDENCE_ID      : PA-04
OFFICIAL_OBJECT  : WAVE
AUTHORITY        : PROGRAM_DIRECTOR
```

Les Work Packages ne sont pas des objets officiels de gouvernance.

## 2. Périmètre exact

PA-04 porte exclusivement sur la conformité live de la RLS et des privilèges
Offer : `relrowsecurity`, policies, grants par rôle, absence de privilège
`anon`, tests tenant et accès direct PostgREST
(`OFFER_G1_NO_GO_REPORT_001.md`, § 9, ligne PA-04).

## 3. Preuves existantes certifiées

| Référence documentaire | Élément établi | Portée pour PA-04 |
|---|---|---|
| `OFFER_G1_NO_GO_REPORT_001.md`, § 5 | Objets Offer absents ; RLS Offer testée sur DEV et privilèges Offer conformes classés `NON SATISFAIT` | Contradiction directe avec la conformité live exigée |
| `OFFER_G1_NO_GO_REPORT_001.md`, §§ 7 et 9 | Écritures via `service_role` non certifiées sans tests négatifs live ; preuve PA-04 absente | Risque R-G1-05 ouvert |
| `OFFER_MD03_AUTHORITY_DECISION_001.md`, §§ 3 à 5 | RLS, ACL, policies, contrôles cross-user/cross-tenant et restriction `service_role` rendus obligatoires ; fermeture seulement après preuve fraîche | Définit la remédiation, sans prouver son exécution |
| `OFFER_MD06_AUTHORITY_DECISION_001.md`, § 4 | Writer serveur unique et écritures anonymes interdites | Règle normative, pas conformité live |
| `OFFER_MD08_AUTHORITY_DECISION_001.md`, §§ 3 et 5 | Aucune preuve fraîche ; aucune validation de PA-01 à PA-10 | Confirme l’absence de certification post-remédiation |

## 4. Évaluation

La conformité live ne peut pas être démontrée sur des objets Offer absents.
Le rapport G1 classe explicitement les exigences RLS et privilèges comme non
satisfaites. Les décisions MD-03 et MD-06 fixent les règles futures sans
modifier l’état observé.

## 5. Écarts et preuves manquantes

- état live `relrowsecurity` ;
- policies et grants par rôle ;
- preuve d’absence de privilège `anon` ;
- tests tenant et accès direct PostgREST ;
- tests cross-user et cross-tenant ;
- preuve de non-contournement par `service_role`.

Ces éléments sont requis par le rapport G1 (§ 9) et MD-03 (§ 4).

## 6. Impact sur Offer G1

PA-04 touche le risque critique R-G1-05, non certifié dans le rapport G1
(§ 7). MD-03 précise que sa décision seule ne ferme aucun risque (§ 5).
MD-08 maintient donc G1 à `NO_GO` (§§ 3 et 4).

## 7. Verdict

```text
PA-04   : FAIL
MOTIF   : CONFORMITÉ LIVE IMPOSSIBLE À ÉTABLIR ET EXIGENCE CLASSÉE NON SATISFAITE
G1      : NO_GO INCHANGÉ
```
