# CEREBRAU — DÉCISION D’AUTORITÉ MD-03

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-MD03-AUTHORITY-DECISION-001
MISSION_TYPE        : GOVERNANCE_FORMALIZATION
EXECUTION_MODE      : ONE_SHOT
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
DECISION_ID         : MD-03
```

Les work packages ne sont pas des objets officiels de gouvernance.

## 2. Objet et périmètre

Le présent document formalise exclusivement la décision MD-03 déjà rendue sur
la remédiation de sécurité QF/Rights et des écritures Offer.

Il ne constitue ni une preuve de correction, ni une certification de sécurité.

## 3. Décision officielle

Le `PROGRAM_DIRECTOR` arrête la remédiation obligatoire suivante sur `DEV` :

1. activer et rendre effectives les protections RLS requises sur `qf_active`,
   `qf_config` et `rights_config` ;
2. retirer à `anon` les privilèges de mutation sur ces objets ;
3. retirer à `anon` le droit d’exécuter `compute_qf(uuid)` et borner cette
   fonction aux rôles explicitement autorisés ;
4. limiter l’usage de `service_role` aux écritures serveur autorisées par le
   writer unique enregistré en MD-06 ;
5. imposer les contrôles applicatifs d’identité, de rôle, d’organisation et de
   périmètre avant toute écriture Offer ;
6. exécuter les tests négatifs cross-user et cross-tenant, ainsi que les tests
   de token absent, invalide, insuffisant ou usurpé ;
7. vérifier les ACL, policies, owners et chemins d’exécution applicables avant
   toute revue G1.

## 4. Conditions de validation

La remédiation n’est considérée exécutée qu’après production d’une preuve
fraîche démontrant :

- l’absence de mutation anonyme ;
- l’absence d’accès cross-user et cross-tenant ;
- l’impossibilité de contourner les contrôles via `service_role` ;
- la restriction effective de `compute_qf(uuid)` ;
- la conformité live des RLS, ACL et policies ;
- l’absence de régression ou d’effet inter-domaines non autorisé.

Tout échec, élargissement de privilège, contournement ou divergence déclenche
l’arrêt et le rollback prévus par MD-01.

## 5. Effets

MD-03 fixe le traitement obligatoire des risques R-G1-03 à R-G1-05. Ces risques
ne sont pas réputés fermés par la publication du présent document : leur
fermeture dépend de l’exécution gouvernée et des preuves PA-04 à PA-06
applicables.

## 6. Éléments explicitement inchangés

Restent inchangés :

- MD-04 et MD-05 ;
- les constats de sécurité du rapport G1 ;
- le statut `NO_GO` du Gate Offer G1 ;
- les Gates et la Master Gates Matrix ;
- l’absence actuelle de preuve post-remédiation ;
- l’interdiction de production ;
- l’absence d’activation métier ou inter-domaines.

## 7. Enregistrement d’autorité

```text
DecisionId                    : MD-03
Authority                     : PROGRAM_DIRECTOR
GovernanceObject              : WAVE
SecurityRemediation           : REQUIRED
AnonymousMutation             : PROHIBITED
AnonymousComputeQfExecution    : PROHIBITED
ServiceRoleUse                : UNIQUE_SERVER_WRITER_ONLY
CrossUserTests                : REQUIRED
CrossTenantTests              : REQUIRED
RollbackOnFailure             : REQUIRED
RiskClosureByDecisionAlone    : NONE
ProductionAuthorization       : NONE
OfferG1Status                 : NO_GO_UNCHANGED
GateModification              : NONE
MasterGatesMatrixModification : NONE
```
