# CEREBRAU — DÉCISION D’AUTORITÉ MD-01

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-MD01-AUTHORITY-DECISION-001
MISSION_TYPE        : GOVERNANCE_FORMALIZATION
EXECUTION_MODE      : ONE_SHOT
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
DECISION_ID         : MD-01
```

Les work packages ne sont pas des objets officiels de gouvernance.

## 2. Objet et périmètre

Le présent document formalise exclusivement la décision MD-01 déjà rendue
relative à l’autorisation corrective Offer sur l’environnement `DEV`.

Il ne constitue ni une preuve d’exécution, ni un ordre de production, ni une
révision du Gate Offer G1.

## 3. Décision officielle

Le `PROGRAM_DIRECTOR` autorise une correction contrôlée sur `DEV`, uniquement
dans le cadre de la `WAVE` et du Mission Order dédiés enregistrés par MD-07.

```text
Environment                 : DEV
MigrationVersion            : 20260717000000
MigrationFile               : supabase/migrations/20260717000000_create_offer_infrastructure.sql
MigrationSHA256             : BA39DAD5BF03D03CC91833B2B1DF6497648E16EE6EFF3E04DAA6B5E4E3DB0F4D
ProductionAuthorization     : NONE
OfferG1                     : NO_GO
```

L’autorisation porte sur la matérialisation contrôlée de la baseline Offer
retenue par MD-02 et sur la remédiation de sécurité arrêtée par MD-03. Elle ne
permet aucune activation métier.

## 4. Conditions d’exécution

L’exécution est bornée par les conditions cumulatives suivantes :

1. utilisation exclusive de l’environnement `DEV` ;
2. exécution sous la `WAVE`, le Mission Order et le manifeste Offer dédiés de
   MD-07 ;
3. responsabilité d’exécution portée par l’autorité Exploitation/Données
   désignée dans ce cadre ;
4. contrôle préalable de la version et du SHA-256 enregistrés ci-dessus ;
5. sauvegarde restaurable avant mutation et procédure de rollback disponible ;
6. journalisation de l’acteur technique, de l’horodatage et du résultat ;
7. production des preuves applicables PA-01 à PA-10 définies par le rapport G1 ;
8. revue humaine avant toute décision de poursuite.

La fenêtre d’exécution s’ouvre uniquement lorsque les conditions MD-02,
MD-03, MD-06 et MD-07 sont satisfaites. Elle se ferme au premier critère
d’arrêt ou à l’achèvement de la mission corrective.

## 5. Critères d’arrêt et rollback

L’exécution s’arrête et le rollback prévu est déclenché en cas :

- de divergence de version ou de SHA-256 ;
- d’échec de sauvegarde ou d’indisponibilité du rollback ;
- de collision avec l’historique live ;
- de divergence de schéma ou de contrainte non prévue ;
- d’exposition de sécurité, d’accès cross-user ou cross-tenant ;
- d’effet inter-domaines ou d’activation implicite ;
- d’intervention hors `DEV`, hors scope ou hors manifeste dédié ;
- d’impossibilité de produire une preuve de sortie exigée.

## 6. Effets

MD-01 enregistre l’autorisation corrective bornée nécessaire à une future
exécution gouvernée sur `DEV`. Elle n’atteste pas que cette exécution a eu lieu
et ne ferme aucun risque ni aucune dépendance.

## 7. Éléments explicitement inchangés

Restent inchangés :

- MD-04 et MD-05 ;
- l’exclusion de `20260717000000` du périmètre historique des 29 migrations ;
- le statut `NO_GO` du Gate Offer G1 ;
- les Gates et la Master Gates Matrix ;
- l’historique de migration existant ;
- l’interdiction de réécrire l’historique ;
- l’interdiction de production ;
- l’absence d’activation des consommateurs Offer.

## 8. Enregistrement d’autorité

```text
DecisionId                    : MD-01
Authority                     : PROGRAM_DIRECTOR
GovernanceObject              : WAVE
CorrectiveAuthorization       : GRANTED_WITH_CONDITIONS
Environment                   : DEV_ONLY
ExecutionVehicle              : MD-07_WAVE_AND_MISSION_ORDER
ExecutionOwner                : EXPLOITATION_DATA_AUTHORITY_DESIGNATED_BY_MD-07
BackupAndRollback             : REQUIRED
StopCriteria                  : MANDATORY
ProductionAuthorization       : NONE
OfferG1Status                 : NO_GO_UNCHANGED
GateModification              : NONE
MasterGatesMatrixModification : NONE
```
