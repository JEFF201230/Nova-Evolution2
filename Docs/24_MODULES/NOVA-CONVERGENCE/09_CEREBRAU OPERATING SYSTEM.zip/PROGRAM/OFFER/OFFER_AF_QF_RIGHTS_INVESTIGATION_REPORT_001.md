# CEREBRAU — Rapport d’investigation AF-QF-RIGHTS

## 1. Identité et verdict

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-AF-QF-RIGHTS-INVESTIGATION-001
MISSION_TYPE        : TECHNICAL_EVIDENCE_INVESTIGATION
EXECUTION_MODE      : READ_ONLY
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
PROFILE             : ARCHITECTURE
DATE_OBSERVATION    : 2026-07-24
BRANCH               : fix/simulation-star
HEAD                 : 706bf1fae540e1798e3b827fbb162cac20b3b019
MISSION_STATUS       : SUCCESS
```

Les faits certifiés fournis à la mission sont appliqués : l’objet officiel de
gouvernance est la `WAVE`, les Work Packages ne sont pas officiels, la
fondation est prête, le Wave Model et le contrat MM L01-03 sont canoniques.

Le verdict porte exclusivement sur l’existence d’un artefact SQL maintenu dans
le dépôt. La présence live documentée de cinq objets legacy ne vaut pas
définition SQL repository.

## 2. Q1 — Définition exacte du besoin

### 2.1 Objets exigés

Les sources d’autorité fixent exactement les objets suivants :

1. `public.qf_active` ;
2. `public.qf_config` ;
3. `public.rights_config` ;
4. `public.user_rights_projection` ;
5. `public.compute_qf(uuid)`.

Les repères d’autorité directs sont :

- `Docs/PROGRAM/OFFER/OFFER_G1_LOT01_EXECUTION_REPORT_001.md:75-108` ;
- `Docs/PROGRAM/OFFER/OFFER_G1_REMEDIATION_PLAN_001.md:34-54` ;
- `Docs/PROGRAM/OFFER/OFFER_G1_EXECUTION_BACKLOG_001.md:38-59` ;
- `Docs/PROGRAM/OFFER/OFFER_G1_EXECUTION_LOTS_001.md:113-145` et
  `182-208` ;
- `Docs/PROGRAM/OFFER/OFFER_G1_CRITICAL_PATH_001.md:35-54` et
  `152-169`.

La signature d’identité exigée est `public.compute_qf(uuid)`. Les cinq sources
initiales ne prescrivent ni le nom de l’argument, ni le type de retour, ni le
langage. Une observation live antérieure, qui n’est pas une définition
repository, documente séparément
`public.compute_qf(p_user_id uuid) RETURNS uuid`.

### 2.2 Critères d’exécutabilité

Pour être recevable comme `AF-QF-RIGHTS`, un ensemble de fichiers doit réunir
les conditions suivantes :

- être du SQL exécutable, et non une description Markdown, un consommateur
  TypeScript ou une Edge Function ;
- couvrir les quatre tables exactes et la fonction d’identité
  `public.compute_qf(uuid)` ;
- avoir des chemins exacts, un propriétaire logique, un mode d’accès autorisé,
  une version ou un hash lorsque requis, et une PA consommatrice, conformément
  à `G1-PRE-01` ;
- avoir un ordre d’exécution déterminable et des dépendances disponibles ;
- permettre la reproduction sur un environnement vierge, ou porter une
  stratégie explicite de création/réconciliation si les objets existent déjà ;
- porter la remédiation de sécurité exigée : RLS effective, retrait des
  mutations `anon`, restriction de la RPC et préservation des accès légitimes ;
- ne muter aucun objet hors des quatre tables et de la RPC.

Un artefact ne devient donc pas exécutable par la seule existence des objets
dans DEV.

## 3. Méthode de recherche

La recherche a été exécutée en lecture seule selon six axes.

1. Lecture intégrale des cinq sources d’autorité obligatoires.
2. Inventaire du système de fichiers avec `rg --files`, y compris les fichiers
   cachés et ignorés, hors `.git`, `node_modules`, sorties `dist/build` et
   caches.
3. Recherche insensible à la casse, séparée pour chacun des cinq noms, dans
   tous les fichiers SQL puis dans tous les fichiers texte du dépôt.
4. Recherche des formes DDL `CREATE TABLE`, `ALTER TABLE`,
   `CREATE FUNCTION` et `CREATE OR REPLACE FUNCTION`.
5. Inspection des candidats QF/Rights, de leurs dépendances, de leurs appels et
   de leur rattachement éventuel à un mécanisme d’exécution.
6. Recherche Git sur toutes les branches, références distantes et tags
   disponibles avec `git log --all -G`, ainsi que recherche des suppressions
   ou renommages de fichiers SQL QF/Rights.

Résultats quantifiés :

```text
FICHIERS_SQL_INSPECTES                         : 46
DONT_SUPABASE_MIGRATIONS                       : 34
FICHIERS_SQL_CONTENANT_qf_active               : 0
FICHIERS_SQL_CONTENANT_qf_config               : 0
FICHIERS_SQL_CONTENANT_rights_config           : 0
FICHIERS_SQL_CONTENANT_user_rights_projection  : 0
FICHIERS_SQL_CONTENANT_compute_qf              : 0
COMMITS_ALL_REFS_AVEC_UN_NOM_REQUIS_EN_SQL     : 0
SUPPRESSIONS_OU_RENOMMAGES_SQL_QF_RIGHTS       : 0
```

La recherche globale a aussi recensé 96 fichiers documentaires contenant au
moins un nom requis. Ils ont été traités comme indices ou preuves secondaires,
jamais comme artefacts SQL exécutables.

## 4. Fichiers inspectés

### 4.1 Sources d’autorité obligatoires

- `Docs/PROGRAM/OFFER/OFFER_G1_LOT01_EXECUTION_REPORT_001.md` ;
- `Docs/PROGRAM/OFFER/OFFER_G1_EXECUTION_LOTS_001.md` ;
- `Docs/PROGRAM/OFFER/OFFER_G1_EXECUTION_BACKLOG_001.md` ;
- `Docs/PROGRAM/OFFER/OFFER_G1_REMEDIATION_PLAN_001.md` ;
- `Docs/PROGRAM/OFFER/OFFER_G1_CRITICAL_PATH_001.md`.

### 4.2 Inventaire exhaustif des fichiers SQL

```text
_SEED_ASC_AEP_BUDGETS_2026-02-25.sql
server/moteur-qf/qf.api.sql
server/moteur-qf/qf.logic.sql
server/moteur-qf/qf.schema.sql
server/moteur-qf/qf.triggers.sql
server/offer-infrastructure/test/bootstrap.native-postgresql.sql
supabase/migrations/20260101000000_create_budgets.sql
supabase/migrations/20260101000010_create_subvention_models.sql
supabase/migrations/20260101110219_dossier_complet_rpc.sql
supabase/migrations/20260222000000_create_budget_ledger.sql
supabase/migrations/20260222000001_create_subventions.sql
supabase/migrations/20260222173757_rpc_approve_subvention.sql
supabase/migrations/20260222181344_patch_rpc_approve_subvention_statut_montant.sql
supabase/migrations/20260222183223_create_view_v_budget_balance.sql
supabase/migrations/20260222184447_rpc_pay_subvention.sql
supabase/migrations/20260222191528_refactor_ledger_reserve_release_v2.sql
supabase/migrations/20260222191655_patch_view_v_budget_balance_reserve.sql
supabase/migrations/20260222192258_fix_view_v_budget_balance_drop_recreate.sql
supabase/migrations/20260222193508_rpc_refund_subvention.sql
supabase/migrations/20260222194550_patch_subventions_add_statut_refunded.sql
supabase/migrations/20260222195145_lock_subventions_budget_id_not_null.sql
supabase/migrations/20260222195900_patch_rpc_pay_idempotence_v24.sql
supabase/migrations/20260222201000_patch_rpc_approve_idempotence_v23.sql
supabase/migrations/20260222202000_add_operation_id_to_ledger_v26.sql
supabase/migrations/20260222203000_drop_strict_unique_debit_v27.sql
supabase/migrations/20260222204500_patch_pay_subvention_operation_id_v28.sql
supabase/migrations/20260222205500_create_subvention_payments_v29.sql
supabase/migrations/20260222211000_patch_pay_subvention_use_subvention_payments_v30.sql
supabase/migrations/20260222232545_ledger_v3_pay_subvention.sql
supabase/migrations/20260225213235_budget_votes_transfers_asc_aep.sql
supabase/migrations/20260326000100_create_budgets.sql
supabase/migrations/20260528120000_add_budget_status_mvp.sql
supabase/migrations/20260612000100_patch_pay_subvention_created_by.sql
supabase/migrations/20260615_create_grand_livre_asc_views.sql
supabase/migrations/20260617_0001_create_ledger_accounts.sql
supabase/migrations/20260617_0002_create_ledger_account_mapping.sql
supabase/migrations/20260622000200_create_budget_status_events.sql
supabase/migrations/20260712000000_create_qf_operations_tables.sql
supabase/migrations/20260717000000_create_offer_infrastructure.sql
supabase/migrations/DISABLED_patch.sql
supabase/snippets/Untitled query 201.sql
supabase/sql/checks/check_grand_livre_asc_v1.sql
supabase/sql/checks/check_ledger_account_mapping.sql
supabase/sql/prototypes/grand_livre_asc_v1.sql
supabase/sql/seeds/ledger_account_mapping_seed.sql
supabase/sql/seeds/ledger_accounts_seed.sql
```

### 4.3 Candidats et consommateurs inspectés

- `server/moteur-qf/qf.schema.sql:1-21` ;
- `server/moteur-qf/qf.logic.sql:1-17` ;
- `server/moteur-qf/qf.api.sql:1-21` ;
- `server/moteur-qf/qf.triggers.sql:1-12` ;
- `supabase/migrations/20260712000000_create_qf_operations_tables.sql:1-240` ;
- `supabase/functions/compute-qf/index.ts:439-482`, `689-785` et
  `859-962` ;
- `supabase/functions/compute-rights/index.ts:332-340`, `389-454` et
  `497-570` ;
- `server/employee-business-state/lifehub-bridge.ts:78-106` ;
- `server/qf-operations/infrastructure/VeeddaQfOperationsReaders.ts:15-68` ;
- `client/src/lib/veedda-sdk/rights.ts:24-31` ;
- `client/src/mon-espace-salarie/pages/MonEspacePage.tsx:191` et `424`.

Sources secondaires utilisées pour qualifier le live ou le legacy :

- `Docs/PROGRAM/OFFER/OFFER_G1_DATA_INVENTORY_REPORT_001.md:75-93`,
  `148-178`, `200-260` et `325-340` ;
- `Docs/26_VEEDDA_BUSINESS_ARCHITECTURE_AUDIT/AUDIT_02_BRIDGE_QF_SOURCE_VERITE_QF.md:140-164`
  et `245-265` ;
- `Docs/03_PATCHES_ET_EVOLUTIONS/LOCALISATION_MOTEUR_QF.md:166-226` et
  `257-315`.

## 5. Matrice obligatoire des composants

| Élément requis | Chemin exact | Repère exact | État | Écart |
|---|---|---|---|---|
| `public.qf_active` | Aucun chemin SQL dans le dépôt | 0 occurrence dans 46 fichiers SQL ; 0 commit SQL sur toutes les refs | `ABSENT` | Objet live documenté, mais aucune création ou modification SQL repository |
| `public.qf_config` | Aucun chemin SQL dans le dépôt | 0 occurrence dans 46 fichiers SQL ; 0 commit SQL sur toutes les refs | `ABSENT` | Deux blocs `CREATE TABLE` existent seulement dans un document descriptif, pas dans un artefact exécutable |
| `public.rights_config` | Aucun chemin SQL dans le dépôt | 0 occurrence dans 46 fichiers SQL ; 0 commit SQL sur toutes les refs | `ABSENT` | Objet consommé par l’Edge Rights, sans DDL maintenue |
| `public.user_rights_projection` | Aucun chemin SQL dans le dépôt | 0 occurrence dans 46 fichiers SQL ; 0 commit SQL sur toutes les refs | `ABSENT` | Objet consommé et alimenté par du TypeScript, sans DDL maintenue |
| `public.compute_qf(uuid)` | Aucun chemin SQL dans le dépôt | 0 occurrence de `compute_qf` dans 46 fichiers SQL ; 0 commit SQL sur toutes les refs | `ABSENT` | RPC live legacy décrite dans les preuves, mais définition absente du dépôt |

## 6. Q2 — Existence des tables

| Table | Migration SQL de création | Migration SQL de modification | Instruction repository | Dépendances repository | Statut |
|---|---|---|---|---|---|
| `public.qf_active` | aucune | aucune | aucune | non définissables faute de DDL | `ABSENT` |
| `public.qf_config` | aucune | aucune | aucune | non définissables faute de DDL | `ABSENT` |
| `public.rights_config` | aucune | aucune | aucune | non définissables faute de DDL | `ABSENT` |
| `public.user_rights_projection` | aucune | aucune | aucune | non définissables faute de DDL | `ABSENT` |

Les seules dépendances structurelles disponibles sont des observations live
documentées, pas des contraintes reproductibles depuis le dépôt :

- `qf_active` : PK `user_id`, FK vers `qf_config`, `qf_history` et `profiles`,
  plus un CHECK `validity_status` ;
- `qf_config` : PK `id`, FK `created_by` vers `profiles` ;
- `rights_config` : PK `id`, aucune FK, unique partiel
  `ux_rights_config_one_active` ;
- `user_rights_projection` : PK `user_id`, aucune FK live.

Ces faits sont consignés dans
`Docs/PROGRAM/OFFER/OFFER_G1_DATA_INVENTORY_REPORT_001.md:200-209`. Ils ne
permettent pas une exécution sur base vierge.

Les dépendances applicatives constatées sont :

- `qf_config` est lue par
  `supabase/functions/compute-qf/index.ts:473-482` ;
- `rights_config` est lue par
  `supabase/functions/compute-rights/index.ts:332-340` ;
- `user_rights_projection` est écrite par
  `supabase/functions/compute-rights/index.ts:414-430` et `538-556`, puis lue
  par les chemins serveur/client listés en section 4.3 ;
- aucun producteur courant de `qf_active` n’a été trouvé.

## 7. Q3 — Existence de `compute_qf(uuid)`

### 7.1 Résultat repository

| Propriété | Résultat |
|---|---|
| Fonction SQL dans le dépôt | non |
| Chemin exact | aucun |
| Signature repository | aucune |
| Type de retour repository | non applicable |
| Langage repository | non applicable |
| Sécurité repository | non précisée, fonction absente |
| Dépendances SQL repository | aucune définition disponible |
| Statut | `ABSENT` |

### 7.2 Implémentation live legacy documentée

La preuve secondaire
`Docs/PROGRAM/OFFER/OFFER_G1_DATA_INVENTORY_REPORT_001.md:250-262` documente
une fonction live qui ne possède aucun fichier SQL source dans le dépôt :

| Propriété | Valeur live documentée |
|---|---|
| Nom qualifié | `public.compute_qf` |
| Signature | `(p_user_id uuid)` |
| Retour | `uuid` |
| Langage | `PL/pgSQL` |
| Sécurité | `SECURITY DEFINER` |
| Owner | `postgres` |
| Volatilité | volatile |
| Dépendance observée dans le corps | lecture de `qf_config` |
| Comportement observé | lève une exception demandant d’utiliser l’Edge Function ; aucune écriture dans le corps |
| Exécution accordée | `anon`, `authenticated`, `service_role` |

Cette présence live ne change pas le statut repository `ABSENT`. Elle démontre
au contraire un drift non reproductible et une implémentation dormant/legacy.
L’Edge Function `supabase/functions/compute-qf/index.ts` n’est pas la RPC
PostgreSQL `compute_qf(uuid)`.

## 8. Q4 — Versionnement

### 8.1 Migrations

- aucune des quatre tables ni la RPC n’est contenue dans les 34 migrations SQL
  actuelles ;
- aucun commit de toutes les refs Git disponibles ne contient un des cinq noms
  requis dans un fichier `.sql` ;
- aucun fichier SQL QF/Rights supprimé ou renommé n’a été trouvé dans
  l’historique disponible ;
- il n’existe donc aucun ordre d’exécution AF-QF-RIGHTS déterminable, aucune
  version concurrente du même artefact et aucune migration AF-QF-RIGHTS
  annulée ou remplacée.

`supabase/migrations/DISABLED_patch.sql:1-38` est un patch ledger legacy sans
rapport avec QF/Rights.

### 8.2 SQL voisins mais non conformes

| Fichier | Versionnement | SHA-256 observé | Qualification |
|---|---|---|---|
| `server/moteur-qf/qf.schema.sql` | suivi depuis `b35e5bc882429638b5793569424dae3a586d0fcb`, aucun commit ultérieur | `91fefcb2ec4d23b67c34bc8aa450e882b5e9d07b49ef5c50145435c62c678a7c` | V1 legacy, mauvais noms |
| `server/moteur-qf/qf.logic.sql` | même commit, aucun commit ultérieur | `d96aa5ee042a4e5f441068b069ef1392d389a82cf5d99743097ead35cbf85266` | fonctions de calcul legacy |
| `server/moteur-qf/qf.api.sql` | même commit, aucun commit ultérieur | `f53fef7118629bd95fbc017c60b80d8e84073de7a807817a077612431a1e4cbd` | RPC `get_qf_for_user`, pas `compute_qf` |
| `server/moteur-qf/qf.triggers.sql` | même commit, aucun commit ultérieur | `3f65bdbb690c12fba5ddbf28b8d4392cc52810432098d5ea4266be62a2596e97` | trigger legacy |
| `supabase/migrations/20260712000000_create_qf_operations_tables.sql` | migration suivie depuis `544d064d040a7516d5f06b9c924703ad9ccd2c95` | `5075e8f20a3a7faac9e974ef07b5168d06e53d4f393468701761b6087f0d4e46` | workflow opérationnel QF distinct, zéro objet requis |

Les quatre fichiers sous `server/moteur-qf` sont suivis par Git, mais ne sont
pas des migrations horodatées et aucun script ou configuration exécutable ne
les charge. Leur ordre logique peut être déduit manuellement
`schema → logic → api → triggers`, mais n’est encodé dans aucun runner. Cela ne
satisfait pas `G1-PRE-01`.

## 9. Implémentations concurrentes ou legacy

### 9.1 Chaîne SQL QF V1

`server/moteur-qf/qf.schema.sql` crée :

- `qf_foyer` à la ligne 1 ;
- `qf_historique` à la ligne 9 ;
- `qf_modele_systeme` à la ligne 17.

`server/moteur-qf/qf.logic.sql` crée `calcul_qf_caf`,
`calcul_qf_cse` et `calcul_qf_hybride`. `qf.api.sql:1-21` crée
`get_qf_for_user(uid uuid) RETURNS numeric`, qui lit les trois tables et écrit
`qf_historique`. `qf.triggers.sql:1-12` l’appelle après mise à jour de
`qf_foyer`.

Cette chaîne est cohérente en interne, mais elle ne définit aucun des quatre
noms exacts et ne définit pas `compute_qf(uuid)`. Elle est une implémentation
legacy concurrente, pas un fragment de `AF-QF-RIGHTS`.

### 9.2 Chaîne Edge QF/Rights V2

- `supabase/functions/compute-qf/index.ts` lit `user_qf_input`,
  `foyer_salarie`, `qf_config`, `parts_rules` et `qf_history`, puis écrit
  `qf_history` et `qf_foyer` ;
- `supabase/functions/compute-rights/index.ts` lit `qf_history` et
  `rights_config`, écrit `rights_history` et
  `user_rights_projection`.

Cette chaîne est le moteur applicatif courant documenté, mais ses fichiers
TypeScript ne créent ni table ni RPC SQL. Elle dépend précisément d’objets dont
les migrations manquent.

### 9.3 DDL documentaire

`Docs/03_PATCHES_ET_EVOLUTIONS/LOCALISATION_MOTEUR_QF.md:174-186` et
`272-285` contient deux exemples `CREATE TABLE qf_config`. Le document les
qualifie de « structure attendue » et précise aux lignes 196-226 qu’aucune
migration versionnée n’existe et que les fichiers `server/moteur-qf` sont
legacy.

Ces blocs Markdown ne sont ni une migration, ni un script appliqué, ni une
seconde source SQL exécutable. Ils révèlent une reconstruction documentaire
partielle et ne couvrent que l’une des quatre tables.

## 10. Q5 — Cohérence et dépendances

### 10.1 Chaîne commune

Les quatre tables requises et la fonction n’appartiennent à aucune chaîne SQL
repository commune, puisqu’aucune définition n’existe. Les objets live
documentés sont reliés à la chaîne Edge V2, tandis que `qf_active` et la RPC
`compute_qf` sont décrits comme anciens/dormants et sans producteur applicatif
courant.

### 10.2 Exécution sur environnement vierge

L’exécution sur environnement vierge est impossible depuis le dépôt :

- les cinq définitions requises manquent ;
- les dépendances live `profiles`, `qf_history`, `user_qf_input`,
  `foyer_salarie`, `parts_rules` et `rights_history` ne sont pas rassemblées
  dans une chaîne AF-QF-RIGHTS versionnée ;
- le dépôt ne contient aucun runner associant les quatre scripts SQL V1 ;
- la migration voisine
  `supabase/migrations/20260712000000_create_qf_operations_tables.sql:113-153`
  dépend de `public.organizations` et `public.profiles`, dont aucune création
  n’a été trouvée dans les migrations locales. Elle ne fournit aucun des cinq
  objets requis.

### 10.3 Sources de vérité

Il existe plusieurs représentations concurrentes :

1. SQL V1 suivi sous `server/moteur-qf`, non migré et dormant ;
2. Edge V2 TypeScript, producteur/consommateur courant ;
3. objets legacy présents dans DEV mais non reproductibles depuis le dépôt ;
4. exemples DDL documentaires partiels ;
5. tables QF Operations versionnées, appartenant à un autre modèle.

Il n’existe cependant pas de seconde source de vérité SQL complète pour
`AF-QF-RIGHTS`. Les contradictions portent sur le modèle QF général, pas sur
deux implémentations complètes du même artefact requis.

## 11. Écarts

| ID | Écart factuel | Conséquence |
|---|---|---|
| `AFQF-01` | zéro DDL repository pour les quatre tables exactes | DEV non reproductible |
| `AFQF-02` | zéro définition repository de `public.compute_qf(uuid)` | RPC live sans provenance versionnée |
| `AFQF-03` | chaîne V1 aux noms et contrats incompatibles | ne peut pas compléter implicitement AF-QF-RIGHTS |
| `AFQF-04` | chaîne V2 TypeScript dépendante de tables non migrées | moteur applicatif non bootstrapable sur base vierge |
| `AFQF-05` | `qf_active` sans producteur courant identifié | projection legacy divergente |
| `AFQF-06` | RLS/grants live dangereux documentés, sans patch repository | remédiation G1 non exécutable |
| `AFQF-07` | comportement attendu de la RPC non prescrit au-delà de son identité et de sa restriction | le prochain PDS doit réconcilier le contrat avant d’écrire son corps |

## 12. Q6 — Conclusion unique

```text
AF_QF_RIGHTS_ABSENT
```

Justification : aucun des cinq composants obligatoires n’existe dans un fichier
SQL du dépôt actuel ou dans l’historique SQL de toutes les refs disponibles.
Les scripts V1, Edge Functions, objets live et exemples documentaires ne
constituent pas un artefact SQL partiel portant les noms exigés.

## 13. Décision de reprise unique

```text
CREATE_AF_QF_RIGHTS_IMPLEMENTATION_PDS
```

Le périmètre exact à créer dans un PDS ultérieur, sans création pendant la
présente mission, est :

1. une ou plusieurs migrations versionnées définissant ou réconciliant
   `public.qf_active` ;
2. une ou plusieurs migrations versionnées définissant ou réconciliant
   `public.qf_config` ;
3. une ou plusieurs migrations versionnées définissant ou réconciliant
   `public.rights_config` ;
4. une ou plusieurs migrations versionnées définissant ou réconciliant
   `public.user_rights_projection` ;
5. une définition versionnée de `public.compute_qf(uuid)`, après décision
   explicite sur le type de retour et le comportement, avec restriction du rôle
   d’exécution ;
6. les contraintes, index, RLS, policies, grants/revokes, tests et rollback
   strictement nécessaires à ces cinq objets ;
7. un ordre déterministe et une stratégie distincte pour base vierge et DEV
   déjà peuplé, sans `DROP` implicite et sans mutation hors des cinq objets.

Le futur PDS ne doit pas assimiler les scripts V1 ou les Edge Functions à la
RPC demandée, ni inventer un nom de migration avant autorisation du manifeste.

## 14. Chemins exacts utilisables par le prochain PDS

Il n’existe aucun chemin SQL AF-QF-RIGHTS existant à appliquer. Les chemins
exacts utilisables comme entrées factuelles sont :

| Usage futur | Chemin exact | Repères |
|---|---|---|
| contrat d’autorité des cinq objets | `Docs/PROGRAM/OFFER/OFFER_G1_LOT01_EXECUTION_REPORT_001.md` | 75-108 |
| définition logique AF-QF-RIGHTS | `Docs/PROGRAM/OFFER/OFFER_G1_REMEDIATION_PLAN_001.md` | 34-54, 77-88 |
| critères PA-06 | `Docs/PROGRAM/OFFER/OFFER_G1_EXECUTION_BACKLOG_001.md` | 53-59 |
| contrat live des colonnes | `Docs/PROGRAM/OFFER/OFFER_G1_DATA_INVENTORY_REPORT_001.md` | 167-178 |
| contraintes live observées | `Docs/PROGRAM/OFFER/OFFER_G1_DATA_INVENTORY_REPORT_001.md` | 200-209 |
| RLS et privilèges live observés | `Docs/PROGRAM/OFFER/OFFER_G1_DATA_INVENTORY_REPORT_001.md` | 211-260 |
| moteur QF V2 consommateur | `supabase/functions/compute-qf/index.ts` | 439-482, 689-785, 859-962 |
| moteur Rights V2 consommateur | `supabase/functions/compute-rights/index.ts` | 332-340, 389-454, 497-570 |
| consommateurs de projection | `server/employee-business-state/lifehub-bridge.ts` | 78-106 |
| consommateurs de projection | `server/qf-operations/infrastructure/VeeddaQfOperationsReaders.ts` | 15-68 |
| comparaison legacy V1 | `server/moteur-qf/qf.schema.sql` | 1-21 |
| comparaison legacy V1 | `server/moteur-qf/qf.logic.sql` | 1-17 |
| comparaison legacy V1 | `server/moteur-qf/qf.api.sql` | 1-21 |
| comparaison legacy V1 | `server/moteur-qf/qf.triggers.sql` | 1-12 |
| répertoire de migrations existant, futur chemin à autoriser | `supabase/migrations/` | 34 fichiers SQL actuels |

Le prochain PDS doit faire autoriser un nouveau chemin exact sous
`supabase/migrations/`, puis enregistrer sa version, son SHA-256, son
propriétaire logique, son mode d’accès et ses PA consommatrices avant la reprise
de `G1-PRE-01`.

## 15. Contrôle de non-mutation

L’état initial était déjà modifié et contenait de nombreux fichiers non suivis.
En particulier, `Docs/PROGRAM/` était déjà présenté globalement comme non suivi
par `git status --short`. Ces modifications préexistantes ont été laissées
intactes.

Le seul fichier créé par cette mission est :

```text
Docs/PROGRAM/OFFER/OFFER_AF_QF_RIGHTS_INVESTIGATION_REPORT_001.md
```

Aucun SQL, migration, code, configuration Supabase, document existant, preuve
PA, Gate ou matrice de gouvernance n’a été modifié.
