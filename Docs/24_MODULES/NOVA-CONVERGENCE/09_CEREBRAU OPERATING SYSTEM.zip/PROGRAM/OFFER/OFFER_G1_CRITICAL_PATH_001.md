# CEREBRAU — Chemin critique Offer G1

## 1. Identité et portée

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-G1-REMEDIATION-001
DELIVERABLE         : OFFER_G1_CRITICAL_PATH_001
EXECUTION_MODE      : READ_ONLY
OFFICIAL_OBJECT     : WAVE
CURRENT_GATE_STATUS : NO_GO
PATH_TYPE           : LOGICAL_NOT_CALENDAR
```

Le corpus d’autorité ne fournit aucune durée d’exécution. Le chemin critique
est donc exprimé en dépendances et points de décision, sans estimation
calendaire. Il planifie un dossier recevable pour réexamen ; il ne vaut ni
autorisation technique, ni `GO`, ni activation, ni production.

## 2. Résultat cible

Le chemin est terminé uniquement lorsque :

- PA-01 à PA-10 sont explicitement `PASS` ;
- le nouvel inventaire live DEV est complet ;
- le rapprochement repository/runtime est cohérent ;
- `R-G1-01` à `R-G1-10` sont fermés ;
- les avis Sécurité et Exploitation/Data sont présents ;
- le dossier est signé et recevable pour une décision complémentaire du
  Program Director et du Certification Board.

La décision G1 reste une étape d’autorité séparée après le présent chemin.

## 3. Séquence critique

| Étape | Micro-mission | PA | Entrée obligatoire | Sortie obligatoire | Blocage traité | Critère de passage |
|---:|---|---|---|---|---|---|
| 1 | `G1-PRE-01` | Transverse | WAVE et décisions formalisées | Manifeste exact des `AF-*`, versions/hash, propriétaires et modes d’accès | Chemins techniques non certifiés dans le corpus exclusif | Aucun artefact non résolu ou hors scope |
| 2 | `G1-PRE-02` | Transverse | Manifeste résolu | DEV identifié, sauvegarde, rollback, fenêtre, acteurs et arrêts confirmés | Mutation non maîtrisée | Rollback et exclusion production explicites |
| 3 | `G1-PA07-01` | PA-07 | Périmètre et rollback | Environnement isolé représentatif, état avant | Absence de terrain de test recevable | Représentativité documentée et aucune mutation DEV |
| 4 | `G1-PA07-02` | PA-07 | Environnement isolé qualifié | Dry-run et plan après, contraintes/FK vérifiées | Compatibilité migration non prouvée | Zéro collision, FK/contraintes valides, zéro activation |
| 5 | `G1-PA07-03` | PA-07 | Dry-run réussi | Rollback exécuté, état restauré, PA-07 `PASS` | Rollback G1 absent (`R-G1-09`) | Restauration complète et absence d’effet consommateur |
| 6 | `G1-PA01-01` | PA-01 | PA-07 `PASS`, sauvegarde prête | Contrôle final version/hash et feu d’exécution | Baseline non sécurisée | Version `20260717000000`, hash et cible DEV conformes |
| 7 | `G1-PA01-02` | PA-01 | Préflight conforme et état PA-08 avant capturé | Baseline appliquée et journal brut | Migration Offer absente live | Application réussie sans activation ni réécriture |
| 8 | `G1-PA01-03` | PA-01 | Application réussie | Rapport DEV revu, PA-01 `PASS` | Exécution non prouvée | Version, hash, acteur, date, résultat, sauvegarde et rollback présents |
| 9 | `G1-PA03-01` | PA-03 | PA-01 `PASS` | Inventaire complet, PA-03 `PASS` | Objets Offer `0/ensemble attendu` | `7/94/53/28/4/1/4/3` exactement constatés |
| 10 | `G1-PA04-01` | PA-04 | PA-03 `PASS` | Audit RLS/policies/ACL/grants | Sécurité Offer non certifiable | Aucun droit `anon` interdit, matrice par rôle complète |
| 11 | `G1-PA04-02` | PA-04 | Audit conforme | Tests tenant/PostgREST conformes, PA-04 `PASS` | `R-G1-05` sur le socle de données | Aucun accès cross-user/cross-tenant ni bypass |
| 12 | `G1-PA05-01` | PA-05 | PA-04 et PA-09 `PASS` | Six scénarios rattachés au runtime | Tests non attribuables | Même commit/configuration pour tous les scénarios |
| 13 | `G1-PA05-02` | PA-05 | Cas de tests figés | Résultats négatifs conformes, PA-05 `PASS` | `R-G1-05` backend | Les six comportements interdits sont refusés |
| 14 | `G1-PA10-01` | PA-10 | PA-01 à PA-09 `PASS` | Replay live read-only et rapprochement | Dossier post-correction absent | Aucun écart repository/runtime non expliqué |
| 15 | `G1-PA10-02` | PA-10 | Replay conforme | Registre fermé et avis requis | Risques critiques et dépendances ouvertes | Aucun `C4` ouvert ; tous les avis présents |
| 16 | `G1-PA10-03` | PA-10 | Registre et avis complets | Dossier signé, PA-10 `PASS` | Révision G1 impossible | Dossier complet et historique `NO_GO` conservé |

## 4. Branches obligatoires hors chaîne principale

Ces branches ne peuvent pas être omises. Elles sont exécutées en parallèle
pour ne pas allonger la chaîne principale, avec une échéance de jonction
explicite.

| Branche | Séquence | Démarrage au plus tôt | Jonction obligatoire | Condition de jonction |
|---|---|---|---|---|
| QF/Rights | `G1-PA06-01` → `G1-PA06-02` → `G1-PA06-03` | Après `G1-PRE-02`; l’état initial peut être capturé en parallèle de PA-07 | Avant `G1-PA10-01` | PA-06 `PASS`, expositions `R-G1-03` et `R-G1-04` fermées |
| Consommateurs | `G1-PA08-01` → `G1-PA08-02` | `G1-PA08-01` après `G1-PRE-01` | État avant requis avant `G1-PA01-02`; PA-08 `PASS` avant `G1-PA10-01` | Aucun effet EBS/Rights/LifeHub/finance ni transition `ACTIVE` |
| Runtime | `G1-PA09-01` → `G1-PA09-02` | Après `G1-PRE-01` | Avant `G1-PA05-01` | Commit, configuration sans secret et contrat reliés |
| Historique | `G1-PA02-01` | Après `G1-PA01-03` | Avant `G1-PA10-01` | Version live, statements/hash et absence de collision établis |

La branche QF/Rights devient critique si PA-07 doit tester ses artefacts et si
`G1-PA06-03` n’est pas terminée avant le replay. La branche consommateurs
devient immédiatement critique si l’état avant n’a pas été capturé avant
l’application. La branche runtime devient critique à l’entrée de PA-05.

## 5. Points de synchronisation

### `SYNC-0` — périmètre exécutable

Entrées :

- `G1-PRE-01` et `G1-PRE-02` clôturées ;
- production exclue ;
- chemins exacts et rollback résolus.

Sortie : autorisation de démarrer les contrôles isolés et read-only préalables,
dans les limites de la WAVE.

### `SYNC-1` — migration compatible

Entrées :

- PA-07 `PASS` ;
- état consommateurs avant disponible ;
- version/hash de baseline conformes.

Sortie : PA-01 peut démarrer. Un simple dry-run positif sans rollback ou sans
preuve de non-activation ne franchit pas `SYNC-1`.

### `SYNC-2` — baseline matérialisée

Entrée : PA-01 `PASS`.

Sorties parallèles :

- rapprochement PA-02 ;
- inventaire PA-03 ;
- contrôle post-déploiement PA-08.

### `SYNC-3` — sécurité applicative testable

Entrées :

- PA-03 `PASS` ;
- PA-04 `PASS` ;
- PA-09 `PASS`.

Sortie : PA-05 peut être exécutée sur le runtime effectivement identifié.

### `SYNC-4` — dossier de preuves complet

Entrées : PA-01 à PA-09 toutes `PASS`.

Sortie : PA-10 peut commencer en lecture seule. Aucun verdict `PARTIAL`,
`NOT_PROVEN` ou `FAIL` ne franchit ce point.

### `SYNC-5` — dossier recevable

Entrées :

- PA-10 `PASS` ;
- aucun risque `C4` ouvert ;
- avis et signatures requis présents.

Sortie : dossier transmis à l’autorité pour une décision G1 complémentaire.
Le statut ne change pas automatiquement.

## 6. Ordre de priorité opérationnelle

| Rang | Travail | Motif dominant |
|---:|---|---|
| 1 | Résolution `G1-PRE-01/02` | Aucun travail sûr n’est possible sans périmètre, DEV et rollback |
| 2 | PA-07 | Empêche une migration incompatible ou non réversible |
| 3 | PA-06 en parallèle | Ferme les expositions QF/Rights `C4` déjà live |
| 4 | PA-01 | Ferme la divergence repository/runtime et débloque les contrôles Offer |
| 5 | PA-03 puis PA-04 | Matérialise puis sécurise les invariants de données |
| 6 | PA-09 puis PA-05 | Rend les tests backend attribuables et ferme le risque `service_role` |
| 7 | PA-02 et PA-08 en parallèle | Ferme provenance et effets inter-domaines |
| 8 | PA-10 | Rejoue le Gate, ferme les risques et assemble le dossier signé |

Cet ordre respecte en priorité l’impact de certification et les risques de
régression/sécurité avant la complexité de mise en œuvre.

## 7. Critères d’arrêt globaux

La séquence s’arrête sans tentative de contournement si l’un des événements
suivants survient :

- chemin, version ou hash non conforme au manifeste ;
- cible autre que DEV ou nécessité d’un fichier hors scope ;
- collision de migration ou besoin de réécrire l’historique ;
- contrainte ou clé étrangère invalide ;
- sauvegarde non restaurable ou rollback en échec ;
- privilège `anon`, fuite cross-user/cross-tenant ou bypass `service_role` ;
- `compute_qf(uuid)` encore accessible au rôle interdit ;
- activation `ACTIVE`, disponibilité ou effet EBS/Rights/LifeHub/finance non
  autorisé ;
- runtime, commit ou configuration non attribuable au contrat testé ;
- secret présent dans une preuve ;
- quantité d’objet Offer différente de `7/94/53/28/4/1/4/3` ;
- PA non `PASS`, risque `C4`, avis ou signature manquant à l’entrée de PA-10.

Après arrêt, le statut demeure `NO_GO`. La reprise exige la résolution formelle
de la cause dans le même périmètre d’autorité ; aucune extension implicite
n’est admise.

## 8. Matrice de sortie du chemin critique

| Contrôle final | Attendu | Responsable logique | Bloquant |
|---|---|---|---|
| PA-01 à PA-09 | Neuf preuves opérationnelles satisfaites selon le plan | Responsables PA | Oui |
| Inventaire Offer | `7/94/53/28/4/1/4/3` | Data/DB + Offer | Oui |
| Sécurité Offer | RLS/ACL/policies et tests tenant conformes | Sécurité + Data | Oui |
| Sécurité QF/Rights | Quatre tables et RPC conformes | Sécurité + Data | Oui |
| Backend | Six tests négatifs sur runtime identifié | Sécurité/API Offer + Exploitation | Oui |
| Effets inter-domaines | Aucun effet ou activation non autorisé | Offer + Integration | Oui |
| Provenance | Historique, statements/hash et runtime rapprochés | Data/DB + Exploitation | Oui |
| Risques | `R-G1-01` à `R-G1-10` fermés | Certification + autorités spécialisées | Oui |
| Avis et signatures | Sécurité, Exploitation/Data, Program Director, Certification Board | Autorités requises | Oui |
| Décision G1 | Décision complémentaire séparée | Program Director + Certification Board | Hors du présent plan |
