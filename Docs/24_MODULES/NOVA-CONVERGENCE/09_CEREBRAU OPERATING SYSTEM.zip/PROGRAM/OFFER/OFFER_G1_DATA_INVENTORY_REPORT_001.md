# CEREBRAU — Inventaire G1 des données Offer

## 1. Identification

| Champ | Valeur |
|---|---|
| Program | `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001` |
| Lot documentaire | `OFFER` |
| MissionId | `OFFER-G1-DATA-INVENTORY-001` |
| MissionType | `DATA_SCHEMA_READ_ONLY_AUDIT` |
| ExecutionMode | `ONE_SHOT` |
| Autorité | `PROGRAM_DIRECTOR / CERTIFICATION_BOARD` |
| Date d'observation live | `2026-07-23 15:55:05.333647+00` (`17:55:05` Europe/Paris) |
| Dépôt | `C:\DEV\veedda-cseV7-core` |
| Branche / HEAD observés | `fix/simulation-star` / `706bf1fae540e1798e3b827fbb162cac20b3b019` |
| Périmètre d'écriture | ce rapport uniquement |
| Verdict de mission | `READY_FOR_G1_AUTHORITY_DECISION` |
| Gate G1 | `NO_GO` |

Les faits certifiés fournis sont appliqués sans réinterprétation : l'objet officiel de gouvernance est `WAVE`, les work packages ne sont pas officiels, la fondation est prête, le Wave Model est canonique et le contrat MM L01-03 est canonique.

## 2. Autorité et périmètre

Les deux sources obligatoires sont :

1. `Docs/PROGRAM/OFFER/OFFER_AUTHORITY_RECONCILIATION_REPORT_001.md` ;
2. `Docs/PROGRAM/OFFER/OFFER_ARCHITECTURE_BOARD_DECISIONS_001.md`.

Le premier rapport prouve la définition dépôt de la migration Offer aux lignes 29, 62 et 170-181, définit K11 à la ligne 387, et identifie les inconnues live U01-U02 aux lignes 414-415. Le second porte G0 à `GO` à la ligne 987, maintient K11 ouverte aux lignes 951-959 et fixe la condition de clôture à la ligne 955.

Le périmètre live couvre les relations, colonnes, contraintes, index, RLS, policies, privilèges, fonctions/RPC, triggers, vues et historique de migrations pouvant appartenir au domaine Offer. Les objets legacy liés à l'éligibilité, aux droits et aux périodes de validité sont qualifiés séparément ; ils ne sont pas élevés au rang de modèle Offer canonique.

Aucune donnée métier n'a été lue. Aucun code, test, fichier de configuration, secret, migration ou schéma n'a été modifié. Aucun appel de fonction métier ni de RPC métier n'a été exécuté.

## 3. Méthode d'accès read-only

L'accès DEV a utilisé la CLI Supabase déjà installée (`2.105.0`) et le projet déjà lié dans le dépôt :

```text
supabase db query --linked --output json "<SELECT ...>"
```

Toutes les instructions SQL fournies par la mission commencent par `SELECT`. Les sous-requêtes ne consultent que `information_schema`, `pg_catalog`, `pg_class`, `pg_namespace`, `pg_constraint`, `pg_indexes`, `pg_policies`, `pg_proc`, `pg_trigger`, `pg_views` et `supabase_migrations.schema_migrations`. Les fonctions de catalogue `pg_get_constraintdef`, `pg_get_triggerdef`, `pg_get_functiondef`, `pg_get_function_identity_arguments` et `pg_get_function_result` ont seulement matérialisé des métadonnées.

La CLI a affiché `Initialising login role...` avant chaque connexion. Ce bootstrap de connexion est géré par la CLI Supabase ; la mission n'a fourni aucune instruction de création, modification ou attribution de rôle. Le rôle de session observé était `postgres`, sur PostgreSQL `17.6`. Aucun secret, project ref, token ou chaîne de connexion n'est reproduit ici.

Familles de consultations exécutées :

- identité de la session et horodatage ;
- découverte des relations, colonnes, vues et fonctions par nom ou définition ;
- inventaire exact des objets attendus par la migration Offer ;
- historique visible des migrations, puis recherche de la version `20260717000000` ;
- inventaire ciblé de `qf_active`, `qf_config`, `rights_config`, `user_rights_projection` et de `compute_qf(uuid)`.

## 4. Sources analysées

### 4.1 Sources dépôt

| Source | Repère exact | Objet |
|---|---:|---|
| `Docs/PROGRAM/OFFER/OFFER_AUTHORITY_RECONCILIATION_REPORT_001.md` | 29, 39, 62, 170-181, 387, 414-415, 618, 638-640 | migration, K11, inconnues et gate |
| `Docs/PROGRAM/OFFER/OFFER_ARCHITECTURE_BOARD_DECISIONS_001.md` | 22-43, 951-959, 976-1002, 1023-1031 | autorité, K11, G0 et G1 |
| `supabase/migrations/20260717000000_create_offer_infrastructure.sql` | 1-229 | définition SQL Offer complète |
| `server/offer-infrastructure/test/bootstrap.native-postgresql.sql` | 1-38 | bootstrap de test isolé, non migration DEV |
| `server/offer-infrastructure/repositories/PostgresRepositories.ts` | 9-26 | contrats de persistance des quatre tables métier |
| `server/offer-infrastructure/idempotency/PostgresIdempotency.ts` | 24-30 | contrat `offer_idempotency` |
| `server/offer-infrastructure/audit/PostgresAuditWriter.ts` | 1-6 | contrat `offer_audit_entry` |
| `server/offer-infrastructure/outbox/PostgresOutbox.ts` | 1-7 | contrat `offer_outbox` |
| `server/offer-infrastructure/projections/PostgresOfferReadModel.ts` | 39-354 | tables et vues attendues par les requêtes |
| `server/offer-infrastructure/security/RlsValidation.ts` | 1-4 | sept tables et RLS obligatoires |
| `supabase/functions/compute-rights/index.ts` | 334-384, 417, 497-588 | lecture `rights_config`, écriture projection Rights |
| `supabase/functions/compute-qf/index.ts` | 473-952 | lecture `qf_config`, production QF |
| `Docs/21_DOMAIN_MODELS/ICCMS_OFFER_INFRASTRUCTURE_CERTIFICATION_002_REPORT.md` | 37-58, 107-144 | certification sur cluster local isolé, sans Supabase Cloud |

Les recherches de définitions SQL sur les termes de mission n'ont trouvé que deux fichiers SQL pertinents : la migration Offer et le bootstrap PostgreSQL natif. Aucune définition SQL maintenue de `qf_active`, `qf_config`, `rights_config` ou `user_rights_projection` n'a été trouvée dans le dépôt.

### 4.2 Registre de preuves

| Id | Classification | Source | Objet | Requête ou fichier / repère | Résultat observé | Conséquence |
|---|---|---|---|---|---|---|
| P-D01 | `FAIT_DÉPÔT_PROUVÉ` | dépôt | migration Offer | migration lignes 1-229 ; SHA-256 `ba39dad5bf03d03cc91833b2b1df6497648e16ee6eff3e04daa6b5e4e3db0f4d` | 7 tables, 15 index explicites, 4 fonctions, 1 trigger, 4 policies, 3 vues, RLS sur 7 tables | état attendu précisément reproductible |
| P-D02 | `FAIT_DÉPÔT_PROUVÉ` | dépôt | bootstrap de test | fichier lignes 1-38 ; SHA-256 `d091175c7c46ab6f909b972145756fdf869bb59234f6c8e2bc2bb089ef2f82cf` | rôles de test, `auth.jwt()` et `organizations`; aucun objet Offer | ne prouve pas DEV |
| P-D03 | `FAIT_DÉPÔT_PROUVÉ` | dépôt | certification antérieure | ICCMS-002 lignes 37-58 | PostgreSQL local isolé, aucune base distante utilisée | les PASS RLS antérieurs ne sont pas une preuve live |
| P-L01 | `FAIT_LIVE_PROUVÉ` | DEV lié | session | `SELECT current_database(), current_user, version(), now()` | PostgreSQL 17.6, observation horodatée, accès réussi | preuve live obtenue |
| P-L02 | `FAIT_LIVE_PROUVÉ` | catalogues DEV | objets Offer nommés | sélection `pg_class`/`pg_proc` par les termes de mission | zéro relation et zéro fonction correspondantes | aucun objet Offer live par nom |
| P-L03 | `FAIT_LIVE_PROUVÉ` | catalogues DEV | inventaire Offer exact | sélection des 7 tables, colonnes, contraintes, index, policies, privilèges, 4 fonctions, trigger et 3 vues attendus | tous les tableaux de résultat sont vides | absence live prouvée objet par objet |
| P-L04 | `FAIT_LIVE_PROUVÉ` | DEV lié | historique migrations | sélection de `supabase_migrations.schema_migrations` | 3 lignes visibles seulement ; première `20260101110219`, dernière `20260225213235`; aucune `20260717000000`; `statements` est nul | migration Offer absente de l'historique visible ; hash distant non calculable |
| P-L05 | `FAIT_LIVE_PROUVÉ` | DEV lié | legacy QF/Rights | catalogues sur 4 tables | 4 tables présentes ; RLS désactivée sur 3 ; privilèges complets aux trois rôles | risques d'exposition et de drift |
| P-L06 | `FAIT_LIVE_PROUVÉ` | DEV lié | `compute_qf(uuid)` | métadonnées `pg_proc`, ACL et définition | `SECURITY DEFINER`, owner `postgres`, exécutable par `anon`, `authenticated`, `service_role` | risque critique selon la règle de mission |
| P-C01 | `DIVERGENCE_PROUVÉE` | dépôt + DEV | modèle Offer | P-D01 rapproché de P-L03/P-L04 | définition locale présente, migration et objets live absents | K11 confirmée |
| P-U01 | `INCONNU` | historique DEV | causalité du drift | historique visible seulement | impossible de prouver si la migration n'a jamais été appliquée ou si ses traces/objets ont été retirés | aucune attribution ni chronologie inventée |

Aucune `CONFORMITÉ_PROUVÉE` dépôt/live n'est enregistrée pour un objet Offer : il n'existe aucun objet live à comparer. Aucun catalogue demandé n'a été `NON_ACCESSIBLE`.

## 5. Définition de K11

`K11_DEFINITION` :

- rapport d'autorité, ligne 387 : migration Offer présente et certifiée localement, mais aucune table `offer_*` dans la photographie Supabase du 19 juillet ; conséquence « dépôt ≠ runtime observé » ;
- décision Architecture Board, ligne 955 : même contradiction, maintenue ouverte parce que l'état live au 23 juillet et l'historique distant n'avaient pas été observés ; clôture conditionnée par un inventaire live read-only, l'historique/hashes, les tables/vues, la RLS et le rapprochement dépôt/runtime.

K11 ne porte donc pas sur la qualité du test PostgreSQL isolé. Elle porte sur l'écart entre la définition versionnée dans le dépôt et l'état réel du DEV/Supabase lié.

## 6. Inventaire des migrations

Le dossier `supabase/migrations` contient 34 fichiers SQL, dont 33 migrations horodatées suivies de `DISABLED_patch.sql` dans l'ordre lexical. La migration Offer est la 33e et la plus récente des migrations horodatées.

| Ordre | Chemin exact | Nom | SHA-256 | Objet / statut attendu |
|---:|---|---|---|---|
| 33 | `supabase/migrations/20260717000000_create_offer_infrastructure.sql` | `20260717000000_create_offer_infrastructure` | `ba39dad5bf03d03cc91833b2b1df6497648e16ee6eff3e04daa6b5e4e3db0f4d` | schéma Offer complet ; attendu appliqué en DEV ; `LIVE_ABSENT` |
| hors historique DEV | `server/offer-infrastructure/test/bootstrap.native-postgresql.sql` | bootstrap natif de test | `d091175c7c46ab6f909b972145756fdf869bb59234f6c8e2bc2bb089ef2f82cf` | prérequis d'une base isolée `veedda_offer_test`; ne doit pas être assimilé à une migration DEV |

Les trois versions visibles dans l'historique live ont une correspondance nominale locale :

| Version live | Nom live | Fichier local | SHA-256 local | Concordance prouvée |
|---|---|---|---|---|
| `20260101110219` | `dossier_complet_rpc` | `20260101110219_dossier_complet_rpc.sql` | `e27c93df6af8f3bfa3b3147f75892de4c7223da9b97f8cd1f966863609fd667c` | nom/version seulement ; contenu live nul, hash non comparable |
| `20260222232545` | `ledger_v3_pay_subvention` | `20260222232545_ledger_v3_pay_subvention.sql` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | nom/version seulement ; fichier local vide et contenu live nul |
| `20260225213235` | `budget_votes_transfers_asc_aep` | `20260225213235_budget_votes_transfers_asc_aep.sql` | `89dc54147f0b55f379cdc3411748ec4e3de9dcf7ca2bdb03b26128fd98eba7fd` | nom/version seulement ; contenu live nul, hash non comparable |

Cette correspondance nominale hors Offer n'établit pas l'intégrité globale de l'historique distant.

### 6.1 Définition attendue par table

| Table dépôt | Colonnes | Contraintes logiques | Index explicites | RLS / policies | Statut attendu |
|---|---:|---|---|---|---|
| `offer_dispositif` | 10 | 6 : PK, FK organisation, 2 CHECK, 2 UNIQUE | `offer_dispositif_org_state_idx`, `offer_dispositif_org_category_idx` | RLS ; SELECT tenant `authenticated` | table métier |
| `offer_offer` | 8 | 8 : PK, 3 FK dont FK tenant composite, 2 CHECK, 2 UNIQUE | `offer_offer_org_state_transition_idx`, `offer_offer_org_dispositif_idx` | RLS ; SELECT tenant `authenticated` | identité Offer |
| `offer_offer_version` | 14 | 10 : PK, 2 FK, 5 CHECK, 2 UNIQUE | 2 uniques partiels « one open/one published », 1 index organisation/Offer/version | RLS ; SELECT tenant `authenticated` | version/configuration immuable cible |
| `offer_operation` | 15 | 10 : PK, 3 FK, 6 CHECK | 2 index organisation/fenêtre/état | RLS ; SELECT tenant `authenticated` | fenêtre d'opération |
| `offer_idempotency` | 9 | 3 : PK composite, FK organisation, CHECK statut | 1 index statut/date | RLS ; aucune policy client | table interne |
| `offer_audit_entry` | 18 | 8 : PK, FK organisation, 6 CHECK | 3 index audit | RLS ; aucune policy client | audit append-only |
| `offer_outbox` | 20 | 8 : PK, FK organisation, 6 CHECK | 2 index publication/ordre agrégat | RLS ; aucune policy client | outbox interne |

Total attendu : **7 tables, 94 colonnes, 53 contraintes logiques, 15 index explicites et 13 index portés par PK/UNIQUE, soit 28 index physiques sur une base vierge**.

### 6.2 Autres objets attendus

- fonctions : `offer_reject_audit_mutation()`, `offer_current_organization_id()`, `offer_current_business_role()`, `offer_has_tenant_access(uuid)` ;
- trigger : `offer_audit_append_only` sur `offer_audit_entry`, avant modification ou suppression, appelant `offer_reject_audit_mutation()` ;
- vues `security_invoker=true` : `offer_dispositif_projection`, `offer_offer_projection`, `offer_operation_projection` ;
- privilèges : aucun privilège `anon`; SELECT `authenticated` seulement sur les quatre tables métier ; tous privilèges `service_role` sur les sept tables ; vues lisibles seulement par `service_role`.

## 7. Inventaire du schéma live

La recherche par nom, par nom de colonne, par définition de vue et par définition de fonction ne trouve aucun objet Offer. Le schéma `public` contient 46 tables et 9 vues, exactement comme la photographie documentaire citée pour le 19 juillet, mais aucune relation `offer_*`.

### Tableau A — Objets live

| Objet | Type | Schéma | État | RLS | Source de vérité potentielle | Preuve |
|---|---|---|---|---|---|---|
| ensemble `offer_*` | tables/vues/fonctions/triggers | `public` attendu | **0 objet live** | non applicable | aucune source Offer persistée | P-L02, P-L03 |
| `qf_active` | table legacy | `public` | présente | désactivée, non forcée | éligibilité/QF courante, non Offer | P-L05 |
| `qf_config` | table legacy | `public` | présente | désactivée, non forcée | configuration QF versionnée, non Offer | P-L05 |
| `rights_config` | table legacy | `public` | présente | désactivée, non forcée | règles Rights indépendantes d'Offer | P-L05 |
| `user_rights_projection` | table legacy | `public` | présente | activée, non forcée | projection de droits consommée par EBS/client | P-L05 |
| `compute_qf(uuid)` | fonction/RPC legacy | `public` | présente | non applicable | orchestrateur QF, non Offer | P-L06 |

Les quatre tables legacy sont `LEGACY_NON_RAPPROCHÉ`. Leur présence ne compense pas l'absence du modèle canonique Offer.

## 8. Tables et colonnes

### 8.1 Offer

Les sept tables Offer attendues sont absentes. En conséquence, **0 colonne Offer live** est recensée contre 94 colonnes définies dans le dépôt. Les champs `owner`, `nullable`, `default`, `identity` et `generated` ne peuvent pas être observés sur des relations inexistantes ; leur état live est « non applicable par absence prouvée », et non `INCONNU`.

### 8.2 Objets legacy liés

Toutes les colonnes suivantes ont `identity=NO` et `generated=NEVER`.

| Table | Colonnes live et caractéristiques |
|---|---|
| `qf_active` | 14 colonnes : `user_id uuid NN`, `qf_history_id uuid NN`, `qf_config_id uuid NN`, `qf_config_version integer NN`, `qf_value numeric NN`, `parts numeric NN`, `tranche_code text NULL`, `taux_subvention numeric NULL`, `plafond_annuel numeric NULL`, `eligible boolean NN`, `validity_status text NN`, `validity_reasons text[] NN DEFAULT '{}'`, `computed_at timestamptz NN`, `updated_at timestamptz NN DEFAULT now()` |
| `qf_config` | 10 colonnes : `id uuid NN DEFAULT gen_random_uuid()`, `version integer NN`, `is_active boolean NN DEFAULT false`, `type_modele text NN`, `config jsonb NN`, `valid_from date NN DEFAULT CURRENT_DATE`, `valid_to date NULL`, `created_by uuid NULL`, `created_at timestamptz NN DEFAULT now()`, `comment text NULL` |
| `rights_config` | 7 colonnes : `id uuid NN DEFAULT gen_random_uuid()`, `is_active boolean NN DEFAULT false`, `version text NN`, `rules jsonb NN`, `created_at timestamptz NN DEFAULT now()`, `valid_from timestamptz NN DEFAULT now()`, `valid_to timestamptz NULL` |
| `user_rights_projection` | 10 colonnes : `user_id uuid NN`, `qf_value numeric NN`, `tranche integer NN`, `tranche_code text NN`, `taux_prise_en_charge numeric NN`, `droits jsonb NN`, `version_regles text NN`, `date_calcul timestamptz NN DEFAULT now()`, `created_at timestamptz NN DEFAULT now()`, `updated_at timestamptz NN DEFAULT now()` |

`NN` signifie `NOT NULL`.

## 9. Contraintes et indexes

### 9.1 Offer

Résultat live : **0 contrainte et 0 index Offer**, puisque les sept relations sont absentes. Les 53 contraintes et 28 index attendus sont donc tous `LIVE_ABSENT`.

Les contraintes structurantes non vérifiables live incluent notamment :

- tenant et organisation sur toutes les tables ;
- lien Offer → Dispositif ;
- lien OfferVersion → Offer ;
- lien Operation → Offer et OfferVersion ;
- unicité du code par organisation ;
- unicité du numéro de version ;
- unicités partielles « une version ouverte » et « une version publiée » ;
- cohérence des fenêtres d'ouverture ;
- domaines d'états, versions positives et types JSON.

L'absence de ces relations signifie qu'aucune clé étrangère ou contrainte d'invariant Offer ne protège DEV. Il s'agit d'une divergence critique, pas d'une simple optimisation manquante.

### 9.2 Legacy

| Table | Contraintes | Index |
|---|---|---|
| `qf_active` | PK `user_id`; FK vers `qf_config`, `qf_history`, `profiles`; CHECK `validity_status` | PK uniquement |
| `qf_config` | PK `id`; FK `created_by` → `profiles` | PK uniquement |
| `rights_config` | PK `id`; aucune FK | PK ; unique partiel `ux_rights_config_one_active` |
| `user_rights_projection` | PK `user_id`; aucune FK live | PK uniquement |

`rights_config` et `user_rights_projection` n'ont aucun lineage Offer/OfferVersion, ce qui concorde avec leur classification legacy mais ne satisfait pas le contrat cible.

## 10. RLS et policies

### Tableau C — RLS

| Table | RLS active | Policy | Roles | Commande | Expression | Risque |
|---|---|---|---|---|---|---|
| `offer_dispositif` | objet absent | policy dépôt absente live | `authenticated` attendu | SELECT | `offer_has_tenant_access(organization_id)` attendue | critique : contrôle non déployé |
| `offer_offer` | objet absent | policy dépôt absente live | `authenticated` attendu | SELECT | même expression attendue | critique |
| `offer_offer_version` | objet absent | policy dépôt absente live | `authenticated` attendu | SELECT | même expression attendue | critique |
| `offer_operation` | objet absent | policy dépôt absente live | `authenticated` attendu | SELECT | même expression attendue | critique |
| `offer_idempotency` | objet absent | aucune policy attendue | aucune exposition client attendue | — | — | critique par absence de table interne |
| `offer_audit_entry` | objet absent | aucune policy attendue | aucune exposition client attendue | — | — | critique par absence d'audit |
| `offer_outbox` | objet absent | aucune policy attendue | aucune exposition client attendue | — | — | critique par absence d'outbox |
| `qf_active` | **non** | aucune | `public` implicite | toutes via grants | aucune | **critique : écritures `anon` non filtrées** |
| `qf_config` | **non** | aucune | `public` implicite | toutes via grants | aucune | **critique : configuration modifiable par `anon`** |
| `rights_config` | **non** | aucune | `public` implicite | toutes via grants | aucune | **critique : règles Rights modifiables par `anon`** |
| `user_rights_projection` | oui, non forcée | `read_own_rights` permissive | `{public}` | SELECT | `user_id = auth.uid()` | lecture filtrée ; grants d'écriture inutiles mais bloqués en pratique par absence de policy d'écriture pour les rôles soumis à RLS |

Policies Offer recensées live : **0** contre 4 attendues.

## 11. Privilèges

### 11.1 Offer

`information_schema.table_privileges` et `routine_privileges` ne retournent aucune ligne pour les objets Offer attendus et `anon`, `authenticated`, `service_role`, car ces objets n'existent pas. Cela ne prouve pas une révocation conforme : il n'existe aucun objet sur lequel le contrat de privilèges pourrait être appliqué.

### 11.2 Legacy

Le grantor live est `postgres` et `is_grantable=NO` dans tous les cas observés.

| Objet | `anon` | `authenticated` | `service_role` | Conclusion |
|---|---|---|---|---|
| `qf_active` | DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE | mêmes 7 privilèges | mêmes 7 privilèges | critique avec RLS désactivée |
| `qf_config` | mêmes 7 privilèges | mêmes 7 privilèges | mêmes 7 privilèges | critique avec RLS désactivée |
| `rights_config` | mêmes 7 privilèges | mêmes 7 privilèges | mêmes 7 privilèges | critique avec RLS désactivée |
| `user_rights_projection` | mêmes 7 privilèges | mêmes 7 privilèges | mêmes 7 privilèges | grants excessifs ; RLS limite actuellement les rôles non bypass |

La présence d'INSERT, UPDATE, DELETE et TRUNCATE pour `anon` répond directement au critère de risque critique de la mission.

## 12. Fonctions et RPC

### Tableau D — Fonctions

| Fonction | Signature | Security | Roles autorisés | Effet métier potentiel | Risque |
|---|---|---|---|---|---|
| `offer_reject_audit_mutation` | `()` → trigger | DEFINER attendu | aucun PUBLIC ; usage trigger | bloque modification/suppression audit | `LIVE_ABSENT`, critique |
| `offer_current_organization_id` | `()` → uuid | INVOKER attendu | authenticated, service_role | lit le JWT tenant | `LIVE_ABSENT` |
| `offer_current_business_role` | `()` → text | INVOKER attendu | authenticated, service_role | lit le rôle métier du JWT | `LIVE_ABSENT` |
| `offer_has_tenant_access` | `(uuid)` → boolean | INVOKER attendu | authenticated, service_role | décision tenant/RBAC RLS | `LIVE_ABSENT`, critique |
| `compute_qf` | `(p_user_id uuid)` → uuid | **DEFINER live**, owner `postgres`, volatile, PL/pgSQL | **anon, authenticated, service_role** | définition actuelle : lit `qf_config`, puis lève une exception ; aucune écriture dans le corps observé | **critique : RPC DEFINER exécutable par anon** |

Fonctions/RPC Offer recensées live : **0** contre 4 attendues. `compute_qf` n'a pas été exécutée ; seule sa définition de catalogue a été lue.

## 13. Triggers

Le dépôt définit un seul trigger Offer :

| Table | Trigger | Moment | Événement | Fonction | État live |
|---|---|---|---|---|---|
| `offer_audit_entry` | `offer_audit_append_only` | BEFORE | UPDATE OR DELETE, FOR EACH ROW | `offer_reject_audit_mutation()` | `LIVE_ABSENT` |

Triggers Offer recensés live : **0**. Aucun trigger n'est présent sur les quatre tables legacy ciblées.

## 14. Vues

| Vue dépôt | Définition / dépendances | Security barrier | Security invoker | État live |
|---|---|---|---|---|
| `offer_dispositif_projection` | projection de `offer_dispositif` | non spécifiée | `true` | `LIVE_ABSENT` |
| `offer_offer_projection` | `offer_offer` joint à `offer_offer_version`; versions draft/validated/published | non spécifiée | `true` | `LIVE_ABSENT` |
| `offer_operation_projection` | projection de `offer_operation` | non spécifiée | `true` | `LIVE_ABSENT` |

Vues Offer recensées live : **0**. Aucune dépendance live ne peut être matérialisée.

## 15. Rapprochement dépôt / live

### Tableau B — Rapprochement

| Objet | Migration | Live | Classification | Écart | Risque |
|---|---|---|---|---|---|
| historique `20260717000000` | présent dépôt | aucune ligne visible | `LIVE_ABSENT` | version/name/hash distant absents | critique |
| `offer_dispositif` | table + 6 contraintes + RLS/policy | absent | `LIVE_ABSENT` | définition entière | critique |
| `offer_offer` | table + 8 contraintes + RLS/policy | absent | `LIVE_ABSENT` | définition entière | critique |
| `offer_offer_version` | table + 10 contraintes + RLS/policy | absent | `LIVE_ABSENT` | définition entière | critique |
| `offer_operation` | table + 10 contraintes + RLS/policy | absent | `LIVE_ABSENT` | définition entière | critique |
| `offer_idempotency` | table + 3 contraintes + RLS | absent | `LIVE_ABSENT` | idempotence persistée absente | critique |
| `offer_audit_entry` | table + 8 contraintes + RLS | absent | `LIVE_ABSENT` | audit persistant absent | critique |
| `offer_outbox` | table + 8 contraintes + RLS | absent | `LIVE_ABSENT` | événement transactionnel absent | critique |
| `offer_dispositif_org_state_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_dispositif_org_category_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_offer_org_state_transition_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_offer_org_dispositif_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_offer_version_one_open_uidx` | unique partiel | absent | `LIVE_ABSENT` | invariant version ouverte absent | critique |
| `offer_offer_version_one_published_uidx` | unique partiel | absent | `LIVE_ABSENT` | invariant version publiée absent | critique |
| `offer_offer_version_org_offer_number_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_operation_org_offer_window_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_operation_org_state_window_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_idempotency_org_status_created_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_audit_org_aggregate_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_audit_org_occurred_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_audit_correlation_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_outbox_pending_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_outbox_aggregate_order_idx` | défini | absent | `LIVE_ABSENT` | index absent | élevé |
| `offer_reject_audit_mutation()` | définie | absente | `LIVE_ABSENT` | protection append-only absente | critique |
| `offer_current_organization_id()` | définie | absente | `LIVE_ABSENT` | helper tenant absent | critique |
| `offer_current_business_role()` | définie | absente | `LIVE_ABSENT` | helper RBAC absent | critique |
| `offer_has_tenant_access(uuid)` | définie | absente | `LIVE_ABSENT` | décision RLS absente | critique |
| `offer_audit_append_only` | défini | absent | `LIVE_ABSENT` | trigger absent | critique |
| policy `offer_dispositif_tenant_select` | définie | absente | `LIVE_ABSENT` | policy absente | critique |
| policy `offer_offer_tenant_select` | définie | absente | `LIVE_ABSENT` | policy absente | critique |
| policy `offer_offer_version_tenant_select` | définie | absente | `LIVE_ABSENT` | policy absente | critique |
| policy `offer_operation_tenant_select` | définie | absente | `LIVE_ABSENT` | policy absente | critique |
| `offer_dispositif_projection` | définie | absente | `LIVE_ABSENT` | vue absente | élevé |
| `offer_offer_projection` | définie | absente | `LIVE_ABSENT` | vue absente | élevé |
| `offer_operation_projection` | définie | absente | `LIVE_ABSENT` | vue absente | élevé |
| `qf_active` | aucune migration SQL trouvée | présente | `MIGRATION_ABSENTE` | objet live non reproductible depuis le dépôt | critique |
| `qf_config` | aucune migration SQL trouvée | présente | `MIGRATION_ABSENTE` | objet live non reproductible depuis le dépôt | critique |
| `rights_config` | aucune migration SQL trouvée | présente | `MIGRATION_ABSENTE` | objet live non reproductible depuis le dépôt | critique |
| `user_rights_projection` | aucune migration SQL trouvée | présente | `MIGRATION_ABSENTE` | objet live non reproductible depuis le dépôt | critique |
| `compute_qf(uuid)` | aucune définition SQL maintenue trouvée | présente | `MIGRATION_ABSENTE` | RPC live non reproductible | critique |

Chaque objet de cette matrice reçoit une seule classification. Aucun objet n'est `CONFORME`, `DIVERGENT`, `PARTIEL`, `INCONNU` ou `LEGACY_NON_RAPPROCHÉ` dans cette matrice stricte : les objets legacy sont classés `MIGRATION_ABSENTE`, avec leur nature legacy conservée dans le tableau A.

## 16. Divergences

| Id | Classification de preuve | Divergence | Preuve | Conséquence |
|---|---|---|---|---|
| D01 | `DIVERGENCE_PROUVÉE` | migration Offer locale absente de l'historique live visible | P-D01 / P-L04 | version distante et hash non alignés |
| D02 | `DIVERGENCE_PROUVÉE` | 7 tables et tous les objets dépendants absents du live | P-D01 / P-L03 | aucun runtime de données Offer conforme au dépôt |
| D03 | `DIVERGENCE_PROUVÉE` | 4 tables QF/Rights live sans définition de migration SQL maintenue | recherche dépôt + P-L05 | DEV non reproductible depuis l'historique local |
| D04 | `DIVERGENCE_PROUVÉE` | RPC `compute_qf` live sans définition SQL maintenue et avec ACL dangereuse | P-L06 | drift fonctionnel et de sécurité |

La causalité historique reste `INCONNU` : l'état observé ne permet pas d'affirmer si la migration Offer n'a jamais été appliquée, si l'historique a été altéré, si les objets ont été supprimés, ou si plusieurs événements se sont succédé.

## 17. Risques de sécurité

| Risque | Gravité | Preuve | Décision |
|---|---:|---|---|
| RLS désactivée sur `qf_active`, table d'éligibilité/QF exposée dans `public` | **critique** | P-L05 | bloque G1 |
| RLS désactivée sur `qf_config`, configuration versionnée | **critique** | P-L05 | bloque G1 |
| RLS désactivée sur `rights_config`, règle déterminant les droits | **critique** | P-L05 | bloque G1 |
| INSERT/UPDATE/DELETE/TRUNCATE accordés à `anon` sur ces trois tables | **critique** | privilèges section 11 | bloque G1 immédiatement |
| `compute_qf(uuid)` `SECURITY DEFINER`, owner `postgres`, exécutable par `anon` | **critique** | P-L06 | bloque G1 selon le critère explicite de mission |
| Toutes les tables, FK, CHECK, UNIQUE, RLS et audit Offer absents | **critique** | P-L03 | aucun invariant Offer live |
| `rights_config` et `user_rights_projection` sans FK/lineage OfferVersion | **critique** au regard de l'architecture cible | section 9 | source Rights parallèle non rapprochée |
| Grants d'écriture complets sur `user_rights_projection` malgré une policy SELECT seule | élevé | P-L05 | surface inutile ; RLS limite actuellement les rôles non bypass |

Aucune policy Offer permissive d'écriture, aucun trigger Offer à effet métier et aucune double table Offer source de vérité ne sont observés, car aucun objet Offer n'existe. Cette absence ne réduit pas la gravité de la divergence.

## 18. Conclusion K11

`K11_LIVE_EVIDENCE` : au 23 juillet 2026 à 15:55:05 UTC, aucun des sept objets table `offer_*`, aucune colonne, contrainte, index, policy, fonction, trigger ou vue Offer attendus n'existe dans DEV. La version `20260717000000` est absente des trois seules lignes visibles de l'historique live.

`K11_MIGRATION_EVIDENCE` : la migration versionnée et suivie par Git existe à `supabase/migrations/20260717000000_create_offer_infrastructure.sql`, SHA-256 `ba39dad5bf03d03cc91833b2b1df6497648e16ee6eff3e04daa6b5e4e3db0f4d`, avec une définition complète de 229 lignes.

`K11_CONCLUSION` : `K11_CONFIRMED`.

L'inconnue sur l'état live est levée et transformée en divergence précisément documentée. K11 ne peut pas être déclarée `K11_RESOLVED`, car dépôt et live ne concordent pas. Sa causalité passée reste inconnue, sans empêcher la preuve de l'écart actuel.

### Tableau E — K11

| Question | Preuve dépôt | Preuve live | Conclusion | Décision Gate |
|---|---|---|---|---|
| La migration Offer existe-t-elle dans le dépôt ? | oui, fichier suivi, hash P-D01 | aucune ligne correspondante dans l'historique visible | divergence confirmée | `NO_GO` |
| Les tables et objets Offer existent-ils en DEV ? | 7 tables et objets dépendants définis | zéro objet attendu | `K11_CONFIRMED` | `NO_GO` |
| Le hash dépôt/live concorde-t-il ? | SHA-256 local prouvé | contenu/statements live absent, hash non calculable | non concordant par absence de version | `NO_GO` |
| K11 peut-elle être fermée comme conformité ? | non | non | non ; transformée en divergence prouvée | `NO_GO` |

## 19. État de Gate G1

| Critère G1 | État | Décision |
|---|---|---|
| schéma live réellement inspecté | satisfait | accès live P-L01 |
| objets Offer inventoriés | satisfait : zéro objet live, absence prouvée | divergence |
| migrations rapprochées | satisfait pour Offer : migration locale présente, historique live absent | divergence |
| contraintes structurantes vérifiées | non satisfait : toutes absentes avec les tables | bloque |
| policies RLS vérifiées | non satisfait : aucune policy Offer live | bloque |
| privilèges vérifiés | satisfait factuellement ; aucun objet Offer, risques legacy critiques | bloque |
| fonctions/RPC/triggers vérifiés | satisfait factuellement ; Offer absent, RPC legacy critique | bloque |
| K11 qualifiée | `K11_CONFIRMED` | divergence prouvée |
| inconnue critique sur l'état actuel Offer | aucune : absence actuelle prouvée | la causalité historique reste inconnue mais n'autorise pas GO |

**Gate G1 : `NO_GO`.**

Le live a été inspecté, mais le schéma attendu n'existe pas et des risques critiques indépendants sont présents sur les objets legacy d'éligibilité et de droits. Les conditions de GO ne sont donc pas réunies.

## 20. Prochain point de reprise

Le prochain point de reprise exact est une décision de l'autorité `PROGRAM_DIRECTOR / CERTIFICATION_BOARD`, dans la gouvernance officielle par `WAVE`, sur :

1. la divergence `LIVE_ABSENT` de la migration Offer et de ses objets ;
2. l'historique de migrations incomplet/non hashable ;
3. les grants `anon`, la RLS désactivée et la RPC `SECURITY DEFINER` legacy ;
4. l'autorisation éventuelle d'une mission corrective distincte.

Après toute correction séparément autorisée, G1 devra être rejouée par un nouvel inventaire live read-only et ne pourra passer à `GO` qu'avec objets, contraintes, index, RLS, policies, privilèges, fonctions, triggers, vues et historique concordants.

## 21. Verdict

```text
MissionId: OFFER-G1-DATA-INVENTORY-001
Verdict: READY_FOR_G1_AUTHORITY_DECISION
Accès live obtenu: OUI — DEV/Supabase lié, lecture catalogues uniquement
Tables Offer recensées: 0 live / 7 attendues et prouvées absentes
Contraintes recensées: 0 live Offer / 53 attendues dépôt
Policies recensées: 0 live Offer / 4 attendues dépôt
Fonctions/RPC recensées: 0 live Offer / 4 attendues dépôt ; 1 RPC legacy critique
Triggers recensés: 0 live Offer / 1 attendu dépôt
Vues recensées: 0 live Offer / 3 attendues dépôt
Divergences recensées: 4 divergences prouvées, dont l'absence complète du modèle Offer
Statut K11: K11_CONFIRMED
Gate G1: NO_GO
Fichier créé: Docs/PROGRAM/OFFER/OFFER_G1_DATA_INVENTORY_REPORT_001.md
Point de reprise exact: décision d'autorité WAVE sur la divergence Offer, l'historique live et les risques legacy, puis nouvelle preuve G1 read-only après toute correction séparément autorisée
```
