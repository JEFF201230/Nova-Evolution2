# CEREBRAU — Roadmap finale d’exécution Offer G1

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-G1-EXECUTION-ORCHESTRATION-001
MISSION_TYPE        : EXECUTION_PLANNING
EXECUTION_MODE      : READ_ONLY
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
CURRENT_GATE_STATUS : NO_GO
FOUNDATION_READY    : TRUE
```

La roadmap assemble les lots, la séquence et le parallélisme en un ordre
immédiatement lançable dès qu’une WAVE corrective autorise formellement
l’exécution. Elle ne réalise ni n’autorise elle-même aucune correction.

## 2. Décision d’orchestration

Le plan officiel retient :

- six lots pour vingt-quatre micro-missions ;
- un premier lot obligatoire de périmètre et de sûreté ;
- deux lots contenant du parallélisme interne ;
- deux fenêtres de mutation DEV strictement exclusives ;
- un lot final read-only conditionné par PA-01 à PA-09 `PASS`.

La séquence de référence est :

```text
LOT-01  Périmètre et sûreté
  -> LOT-02  Qualification préalable et captures
  -> LOT-03  Remédiation QF/Rights
  -> LOT-04  Baseline Offer
  -> LOT-05  Qualification post-baseline
  -> LOT-06  Replay et dossier final
  -> demande de nouvelle certification G1
```

LOT-03 est hors de la chaîne critique la plus longue définie par les
dépendances, mais il est exécuté avant LOT-04 pour respecter la priorité
sécurité et le verrou DEV. Il doit dans tous les cas être `PASS` avant LOT-06.

## 3. Roadmap exécutoire

| Phase | Lot | Résultat opérationnel attendu | Go/No-Go local | Responsable de clôture logique |
|---:|---|---|---|---|
| 1 | `OFFER-G1-LOT-01` | Manifeste gelé, DEV borné, sauvegarde et rollback confirmés | `GO local` seulement si aucun `AF-*` non résolu | Pilotage WAVE + Data/DB + Offer + Sécurité + Exploitation |
| 2 | `OFFER-G1-LOT-02` | PA-07 `PASS`, états avant capturés, runtime–contrat figé | `NO_GO` sur collision, rollback, activation ou identité non attribuable | Data/DB + Offer, responsables des lanes |
| 3 | `OFFER-G1-LOT-03` | PA-06 `PASS`, QF/Rights et RPC conformes | `NO_GO` sur permission interdite, fuite ou rollback indisponible | Sécurité + Data |
| 4 | `OFFER-G1-LOT-04` | PA-01 `PASS`, baseline appliquée et rapport revu | `NO_GO` sur hash, cible, migration, activation ou historique | Data/DB + Exploitation |
| 5 | `OFFER-G1-LOT-05` | PA-02/03/04/05/08 `PASS` sur état et runtime figés | `NO_GO` sur quantité, RLS/ACL, tenant, backend ou consommateurs | Responsables PA concernés |
| 6 | `OFFER-G1-LOT-06` | PA-10 `PASS`, risques fermés, dossier signé recevable | `NO_GO` si une PA, un `C4`, un avis ou une signature manque | Certification + autorités requises |

Un « GO local » autorise uniquement le passage au lot suivant dans la même
WAVE. Il ne change ni le statut G1, ni le statut d’activation, ni l’autorisation
de production.

## 4. Jalons officiels

| Jalon | Condition exacte | Décision permise |
|---|---|---|
| `M0 — READY` | WAVE officielle et fondation prête | Démarrer LOT-01 |
| `M1 — SCOPED` | `D-01` et `D-02` fermées | Démarrer les lanes de LOT-02 |
| `M2 — COMPATIBLE` | PA-07 `PASS`, états avant disponibles, runtime figé | Réserver les fenêtres DEV |
| `M3 — QF_SECURED` | PA-06 `PASS` | Libérer le verrou DEV pour la baseline |
| `M4 — BASELINE_MATERIALIZED` | PA-01 `PASS` | Démarrer les contrôles post-baseline |
| `M5 — OFFER_SECURED` | PA-03, PA-04 et PA-09 `PASS` | Exécuter PA-05 |
| `M6 — EVIDENCE_COMPLETE` | PA-01 à PA-09 toutes `PASS` | Démarrer LOT-06 |
| `M7 — G1_REVIEWABLE` | PA-10 `PASS`, risques/avis/signatures complets | Demander une nouvelle certification G1 |

## 5. Chemin critique et branches de jonction

```mermaid
flowchart TD
    L1[LOT-01] --> P7[LOT-02 / PA-07]
    P7 --> L4[LOT-04 / PA-01]
    L4 --> P3[LOT-05 / PA-03]
    P3 --> P4[LOT-05 / PA-04]
    P4 --> P5[LOT-05 / PA-05]
    P5 --> L6[LOT-06]

    L1 --> Q0[LOT-02 / état QF]
    Q0 --> L3[LOT-03 / PA-06]
    L3 --> L6

    L1 --> C0[LOT-02 / état consommateurs]
    C0 --> L4
    L4 --> C1[LOT-05 / PA-08]
    C1 --> L6

    L1 --> R[LOT-02 / PA-09]
    R --> P5

    L4 --> H[LOT-05 / PA-02]
    H --> L6
```

Les jonctions impératives sont :

- état consommateurs avant, avant l’application baseline ;
- PA-09 `PASS`, avant la préparation des tests backend ;
- PA-06, PA-02 et PA-08 `PASS`, avant le replay final ;
- toutes les PA `PASS`, avant l’assemblage du dossier.

## 6. Paquet de lancement de chaque lot

Avant de lancer un lot, son responsable vérifie :

1. identifiant de WAVE et portée DEV ;
2. verdict `PASS` de toutes les dépendances d’entrée ;
3. chemins exacts, version/hash/commit et modes d’accès du manifeste ;
4. responsable, acteur, fenêtre et destinations de preuve ;
5. verrou de ressource requis et absence d’exécution concurrente incompatible ;
6. sauvegarde et rollback applicables lorsqu’une mutation est prévue ;
7. critères `PASS`, non-régression et arrêt repris sans modification ;
8. revue de sortie nommée.

Le lancement est refusé si un de ces éléments manque. Aucun fichier ou
micro-mission ne peut être ajouté implicitement au paquet.

## 7. Tableau de pilotage minimal

| Lot | Entrée | Travail dominant | Sortie | État initial |
|---|---|---|---|---|
| LOT-01 | WAVE officielle | Résolution et sûreté | Manifeste/rollback | `PLANNED` |
| LOT-02 | LOT-01 `PASS` | Dry-run et captures | PA-07 + références | `BLOCKED_BY_LOT-01` |
| LOT-03 | LOT-02 `PASS` | Mutation QF/Rights | PA-06 `PASS` | `BLOCKED_BY_LOT-02` |
| LOT-04 | PA-07 `PASS`, capture PA-08 avant, verrou DEV libre | Mutation baseline | PA-01 `PASS` | `BLOCKED_BY_LOT-02/LOCK` |
| LOT-05 | LOT-04 `PASS` | Inventaires et tests | PA-02/03/04/05/08 `PASS` | `BLOCKED_BY_LOT-04` |
| LOT-06 | PA-01 à PA-09 `PASS` | Replay et certification | Dossier recevable | `BLOCKED_BY_SYNC-4` |

Les états ci-dessus sont des états de planification. Le statut G1 officiel
reste `NO_GO`.

## 8. Critères de demande d’une nouvelle certification G1

La demande ne peut être formulée qu’après LOT-06 `PASS` et présence simultanée
de tous les éléments suivants :

- rapport d’application DEV de la baseline ;
- historique live rapproché sans réécriture ;
- inventaire exact `7/94/53/28/4/1/4/3` ;
- sécurité Offer et QF/Rights conforme ;
- six tests backend négatifs conformes sur runtime identifié ;
- absence d’effet ou d’activation EBS/Rights/LifeHub/finance ;
- PA-01 à PA-10 explicitement `PASS` ;
- `R-G1-01` à `R-G1-10` fermés ;
- avis Sécurité et Exploitation/Data ;
- signatures du Program Director, du Certification Board et des autorités
  requises ;
- historique `NO_GO` conservé et décision future séparée.

Cette complétude rend le dossier recevable. Elle ne préjuge pas de la décision
G1 complémentaire.

## 9. Contrôle de couverture et limites

Le registre canonique d’affectation de
`OFFER_G1_EXECUTION_LOTS_001.md` contient exactement les 24 micro-missions du
backlog, chacune affectée à un seul lot. Les documents de séquence et de
parallélisme n’ajoutent aucune micro-mission.

Restent hors portée :

- modification de code, Supabase, migrations ou Gates ;
- modification des décisions MD, preuves PA ou backlog ;
- activation, production ou décision G1 ;
- création de Work Package officiel ;
- création d’une micro-mission supplémentaire.
