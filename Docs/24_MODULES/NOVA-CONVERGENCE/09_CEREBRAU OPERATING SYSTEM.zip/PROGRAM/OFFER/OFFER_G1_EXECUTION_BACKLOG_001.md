# CEREBRAU — Backlog d’exécution Offer G1

## 1. Identité et statut

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-G1-REMEDIATION-001
DELIVERABLE         : OFFER_G1_EXECUTION_BACKLOG_001
EXECUTION_MODE      : READ_ONLY
BACKLOG_STATUS      : PLANNED_NOT_EXECUTED
OFFICIAL_OBJECT     : WAVE
CURRENT_GATE_STATUS : NO_GO
```

Ce backlog décompose la remédiation future en micro-missions atomiques. Il
n’ordonne et n’exécute aucune mutation. Les références `AF-*` sont définies
dans `OFFER_G1_REMEDIATION_PLAN_001.md`. Le chemin exact de chaque artefact doit
être résolu par `G1-PRE-01` à partir du périmètre de la WAVE avant exécution.

## 2. Règle de clôture d’une micro-mission

Une micro-mission est clôturable seulement si :

1. ses prérequis sont tous `PASS` ;
2. ses entrées, environnement, acteur, date et résultat sont journalisés ;
3. ses critères de réussite sont tous satisfaits ;
4. ses contrôles de non-régression sont tous satisfaits ;
5. aucun critère d’arrêt du plan de remédiation n’est rencontré ;
6. sa sortie est revue par le responsable logique indiqué.

Un succès partiel ne débloque pas la micro-mission suivante. Toute mutation ou
tout fichier non prévu dans le manifeste résolu impose l’arrêt et une décision
de périmètre ; il ne peut pas être ajouté implicitement.

## 3. Backlog priorisé

### 3.1 Préparation et verrouillage du périmètre

| ID | PA | Priorité | Responsable logique | Objectif | Fichiers concernés | Prérequis | Critères de réussite | Critères de non-régression |
|---|---|---|---|---|---|---|---|---|
| `G1-PRE-01` | Transverse | `P0` | Pilotage WAVE + Data/DB + Offer + Sécurité + Exploitation | Résoudre le chemin exact, le commit/version et le rôle de chaque `AF-*`; produire le manifeste d’exécution borné | `AF-BASELINE`, `AF-QF-RIGHTS`, `AF-OFFER-SECURITY`, `AF-BACKEND`, `AF-RUNTIME-CONFIG`, `AF-CONSUMERS`, destinations `AF-EVIDENCE` | WAVE officielle et décisions formalisées | Chaque artefact possède un chemin exact, un propriétaire logique, un mode lecture/écriture autorisé, une version/hash lorsque requis et une PA consommatrice | Aucun fichier hors périmètre ; aucun secret copié ; aucune modification de source, migration, Supabase, décision, preuve ou Gate |
| `G1-PRE-02` | Transverse | `P0` | Data/DB + Exploitation | Établir les contrôles de départ DEV, les critères d’arrêt, les sauvegardes requises et la procédure de rollback | Références résolues de `AF-BASELINE`, `AF-QF-RIGHTS`, `AF-OFFER-SECURITY`; configuration DEV référencée par `AF-RUNTIME-CONFIG` | `G1-PRE-01` | Environnement DEV identifié ; contrôles préalables, sauvegarde, rollback, acteurs et fenêtre confirmés avant mutation | Production explicitement exclue ; aucun autre environnement ou consommateur activé ; état initial préservé et traçable |

### 3.2 Compatibilité de migration — PA-07

| ID | PA | Priorité | Responsable logique | Objectif | Fichiers concernés | Prérequis | Critères de réussite | Critères de non-régression |
|---|---|---|---|---|---|---|---|---|
| `G1-PA07-01` | PA-07 | `P0-A` | Data/DB + Offer | Qualifier un environnement isolé comme représentatif de DEV et capturer le plan avant | `AF-BASELINE`, schéma/configuration isolés référencés dans `AF-EVIDENCE` | `G1-PRE-01`, `G1-PRE-02` | Parité pertinente documentée ; inventaire avant, contraintes et FK capturés ; environnement séparé de DEV et production | Aucune mutation DEV/production ; aucune donnée ou secret de production introduit |
| `G1-PA07-02` | PA-07 | `P0-A` | Data/DB + Offer | Exécuter le dry-run de la baseline et des étapes additives autorisées dans l’ordre prévu | `AF-BASELINE`, `AF-OFFER-SECURITY` et `AF-QF-RIGHTS` seulement si inclus dans l’ordre autorisé | `G1-PA07-01` | Exécution sans collision ; plan après complet ; contraintes/FK valides ; écarts avant/après expliqués | Aucun objet hors manifeste ; aucun changement d’état `ACTIVE`; aucune réécriture d’historique |
| `G1-PA07-03` | PA-07 | `P0-A` | Data/DB + Offer + Integration | Exécuter et vérifier le rollback isolé, puis conclure sur l’absence d’activation implicite | Mêmes fichiers que `G1-PA07-02`, états de consommateurs référencés par `AF-CONSUMERS` | `G1-PA07-02` | Rollback réussi ; état restauré ; aucune activation/disponibilité induite ; dossier PA-07 complet | Aucune perte de données ou dérive de schéma ; consommateurs EBS/Rights/LifeHub/finance inchangés |

### 3.3 Sécurité QF/Rights — PA-06

| ID | PA | Priorité | Responsable logique | Objectif | Fichiers concernés | Prérequis | Critères de réussite | Critères de non-régression |
|---|---|---|---|---|---|---|---|---|
| `G1-PA06-01` | PA-06 | `P0-B` | Sécurité + Data | Capturer l’état live avant remédiation des quatre tables et de `compute_qf(uuid)` | `AF-QF-RIGHTS`, inventaire `AF-EVIDENCE` | `G1-PRE-01`, `G1-PRE-02` | RLS, policies, ACL/grants, owner, exécution RPC et scénarios négatifs de départ documentés | Lecture seule ; aucune exposition supplémentaire ; état de départ reproductible |
| `G1-PA06-02` | PA-06 | `P0-B` | Sécurité + Data | Appliquer exclusivement la remédiation QF/Rights autorisée | `AF-QF-RIGHTS` résolu | `G1-PA06-01`, PA-07 compatible pour tout artefact de migration partagé | RLS effective ; mutations `anon` retirées ; `compute_qf(uuid)` restreinte ; exécution journalisée ; rollback disponible | Pas de perte de droits légitimes documentés ; pas de mutation hors cinq objets ; aucune modification Offer ou production non autorisée |
| `G1-PA06-03` | PA-06 | `P0-B` | Sécurité + Data | Vérifier la sécurité et la non-régression QF/Rights après remédiation | `AF-QF-RIGHTS`, résultats `AF-EVIDENCE` | `G1-PA06-02` | État live conforme ; tests cross-user/cross-tenant et `anon` négatifs ; RPC non accessible au rôle interdit ; rollback applicable | Fonctionnement des accès autorisés conservé ; aucune nouvelle permission excessive ; quatre tables et RPC attribuables à la version exécutée |

### 3.4 Baseline Offer — PA-01

| ID | PA | Priorité | Responsable logique | Objectif | Fichiers concernés | Prérequis | Critères de réussite | Critères de non-régression |
|---|---|---|---|---|---|---|---|---|
| `G1-PA01-01` | PA-01 | `P0-C` | Data/DB + Exploitation | Faire le contrôle final version/hash, sauvegarde, fenêtre, acteur et rollback avant application DEV | `AF-BASELINE`, configuration DEV `AF-RUNTIME-CONFIG` | `G1-PA07-03`, `G1-PRE-02` | Version `20260717000000` et hash égaux au manifeste ; sauvegarde restaurable ; acteur et fenêtre enregistrés | Aucun fichier modifié ; aucune cible autre que DEV ; arrêt sur toute divergence |
| `G1-PA01-02` | PA-01 | `P0-C` | Data/DB | Appliquer la baseline autorisée sur DEV et capturer le résultat brut | `AF-BASELINE` en lecture/application ; journal `AF-EVIDENCE` | `G1-PA01-01` | Application réussie et horodatée ; acteur, version, hash et résultat capturés ; aucun critère d’arrêt rencontré | Aucun passage implicite à `ACTIVE` ; aucune production ; aucun historique réécrit ; rollback toujours disponible |
| `G1-PA01-03` | PA-01 | `P0-C` | Data/DB + Exploitation | Consolider et faire revoir le rapport d’exécution PA-01 | Sorties de `G1-PA01-01/02` dans `AF-EVIDENCE` | `G1-PA01-02` | Rapport complet avec version, hash, acteur, horodatage, résultat, sauvegarde, rollback et revue humaine | Le rapport reflète les journaux sans masquer d’écart ; aucune nouvelle mutation pendant la consolidation |

### 3.5 Contrôles post-baseline parallélisables

| ID | PA | Priorité | Responsable logique | Objectif | Fichiers concernés | Prérequis | Critères de réussite | Critères de non-régression |
|---|---|---|---|---|---|---|---|---|
| `G1-PA02-01` | PA-02 | `P1-A` | Data/DB | Rapprocher l’historique live avec la baseline appliquée | `AF-BASELINE`, historique live en lecture, `AF-EVIDENCE` | `G1-PA01-03` | Ligne `20260717000000` présente ; statements/hash comparables ; absence de collision ; rapprochement repository/runtime signé | Aucune insertion ou édition manuelle du ledger ; statuts historiques non maquillés |
| `G1-PA03-01` | PA-03 | `P1-B` | Data/DB + Offer | Inventorier tous les objets Offer live après application | `AF-BASELINE`, `AF-OFFER-SECURITY`, inventaire `AF-EVIDENCE` | `G1-PA01-03` | 7 tables, 94 colonnes, 53 contraintes, 28 index, 4 fonctions, 1 trigger, 4 policies, 3 vues constatés | Lecture seule ; aucun objet additionnel non expliqué ; contraintes/FK restent valides |
| `G1-PA04-01` | PA-04 | `P0-D` | Sécurité + Data | Auditer l’état RLS/policies/ACL/grants de chaque objet Offer | `AF-OFFER-SECURITY`, `AF-BASELINE`, résultats `AF-EVIDENCE` | `G1-PA03-01` | `relrowsecurity`, policies et grants complets par rôle ; aucun privilège `anon` interdit | Audit en lecture seule ; accès autorisés documentés conservés ; aucun secret exposé |
| `G1-PA04-02` | PA-04 | `P0-D` | Sécurité + Data | Tester l’isolation tenant et l’accès direct PostgREST, y compris le non-bypass `service_role` | Références de test à `AF-OFFER-SECURITY` et configuration expurgée `AF-RUNTIME-CONFIG` | `G1-PA04-01` | Tests tenant, cross-user, cross-tenant, `anon`, PostgREST direct et bypass tous conformes | Les scénarios autorisés continuent de fonctionner ; aucune donnée d’un autre tenant n’est lisible ou mutable |
| `G1-PA08-01` | PA-08 | `P1-C` | Offer + Integration | Capturer avant application l’état d’activation et de disponibilité vu par EBS, Rights, LifeHub et finance | `AF-CONSUMERS`, `AF-RUNTIME-CONFIG`, état `AF-EVIDENCE` | `G1-PRE-01`; exécution avant `G1-PA01-02` | État de référence des quatre familles daté ; source `ACTIVE_OFFER_VERSION` et absence d’activation documentées | Lecture seule ; aucun consommateur, flag ou statut modifié |
| `G1-PA08-02` | PA-08 | `P1-C` | Offer + Integration | Comparer l’état post-baseline et démontrer l’absence d’effet inter-domaines | `AF-CONSUMERS`, `AF-RUNTIME-CONFIG`, comparatif `AF-EVIDENCE` | `G1-PA01-03`, `G1-PA08-01` | Aucun consommateur n’interprète la baseline comme activation/disponibilité ; aucune transition `ACTIVE`; revue humaine hors scope | Comportements préexistants inchangés ; aucune activation E2E, finance ou production |
| `G1-PA09-01` | PA-09 | `P1-D` | Exploitation | Identifier de manière immutable le backend Offer réellement déployé | `AF-BACKEND`, `AF-RUNTIME-CONFIG`, relevé `AF-EVIDENCE` | `G1-PRE-01` | Commit/version, environnement, identité runtime et configuration pertinente sans secret capturés | Aucun redéploiement ; aucune configuration modifiée ; aucun secret dans le livrable |
| `G1-PA09-02` | PA-09 | `P1-D` | Exploitation + Offer/API | Rattacher le runtime identifié au contrat qui sera testé | `AF-BACKEND`, `AF-RUNTIME-CONFIG`, contrat/résultat référencé dans `AF-EVIDENCE` | `G1-PA09-01` | Correspondance explicite commit–configuration–contrat ; écart nul ou expliqué et résolu avant test | Aucun changement de runtime pour faire correspondre artificiellement le test ; traçabilité immutable conservée |

### 3.6 Sécurité backend — PA-05

| ID | PA | Priorité | Responsable logique | Objectif | Fichiers concernés | Prérequis | Critères de réussite | Critères de non-régression |
|---|---|---|---|---|---|---|---|---|
| `G1-PA05-01` | PA-05 | `P0-E` | Sécurité/API Offer | Préparer les scénarios négatifs et les rattacher au runtime PA-09 | `AF-BACKEND`, `AF-RUNTIME-CONFIG`, cas de test `AF-EVIDENCE` | `G1-PA04-02`, `G1-PA09-02` | Six scénarios exigés définis avec résultat interdit explicite et identité runtime figée | Aucun changement backend/configuration ; données de test isolées ; aucun secret |
| `G1-PA05-02` | PA-05 | `P0-E` | Sécurité/API Offer | Exécuter les tests token, rôle, organisation, usurpation et `service_role` | Même périmètre que `G1-PA05-01` | `G1-PA05-01` | Token absent, token invalide, rôle insuffisant, autre organisation, identifiant usurpé et bypass `service_role` tous refusés comme attendu | Cas positifs autorisés conservés ; aucune fuite cross-user/cross-tenant ; résultats rattachés au même commit/configuration |

### 3.7 Replay et dossier final — PA-10

| ID | PA | Priorité | Responsable logique | Objectif | Fichiers concernés | Prérequis | Critères de réussite | Critères de non-régression |
|---|---|---|---|---|---|---|---|---|
| `G1-PA10-01` | PA-10 | `P0-FINAL` | Mission de certification | Rejouer en lecture seule l’inventaire et le rapprochement G1 | Tous `AF-*` en lecture ; nouveau dossier `AF-EVIDENCE` | PA-01 à PA-09 `PASS` | Inventaire live daté, rapprochement repository/runtime complet et reprise explicite des neuf verdicts | Aucune mutation ; mêmes versions/hash/commit que les preuves amont ; aucune preuve historique modifiée |
| `G1-PA10-02` | PA-10 | `P0-FINAL` | Certification + Sécurité + Exploitation/Data | Vérifier la fermeture du registre `R-G1-01` à `R-G1-10` et l’absence de décision incompatible | Registre et preuves `AF-EVIDENCE` | `G1-PA10-01` | Chaque risque possède une preuve de fermeture ; aucun `C4` ouvert ; avis Sécurité et Exploitation/Data favorables | Aucun risque supprimé sans preuve ; toute divergence reste visible et bloque la suite |
| `G1-PA10-03` | PA-10 | `P0-FINAL` | Program Director + Certification Board, avec autorités requises | Assembler le dossier signé recevable pour la décision G1 post-remédiation | Dossier `AF-EVIDENCE`; aucune décision existante modifiée | `G1-PA10-02` | Dossier complet, daté, signé, PA-01 à PA-10 explicitement `PASS`, portée DEV et limites indiquées | Historique `NO_GO` conservé ; aucune autorisation de production ou activation déduite ; décision future séparée |

## 4. Affectation PA–micro-missions

| PA | Micro-missions obligatoires | Sortie terminale |
|---|---|---|
| PA-01 | `G1-PA01-01` à `G1-PA01-03` | Rapport d’application DEV complet |
| PA-02 | `G1-PA02-01` | Historique live aligné et rapproché |
| PA-03 | `G1-PA03-01` | Inventaire complet aux quantités exigées |
| PA-04 | `G1-PA04-01`, `G1-PA04-02` | RLS/ACL et tests tenant conformes |
| PA-05 | `G1-PA05-01`, `G1-PA05-02` | Six scénarios négatifs conformes |
| PA-06 | `G1-PA06-01` à `G1-PA06-03` | QF/Rights et RPC remédiés et testés |
| PA-07 | `G1-PA07-01` à `G1-PA07-03` | Compatibilité, rollback et non-activation démontrés |
| PA-08 | `G1-PA08-01`, `G1-PA08-02` | Absence d’effet inter-domaines démontrée |
| PA-09 | `G1-PA09-01`, `G1-PA09-02` | Runtime et contrat testés identifiés |
| PA-10 | `G1-PA10-01` à `G1-PA10-03` | Replay, risques fermés, avis et signatures |

Toutes les PA possèdent une action atomisée, une priorité, un responsable
logique et une sortie terminale vérifiable.

