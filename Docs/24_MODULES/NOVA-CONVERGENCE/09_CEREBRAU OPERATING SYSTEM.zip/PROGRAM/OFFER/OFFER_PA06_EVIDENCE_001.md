# CEREBRAU — CERTIFICATION DE PREUVE PA-06

## 1. Identité

```text
PROGRAM          : VEEDDA
DOMAIN           : OFFER
MISSION_ID       : OFFER-PA-CONSOLIDATION-001
EVIDENCE_ID      : PA-06
OFFICIAL_OBJECT  : WAVE
AUTHORITY        : PROGRAM_DIRECTOR
```

Les Work Packages ne sont pas des objets officiels de gouvernance.

## 2. Périmètre exact

PA-06 porte exclusivement sur la remédiation QF/Rights : état live de
`qf_active`, `qf_config`, `rights_config`, `user_rights_projection` et
`compute_qf`; ACL/RLS conformes et tests négatifs
(`OFFER_G1_NO_GO_REPORT_001.md`, § 9, ligne PA-06).

## 3. Preuves existantes certifiées

| Référence documentaire | Élément établi | Portée pour PA-06 |
|---|---|---|
| `OFFER_G1_NO_GO_REPORT_001.md`, §§ 5, 7 et 9 | RLS désactivée et grants excessifs sur trois tables ; `compute_qf(uuid)` `SECURITY DEFINER`, owner `postgres`, exécutable par `anon` | Contradiction directe avec la remédiation exigée |
| `OFFER_MD03_AUTHORITY_DECISION_001.md`, §§ 3 à 5 | RLS effective, retrait des mutations `anon`, restriction de `compute_qf`, tests négatifs et rollback rendus obligatoires | Traitement décidé mais non exécuté par la décision |
| `OFFER_MD01_AUTHORITY_DECISION_001.md`, §§ 3 à 6 | Remédiation autorisée sous conditions en `DEV`; arrêt et rollback sur exposition de sécurité | Autorisation, pas état corrigé |
| `OFFER_MD07_AUTHORITY_DECISION_001.md`, §§ 4, 6 et 7 | Remédiation MD-03 et PA-06 intégrées à la mission corrective | Ordre d’exécution, pas preuve de sortie |
| `OFFER_MD08_AUTHORITY_DECISION_001.md`, §§ 3 et 5 | Aucune preuve fraîche post-remédiation et aucun risque fermé | Confirme le maintien du constat défavorable |

## 4. Évaluation

L’état live certifié présente les expositions que PA-06 doit supprimer.
MD-03 définit la remédiation, mais indique explicitement que les risques ne
sont pas fermés par sa publication. Aucune preuve post-remédiation ne remplace
le constat live défavorable.

## 5. Écarts et preuves manquantes

- état live corrigé des quatre tables visées ;
- ACL et RLS conformes ;
- retrait effectif des droits de mutation `anon` ;
- restriction effective de `compute_qf(uuid)` ;
- tests négatifs cross-user et cross-tenant ;
- preuve de non-régression et de rollback applicable.

Ces éléments sont exigés par le rapport G1 (§ 9) et MD-03 (§ 4).

## 6. Impact sur Offer G1

Le rapport G1 classe les expositions QF/Rights et `compute_qf` en
`INCOMPATIBLE C4` (§ 5) et les associe aux risques R-G1-03 et R-G1-04
(§ 7). DB-05 exige une PA-06 passante (§ 10). MD-08 maintient G1 à `NO_GO`
(§§ 3 et 4).

## 7. Verdict

```text
PA-06   : FAIL
MOTIF   : EXPOSITIONS QF/RIGHTS CRITIQUES CERTIFIÉES ET REMÉDIATION NON PROUVÉE
G1      : NO_GO INCHANGÉ
```
