# CEREBRAU — DÉCISION D’AUTORITÉ MD-02

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-MD02-AUTHORITY-DECISION-001
MISSION_TYPE        : GOVERNANCE_FORMALIZATION
EXECUTION_MODE      : ONE_SHOT
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
DECISION_ID         : MD-02
```

Les work packages ne sont pas des objets officiels de gouvernance.

## 2. Objet et périmètre

Le présent document formalise exclusivement la décision MD-02 déjà rendue sur
la stratégie de baseline Offer.

Il ne vaut ni exécution de migration, ni preuve live, ni révision de Gate.

## 3. Décision officielle

Le `PROGRAM_DIRECTOR` retient la stratégie suivante :

```text
BaselineStrategy      : APPLY_20260717000000_THEN_ADDITIVE_MIGRATIONS
BaselineVersion       : 20260717000000
HistoryRewrite        : PROHIBITED
SupersessionChoice    : NOT_RETAINED
ProductionExecution   : PROHIBITED
```

La migration `20260717000000_create_offer_infrastructure.sql` constitue la
baseline à appliquer de manière contrôlée sur `DEV`. Toute évolution nécessaire
après cette baseline est portée par une migration additive distincte. La
migration existante et l’historique ne sont pas réécrits.

## 4. Ordre obligatoire

L’ordre arrêté est le suivant :

1. vérifier l’environnement `DEV`, la version, le SHA-256, la sauvegarde et le
   rollback conformément à MD-01 ;
2. vérifier l’absence de collision avec l’historique live ;
3. appliquer la baseline `20260717000000` sous le véhicule MD-07 ;
4. contrôler les objets, contraintes, privilèges et effets inter-domaines ;
5. appliquer ensuite seulement les migrations additives autorisées ;
6. produire les preuves de sortie et soumettre le résultat à revue humaine ;
7. rejouer G1 en lecture seule avant MD-08.

Toute divergence interrompt cet ordre conformément aux critères d’arrêt MD-01.

## 5. Compatibilité normative

La stratégie conserve les décisions d’architecture D01 à D04 telles que
reprises par le rapport G1 :

- `PUBLISHED` reste un état administratif ;
- `ACTIVE` reste requis pour la distribution ;
- les préconditions souveraines restent résolues côté serveur ;
- `OfferVersion v2` conserve son contrat typé.

L’application de la baseline ne vaut donc ni passage à `ACTIVE`, ni
distribution, ni activation métier.

## 6. Effets

MD-02 ferme uniquement le choix de stratégie de baseline entre application et
supersession. Son exécution reste soumise à MD-01, MD-03, MD-06 et MD-07 et aux
contrôles définis par le rapport G1.

## 7. Éléments explicitement inchangés

Restent inchangés :

- MD-04 et MD-05 ;
- le statut historique `NO_REMOTE_MATCH` observé ;
- la provenance historique `UNKNOWN` ;
- l’exclusion de la migration du périmètre historique des 29 migrations ;
- le statut `NO_GO` du Gate Offer G1 ;
- les Gates et la Master Gates Matrix ;
- l’absence de preuve d’exécution ;
- l’interdiction d’activation métier et de production.

## 8. Enregistrement d’autorité

```text
DecisionId                    : MD-02
Authority                     : PROGRAM_DIRECTOR
GovernanceObject              : WAVE
BaselineDecision              : APPLY_20260717000000
SubsequentEvolution           : ADDITIVE_MIGRATIONS_ONLY
HistoryRewrite                : PROHIBITED
ExecutionAuthorizationSource  : MD-01_AND_MD-07
ActivationEffect              : NONE
ProductionAuthorization       : NONE
OfferG1Status                 : NO_GO_UNCHANGED
GateModification              : NONE
MasterGatesMatrixModification : NONE
```
