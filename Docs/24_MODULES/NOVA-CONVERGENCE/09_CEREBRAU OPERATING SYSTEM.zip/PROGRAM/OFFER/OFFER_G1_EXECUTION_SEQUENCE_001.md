# CEREBRAU — Séquence officielle d’exécution Offer G1

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-G1-EXECUTION-ORCHESTRATION-001
MISSION_TYPE        : EXECUTION_PLANNING
EXECUTION_MODE      : READ_ONLY
EXPECTED_CHANGES    : DOCUMENTATION_ONLY
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
CURRENT_GATE_STATUS : NO_GO
SEQUENCE_TYPE       : LOGICAL_NOT_CALENDAR
```

Cette séquence ordonne les six lots définis dans
`OFFER_G1_EXECUTION_LOTS_001.md`. Elle ne constitue ni une autorisation
technique, ni un `GO`, ni une activation, ni une autorisation de production.

## 2. Séquence exécutoire

```mermaid
flowchart TD
    W[WAVE corrective autorisée] --> L1[LOT-01<br/>Périmètre et sûreté]
    L1 --> L2[LOT-02<br/>Qualification préalable]
    L2 --> LOCK{Verrou DEV exclusif}
    LOCK --> L3[LOT-03<br/>QF/Rights]
    L3 --> L4[LOT-04<br/>Baseline Offer]
    L4 --> L5[LOT-05<br/>Qualification post-baseline]
    L3 --> S4{{PA-01 à PA-09 PASS}}
    L5 --> S4
    S4 --> L6[LOT-06<br/>Replay et dossier final]
    L6 --> D[Dossier recevable pour décision G1]
```

L’ordre LOT-03 puis LOT-04 applique la priorité `P0-B` avant `P0-C` et évite
deux mutations concurrentes sur DEV. Il s’agit d’un ordre de ressource
exclusive. Les prérequis logiques de PA-01 restent ceux du graphe d’autorité.

## 3. Table d’entrée, d’exécution et de sortie

| Rang | Lot | Condition d’entrée | Exécution interne | Condition de sortie | Débloque |
|---:|---|---|---|---|---|
| 1 | `OFFER-G1-LOT-01` | WAVE officielle et décisions formalisées | Manifeste puis sûreté DEV | `D-01` et `D-02` fermées | Qualification isolée et captures read-only |
| 2 | `OFFER-G1-LOT-02` | LOT-01 `PASS` | Quatre lanes contrôlées ; PA-07 séquentielle | PA-07 `PASS`, états avant et runtime figés | Mutations PA-06/PA-01 et futur PA-05 |
| 3 | `OFFER-G1-LOT-03` | LOT-02 `PASS`, verrou DEV acquis | Remédiation QF/Rights puis tests | PA-06 `PASS`, verrou libérable | Fermeture de la branche QF/Rights |
| 4 | `OFFER-G1-LOT-04` | PA-07 `PASS`, état consommateurs avant disponible, verrou DEV libéré puis acquis | Préflight, application, rapport | PA-01 `PASS`, `D-06` fermée | PA-02, PA-03, PA-08 post-baseline |
| 5 | `OFFER-G1-LOT-05` | LOT-04 `PASS` et identité runtime déjà `PASS` | Contrôles parallèles, puis PA-04, puis PA-05 | PA-02/03/04/05/08 `PASS` | Synchronisation PA-01 à PA-09 |
| 6 | `OFFER-G1-LOT-06` | PA-01 à PA-09 toutes `PASS` | Replay, risques/avis, signatures | PA-10 `PASS`, dossier recevable | Demande de nouvelle certification G1 |

## 4. Points de synchronisation

### `EXEC-SYNC-0` — manifeste gelé

Entrées :

- WAVE officielle ;
- `G1-PRE-01` clôturée ;
- chemins, versions/hash, propriétaires, modes d’accès et destinations de
  preuve résolus.

Passage : `G1-PRE-02` peut finaliser la sûreté DEV. Aucun autre travail ne
démarre sur un `AF-*` non résolu.

### `EXEC-SYNC-1` — exécution préalable recevable

Entrées :

- LOT-01 `PASS` ;
- PA-07 `PASS` ;
- état initial QF/Rights disponible ;
- état consommateurs avant disponible ;
- runtime et contrat reliés.

Passage : les mutations DEV peuvent être planifiées une par une sous verrou
exclusif.

### `EXEC-SYNC-2` — mutations DEV terminées

Entrées :

- PA-06 `PASS` ;
- PA-01 `PASS` ;
- aucune activation, collision ou réécriture d’historique ;
- sauvegarde et rollback restés disponibles pendant chaque fenêtre.

Passage : les contrôles post-baseline commencent sur un état DEV figé.

### `EXEC-SYNC-3` — sécurité backend testable

Entrées :

- PA-03 `PASS` ;
- PA-04 `PASS` ;
- PA-09 `PASS`.

Passage : PA-05 est exécutée sur le commit et la configuration déjà figés.

### `EXEC-SYNC-4` — dossier de preuves complet

Entrées : PA-01 à PA-09 toutes `PASS`.

Passage : LOT-06 peut commencer en lecture seule. Tout verdict `PARTIAL`,
`FAIL` ou `NOT_PROVEN` bloque le passage.

### `EXEC-SYNC-5` — dossier recevable

Entrées :

- PA-10 `PASS` ;
- registre `R-G1-01` à `R-G1-10` fermé ;
- aucun `C4` ouvert ;
- avis et signatures requis présents.

Sortie : demande d’une décision G1 complémentaire. Le statut ne devient pas
automatiquement `GO`.

## 5. Chemin critique par lots

Le chemin critique logique est :

```text
OFFER-G1-LOT-01
  -> OFFER-G1-LOT-02 / lane PA-07
  -> OFFER-G1-LOT-04
  -> OFFER-G1-LOT-05 / PA-03 -> PA-04 -> PA-05
  -> OFFER-G1-LOT-06
```

LOT-03 est une branche obligatoire parallèle au chemin critique logique, mais
son verrou DEV impose sa fenêtre avant LOT-04 dans la séquence officielle. Il
devient bloquant au plus tard à `EXEC-SYNC-4`.

Dans LOT-02 :

- la capture consommateurs devient critique si elle n’est pas terminée avant
  l’application de la baseline ;
- la lane runtime devient critique avant PA-05 ;
- la capture QF/Rights devient critique avant LOT-03.

Dans LOT-05, PA-02 et PA-08 ne sont pas sur la chaîne la plus longue, mais
restent obligatoires avant LOT-06.

## 6. Premier lot, lots bloquants et dernier lot

| Question | Réponse officielle |
|---|---|
| Premier lot à exécuter | `OFFER-G1-LOT-01` |
| Lots contenant du parallélisme interne | `OFFER-G1-LOT-02`, `OFFER-G1-LOT-05` |
| Lots mutables à sérialiser | `OFFER-G1-LOT-03`, puis `OFFER-G1-LOT-04` |
| Lots bloquants du chemin principal | LOT-01, lane PA-07 de LOT-02, LOT-04, chaîne PA-03/04/05 de LOT-05, LOT-06 |
| Branche obligatoire à joindre | LOT-03 avec PA-06 `PASS` |
| Dernier lot avant demande de certification | `OFFER-G1-LOT-06` |

## 7. Règles de passage et d’arrêt

Un lot ne transmet pas de dépendance sur un succès partiel. Toutes ses
micro-missions doivent être journalisées, revues et `PASS`.

La séquence s’arrête si l’un des événements suivants est constaté :

- chemin, version ou hash non conforme au manifeste ;
- cible autre que DEV ou fichier hors scope requis ;
- collision de migration ou besoin de réécrire l’historique ;
- contrainte/FK invalide ;
- sauvegarde non restaurable ou rollback en échec ;
- privilège `anon`, fuite cross-user/cross-tenant ou bypass `service_role` ;
- RPC `compute_qf(uuid)` accessible au rôle interdit ;
- activation ou effet EBS/Rights/LifeHub/finance non autorisé ;
- runtime ou contrat non attribuable, ou secret dans une preuve ;
- inventaire différent de `7/94/53/28/4/1/4/3` ;
- PA non `PASS`, risque `C4`, avis ou signature manquant à l’entrée de LOT-06.

Après arrêt, le statut reste `NO_GO`. La reprise exige la résolution formelle
de la cause dans le même périmètre de WAVE.
