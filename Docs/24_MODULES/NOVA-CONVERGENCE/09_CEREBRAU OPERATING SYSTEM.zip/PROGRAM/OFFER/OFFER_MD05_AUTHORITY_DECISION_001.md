# CEREBRAU — DÉCISION D’AUTORITÉ MD-05

## 1. Identité

```text
PROGRAM          : VEEDDA
DOMAIN           : OFFER
MISSION_ID       : OFFER-MD05-AUTHORITY-DECISION-001
MISSION_TYPE     : GOVERNANCE_DECISION
EXECUTION_MODE   : ONE_SHOT
AUTHORITY        : PROGRAM_DIRECTOR
DECISION         : MD-05
```

## 2. Objet

Le présent document formalise exclusivement la décision MD-05 relative au devenir des objets Offer présents dans le repository mais absents du schéma DEV observé.

Il ne rouvre pas MD-04 et ne rend aucune autre décision de gouvernance.

## 3. Faits établis

Les faits suivants sont repris des deux documents d’autorité applicables :

1. La migration `supabase/migrations/20260717000000_create_offer_infrastructure.sql` existe dans le repository et n’est pas présente dans l’historique live observé.
2. Les objets Offer attendus issus de cette migration sont absents du schéma DEV observé : 7 tables, 94 colonnes, 53 contraintes, 28 index physiques, 4 fonctions, 1 trigger, 4 policies et 3 vues.
3. Le backend Offer est monté dans le monolithe au niveau repository ; son déploiement effectif et son activité dans le Runtime DEV ne sont pas démontrés.
4. Le rapport G1 identifie MD-05 comme la décision devant choisir, pour les objets Offer `repository-only`, entre `déployer`, `superséder` et `abandonner`, avec preuve de consommateur et d’impact.
5. MD-04 a exclu la migration `20260717000000` du périmètre historique de la décision relative aux 29 migrations. MD-04 n’autorise ni le déploiement de cette migration, ni sa suppression, ni une modification des Gates.
6. Le Gate Offer G1 demeure `NO_GO`.

### Preuves

| Fait | Document | Section exacte | Preuve |
|---|---|---|---|
| Migration présente dans le repository et absente du live observé | `Docs/PROGRAM/OFFER/OFFER_G1_NO_GO_REPORT_001.md` | `3. Faits établis` | « la migration Offer `20260717000000` existe dans le repository » et « elle est absente de l’historique live » |
| Objets Offer absents de DEV | `Docs/PROGRAM/OFFER/OFFER_G1_NO_GO_REPORT_001.md` | `3. Faits établis` et `5.1 Exigences G1 DATA` | Inventaire chiffré des objets attendus et résultat DEV nul pour chaque catégorie |
| Backend Offer présent au repository, déploiement non démontré | `Docs/PROGRAM/OFFER/OFFER_G1_NO_GO_REPORT_001.md` | `6.1 Surfaces applicatives` | « Le backend Offer est monté dans le monolithe au niveau repository » et « Son déploiement effectif [...] n’est pas démontré » |
| Définition de MD-05 | `Docs/PROGRAM/OFFER/OFFER_G1_NO_GO_REPORT_001.md` | `8. Décisions manquantes` | Ligne MD-05 : décider « déployer », « superséder » ou « abandonner » chaque objet Offer `repository-only` avec preuve de consommateur et d’impact |
| Portée limitée de MD-04 | `Docs/PROGRAM/OFFER/OFFER_MD04_AUTHORITY_DECISION_001.md` | `3. Décision officielle`, `4. Périmètre exact de MD-04` et `7. Enregistrement d’autorité` | Migration exclue du périmètre historique ; autorisation de déploiement `AUCUNE` ; autres statuts inchangés |
| G1 inchangé | `Docs/PROGRAM/OFFER/OFFER_MD04_AUTHORITY_DECISION_001.md` | `3. Décision officielle` et `7. Enregistrement d’autorité` | `OfferG1Status : NO_GO` |

## 4. Périmètre exact de MD-05

MD-05 décide uniquement de la disposition de gouvernance des objets Offer `repository-only`.

MD-05 ne décide pas :

- du véhicule technique qui matérialisera ces objets ;
- de l’application de la migration `20260717000000` ;
- d’une autorisation d’écriture ou d’exécution en DEV ;
- d’une activation métier Offer ;
- d’une validation E2E ;
- d’une certification ;
- d’un déploiement en production ;
- d’un changement de Gate ou de Master Gates Matrix.

## 5. Décision officielle du PROGRAM_DIRECTOR

```text
MD-05

DISPOSITION DES OBJETS OFFER REPOSITORY-ONLY : DÉPLOYER

AUTORISATION D’EXÉCUTION                       : AUCUNE
VÉHICULE DE MATÉRIALISATION                    : NON DÉCIDÉ PAR MD-05
ACTIVATION MÉTIER                              : NON AUTORISÉE
STATUT OFFER G1                                : NO_GO INCHANGÉ
```

Le PROGRAM_DIRECTOR décide que les objets Offer `repository-only` recensés dans le rapport G1 ne sont ni abandonnés ni déclarés supersédés par MD-05. Leur disposition est `DÉPLOYER`.

Cette disposition désigne le résultat attendu pour ces objets. Elle ne constitue pas l’ordre d’appliquer la migration `20260717000000` et ne préjuge pas du véhicule technique à utiliser pour obtenir ce résultat.

## 6. Objets couverts par la décision

| Catégorie d’objet Offer recensée | Quantité attendue selon G1 | Disposition MD-05 |
|---|---:|---|
| Tables | 7 | `DÉPLOYER` |
| Colonnes | 94 | `DÉPLOYER` |
| Contraintes | 53 | `DÉPLOYER` |
| Index physiques | 28 | `DÉPLOYER` |
| Fonctions | 4 | `DÉPLOYER` |
| Trigger | 1 | `DÉPLOYER` |
| Policies | 4 | `DÉPLOYER` |
| Vues | 3 | `DÉPLOYER` |

La migration `20260717000000_create_offer_infrastructure.sql` reste un véhicule possible de matérialisation cité dans le rapport G1. MD-05 ne décide ni de son application, ni de son remplacement, ni de sa suppression.

## 7. Consommateur et impact établis

### Consommateur

Le seul consommateur applicatif établi par les sources autorisées est le backend Offer monté dans le monolithe au niveau repository.

La consommation effective de chacun des objets de données dans le Runtime DEV n’est pas démontrée par les sources autorisées.

### Impact

Le rapport G1 établit qu’une matérialisation technique de baseline en DEV n’équivaut pas à :

- une activation métier ;
- une autorisation d’interagir avec des tables inter-domaines ;
- une validation E2E ;
- une certification ;
- une autorisation de production.

La décision MD-05 fixe donc une disposition de gouvernance. Elle ne produit aucun de ces effets d’exécution ou d’activation.

## 8. Effets de la décision

La décision MD-05 produit exclusivement les effets suivants :

1. le choix `abandonner` est écarté pour les catégories d’objets Offer recensées ;
2. le choix `superséder` n’est pas retenu par MD-05 pour ces objets ;
3. le résultat de gouvernance attendu pour ces objets est `DÉPLOYER` ;
4. la décision de disposition demandée par MD-05 est enregistrée ;
5. l’exécution demeure subordonnée aux autorisations, décisions, preuves et contrôles distincts identifiés par le rapport G1.

La preuve disponible identifie un consommateur au niveau repository, mais ne démontre pas la consommation effective objet par objet en DEV. En conséquence, le présent document n’enregistre pas la clôture de `L09-G04` et ne modifie aucun Gate.

## 9. Éléments explicitement inchangés

Restent inchangés :

- la décision MD-04 ;
- l’exclusion de la migration `20260717000000` du périmètre historique des 29 migrations ;
- l’absence d’autorisation de déployer ou d’appliquer cette migration ;
- l’absence de preuve d’exécution et de suppression ;
- le statut `NO_GO` du Gate Offer G1 ;
- les statuts des Gates et de la Master Gates Matrix ;
- les autres décisions manquantes recensées dans le rapport G1 ;
- les exigences de sécurité, de certification et de preuve ;
- l’interdiction d’activation métier et de déploiement en production issue du dossier G1.

## 10. Enregistrement d’autorité

```text
DecisionId                    : MD-05
Authority                     : PROGRAM_DIRECTOR
GovernanceObject              : WAVE
Domain                        : OFFER
RepositoryOnlyObjectDecision  : DÉPLOYER
AbandonDecision               : NON
SupersessionDecision          : NON
DeploymentAuthorization       : AUCUNE
MigrationExecutionOrder       : AUCUN
MaterializationVehicle        : NON DÉCIDÉ PAR MD-05
ConsumerProof                 : BACKEND OFFER AU NIVEAU REPOSITORY
PerObjectRuntimeConsumption   : NON DÉMONTRÉE
OfferG1Status                 : NO_GO
GateModification              : AUCUNE
MasterGatesMatrixModification : AUCUNE
MD04Status                    : INCHANGÉ
```

## 11. Verdict

```text
MissionId : OFFER-MD05-AUTHORITY-DECISION-001
MD-05     : RENDUE
Décision  : DÉPLOYER
Exécution : NON AUTORISÉE
G1        : NO_GO INCHANGÉ
Verdict   : SUCCESS
```
