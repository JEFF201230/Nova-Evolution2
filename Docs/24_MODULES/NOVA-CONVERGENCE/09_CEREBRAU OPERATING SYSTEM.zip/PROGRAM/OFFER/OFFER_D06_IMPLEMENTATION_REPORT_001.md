# ARCH-D06-IMPLEMENTATION-001 — Rapport d'implémentation

## Verdict

| Champ | Résultat |
|---|---|
| Décision | `PASS` |
| Runtime D06 | `SUCCESS` |
| Périmètre | `D06 uniquement` |
| Objet officiel de gouvernance | `WAVE` |

Les décisions `D01` à `D05` ont été utilisées comme références immuables.
Aucun de leurs rapports, migrations ou comportements certifiés n'a été
modifié.

## Écarts D06 corrigés

### Capacités et frontière d'autorisation

Les cinq capacités normatives sont matérialisées dans le domaine :

- `OFFER_EDITOR` ;
- `OFFER_VALIDATOR` ;
- `OFFER_PUBLISHER` ;
- `OFFER_OPERATOR` ;
- `OFFER_AUDITOR`.

Le mapping IAM approuvé est appliqué :

- `SUPERADMIN` est normalisé en `SUPER_ADMIN` ;
- `SUPER_ADMIN`, `ADMIN` et `SECRETAIRE` cumulent les cinq capacités ;
- `TRESORIER`, `COMPTABLE`, `BENEFICIAIRE`, `SALARIE` et les identifiants
  inconnus restent refusés ;
- le cumul ne désactive pas la séparation auteur/validateur, qui reste fondée
  sur les identités d'acteur.

Chaque commande Offer est reliée à une capacité explicite. Toutes les queries
exigent `OFFER_AUDITOR`. Les contrôles existants d'acteur, rôle, organisation,
tenant et SOD sont conservés.

### Ouverture par cohorte

`GET /api/v1/offer/workbench-access` restitue, depuis l'identité serveur :

- l'ouverture effective de la cohorte ;
- les capacités accordées.

La fonctionnalité est désactivée par défaut :

- `OFFER_WORKBENCH_ENABLED=true` active la WAVE runtime ;
- `OFFER_WORKBENCH_ORGANIZATION_IDS` limite l'ouverture à une liste
  d'organisations séparées par des virgules ;
- une liste vide ouvre à tous les tenants IAM autorisés uniquement lorsque le
  flag est explicitement activé.

Le contrat OpenAPI est additif : 42 opérations documentées, dont la nouvelle
lecture d'accès D06.

### Workbench GDBCSE

Le même espace GDBCSE reçoit une vue `Offer Workbench`; aucune UI concurrente
n'est créée. La navigation `Offres` n'est visible que si le serveur ouvre la
cohorte.

Le parcours couvre :

- création d'Offer et de Version v2 ;
- édition complète d'une Version brouillon ;
- soumission, demande de changements, validation, publication ;
- activation, suspension, reprise, fermeture, archivage ;
- création et édition d'Operation ;
- planification, ouverture, suspension, reprise, fermeture et archivage
  d'Operation ;
- consultation des projections, transitions et audits.

Toutes les mutations ciblent exclusivement
`/api/v1/offer/commands/*`. Les lectures ciblent exclusivement l'API Offer.
Le Workbench n'accède directement à aucune table et n'appelle ni QF, Rights,
Budget, Ledger, EBS, Dotation ou Simulation.

Les preuves déclaratives v1 encore obligatoires dans le contrat HTTP sont
envoyées uniquement pour compatibilité ; D04 continue à les ignorer et à
résoudre les preuves autoritatives dans la transaction.

### Concurrence et idempotence

- `If-Match` transporte la version d'agrégat lue ;
- la projection est rechargée après chaque commande ;
- aucun conflit n'écrase silencieusement la projection ;
- une double soumission identique partage une seule Promise et une seule clé
  d'idempotence ;
- un échec réseau conserve la même clé pour le retry ;
- un refus HTTP stable libère la clé avant une nouvelle intention.

### Projections d'édition

Les DTO de lecture exposent additivement :

- la définition complète sérialisable de l'OfferVersion ;
- l'identité du dernier auteur du brouillon ;
- la population cible complète d'une Operation détaillée.

Les lectures restent tenant-scoped. Aucune colonne ni table D06 n'a été
ajoutée.

## Fichiers principaux

- `server/offer-domain/types/roles.ts`
- `server/offer-application/authorization/Authorization.ts`
- `server/offer-application/dto/ApplicationDtos.ts`
- `server/offer-api/**`
- `server/offer-infrastructure/projections/**`
- `server/routes.ts`
- `client/src/gdbcse/offer-workbench/**`
- `client/src/gdbcse/layouts/GdbcseLayout.tsx`
- `client/src/gdbcse/components/HeaderGdbcse.tsx`
- `client/src/lib/apiClient.ts`
- `client/src/lib/proxyClient.ts`
- `client/tsconfig.offer-workbench.json`

## Preuves objectives

### Compilations ciblées

| Validation | Résultat |
|---|---|
| TypeScript `offer-domain` | `PASS` |
| TypeScript `offer-application` | `PASS` |
| TypeScript `offer-infrastructure` | `PASS` |
| TypeScript `offer-api` | `PASS` |
| TypeScript `client/tsconfig.offer-workbench.json` | `PASS` |
| Transpilation syntaxique intégration `GdbcseLayout.tsx` | `PASS` |
| Transpilation syntaxique intégration `HeaderGdbcse.tsx` | `PASS` |
| Transpilation syntaxique montage `server/routes.ts` | `PASS`, avec warning de baseline sur `tsconfig.base.json` absent |

### Tests

| Validation | Résultat |
|---|---|
| Domain/Application/Infrastructure + frontière client D06 | `124 PASS` |
| PostgreSQL conditionnels de la suite précédente | `14 SKIP` |
| API HTTP réelle Express, architecture incluse | `19 PASS` |
| Mapping des 5 capacités et des 26 commandes | `PASS` |
| Cohorte active/inactive et alias `SUPERADMIN` | `PASS` |
| Projection complète Version/auteur tenant-scoped | `PASS` |
| Double clic, retry réseau et rotation de clé après refus stable | `PASS` |
| Frontière API-only et sémantique d'accessibilité | `PASS` |
| `git diff --check` | `PASS` |
| Recherche `TODO`, `FIXME`, placeholder sur le périmètre D06 | `PASS` |

`OFFER_TEST_DATABASE_URL` n'est pas défini et aucun PostgreSQL/Docker local
n'est disponible. Les 14 scénarios PostgreSQL existants restent donc
conditionnellement ignorés. D06 n'ajoute ni migration, ni table, ni policy
RLS. Les requêtes additives D06 sont couvertes par les tests de contrat du
read model et utilisent les tables déjà certifiées D01–D05.

### Contrôles globaux hors verdict D06

Le build global serveur reste rouge sur des erreurs préexistantes hors Offer
dans `email.ts`, `qf-operations`, `routes/users.ts` et `shared/schema.ts`, ainsi
que sur la cible ES de `CompositionContract.ts`.

Le check global client reste rouge sur les erreurs syntaxiques préexistantes
de `client/src/gdbcse/engines/narrativeRoutingMatrix.ts`.

Ces fichiers ne font pas partie du diff D06 et n'ont pas été modifiés.

## Non-régression et périmètre

- aucune migration D01–D05 modifiée ;
- aucun rapport D01–D05 modifié ;
- aucun accès direct PostgreSQL/Supabase depuis le Workbench ;
- aucune logique QF, Rights, Budget, Ledger, EBS, Dotation ou Simulation
  introduite ;
- anciennes routes GDBCSE préservées ;
- feature désactivée : navigation et parcours MVP inchangés ;
- aucune modification d'une OfferVersion publiée ;
- aucun commit et aucun push.

## Certification

`D06 : PASS`

`Runtime : SUCCESS`

