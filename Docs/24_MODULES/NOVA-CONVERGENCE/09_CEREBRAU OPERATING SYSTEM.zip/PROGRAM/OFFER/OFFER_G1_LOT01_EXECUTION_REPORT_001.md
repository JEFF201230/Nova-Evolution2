# VEEDDA — Rapport d’exécution Offer G1 LOT-01

## 1. Identité

```text
PROGRAM             : VEEDDA
DOMAIN              : OFFER
MISSION_ID          : OFFER-G1-LOT-01-EXECUTION-001
MISSION_TYPE        : IMPLEMENTATION
LOT                 : LOT-01
EXECUTION_MODE      : SAFE_IMPLEMENTATION
AUTHORITY           : PROGRAM_DIRECTOR
OFFICIAL_OBJECT     : WAVE
DATE_OBSERVATION    : 2026-07-23
ENVIRONMENT_SCOPE   : DEV_ONLY
PRODUCTION          : EXPLICITLY_EXCLUDED
LOT_VERDICT         : BLOCKED
GATE_EFFECT         : NONE
```

Le présent rapport est le seul fichier créé par la mission. Il ne modifie
aucune décision, preuve PA, Gate, migration, source, configuration ou donnée.
Le statut Offer G1 reste `NO_GO`.

## 2. Périmètre officiel exécuté

La composition officielle de `OFFER-G1-LOT-01` a été lue dans
`OFFER_G1_EXECUTION_LOTS_001.md`.

| Ordre | Micro-mission | Objet | Résultat |
|---:|---|---|---|
| 1 | `G1-PRE-01` | Résoudre et geler tous les `AF-*` | `BLOCKED` : `AF-QF-RIGHTS` non résolvable |
| 2 | `G1-PRE-02` | Confirmer DEV, sauvegarde, rollback, acteurs, fenêtre et arrêts | `NOT_STARTED`, dépendance `G1-PRE-01 PASS` non satisfaite |

Aucune micro-mission d’un autre lot n’a été démarrée.

## 3. Entrées et contrôles d’autorité

Les faits certifiés fournis avec le PDS ont été appliqués :

- l’objet officiel de gouvernance est la `WAVE` ;
- les Work Packages ne sont pas officiels ;
- la fondation est prête ;
- le Wave Model et le contrat MM L01-03 sont canoniques.

Les décisions MD-01, MD-02, MD-03, MD-06 et MD-07 présentes sous
`Docs/PROGRAM/OFFER` confirment la portée `DEV_ONLY`, l’interdiction de
production, la baseline Offer, la remédiation QF/Rights exigée, le writer
serveur unique et la nécessité d’un manifeste dédié. Elles imposent aussi une
sauvegarde restaurable et un rollback avant toute mutation.

Observation repository :

| Élément | Valeur |
|---|---|
| Branche | `fix/simulation-star` |
| HEAD | `706bf1fae540e1798e3b827fbb162cac20b3b019` |
| Working tree initial | déjà modifié et non suivi sur des fichiers hors LOT-01 ; aucun de ces changements n’a été altéré |

## 4. Résolution `G1-PRE-01`

### 4.1 Éléments établis avant le blocage

Les éléments ci-dessous sont des constats de résolution, pas un manifeste
gelé. Ils ne ferment pas `D-01`.

| Référence | Chemin ou objet exact observé | Version / hash | Propriétaire logique | Mode prévu |
|---|---|---|---|---|
| `AF-BASELINE` | `supabase/migrations/20260717000000_create_offer_infrastructure.sql` | version `20260717000000`; SHA-256 `ba39dad5bf03d03cc91833b2b1df6497648e16ee6eff3e04daa6b5e4e3db0f4d` | Data/DB + Offer | lecture, puis application DEV seulement dans LOT-04 |
| `AF-OFFER-SECURITY` — partie baseline | même fichier, définitions RLS, policies, ACL/grants et fonctions Offer | même SHA-256 | Sécurité + Data | lecture dans LOT-02/05 ; aucune réécriture |
| `AF-BACKEND` — source repository | `server/offer-domain`, `server/offer-application`, `server/offer-api`, `server/offer-infrastructure`, montage `server/routes.ts` | HEAD repository observé ci-dessus ; identité déployée à établir par PA-09 | Offer/API + Exploitation | lecture/tests ; aucune modification dans LOT-01 |
| `AF-RUNTIME-CONFIG` — repository | `server/package.json`, `server/routes.ts`, `supabase/config.toml` | configuration déployée et secrets non copiés ; identité runtime à établir par PA-09 | Exploitation | lecture expurgée |
| `AF-CONSUMERS` — points prouvés | `server/employee-business-state/lifehub-bridge.ts`, `server/employee-business-state/projections/lifehub.helpers.ts`, `client/src/lifehub/hooks/useLifeHubDashboardData.ts`, `supabase/functions/compute-rights/index.ts`, `client/src/pages/DashboardSalarie.tsx`, `client/src/gdbcse/pages/GdbcseFinancialCockpit.tsx` | HEAD repository observé ; état déployé à capturer par PA-08 | Offer + Integration | lecture uniquement |

### 4.2 Blocage déterminant

`AF-QF-RIGHTS` doit désigner les migrations, patches ou scripts SQL
exécutables couvrant exclusivement :

- `public.qf_active` ;
- `public.qf_config` ;
- `public.rights_config` ;
- `public.user_rights_projection` ;
- `public.compute_qf(uuid)`.

La recherche repository sur les fichiers SQL de `supabase` et `server` ne
trouve aucune occurrence de ces cinq objets. La recherche globale ne trouve
que des descriptions documentaires et des consommateurs TypeScript, notamment
`supabase/functions/compute-qf/index.ts`,
`supabase/functions/compute-rights/index.ts`,
`server/qf-operations/infrastructure/VeeddaQfOperationsReaders.ts` et
`server/employee-business-state/lifehub-bridge.ts`. Ces fichiers ne sont ni la
définition SQL live de `compute_qf(uuid)`, ni un artefact de remédiation des
ACL/RLS.

Ce constat concorde avec
`OFFER_G1_DATA_INVENTORY_REPORT_001.md`, qui classe les quatre tables et la RPC
comme présentes en DEV mais sans définition SQL maintenue dans le dépôt.

Créer maintenant une migration ou un patch pour combler cet écart serait :

- une modification de migration/source interdite par LOT-01 ;
- l’exécution anticipée d’un travail technique relevant de LOT-03 ;
- l’ajout implicite d’un fichier non encore autorisé par le manifeste.

La dépendance `D-01 — Périmètre fichier certifié` reste donc ouverte. Le critère
« 100 % des `AF-*` ont un chemin exact » n’est pas satisfait et
`G1-PRE-01` ne peut pas être déclarée `PASS`.

### 4.3 Conséquences

Conformément aux règles d’arrêt du PDS et au graphe officiel :

- aucun manifeste n’est déclaré gelé ;
- aucune destination `AF-EVIDENCE` n’est autorisée comme destination finale ;
- `G1-PRE-02` n’est pas démarrée ;
- aucune sauvegarde, restauration, mutation DEV, qualification PA-07, capture
  PA-06/08/09 ou autre activité LOT-02+ n’est exécutée ;
- le jalon `M1 — SCOPED` et `EXEC-SYNC-0` ne sont pas franchis.

Une seconde insuffisance a été observée sans poursuivre `G1-PRE-02` : aucun
artefact de sauvegarde DEV restaurable, résultat de restauration, acteur
technique nommé ni fenêtre d’exécution enregistrée n’a été trouvé dans le
corpus. Les décisions exigent ces éléments mais indiquent explicitement
qu’elles ne constituent pas leur preuve d’exécution.

## 5. Fichiers modifiés

| Fichier | Action | Motif |
|---|---|---|
| `Docs/PROGRAM/OFFER/OFFER_G1_LOT01_EXECUTION_REPORT_001.md` | création | rapport obligatoire et documentation du blocage |

Aucun code, test, manifeste runtime, migration, décision, preuve PA, Gate ou
historique n’a été modifié.

## 6. Tests et contrôles exécutés

| Contrôle | Résultat | Détail |
|---|---|---|
| Recherche de l’artefact SQL `AF-QF-RIGHTS` | `FAIL / BLOCKING` | zéro fichier SQL correspondant sous `supabase` ou `server` |
| `npm test` | `FAIL` | le wrapper `npm.ps1` est interdit par la policy PowerShell ; relance équivalente `npm.cmd test` : 64 fichiers PASS, 51 FAIL, 1 SKIP ; 284 tests PASS et 2 SKIP |
| `npm run build` | `FAIL` | le package racine ne déclare aucun script `build` |
| `client — npm run build` | `PASS WITH WARNINGS` | build Vite réussi, 4 151 modules ; avertissements préexistants sur clés dupliquées, CSS invalide et taille de chunk |
| `frontend — npm run build` | `PASS` | `tsc -b` et build Vite réussis |
| `server — npm run build` | `FAIL` | 16 erreurs TypeScript préexistantes dans `email.ts`, `qf-operations/api/QfOperationsRouter.ts`, `routes/users.ts` et `shared/schema.ts` |
| `git diff --check` | `PASS` | code retour `0`; avertissements de conversion LF/CRLF sur des fichiers déjà modifiés |
| `git status --short` | `PASS / DIRTY PRE-EXISTING` | exécution réussie ; changements et fichiers non suivis antérieurs conservés ; le présent rapport est sous le répertoire non suivi `Docs/PROGRAM` |

Les contrôles npm qualifient le dépôt existant ; aucune correction de leurs
éventuels échecs n’est autorisée dans ce run si elle sort de LOT-01.

Les causes dominantes de l’échec des tests racine sont l’absence de
`tsconfig` résolvable pour plusieurs suites serveur, l’inclusion des sorties
`server/dist` dans la découverte de tests, deux imports client absents et
l’absence de `OFFER_TEST_DATABASE_URL` pour la certification PostgreSQL.
Aucune de ces causes n’a été modifiée, car elles ne font pas partie de
`G1-PRE-01` ou `G1-PRE-02`.

## 7. Critères PASS du LOT-01

| Critère | État | Justification |
|---|---|---|
| 100 % des `AF-*` ont un chemin exact et un propriétaire logique | `FAIL` | `AF-QF-RIGHTS` sans artefact SQL exécutable |
| chaque accès est classé lecture ou écriture autorisée | `OPEN` | aucun manifeste complet ne peut être gelé tant qu’un `AF-*` manque |
| DEV, sauvegarde restaurable, rollback, acteurs et fenêtre confirmés | `NOT_EVALUATED` | `G1-PRE-02` bloquée par `G1-PRE-01` |
| destinations `AF-EVIDENCE` distinctes | `OPEN` | aucune destination finale autorisée avant gel complet |
| production et activation explicitement exclues | `PASS` | PDS et décisions MD-01/02/06/07 ; aucune action externe exécutée |

Verdict : `LOT-01 BLOCKED`, et non `PASS`.

## 8. Critères de non-régression

| Critère | État | Résultat |
|---|---|---|
| aucun fichier, secret, environnement ou consommateur hors périmètre | `PASS` | aucun accès mutable ; aucun secret reproduit |
| aucune source, migration, décision, preuve ou Gate modifiée | `PASS` | seul le présent rapport a été créé |
| état initial conservé et traçable | `PASS` pour les actions de cette mission | aucune mutation DEV/Supabase ou runtime |
| compatibilité avec l’existant | `PASS` pour les actions de cette mission | aucune modification de code ou configuration |

## 9. Risques résiduels

- périmètre d’exécution non déterministe tant que `AF-QF-RIGHTS` n’a pas un
  véhicule SQL exact, autorisé et hashé ;
- impossibilité de tester la compatibilité PA-07 ou de préparer le rollback
  QF/Rights sans cet artefact ;
- exposition DEV QF/Rights déjà documentée restant non corrigée ;
- sauvegarde/restauration DEV, acteur et fenêtre non confirmés ;
- risque de confondre les Edge Functions `compute-qf`/`compute-rights` avec la
  RPC PostgreSQL `compute_qf(uuid)` ;
- suite de tests globale et compilation serveur non vertes dans l’état initial
  du dépôt.

## 10. Points non traités et reprise

Points non traités par arrêt obligatoire :

- finalisation du manifeste dédié et de toutes les destinations
  `AF-EVIDENCE` ;
- `G1-PRE-02` ;
- toute correction des échecs de tests ou de compilation hors LOT-01 ;
- toutes les micro-missions LOT-02 à LOT-06.

Condition minimale de reprise dans le même périmètre de WAVE :

1. fournir ou autoriser formellement un artefact SQL exact pour
   `AF-QF-RIGHTS`, couvrant uniquement les quatre tables et
   `compute_qf(uuid)` ;
2. enregistrer son chemin, son propriétaire logique, son mode d’accès, sa
   version et son SHA-256 ;
3. reprendre `G1-PRE-01` depuis la validation du manifeste complet ;
4. seulement après `G1-PRE-01 PASS`, confirmer la sauvegarde restaurable, le
   rollback, les acteurs et la fenêtre dans `G1-PRE-02`.

## 11. Conclusion

Le LOT-01 n’est pas terminé. L’arrêt est conforme au plan d’exécution : aucune
dépendance n’a été contournée, aucun autre lot n’a été modifié et aucun `GO`
local, Gate ou droit d’activation/production n’est déduit.
