# CEREBRAU — Plan de régénération de la campagne autoritative

## Composants producteurs

| Producteur | Rôle constaté | Preuve et état courant |
|---|---|---|
| `Invoke-CerebrauCampaign.ps1` | Point d'entrée, pas producteur de campagne. Le paramètre `CampaignFile` est obligatoire ; aucun manifeste par défaut n'est codé. | `tools/cerebrau/Invoke-CerebrauCampaign.ps1:2`, `:16-18`. L'autorité opérationnelle est donc le fichier explicitement fourni par l'appelant. |
| `tools/cerebrau/campaigns/VEEDDA-URBANIZATION-LOT-002-CLOSURE.json` | Manifeste fourni au Runner lors du preflight observé ; campagne autoritative courante pour cette tentative. | Le journal `tools/cerebrau/reports/campaigns/VEEDDA-URBANIZATION-LOT-002-CLOSURE-001/state/campaign-events.jsonl` porte `campaignId=VEEDDA-URBANIZATION-LOT-002-CLOSURE-001` et `CAMPAIGN_AUTHORITY_HASH_MISMATCH:17B6F604…B4141`. Le manifeste déclare quatre entrées, toutes `LOT-002`, `MM-L02-01` à `MM-L02-04`, Gates `L02-G03` à `L02-G06`. |
| `MM_FOUNDATION_CAMPAIGN.json` | Manifeste historique de fondation, distinct de la tentative LOT-002 courante. | `MM_FOUNDATION_REPORT.md:5-7` indique qu'il a été créé pour les cinq racines alors autorisées (`MM-L01-01`, `MM-L01-02`, `MM-L02-01`, `MM-L02-02`, `MM-L03-01`). Il porte lui aussi la baseline `93F0D83F…58BEF`, mais ce n'est pas le manifeste identifié par le journal d'échec LOT-002. |
| Mission documentaire `MM-LOT02-OWNERROLE-FULL-CLOSURE-001` | Producteur humain/documentaire du manifeste LOT-002, des deux dernières missions unitaires du LOT et des preuves associées. | `MM_LOT02_OWNERROLE_FULL_CLOSURE_REPORT.md:53-58` classe le manifeste comme « Créé — Campagne LOT-002 à quatre missions ». Aucun générateur exécutable de campagnes VEEDDA n'est présent dans le dépôt. Le Runner valide et consomme un manifeste ; il ne le fabrique pas. |
| `PROGRAM_MASTER_GATES_REGISTER.md` | Registre courant des 63 Gates, preuves, doctrine et décisions. | Il porte actuellement `19 GO`, `1 GO_WITH_DEROGATION` et `43 NO_GO` par lecture des lignes LOT-001 à LOT-010. Il conserve `L02-G03` à `L02-G06 = NO_GO`. |
| `PROGRAM_GATE_CERTIFICATION_CARDS.md` | Contrats de certification détaillés des Gates. | Source nécessaire pour reconstruire objectifs, preuves requises, décision et acceptation sans les déduire d'un titre de Work Package. |
| `PROGRAM_GATE_EXECUTION_ORDER.md` | Projection de l'ordre courant et des dépendances entre Gates. | Il fournit les niveaux `P1` à `P15`, les prérequis et les relations « dépend de / débloque ». |
| `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md` | Règles de décision et de certification. | Autorité normative référencée par chaque ligne du Master Gates Register. |
| `PROGRAM_DIRECTOR_STATUS_REPORT.md` | Décision de pilotage la plus récente à réconcilier avant toute reconstruction. | Le rapport du `2026-07-21` classe `LOT-002` `CERTIFIED` par décision Program Director tout en constatant que les registres persistés ne reflètent pas cette décision. Cette divergence interdit de choisir automatiquement entre « LOT-002 à rejouer » et « LOT-002 satisfait ». |
| `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md` | Source unique actuelle des relations LOT/Gate/Mission/Dépendance consommées par le Runner. | La matrice se déclare `AUTORITATIF` à la ligne 147 ; son registre exploité est la section 16. SHA-256 courant recalculé en lecture seule : `17B6F604BF246DD6486292C88C72B05E8389D4B67DF78C8CBB1825E9E67B4141`. |
| `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX_REPORT.md` | Certification structurelle de la matrice. | Le Runner exige seulement sa présence, mais le rapport conserve encore le bilan antérieur `19 GO / 44 NO GO`, dix LOTS `NO GO` et cinq missions « immédiatement lançables » (`:16-28`, `:108-151`). Il doit être régénéré après la matrice. |
| `PROGRAM_CAPABILITY_URBANIZATION.md` | Projection de la matrice en 10 Work Packages et 7 Capabilities. | Les contrôles publiés donnent 44 missions affectées exactement une fois, 0 omission et 0 doublon (`:74-113`). Le même document constate 7 manifestes/prompts présents et 37 absents (`:149-158`). |
| `PROGRAM_WORKPACKAGE_EXECUTION_PLAN.md` | Projection exécutable des Work Packages, phases, micro-missions et prérequis. | La Phase 1 est explicitement `WP-01`, `WP-02` (`:343-349`) : `MM-L01-01` à `MM-L01-03` et `MM-L02-01` à `MM-L02-04`, soit 7 missions et non les seules 4 missions de LOT-002. |
| Manifestes et prompts `tools/cerebrau/missions/veedda/MM-Lxx-yy.*` | Contrats unitaires que la campagne référence sans les créer. | Sept couples JSON/prompt existent : `MM-L01-01`, `MM-L01-02`, `MM-L02-01` à `04`, `MM-L03-01`. Pour la Phase 1, `MM-L01-03.json` et `MM-L01-03.prompt.md` manquent. |
| Bibliothèque de preuves et registres `EV-*` | Sources hashées des `sharedEvidence` et `baselineEvidence`. | Dans la campagne LOT-002, `EV-OR-001` et `EV-L02-01-COVERAGE` ont dérivé. Les quatre autres preuves partagées conservent leur hash déclaré. Les baselines de `MM-L02-03` et `MM-L02-04` ont également dérivé. |

La campagne LOT-002 est donc obsolète à trois niveaux indépendants : son hash d'autorité est `93F0D83F3872711F4AC0ABD20BEBDF56C28A2D00D71FE9A8257E0A1DDC758BEF` au lieu de `17B6F604…B4141` ; sa couverture est celle de `WP-02` seulement alors que la Phase 1 publiée contient `WP-01 + WP-02` ; ses preuves et certaines baselines unitaires ne correspondent plus aux fichiers courants. Sa couverture limitée à LOT-002 n'est pas une sélection effectuée par le Runner : elle résulte des quatre seules entrées écrites dans `missions[]` par la mission documentaire qui l'a créée.

## Composants consommateurs

| Consommateur | Entrées consommées | Contrôle exercé |
|---|---|---|
| `Invoke-CerebrauCampaign.ps1` | Chemin `CampaignFile`, action opérateur | Transmet le fichier au module et retourne le code d'erreur ; il ne découvre ni Phase, ni Work Package, ni Capability. |
| `Test-CerebrauCampaignManifest` dans `Cerebrau.Campaign.psm1` | Manifeste campagne, dépôt Git, branche, matrice, rapport de certification, preuves, manifestes unitaires et prompts | Recalcule le hash de l'autorité avant tout autre contrôle de contenu (`:303-306`) ; valide ensuite références, missions, profils, scopes, DAG et hashes de preuves (`:312-389`). |
| `Get-CerebrauGateRegistry` | Section 16 de la Master Gates Matrix | Parse uniquement les lignes `MM-Lxx-yy → Gate` comprises entre les titres `## 16.` et `## 17.` ; extrait les dépendances `MM-*` de la quatrième cellule (`Cerebrau.Campaign.psm1:250-268`). |
| `Test-CerebrauMission.ps1` et `Resolve-CerebrauProfile.ps1` | Chaque manifeste unitaire, prompt, profil et baseline | Refusent une mission absente, invalide, non résolue ou incohérente avec le manifeste de campagne. |
| Scheduler Campaign | `missions[]`, `dependsOn`, prérequis, preuves, revues | Ordonne seulement les missions inscrites dans le manifeste. Il ne complète pas les 44 missions depuis la matrice et ne lit pas les Work Packages ou Capabilities. |
| State Store / reprise | `campaignId`, `campaignFingerprint`, `stateDirectory`, journal | L'état LOT-002 existant est `FAILED`, séquence 2, sans tentative de mission. Une définition régénérée ne doit pas être greffée sur cet état historique. |
| Report Projector | État, journal, index de preuves, rapports unitaires | Produit les rapports et métriques de campagne ; il ne modifie aucune Gate et ne certifie pas le PROGRAM. |
| Pilotage PROGRAM | Matrix, Master Gates Register, Execution Order, Work Packages, Capabilities, campagnes | Consomme les mêmes identités et dépendances. Cette cohérence doit être certifiée en amont, car le Runner ne lit pas les deux projections d'urbanisation. |

## Artefacts à régénérer

| Classe | Artefact futur | Exigence de régénération |
|---|---|---|
| Décisions et Gates | `Docs/PROGRAM/PROGRAM_MASTER_GATES_REGISTER.md` | Incorporer uniquement les décisions approuvées, notamment statuer formellement sur la décision Program Director relative à LOT-002 ; conserver 63 GateId uniques et une décision doctrinalement valide par Gate. |
| Décisions et Gates | `Docs/PROGRAM/PROGRAM_GATE_CERTIFICATION_CARDS.md` | Réaligner preuves, décisions, propriétaires, dates et critères avec le Master Gates Register. |
| Ordonnancement | `Docs/PROGRAM/PROGRAM_GATE_EXECUTION_ORDER.md` | Recalculer les Gates restantes et les niveaux après décision sur LOT-002 ; ne pas conserver comme exécutables des Gates déjà certifiées. |
| Autorité Campaign | `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md` | Régénérer les sections de statut, le registre section 16, les prérequis, les dépendances, les racines et les chemins critiques depuis les décisions réconciliées. La forme des sections 16 et 17 doit rester compatible avec le parseur actuel. |
| Certification d'autorité | `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX_REPORT.md` | Recalculer les comptes LOT/Gate/Mission, cardinalité Gate↔Mission, arêtes, cycles, racines, prérequis et verdict ; certifier exactement le contenu final de la matrice. |
| Urbanisation | `Docs/PROGRAM/PROGRAM_CAPABILITY_URBANIZATION.md` | Reprojeter la partition exhaustive des missions actives : 0 mission omise, 0 mission dupliquée, traçabilité Gate→WP→Capability. Les missions terminées restent traçables mais ne deviennent pas implicitement réexécutables. |
| Urbanisation | `Docs/PROGRAM/PROGRAM_WORKPACKAGE_EXECUTION_PLAN.md` | Recalculer phases, statuts, prérequis de package et tableau de bord depuis la matrice, l'ordre des Gates et la partition approuvée. La Phase 1 doit rendre compte de `WP-01 + WP-02` et de leurs 7 missions, soit comme travail à exécuter, soit comme dépendance déjà satisfaite avec preuve. |
| Contrats unitaires | `tools/cerebrau/missions/veedda/MM-Lxx-yy.json` et `.prompt.md` | Matérialiser avant campagne toute mission sélectionnée qui n'existe pas. Minimum Phase 1 : créer le couple `MM-L01-03`. Pour une reconstruction complète du PROGRAM : matérialiser les 37 couples encore absents. Réétablir les baselines de `MM-L02-03` et `MM-L02-04` après stabilisation des preuves, sans valider automatiquement leur contenu métier. |
| Campagne Phase 1 | Nouveau manifeste sous `tools/cerebrau/campaigns/` | Créer un nouvel `campaignId` et de nouveaux `stateDirectory`/`reportDirectory`. Sa couverture doit être dérivée de la Phase 1 finale, pas copiée depuis la campagne LOT-002. Les 7 missions de `WP-01 + WP-02` doivent être comptabilisées exactement une fois : mission à exécuter si sa Gate reste ouverte, ou prérequis satisfait et hashé si une décision approuvée établit sa clôture. |
| Campagnes suivantes | Nouveaux manifestes sous `tools/cerebrau/campaigns/` | Les dériver des phases/WP approuvés, uniquement après matérialisation des contrats unitaires correspondants. Chaque campagne doit conserver le sous-graphe exact induit par la section 16 et déclarer les dépendances antérieures comme prérequis externes prouvés, jamais comme hypothèses. |
| Intégrité | Valeurs `authority.sourceSha256`, `sharedEvidence[].sourceSha256` et baselines unitaires | Les recalculer une seule fois, à la fin, sur les artefacts figés. Valeurs actuellement divergentes à traiter : matrice `93F0D83F…58BEF → 17B6F604…B4141` ; `EV-OR-001` `908A88D4…F007 → 6206C295…53E0` ; `EV-L02-01-COVERAGE` `9235124A…04E → D5E001FE…E065` ; baseline OwnerRole Resolution de `MM-L02-03` `652E1907…9231 → B8842C26…DF79`. |
| Sorties du Runner | Nouvel état, journal, evidence index, rapports et métriques | Ne pas les fabriquer ni les migrer. Ils seront produits par le Runner lors d'une mission future, après validation du nouveau manifeste. Conserver les sorties de la campagne LOT-002 échouée comme trace historique. |

## Ordre de régénération

1. Geler un snapshot de lecture des sources et établir la décision de préséance sur LOT-002 : soit la décision Program Director est approuvée et transcrite dans les registres, soit les `NO_GO` persistés restent autoritatifs. Aucun hash ni manifeste ne doit être calculé avant cette décision.
2. Régénérer, dans cet ordre, `PROGRAM_MASTER_GATES_REGISTER.md`, `PROGRAM_GATE_CERTIFICATION_CARDS.md`, puis `PROGRAM_GATE_EXECUTION_ORDER.md`. Contrôler 63 GateId uniques, décisions permises par la doctrine, preuves et dépendances nommées.
3. Régénérer la Master Gates Matrix depuis ces registres : bibliothèque de preuves, états LOT/PROGRAM, section 16 Gate→Mission→dépendances, section 17 des missions ouvrables, graphes et chemins critiques.
4. Régénérer le rapport de certification de la matrice et exiger la concordance exacte des comptes, identités, arêtes, racines et décisions. La matrice ne devient baseline de campagne qu'après ce verdict.
5. Dériver la partition Work Package des missions de la section 16, affecter chaque WP à une Capability, puis régénérer `PROGRAM_CAPABILITY_URBANIZATION.md` et `PROGRAM_WORKPACKAGE_EXECUTION_PLAN.md`. Certifier les invariants Gate→Mission→WP→Capability et la définition finale des phases.
6. Matérialiser les manifestes/prompts unitaires requis par la phase ciblée. Pour la Phase 1 publiée aujourd'hui, matérialiser au minimum `MM-L01-03`; régénérer les contrats unitaires dont les sources ont changé. Valider statiquement identité, lot, branche, profil, prompt, scopes, revue et baselines.
7. Construire le registre d'entrée de la campagne à partir des seuls artefacts figés : missions ouvertes, preuves, décisions de prédécesseurs terminés, prérequis externes, modes d'exécution, scopes et politique de revue. Aucune dépendance satisfaite ne doit disparaître sans preuve hashée.
8. Calculer les SHA-256 finaux de la matrice, des preuves partagées et des baselines unitaires. Toute modification après ce point invalide la génération et impose de reprendre à l'étape productrice concernée.
9. Générer un nouveau manifeste de Phase 1 avec un nouvel identifiant et de nouveaux répertoires. Ne pas modifier `VEEDDA-URBANIZATION-LOT-002-CLOSURE.json`, son état `FAILED`, son journal ou ses hashes historiques.
10. Effectuer, dans une future mission autorisée, `-Action Validate` seulement. Corriger la source productrice en cas d'échec ; ne jamais contourner le contrôle. `Start` ou `Resume` ne peut intervenir qu'après un preflight `VALID` et une revue de la couverture Phase/WP/Capability, laquelle n'est pas assurée par le Runner.
11. Après validation de toutes les campagnes projetées, certifier globalement : chaque mission active de la matrice est couverte exactement une fois, chaque dépendance inter-campagne possède une preuve satisfaite, et aucune mission terminée n'est rejouée sans décision explicite.

## Dépendances

| Producteur amont | Artefact aval | Invariant obligatoire |
|---|---|---|
| Doctrine + décisions approuvées + preuves | Master Gates Register / Certification Cards | Aucune décision inventée ; propriétaire, preuve, date et statut compatibles. |
| Master Gates Register + Gate Execution Order | Master Gates Matrix | Même ensemble de 63 Gates, mêmes décisions et mêmes dépendances actives. |
| Master Gates Matrix | Matrix Report | Le rapport certifie le hash/contenu final, les comptes et le DAG exacts. |
| Matrix section 16 + Execution Order | Work Packages | Chaque mission de remédiation/certification appartient à un seul WP ; aucune fusion de Gate. |
| Work Packages | Capabilities | Chaque WP appartient à une Capability ; les agrégations ne changent ni GateId ni MissionId. |
| Matrix + Cards + preuves + schéma/profils CEREBRAU | Manifestes unitaires | Concordance `missionId`, `program`, `lot`, branche, profil, prompt, mode, revue, scopes et baselines. |
| Phase/WP + manifestes unitaires | Manifeste de campagne | Seules des missions existantes sont référencées ; couverture et sous-graphe exacts. |
| Matrice et preuves figées | Hashes du manifeste | Égalité octet pour octet au moment du preflight. |
| Décisions de prédécesseurs hors campagne | `externalPrerequisites` et `sharedEvidence` | Statut `SATISFIED` seulement avec une preuve datée, autorisée, présente et hashée. |
| Nouveau manifeste | Nouvel état Campaign | Nouvel `campaignId` et répertoires distincts ; aucun recyclage du fingerprint ou de l'état LOT-002. |

## Risques de régression

| Risque | Effet | Barrière exigée |
|---|---|---|
| Remplacer seulement `93F0D83F…58BEF` par `17B6F604…B4141` | Masque l'écart de gouvernance, puis expose les dérives de preuves ou rejoue une couverture LOT-002 obsolète. | Régénération complète dans l'ordre ci-dessus ; jamais de patch de hash isolé. |
| Décision LOT-002 non réconciliée | Deux vérités incompatibles : `CERTIFIED` dans le rapport Director, `NO_GO` dans Matrix/Register. | Décision humaine de préséance puis transcription avant toute projection. |
| Rapport de matrice ancien | Fausse certification `19/44`, dix LOTS `NO_GO`, cinq racines ouvrables alors que la matrice courante a évolué. | Régénérer le rapport après la matrice, jamais avant. |
| Preuves/baselines périmées | `CAMPAIGN_EVIDENCE_HASH_MISMATCH` ou rejet des missions unitaires après correction du hash d'autorité. | Recalcul final exhaustif et revue du contenu avant acceptation du nouveau hash. |
| 37 missions sans contrat unitaire | Impossible de produire des campagnes complètes ; `CAMPAIGN_MANIFEST_PATH_NOT_FOUND` ou manifeste incomplet. | Matérialiser et valider chaque couple JSON/prompt avant inclusion. |
| Work Packages/Capabilities supposés contrôlés par le Runner | Une campagne peut être techniquement `VALID` tout en étant fausse au niveau Phase/WP/Capability. | Contrôle documentaire séparé de partition et de couverture avant le preflight. |
| Réutilisation du manifeste ou de l'état échoué | Fingerprint différent, reprise interdite ou mélange d'historique. | Nouvel identifiant et nouveaux répertoires ; archives historiques immuables. |
| Rejeu de missions terminées | Duplication de preuves, nouvelles décisions non demandées ou incohérence avec la section 16. | Transformer les prédécesseurs clôturés en prérequis prouvés ; ne les inclure comme missions qu'avec autorisation explicite. |
| Dépendance inter-campagne supprimée par le filtrage du sous-graphe | Mission aval techniquement prête sans preuve que l'amont est satisfait. | Déclarer une preuve/prérequis externe pour chaque prédécesseur hors campagne. |
| Modification du format Markdown de la section 16 | `SECTION_16_NOT_PARSED`, Gate inconnue ou dépendance mal extraite. | Conserver titres `## 16.`/`## 17.` et colonnes `Mission | Gate | … | Dépendances`; tester la cardinalité 1:1. |
| Branche ou scopes obsolètes | `CAMPAIGN_BRANCH_MISMATCH`, mismatch unitaire ou scope documentaire invalide. | Figer la branche cible et aligner campagne et chaque manifeste unitaire ; vérifier tous les `allowedPaths`. |
| Prérequis externes promus sans preuve | Ouverture indue d'une mutation ou blocage tardif du scheduler. | `SATISFIED` uniquement avec assertion autorisée, datée et preuve hashée ; sinon `NOT_SATISFIED`. |
| Changement d'une source après calcul des hashes | Nouvelle dérive d'autorité ou d'evidence. | Gel des sources entre calcul, revue et validation ; toute modification relance la chaîne depuis le producteur. |

## Critères permettant au Campaign Runner de réussir le preflight

| Critère | Résultat attendu |
|---|---|
| Fichier et schéma | JSON UTF-8 valide, `schemaVersion=1.0.0`, propriétés strictement conformes à `campaign-manifest.schema.json`, identifiants uniques et chemins relatifs confinés au dépôt. |
| Dépôt et branche | `repository` résout la racine réelle ; la branche Git courante égale `expectedBranch` de la campagne et de chaque mission. Branche observée lors de cette mission : `fix/simulation-star`. |
| Autorité | `authority.sourcePath` existe ; son SHA-256 recalculé égale exactement `authority.sourceSha256` ; le rapport de certification existe et correspond à la même matrice régénérée. |
| Programme | `programId` de campagne égale `program` de toutes les missions ; `programDecision` transporte la décision approuvée sans être inventée ni recalculée par le Runner. |
| Section 16 | Chaque `missionId` de la campagne existe une fois dans la section 16, pointe vers le même `gateId`, et ses dépendances internes déclarées égalent exactement l'intersection entre les dépendances de la matrice et les missions de la campagne. |
| DAG | Aucun doublon, identifiant inconnu, auto-dépendance, cycle ou mission orpheline ; ordre topologique stable calculable. |
| Contrats unitaires | Chaque `missionFile` et prompt existe ; `Test-CerebrauMission.ps1` retourne `VALID` ; identité, lot, branche, repository et exigence de revue concordent. |
| Profils | Chaque profil unitaire est résolu par le registre officiel ; aucune substitution locale au niveau Campaign. |
| Preuves | Chaque `sharedEvidence` existe ; hash déclaré = hash courant ; consommateurs déclarés présents ; chaque `requiresEvidence` référence une preuve dont la mission est consommatrice. |
| Prérequis | Identifiants uniques, preuve associée présente, auteur et date valides ; tout prérequis requis existe. Une `RUNTIME_MUTATION` n'est validable que si tous ses prérequis sont `SATISFIED`. |
| Scopes | Chaque `resourceScopes` couvre les `allowedPaths` unitaires ; tout `DOCUMENTARY_WRITE` reste sous `Docs/**` ; aucun conflit entre répertoire de rapport campagne et rapports unitaires. |
| Politiques MVP | `maxConcurrency=1`, revue `BLOCK_DEPENDENTS_UNTIL_APPROVED`, reprise `REUSE_TERMINAL_ATTEMPTS`, dérive `BLOCK_AFFECTED`, politique d'échec et rollback parmi les valeurs autorisées. |
| État | Nouvel `campaignId`, `stateDirectory` inclus dans `reportDirectory`, répertoires distincts de ceux des missions et de la campagne échouée ; aucun état antérieur portant un autre fingerprint. |
| Couverture de gouvernance hors Runner | Phase 1 finale comptabilisée sans omission ni doublon : `WP-01 + WP-02`, 7 missions historiques au total, chacune classée soit à exécuter, soit déjà satisfaite par une preuve approuvée. Mapping Gate→Mission→WP→Capability certifié séparément. |
| Verdict | `Invoke-CerebrauCampaign.ps1 -CampaignFile <nouveau-manifeste> -Action Validate` retourne `Status=VALID`, `ExitCode=0`, le nombre de missions attendu et un fingerprint nouveau ; aucun appel à `Start` ou `Resume` pendant la mission de validation. |
