# CEREBRAU Runtime — audit du point d'entrée

## 1. Identification

| Champ | Valeur |
|---|---|
| Mission | `CEREBRAU-RUNTIME-ENTRYPOINT-001` |
| Programme | `VEEDDA` |
| Lot | `RUNTIME` |
| Type | `AUDIT_READ_ONLY` |
| Date de l'audit | `2026-07-23` |
| Portée | État de travail présent dans le dépôt au moment de l'audit |
| Résultat | `PASS` — point d'entrée du Runtime unitaire identifié ; inexistence d'un décideur final unique `ACCEPTED/REJECTED` démontrée |

Faits certifiés reçus et non réinterprétés :

- l'objet officiel de gouvernance est `WAVE` ;
- les Work Packages ne sont pas officiels ;
- la fondation est prête ;
- le modèle Wave est canonique ;
- le contrat `MM-L01-03` est canonique.

## 2. Conclusion certaine

1. Le point d'entrée effectif et commun de l'exécution d'une mission unitaire est le script top-level `tools/cerebrau/Invoke-CerebrauMission.ps1`. Il n'est contenu dans aucune classe et n'est enveloppé par aucune fonction principale. L'exécution de Codex a lieu à la ligne 291.
2. Le Campaign Runner n'est pas une étape située après ce point d'entrée. Il est un orchestrateur amont distinct : `Invoke-CerebrauCampaign.ps1` appelle `Invoke-CerebrauCampaign`, puis `Invoke-CerebrauUnitMission`, qui appelle `Invoke-CerebrauMission.ps1`.
3. L'assemblage de contexte est optionnel. Il est exécuté dans le Runtime unitaire uniquement lorsque `-ContextAssemblyEnabled` est présent.
4. Le Runtime PowerShell n'a aucune phase ou fonction d'`Authorization`. Il valide le manifeste, exécute Codex, valide les résultats puis calcule un statut officiel.
5. Les chaînes littérales `MISSION ACCEPTED` et `MISSION REJECTED` n'apparaissent dans le périmètre exécutable que comme texte du prompt à `tools/cerebrau/prompt.md:57-65`. Elles ne sont ni émises, ni recherchées, ni parsées par le Runtime.
6. Le transcript Codex est explicitement marqué non autoritatif dans le rapport (`Cerebrau.Reporting.psm1:319`) ; il ne décide donc pas du statut officiel.
7. Le seul calcul automatique du résultat unitaire est `Get-CerebrauClassification` dans `tools/cerebrau/Cerebrau.Reporting.psm1:285-297`. Son vocabulaire est `CANCELLED`, `FAILED`, `PARTIAL`, `BLOCKED`, `NO_CHANGE`, `READY_FOR_REVIEW`, `SUCCESS`, et non `ACCEPTED/REJECTED`.
8. Un second Runtime, TypeScript et sans appel depuis la chaîne PowerShell, déclare les états terminaux `ACCEPTED` et `REJECTED`. Il expose deux méthodes distinctes, `approveMission` et `rejectMission`. Aucune méthode ne choisit entre les deux à partir d'un résultat de validation.
9. Il n'existe donc pas de composant unique qui, depuis `Invoke-CerebrauMission.ps1`, décide `MISSION ACCEPTED` ou `MISSION REJECTED`. Cette chaîne demandée n'existe pas dans le code observé.
10. Aucune Recovery Lane conforme aux classes `READ_ONLY`, `EVIDENCE_PRODUCTION`, `AUDIT`, `CERTIFICATION_REMEDIATION` n'est implémentée dans le code exécutable observé.

## 3. Graphe réel d'exécution

### 3.1 Campaign Runner vers Runtime unitaire

```mermaid
flowchart TD
    CCLI["Invoke-CerebrauCampaign.ps1<br/>switch Action"]
    CMOD["Cerebrau.Campaign.psm1<br/>Invoke-CerebrauCampaign"]
    CMPRE["Test-CerebrauCampaignManifest<br/>preflight global"]
    CLOCK["Enter-CerebrauCampaignLock"]
    CEVI["Update-CerebrauCampaignEvidence"]
    CREADY["Get-CerebrauCampaignReadySet"]
    CUNIT["Invoke-CerebrauUnitMission"]
    PS["Invoke-CerebrauMission.ps1<br/>Runtime unitaire"]
    MVAL["Test-CerebrauMission.ps1"]
    PROF["Resolve-CerebrauProfile.ps1"]
    BEFORE["New-CerebrauWorkspaceSnapshot<br/>avant"]
    CTX{"ContextAssemblyEnabled ?"}
    CASM["New-CerebrauMissionContextAssembly"]
    EXEC["codex exec"]
    AFTER["Snapshot après + delta"]
    VAL["Invoke-CerebrauValidation"]
    CLASS["Get-CerebrauClassification"]
    MREP["New-CerebrauOfficialReport<br/>JSON + Markdown + journal"]
    IMPORT["Import-CerebrauUnitReport<br/>Convert-CerebrauUnitStatus"]
    CREP["Write-CerebrauCampaignReports"]

    CCLI --> CMOD --> CMPRE --> CLOCK --> CEVI --> CREADY --> CUNIT --> PS
    PS --> MVAL --> PROF --> BEFORE --> CTX
    CTX -->|oui| CASM --> EXEC
    CTX -->|non| EXEC
    EXEC --> AFTER --> VAL --> CLASS --> MREP --> IMPORT --> CREP
```

Preuves :

- dispatch Campaign : `tools/cerebrau/Invoke-CerebrauCampaign.ps1:14-42` ;
- preflight avant tout appel unitaire : `Cerebrau.Campaign.psm1:851-880` ;
- calcul du ready set : `Cerebrau.Campaign.psm1:891-894` ;
- appels au Runtime unitaire : `Cerebrau.Campaign.psm1:747-756` ;
- identification explicite de `Invoke-CerebrauMission.ps1` comme `unitRuntime` dans le rapport Campaign : `Cerebrau.Campaign.psm1:785-790`.

### 3.2 Exécution directe du Runtime unitaire

```text
Invoke-CerebrauMission.ps1
  → lecture bootstrap du Mission Manifest
  → création du répertoire de run et du journal
  → import du module Reporting
  → Test-CerebrauMission.ps1
  → seconde lecture du Mission Manifest
  → résolution du profil
  → lecture du prompt
  → ajout éventuel des Certified Facts
  → résolution et contrôle de version de Codex
  → snapshot Git avant
  → [option] Mission Context Assembly
  → Codex
  → persistance du transcript
  → snapshot Git après
  → calcul du delta
  → validations post-exécution
  → classification
  → rapport officiel et métriques
```

Preuves :

- bootstrap et création des chemins de run : `Invoke-CerebrauMission.ps1:29-47` ;
- import Reporting et validation du manifeste : `Invoke-CerebrauMission.ps1:145-161` ;
- relecture du manifeste, profil et prompt : `Invoke-CerebrauMission.ps1:163-181` ;
- Certified Facts : `Invoke-CerebrauMission.ps1:183-190` ;
- résolution et version de Codex : `Invoke-CerebrauMission.ps1:192-224` ;
- snapshot avant : `Invoke-CerebrauMission.ps1:240-245` ;
- contexte optionnel : `Invoke-CerebrauMission.ps1:247-261` ;
- exécution : `Invoke-CerebrauMission.ps1:263-311` ;
- transcript : `Invoke-CerebrauMission.ps1:333-339` ;
- snapshot, delta et validations : `Invoke-CerebrauMission.ps1:343-356` ;
- classification et reporting : `Invoke-CerebrauMission.ps1:358-422`.

### 3.3 Runtime Orchestrator TypeScript séparé

```text
createOrchestratorRuntime / createMissionRuntime
  → OrchestratorRuntimeService.createMission
  → acceptMission                 DRAFT → READY
  → assignMission                READY → ASSIGNED
  → acquireLock               ASSIGNED → LOCKED
  → executeMission/startMission LOCKED → RUNNING
  → submitReport                RUNNING → SUBMITTED
  → startTechnicalValidation ou startDocumentaryValidation ou startHumanValidation
  → approveMission     HUMAN_VALIDATION → ACCEPTED
    ou
  → rejectMission      HUMAN_VALIDATION → REJECTED
```

Preuves :

- fabriques : `server/cerebrau-runtime/orchestrator-runtime/orchestrator-runtime.ts:1-14` ;
- états : `orchestrator-runtime.types.ts:1-18` ;
- transitions déclarées : `orchestrator-runtime.service.ts:21-104` ;
- création et admission initiale : `orchestrator-runtime.service.ts:350-390` ;
- agent, lock, contexte et exécution : `orchestrator-runtime.service.ts:392-498` ;
- rapport et validations : `orchestrator-runtime.service.ts:500-540` ;
- décision terminale : `orchestrator-runtime.service.ts:543-554`.

La recherche de `createOrchestratorRuntime`, `createMissionRuntime`, `OrchestratorRuntimeService` et `orchestrator-runtime` hors de ce répertoire ne trouve aucun appel de production. La recherche de ces symboles et chemins dans `tools/cerebrau/*.ps1` et `*.psm1` ne trouve aucun résultat. Cette chaîne n'est donc pas la continuation du Runtime PowerShell.

## 4. Correspondance avec les étapes demandées

| Étape demandée | Réalité codée | Preuve |
|---|---|---|
| PowerShell | Oui : deux CLI, Campaign et mission unitaire | `Invoke-CerebrauCampaign.ps1:1-52`; `Invoke-CerebrauMission.ps1:1-465` |
| Mission Loader | Aucun composant portant ce nom. Le JSON est lu directement | `Invoke-CerebrauMission.ps1:31-35,163-165` |
| Mission Manifest Loader | Le script `Test-CerebrauMission.ps1` lit et valide le JSON | `Test-CerebrauMission.ps1:8-149` |
| Campaign | Amont et optionnelle ; absente en exécution directe | `Cerebrau.Campaign.psm1:747-756`; `ContextAssembly.psm1:200-202` |
| Context Assembly | Optionnelle, entre snapshot avant et Codex | `Invoke-CerebrauMission.ps1:247-261` |
| Validation | Pré-exécution pour le manifeste ; post-exécution pour le livrable | `Invoke-CerebrauMission.ps1:155-161,354-356` |
| Authorization | Aucune étape de ce nom dans la chaîne PowerShell. L'autorité Campaign est contrôlée pour existence et hash, sans branchement `GO/NO_GO` | `Cerebrau.Campaign.psm1:303-306,339-340,391-392` |
| Execution | Pipe du prompt vers `codex exec` | `Invoke-CerebrauMission.ps1:263-311` |
| Evidence | Journal, snapshots, delta ; index de preuves seulement en Campaign ; références de contexte seulement si option activée | `Invoke-CerebrauMission.ps1:49-143,241-245,343-352`; `Cerebrau.Campaign.psm1:537-560` |
| Reporting | Rapport unitaire, puis projection Campaign si appelée | `Invoke-CerebrauMission.ps1:364-445`; `Cerebrau.Campaign.psm1:777-812` |

Il n'existe donc aucun graphe réel ayant l'ordre demandé
`PowerShell → Mission Loader → Mission Manifest Loader → Campaign → Context → Validation → Authorization → Execution → Evidence → Reporting`.

## 5. Point de décision

### 5.1 Décision automatique réellement exécutée par PowerShell

| Élément | Identification |
|---|---|
| Fichier | `tools/cerebrau/Cerebrau.Reporting.psm1` |
| Classe | Aucune |
| Fonction | `Get-CerebrauClassification` |
| Lignes | `285-297` |
| Appelant | `Invoke-CerebrauMission.ps1:360-362` |
| Entrées | Exit code, statut technique, delta Git, validations, revue requise, changements attendus |
| Sorties | `CANCELLED`, `FAILED`, `PARTIAL`, `BLOCKED`, `NO_CHANGE`, `READY_FOR_REVIEW`, `SUCCESS` |

Cette fonction est l'unique classificateur du rapport officiel unitaire. Elle ne produit pas `ACCEPTED` ou `REJECTED`.

### 5.2 Revue Campaign

| Élément | Identification |
|---|---|
| Fichier | `tools/cerebrau/Cerebrau.Campaign.psm1` |
| Classe | Aucune |
| Fonction | `Set-CerebrauCampaignReview` |
| Lignes | `929-942` |
| Décision reçue | Paramètre externe `APPROVE` ou `REJECT` |
| Effet | `SUCCEEDED` ou `FAILED` |
| Limite explicite | `GateDecisionModified=false` |

La fonction ne choisit pas elle-même : elle applique le paramètre reçu. Elle ne produit pas les états `ACCEPTED/REJECTED`.

### 5.3 États terminaux TypeScript

| Élément | Autorisation finale | Refus final |
|---|---|---|
| Fichier | `orchestrator-runtime.service.ts` | `orchestrator-runtime.service.ts` |
| Classe | `OrchestratorRuntimeService` | `OrchestratorRuntimeService` |
| Méthode | `approveMission` | `rejectMission` |
| Lignes | `543-548` | `550-555` |
| Événement | `FinalValidationAccepted` | `FinalValidationRejected` |
| Transition | `HUMAN_VALIDATION → ACCEPTED` | `HUMAN_VALIDATION → REJECTED` |

Les deux méthodes transmettent un événement à la méthode privée `transition`, puis à `OrchestratorEventBus.publish`, qui valide l'événement et applique `mission.state = event.targetState` (`orchestrator-runtime.service.ts:581-600,140-175`). Le choix entre acceptation et rejet demeure celui de l'appelant externe ; aucune condition métier ne sélectionne l'une des deux méthodes.

### 5.4 Démonstration formelle de l'absence de décideur unique

Soit `P` la chaîne démarrant à `Invoke-CerebrauMission.ps1`.

- Les seuls appels externes de `P` sont les scripts/modules PowerShell, Git et Codex décrits en section 3.2.
- Aucun appel de `P` ne cible `server/cerebrau-runtime/orchestrator-runtime/**`.
- Le statut officiel de `P` appartient à l'ensemble `{CANCELLED, FAILED, PARTIAL, BLOCKED, NO_CHANGE, READY_FOR_REVIEW, SUCCESS}`.
- `ACCEPTED` et `REJECTED` appartiennent au type TypeScript `MissionState` et sont atteints par deux méthodes publiques distinctes.
- Le texte Codex n'est pas autoritatif et n'est pas parsé pour ces deux libellés.

Donc aucune fonction, méthode ou classe atteignable depuis `P` ne prend une décision binaire finale `MISSION ACCEPTED` / `MISSION REJECTED`. Le décideur unique demandé n'existe pas dans le code observé.

## 6. Causes de non-admission, blocage, échec ou rejet implémentées

Les mots « refus » et « rejet » ne correspondent pas à un état commun. Le registre ci-dessous conserve les catégories exactes du code.

### 6.1 Runtime unitaire — refus avant exécution

| Cause prouvée | Code ou exception | Preuve |
|---|---|---|
| Fichier mission absent | `CEREBRAU_MISSION_FILE_NOT_FOUND` | `Test-CerebrauMission.ps1:8-10` |
| JSON mission illisible | exception `ConvertFrom-Json` | `Test-CerebrauMission.ps1:12` |
| Propriété obligatoire absente | `CEREBRAU_MISSION_PROPERTY_MISSING` | `Test-CerebrauMission.ps1:14-31` |
| Mission désactivée | `CEREBRAU_MISSION_DISABLED` | `Test-CerebrauMission.ps1:34-36` |
| Repository, working directory ou prompt absent | `CEREBRAU_REPOSITORY_NOT_FOUND`, `CEREBRAU_WORKING_DIRECTORY_NOT_FOUND`, `CEREBRAU_PROMPT_FILE_NOT_FOUND` | `Test-CerebrauMission.ps1:38-48` |
| Working directory différent du repository résolu | `CEREBRAU_WORKING_DIRECTORY_OUTSIDE_REPOSITORY` | `Test-CerebrauMission.ps1:50-55` |
| Resolveur/registre/profil absent ou inconnu | `CEREBRAU_PROFILE_RESOLVER_NOT_FOUND`, `CEREBRAU_PROFILE_REGISTRY_NOT_FOUND`, `CEREBRAU_PROFILE_UNKNOWN` | `Test-CerebrauMission.ps1:57-63`; `Resolve-CerebrauProfile.ps1:11-30` |
| Contrat/type/commande/path de validation invalide | `CEREBRAU_VALIDATION_CONTRACT_INVALID`, `CEREBRAU_VALIDATION_TYPE_NOT_ALLOWED`, `CEREBRAU_NAMED_COMMAND_NOT_ALLOWED`, `CEREBRAU_VALIDATION_PATH_MISSING`, `CEREBRAU_VALIDATION_PATH_OUTSIDE_REPOSITORY` | `Test-CerebrauMission.ps1:65-99` |
| Scope de manifeste invalide | `CEREBRAU_MANIFEST_PATH_INVALID` | `Test-CerebrauMission.ps1:102-109` |
| Répertoire de rapport hors repository | `CEREBRAU_REPORT_DIRECTORY_OUTSIDE_REPOSITORY` | `Test-CerebrauMission.ps1:112-116` |
| Branche introuvable ou différente | `CEREBRAU_GIT_BRANCH_UNRESOLVED`, `CEREBRAU_GIT_BRANCH_MISMATCH` | `Test-CerebrauMission.ps1:119-134` |
| Exécutable Codex absent | `CEREBRAU_CODEX_NOT_FOUND` | `Invoke-CerebrauMission.ps1:192-201` |
| Version Codex illisible ou inférieure à `0.144.1` | `CEREBRAU_CODEX_VERSION_NOT_SUPPORTED` | `Invoke-CerebrauMission.ps1:203-224` |

Toute exception top-level produit, si possible, un rapport de secours `FAILED`, puis est relancée (`Invoke-CerebrauMission.ps1:447-464`).

### 6.2 Context Assembly — refus conditionnels

Ces causes n'existent que lorsque le switch de contexte est actif.

| Groupe | Codes exacts | Preuve |
|---|---|---|
| Source invalide, hors scope, absente ou hash incorrect | `CEREBRAU_CONTEXT_SOURCE_PATH_INVALID`, `CEREBRAU_CONTEXT_SOURCE_OUT_OF_SCOPE`, `CEREBRAU_CONTEXT_SOURCE_MISSING`, `CEREBRAU_CONTEXT_SOURCE_HASH_MISMATCH` | `Cerebrau.ContextAssembly.psm1:20-45,96-111` |
| Index de preuves absent ou incohérent | `CEREBRAU_CONTEXT_EVIDENCE_INDEX_MISSING`, `CEREBRAU_CONTEXT_EVIDENCE_INDEX_MISMATCH` | `Cerebrau.ContextAssembly.psm1:148-153,191-195` |
| Campaign absente ou incohérente | `CEREBRAU_CONTEXT_CAMPAIGN_MANIFEST_MISSING`, `CEREBRAU_CONTEXT_CAMPAIGN_REPOSITORY_MISMATCH`, `CEREBRAU_CONTEXT_CAMPAIGN_PROGRAM_MISMATCH`, `CEREBRAU_CONTEXT_CAMPAIGN_BRANCH_MISMATCH` | `Cerebrau.ContextAssembly.psm1:155-162` |
| Mission non rattachée ou fichier différent | `CEREBRAU_CONTEXT_MISSION_NOT_IN_CAMPAIGN`, `CEREBRAU_CONTEXT_CAMPAIGN_MISSION_ORDER_MISMATCH` | `Cerebrau.ContextAssembly.psm1:163-167` |
| Rapport prédécesseur non déclaré comme dépendance | `CEREBRAU_CONTEXT_PREDECESSOR_NOT_REQUIRED` | `Cerebrau.ContextAssembly.psm1:249-254` |

`SOURCE_NOT_APPLICABLE` et `RESUME_REPORT_REJECTED` sont des diagnostics de sélection non bloquants, pas des rejets de mission (`Cerebrau.ContextAssembly.psm1:173-188,256-263`).

### 6.3 Runtime unitaire — classification post-exécution

| Condition | Statut officiel | Preuve |
|---|---|---|
| Statut technique `CANCELLED` | `CANCELLED` | `Cerebrau.Reporting.psm1:287` |
| Exit code Codex non nul | `FAILED` | `Cerebrau.Reporting.psm1:288` |
| Validation obligatoire échouée et delta non vide | `PARTIAL` | `Cerebrau.Reporting.psm1:289-292` |
| Validation obligatoire échouée et delta vide | `BLOCKED` | `Cerebrau.Reporting.psm1:289-292` |
| Changements attendus mais delta vide | `NO_CHANGE` | `Cerebrau.Reporting.psm1:294-295` |

Les validations pouvant alimenter `PARTIAL` ou `BLOCKED` sont : fichier exigé absent, fichier interdit présent, JSON invalide, UTF-8 avec caractère de remplacement, erreur de syntaxe PowerShell, `git diff --check` non nul, commande nommée non nulle, `expectedFile` absent et violation de scope (`Cerebrau.Reporting.psm1:179-244`).

### 6.4 Campaign — preflight global

| Groupe | Causes codées | Preuve |
|---|---|---|
| Structure, version, types, politiques, unicité et chemins | `CAMPAIGN_MANIFEST_FILE_NOT_FOUND`, `CAMPAIGN_MANIFEST_INVALID`, `CAMPAIGN_VERSION_NOT_SUPPORTED`, `CAMPAIGN_MANIFEST_PATH_INVALID`, `CAMPAIGN_MANIFEST_PATH_NOT_FOUND`, `CAMPAIGN_MAX_CONCURRENCY_UNSUPPORTED` | `Cerebrau.Campaign.psm1:28-212,286-310` |
| Repository et branche | `CAMPAIGN_REPOSITORY_INVALID`, `CAMPAIGN_BRANCH_MISMATCH` | `Cerebrau.Campaign.psm1:294-301` |
| Autorité et certification | source d'autorité absente, rapport de certification absent, `CAMPAIGN_AUTHORITY_HASH_MISMATCH` | `Cerebrau.Campaign.psm1:303-306` |
| Références | `CAMPAIGN_PREREQUISITE_REFERENCE_INVALID`, `CAMPAIGN_EVIDENCE_REFERENCE_INVALID` | `Cerebrau.Campaign.psm1:312-330` |
| Dépendances | `CAMPAIGN_DEPENDENCY_NOT_FOUND`, `CAMPAIGN_DEPENDENCY_CYCLE`, `CAMPAIGN_DUPLICATE_MISSION_ID` | `Cerebrau.Campaign.psm1:214-247,323-330,369` |
| Mutation et prérequis | `CAMPAIGN_RUNTIME_MUTATION_PREREQUISITE_INVALID` | `Cerebrau.Campaign.psm1:331-334` |
| Manifeste unitaire | `CAMPAIGN_UNIT_MANIFEST_INVALID`, `CAMPAIGN_UNIT_MANIFEST_MISMATCH`, `CAMPAIGN_UNIT_REVIEW_MISMATCH`, `CAMPAIGN_UNIT_PROMPT_INVALID` | `Cerebrau.Campaign.psm1:335-364` |
| Scopes et rapports | `CAMPAIGN_RESOURCE_SCOPE_MISMATCH`, `CAMPAIGN_DOCUMENTARY_SCOPE_INVALID`, `CAMPAIGN_REPORT_DIRECTORY_CONFLICT` | `Cerebrau.Campaign.psm1:344-356` |
| Gate et DAG de la matrice | `CAMPAIGN_GATE_REFERENCE_INVALID`, `CAMPAIGN_GATE_DEPENDENCY_MISMATCH` | `Cerebrau.Campaign.psm1:250-268,371-379` |
| Preuves partagées | `CAMPAIGN_EVIDENCE_HASH_MISMATCH` pour preuve absente ou périmée au Start | `Cerebrau.Campaign.psm1:382-389` |

Le preflight complet est appelé avant le lock et avant toute mission (`Cerebrau.Campaign.psm1:851-860`). Une seule exception provoque `PREFLIGHT_FAILED` si un état minimal peut être persisté (`Cerebrau.Campaign.psm1:830-848`).

### 6.5 Campaign — admission au ready set, exécution et revue

| Cause | Effet | Preuve |
|---|---|---|
| Dépendance non `SUCCEEDED` | `BLOCKED_DEPENDENCY / DEPENDENCY_NOT_SUCCEEDED` | `Cerebrau.Campaign.psm1:579-580` |
| Prérequis non `SATISFIED` | `BLOCKED_PREREQUISITE / PREREQUISITE_NOT_SATISFIED` | `Cerebrau.Campaign.psm1:582-583` |
| Preuve non `VALID` | `BLOCKED_EVIDENCE / EVIDENCE_NOT_VALID` | `Cerebrau.Campaign.psm1:585-586` |
| Dérive du fingerprint au Resume | `STALE / INPUT_FINGERPRINT_DRIFT` | `Cerebrau.Campaign.psm1:875-878` |
| Rapport unitaire invalide | `CAMPAIGN_UNIT_RESULT_INVALID` ou `UNIT_RESULT_INVALID` | `Cerebrau.Campaign.psm1:689-708,753-760` |
| Exception du Runtime unitaire | `FAILED / UNIT_EXECUTION_EXCEPTION` | `Cerebrau.Campaign.psm1:747-765` |
| Statut unitaire `BLOCKED`, `FAILED`, `CANCELLED` | `FAILED/UNIT_BLOCKED`, `FAILED/UNIT_FAILED`, `CANCELLED/UNIT_CANCELLED` | `Cerebrau.Campaign.psm1:675-686` |
| Politique `STOP_ALL` après résultat autre que `SUCCEEDED` | Campaign `FAILED`, autres missions `SKIPPED/STOP_ALL` | `Cerebrau.Campaign.psm1:898-900` |
| Revue humaine `REJECT` avec hash de rapport valide | Mission Campaign `FAILED`, événement `MISSION_REVIEW_REJECTED` | `Cerebrau.Campaign.psm1:929-941` |

### 6.6 Locks, état et reprise Campaign

| Cause | Code | Preuve |
|---|---|---|
| Lock actif non orphelin | `CAMPAIGN_LOCKED` | `Cerebrau.Campaign.psm1:505-525` |
| État ou journal invalide | `CAMPAIGN_STATE_INVALID`, `CAMPAIGN_JOURNAL_INVALID` | `Cerebrau.Campaign.psm1:448-503` |
| Start sur état existant | `CAMPAIGN_STATE_ALREADY_EXISTS` | `Cerebrau.Campaign.psm1:861-864` |
| Resume interdit par politique, état `CANCELLED`/`COMPLETED` ou manifeste modifié | `CAMPAIGN_RESUME_NOT_ALLOWED` | `Cerebrau.Campaign.psm1:462-468,488-493,867-879` |

`Find-CerebrauRecoverableUnitReport` et `Resolve-CerebrauInterruptedAttempts` (`Cerebrau.Campaign.psm1:700-727`) récupèrent uniquement un rapport unitaire après interruption d'une Campaign. Ce mécanisme n'est pas une Recovery Lane d'admission de missions.

### 6.7 Gardes et refus des opérations auxiliaires

Ces codes n'ajoutent pas de cause d'admission d'une mission, mais ils sont exhaustivement conservés parce qu'ils refusent une opération Runtime ou Campaign :

| Opération refusée | Code | Preuve |
|---|---|---|
| Garde du wrapper unitaire si le validateur retournait autre chose que `VALID` | `CEREBRAU_MISSION_NOT_VALID` | `Invoke-CerebrauMission.ps1:155-160` |
| Garde Campaign si le validateur unitaire retournait autre chose que `VALID` | `UNIT_VALIDATOR_REJECTED`, enveloppé en `CAMPAIGN_UNIT_MANIFEST_INVALID` | `Cerebrau.Campaign.psm1:357-362` |
| Lecture d'un index de preuves Campaign invalide | `CAMPAIGN_EVIDENCE_INDEX_INVALID` | `Cerebrau.Campaign.psm1:537-542` |
| Consultation/contrôle sans état | `CAMPAIGN_STATE_NOT_FOUND`, `CAMPAIGN_CONTROL_REFUSED` | `Cerebrau.Campaign.psm1:910-926` |
| Requête de contrôle illisible | `CAMPAIGN_CONTROL_INVALID` | `Cerebrau.Campaign.psm1:598-602` |
| Revue hors état attendu ou hash de rapport différent | `CAMPAIGN_REVIEW_INVALID` | `Cerebrau.Campaign.psm1:929-941` |
| Rollback inéligible ou bundle incomplet | `CAMPAIGN_ROLLBACK_NOT_ELIGIBLE` | `Cerebrau.Campaign.psm1:604-629,945-955` |
| Conflit de contenu après tentative | `ROLLBACK_REFUSED_CONFLICT` | `Cerebrau.Campaign.psm1:650-662,956` |
| Vérification après restauration échouée | `CAMPAIGN_ROLLBACK_VERIFICATION_FAILED` | `Cerebrau.Campaign.psm1:957-958` |

### 6.8 Runtime TypeScript — causes réellement exécutables

| Cause | Code | Preuve |
|---|---|---|
| Définition incomplète : identité/type/objectif, scope, livrables/critères, autorité | `ORCH-ERR-008`, `ORCH-ERR-009`, `ORCH-ERR-015` | `orchestrator-runtime.service.ts:654-667` |
| Mission dupliquée, absente ou mauvais état | `ORCH-ERR-002`, `ORCH-ERR-003` | `orchestrator-runtime.service.ts:350-355,669-683` |
| Événement ou transition invalide | `ORCH-ERR-004`, `ORCH-ERR-005` | `orchestrator-runtime.service.ts:140-175,205-248` |
| Agent absent, inconnu ou non autorisé pour type/scope | `ORCH-ERR-006` | `orchestrator-runtime.service.ts:392-399,627-651` |
| Lock en conflit ou lock actif absent au démarrage | `ORCH-ERR-013`, `ORCH-ERR-012` | `orchestrator-runtime.service.ts:402-435,458-467` |
| Contexte non créé | `ORCH-ERR-008` | `orchestrator-runtime.service.ts:470-479` |
| Rapport sans confirmation de scope ou sans livrable | `ORCH-ERR-018` | `orchestrator-runtime.service.ts:500-510` |
| Rejet terminal demandé par l'autorité | `FinalValidationRejected`, état `REJECTED` | `orchestrator-runtime.service.ts:550-554` |

Les transitions `TechnicalValidationRejectedFinal`, `DocumentaryValidationRejectedFinal`, `ValidationRejected` et `RevisionRejected` sont déclarées dans la table `TRANSITIONS` (`orchestrator-runtime.service.ts:77-99`), mais aucune méthode publique du service ne les émet. Elles ne constituent donc pas des causes atteignables par l'API publique observée. Les codes `ORCH-ERR-011` et `ORCH-ERR-017` figurent dans le type `RuntimeErrorCode` (`orchestrator-runtime.types.ts:59-72`) mais ne sont jamais produits par le service observé.

### 6.9 Vérification des exemples de la mission

| Exemple | Fait codé |
|---|---|
| `PROGRAM` | `programId`/`program` doit correspondre entre Campaign et unité (`Cerebrau.Campaign.psm1:339-340`) et dans le contexte (`ContextAssembly.psm1:161`). La valeur `programDecision` est copiée dans l'état et les rapports ; aucun branchement `GO/NO_GO` n'existe (`Cerebrau.Campaign.psm1:439-445,785-790`). |
| `FREEZE` | Aucun contrôle `FREEZE` n'existe dans les scripts/modules Runtime ou dans l'Orchestrator TypeScript observés. Ce n'est pas une cause de refus implémentée. |
| `LOCK` | Oui : `CAMPAIGN_LOCKED`, `ORCH-ERR-012`, `ORCH-ERR-013`. |
| `HASH` | Oui : hash d'autorité, preuves Campaign, sources de contexte, fingerprint de reprise et hash de rapport de revue. |
| `MANIFEST` | Oui : validation unitaire et preflight Campaign global. |
| `CERTIFICATION` | Le fichier `authority.certificationReportPath` doit exister au preflight ; son contenu et une décision de certification ne sont pas validés. |
| `CONTEXT` | Oui, uniquement lorsque l'option est active. |
| `DEPENDENCIES` | Oui : références/cycles au preflight, puis états des dépendances dans le ready set. |
| Work Packages | Aucun contrôle de Work Package n'est présent dans ces chaînes. |

## 7. Recovery Lane — localisation prouvable

### 7.1 État du code

La recherche des symboles `Recovery Lane`, `RECOVERY_LANE`, `RecoveryLane`, `EVIDENCE_PRODUCTION` et `CERTIFICATION_REMEDIATION` dans le code exécutable ne trouve aucune implémentation. `READ_ONLY_EVIDENCE` existe uniquement comme valeur d'`executionMode` Campaign (`Cerebrau.Campaign.psm1:207`). Les déclarations `READ_ONLY_SOURCE` du Context Assembly décrivent des sources de contexte et non une voie d'admission (`Cerebrau.ContextAssembly.psm1:224-238`).

Il n'existe donc aucun fichier, classe, fonction ou méthode actuel pouvant être désigné comme point d'insertion interne déjà réservé.

### 7.2 Frontière exacte imposée par le graphe actuel

La seule frontière de raccordement démontrable sans traverser les refus globaux de Campaign est :

```text
voie distincte
  → frontière d'appel de tools/cerebrau/Invoke-CerebrauMission.ps1
  → avant MISSION_VALIDATED (lignes 155-161)
```

Cette frontière est l'interface top-level du script, paramètres `Invoke-CerebrauMission.ps1:1-8`, avant l'entrée dans la séquence instrumentée `Invoke-CerebrauMission.ps1:145-161`.

Démonstration d'unicité de cette frontière :

1. Toute branche placée après `Test-CerebrauCampaignManifest` reste inaccessible lorsque le manifeste Campaign, l'autorité, la certification, un manifeste unitaire ou une preuve fait échouer le preflight (`Cerebrau.Campaign.psm1:854-855`).
2. Le ready set est lui aussi postérieur au preflight et applique les dépendances, prérequis et preuves (`Cerebrau.Campaign.psm1:572-596`).
3. Le Context Assembly est postérieur à la validation unitaire et optionnel (`Invoke-CerebrauMission.ps1:247-261`) ; il ne peut pas fournir une voie d'admission indépendante.
4. La validation post-exécution, la classification et le reporting sont postérieurs à Codex ; ils sont trop tardifs pour autoriser une mission (`Invoke-CerebrauMission.ps1:343-422`).
5. L'Orchestrator TypeScript n'est relié à aucun appel PowerShell observé.
6. Le seul exécuteur commun des missions directes et des unités Campaign est `Invoke-CerebrauMission.ps1`, appelé par `Invoke-CerebrauUnitMission` aux lignes 749 et 751 et identifié comme `unitRuntime` à la ligne 788.

La conclusion exacte est donc double :

- le point de convergence d'exécution est prouvé : frontière d'appel de `Invoke-CerebrauMission.ps1`, avant la ligne 155 ;
- le point de décision Recovery à l'intérieur d'un composant existant n'existe pas et ne peut pas être nommé sans inventer du code.

Cette constatation ne décrit aucune implémentation. Elle exclut seulement, par le graphe réel, tous les emplacements qui resteraient derrière un blocage Campaign ou après le début de l'exécution.

## 8. Fichiers et empreintes de la preuve

| Fichier | État Git observé | SHA-256 observé |
|---|---|---|
| `tools/cerebrau/Invoke-CerebrauMission.ps1` | modifié avant l'audit | `1707D60706F630CCEC3B464DE3A7687029CA7A73C3E9ED1D887D1D2CD9784FF3` |
| `tools/cerebrau/Test-CerebrauMission.ps1` | suivi, non modifié | `9E68B728A8BBEBD82195A722DA689762B28489F3A7AB66D3CF3505E587C1D3EF` |
| `tools/cerebrau/Resolve-CerebrauProfile.ps1` | modifié avant l'audit | `704B2F70D16448EDFF3F6D8C833DBB152DBF1F0C66F9021E25C83F9C52BAA389` |
| `tools/cerebrau/Cerebrau.Reporting.psm1` | modifié avant l'audit | `1166C1D0EBD6B20EDC1F055B9131AF51A48AB2414BF905E988E52568DFE78F31` |
| `tools/cerebrau/Cerebrau.ContextAssembly.psm1` | non suivi avant l'audit | `DAB748AEEB9D6A62C8E628579B170B6F20E1987CAE87C0FD9CDCE5178286A995` |
| `tools/cerebrau/Invoke-CerebrauCampaign.ps1` | non suivi avant l'audit | `A6ABB87C8B1DC21E059009BEB4CBF35B57756497D6DD5C8BE79909A9322AD060` |
| `tools/cerebrau/Cerebrau.Campaign.psm1` | non suivi avant l'audit | `3EB017DB77183A324B2D8B2F6AE6BF400D33CCC18F834AE024F710A366DAAFED` |
| `server/cerebrau-runtime/orchestrator-runtime/orchestrator-runtime.ts` | suivi, non modifié | `66308D27AC9E11FD94EB6B08BA64048DE404EC0E1A1555EBA514484C071A6E9C` |
| `server/cerebrau-runtime/orchestrator-runtime/orchestrator-runtime.types.ts` | suivi, non modifié | `4093E5AD29C412053F341907DE194DAB989073812A4D9C7F67B9CA3435B3420A` |
| `server/cerebrau-runtime/orchestrator-runtime/orchestrator-runtime.service.ts` | suivi, non modifié | `8E22EB0C696A771FA6AA465854EFE846B978FF31B2A0C63BBB090D67AFEF7DB7` |
| `tools/cerebrau/prompt.md` | modifié avant l'audit | `E2BE00B96FBCD5F62774D398878059528D0E8FC6DE29EFC823B338ECE2DE3D70` |

Les fichiers marqués modifiés ou non suivis l'étaient avant la création de ce rapport. Ils ont été lus comme état effectif du code et n'ont pas été modifiés par l'audit.

## 9. Verdict

`PASS` pour la mission d'audit :

- point d'entrée du Runtime unitaire : identifié ;
- graphe réel : reconstruit sans ajouter les étapes absentes ;
- fichiers, fonctions, classe et méthodes : identifiés ;
- causes de refus/blocage/échec : recensées selon chaque machine d'état ;
- décideur final unique `MISSION ACCEPTED/REJECTED` : inexistence formellement démontrée ;
- Recovery Lane actuelle : absente ;
- frontière d'exécution à laquelle une voie distincte devrait nécessairement converger : identifiée avant `Invoke-CerebrauMission.ps1:155` ;
- aucun code, script, manifeste, test ou autre document modifié ou créé par cet audit.
