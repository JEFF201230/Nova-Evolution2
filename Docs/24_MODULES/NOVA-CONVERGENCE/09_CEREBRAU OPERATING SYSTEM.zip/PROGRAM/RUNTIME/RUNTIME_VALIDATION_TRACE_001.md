# RUNTIME-VALIDATION-TRACE-001 — Trace du chemin de validation runtime

## 1. Verdict

Le journal ne copie pas un littéral `VALIDATION_STARTED` présent dans le dépôt.
Il le construit à l'exécution à partir du nom d'étape `VALIDATION` et du suffixe
`_STARTED`.

Pour l'exécution bloquée
`tools/cerebrau/reports/bootstrap-20260726T185830024`, l'appel qui ne rend pas
la main est la validation `gitDiffCheck`, et non `powershellSyntax` ni le parse
PowerShell du module. Le processus exécute encore l'ancienne version de
`Invoke-CerebrauValidation`, importée en mémoire avant que la mission ne
remédie le fichier sur disque. Cette version lance `git diff --check`, redirige
ses deux sorties, lit `stdout` puis `stderr` séquentiellement et n'impose aucun
timeout. L'attente se produit sur
`$process.StandardOutput.ReadToEnd()` pendant que `git` peut être bloqué par la
sortie `stderr` non drainée.

## 2. Fichiers et artefacts concernés

| Rôle | Chemin |
|---|---|
| Lanceur réellement exécuté | `tools/cerebrau/Invoke-CerebrauMission.ps1` |
| Module de reporting et de validation | `tools/cerebrau/Cerebrau.Reporting.psm1` |
| Commande nommée de syntaxe | `tools/cerebrau/Test-CerebrauSyntax.ps1` |
| Journal bloqué principal | `tools/cerebrau/reports/bootstrap-20260726T185830024/execution-journal.jsonl` |
| Delta de cette exécution | `tools/cerebrau/reports/bootstrap-20260726T185830024/mission-delta.json` |
| Preuve des entrées capturées avant exécution | `tools/cerebrau/reports/bootstrap-20260726T185830024/input-evidence.json` |
| Manifeste exact sauvegardé avant exécution | `C:\Users\JEFF1\AppData\Local\Temp\cerebrau-before-bootstrap-20260726T185830024\tools\cerebrau\mission.json` |
| Module exact sauvegardé avant exécution | `C:\Users\JEFF1\AppData\Local\Temp\cerebrau-before-bootstrap-20260726T185830024\tools\cerebrau\Cerebrau.Reporting.psm1` |
| Rapport de remédiation produit pendant l'exécution | `Docs/PROGRAM/RUNTIME/CEREBRAU_GITDIFF_DEADLOCK_REPORT_001.md` |
| Test de non-régression produit pendant l'exécution | `tools/cerebrau/Test-CerebrauReporting.ps1` |

Le manifeste historique récupéré a pour SHA-256
`3F8218586972972A462595E3E0ED3C45D9715747A7D7AA003A7106B93C6DF121`.
Le module historique récupéré a pour SHA-256
`7F99A6A65D0F2BE23700360FD37701D9CD505148AB3BE6BC88086AC9C7667509`.

## 3. Code exact qui écrit `VALIDATION_STARTED`

L'appel de validation du lanceur est :

```powershell
$validationResults = @(Invoke-CerebrauInstrumentedStage -StageName 'VALIDATION' -Action {
    Invoke-CerebrauValidation -Mission $mission -Repository $validatedMission.Repository -Delta $missionDelta
} -Repository $validatedMission.Repository)
```

Il se trouve dans `tools/cerebrau/Invoke-CerebrauMission.ps1`, lignes 731 à
733.

`Invoke-CerebrauInstrumentedStage`, lignes 392 à 412 du même fichier, écrit
l'événement par ce code exact :

```powershell
Write-ExecutionJournalEntry -Step ($StageName + '_STARTED') -Status 'STARTED'
```

Avec `StageName = 'VALIDATION'`, l'expression
`$StageName + '_STARTED'` produit `VALIDATION_STARTED`.

`Write-ExecutionJournalEntry` (lignes 61 à 84) place cette valeur dans la
propriété JSON `step`, puis appelle `Write-CerebrauJournalLine`. Cette dernière
fonction (lignes 86 à 105) ouvre
`$runDirectory/execution-journal.jsonl`, se positionne à la fin, écrit les
octets UTF-8 et force leur vidage sur disque avec `Flush($true)`.

## 4. Pourquoi les recherches ne trouvaient rien

Deux différences expliquent les recherches sans résultat :

1. `VALIDATION_STARTED` est une valeur calculée. Le code source contient
   séparément le nom d'étape `'VALIDATION'` à la ligne 731 et le suffixe
   `'_STARTED'` à la ligne 400. Il ne contient pas le littéral composé dans le
   code exécutable.
2. La fonction appelée est au singulier :
   `Invoke-CerebrauValidation`. Elle est définie dans
   `tools/cerebrau/Cerebrau.Reporting.psm1` et appelée à la ligne 732 du
   lanceur. `Invoke-CerebrauValidations`, au pluriel, n'existe pas.

Les occurrences actuelles du littéral dans `tools/cerebrau/prompt.md`
appartiennent au texte de la présente mission ; elles ne participent pas à
l'exécution.

## 5. Pile d'appels complète

La pile fonctionnelle menant à l'écriture puis au blocage est la suivante :

```text
Invoke-CerebrauMission.ps1
├─ initialise runDirectory et journalPath
├─ Invoke-CerebrauInstrumentedStage('REPORTING_MODULE_IMPORTED')
│  └─ Import-Module Cerebrau.Reporting.psm1 -Force
├─ Invoke-CerebrauInstrumentedStage('MISSION_VALIDATED')
│  └─ Test-CerebrauMission.ps1
├─ Invoke-CerebrauInstrumentedStage('MISSION_READ')
│  └─ Get-Content mission.json | ConvertFrom-Json
├─ Invoke-CerebrauInstrumentedStage('CODEX_EXECUTION')
│  └─ Invoke-CerebrauCodexProcess
│     └─ la mission modifie Cerebrau.Reporting.psm1 sur disque
├─ Invoke-CerebrauInstrumentedStage('CAPTURE_GIT_AFTER')
│  └─ New-CerebrauWorkspaceSnapshot
├─ Invoke-CerebrauInstrumentedStage('GIT_DELTA_COMPUTED')
│  └─ Compare-CerebrauWorkspaceSnapshot
└─ Invoke-CerebrauInstrumentedStage('VALIDATION')
   ├─ Write-ExecutionJournalEntry('VALIDATION_STARTED', 'STARTED')
   │  └─ Write-CerebrauJournalLine
   │     └─ FileStream.Write + FileStream.Flush(true)
   └─ scriptblock Action
      └─ Invoke-CerebrauValidation
         ├─ validation 1 : namedCommand/powershellSyntax
         │  └─ Invoke-CerebrauNamedCommand
         │     └─ powershell.exe -File Test-CerebrauSyntax.ps1
         ├─ validation 2 : powershell/reporting-module
         │  └─ Language.Parser.ParseFile(Cerebrau.Reporting.psm1)
         └─ validation 3 : gitDiffCheck
            ├─ ProcessStartInfo('git', 'diff --check')
            ├─ Process.Start()
            ├─ StandardOutput.ReadToEnd()       ← attente effective
            ├─ StandardError.ReadToEnd()        ← non atteint tant que stdout ne ferme pas
            └─ WaitForExit()                    ← non atteint tant que les lectures ne finissent pas
```

## 6. Identification de la validation bloquante

Le manifeste historique, sauvegardé avant la mission, impose cet ordre :

1. `powershell-syntax` — type `namedCommand`, commande
   `powershellSyntax` ;
2. `reporting-module` — type `powershell`, chemin
   `tools/cerebrau/Cerebrau.Reporting.psm1` ;
3. `git-diff-check` — type `gitDiffCheck`.

Les contrôles ciblés effectués sur les artefacts historiques excluent les deux
premiers appels :

| Appel | Résultat ciblé |
|---|---|
| `powershell.exe -File Test-CerebrauSyntax.ps1` de la sauvegarde historique | code retour `0`, aucune sortie, `725 ms` |
| `Language.Parser.ParseFile` sur le module historique de la mission | `0` erreur |
| `git diff --check`, sorties drainées simultanément pour la mesure | code retour `0`, `0` caractère sur `stdout`, `5 037` caractères sur `stderr` |

Le journal principal se termine par
`VALIDATION_STARTED` à `2026-07-26 19:05:28` heure de Paris
(`2026-07-26T17:05:28Z`). Il ne contient ni `VALIDATION_FINISHED`, ni entrée
d'exception `VALIDATION`. Une exception aurait été capturée par le `catch` de
`Invoke-CerebrauInstrumentedStage` et journalisée. L'absence de ces deux
événements caractérise une attente interne qui ne rend pas la main.

Un second journal indépendant,
`tools/cerebrau/reports/bootstrap-20260726T152148406/execution-journal.jsonl`,
se termine de la même manière. Son manifeste historique ordonne également
`powershellSyntax`, un parse PowerShell, puis `gitDiffCheck`. Le dernier appel
commun aux deux chemins bloqués est donc `gitDiffCheck`.

## 7. Cause racine démontrée

La cause comporte deux éléments indissociables.

### 7.1 Ancienne fonction conservée en mémoire

Le lanceur importe `Cerebrau.Reporting.psm1` aux lignes 420 à 422, avant le
début de `CODEX_EXECUTION`. Durant cette exécution, la mission modifie ensuite
le fichier sur disque. Le delta autoritatif confirme :

- `tools/cerebrau/Cerebrau.Reporting.psm1` modifié ;
- `tools/cerebrau/Test-CerebrauReporting.ps1` modifié ;
- `Docs/PROGRAM/RUNTIME/CEREBRAU_GITDIFF_DEADLOCK_REPORT_001.md` créé.

Le module n'est jamais réimporté après `CODEX_EXECUTION`. La validation utilise
donc la définition déjà chargée, c'est-à-dire celle de la sauvegarde
`workspace-before`, et non la remédiation présente sur disque.

### 7.2 Lecture séquentielle sans borne des sorties de `git`

Dans le module historique, lignes 202 à 216, la branche `gitDiffCheck`
exécute exactement :

```powershell
$process = [Diagnostics.Process]::Start($startInfo)
$standardOutput = $process.StandardOutput.ReadToEnd()
$standardError = $process.StandardError.ReadToEnd()
$process.WaitForExit()
```

Les deux pipes sont redirigés, mais un seul est drainé à la fois. Le parent
attend la fermeture de `stdout` dans `ReadToEnd()`. `git diff --check` écrit
principalement ses avertissements de conversion LF/CRLF sur `stderr`. Si ce
pipe atteint sa capacité avant d'être lu, `git` attend qu'il soit drainé et ne
termine pas ; le parent attend simultanément la terminaison de `git` pour
obtenir la fin de `stdout`. Aucun timeout ne borne cette attente.

Le point bloquant côté PowerShell est donc
`$process.StandardOutput.ReadToEnd()` à la ligne 212 du module historique. Le
processus enfant correspondant est `git diff --check`, bloqué côté écriture
sur son pipe `stderr`. `StandardError.ReadToEnd()` et `WaitForExit()` ne sont
pas encore atteints.

La version actuellement présente sur disque déplace ce traitement dans
`Invoke-CerebrauGitDiffCheck`, démarre `ReadToEndAsync()` sur les deux flux
avant l'attente et impose un timeout. Cette correction ne pouvait toutefois
pas réparer le processus qui avait déjà importé l'ancienne version.

## 8. Conclusion

`VALIDATION_STARTED` est produit par instrumentation générique et concaténation
dynamique ; sa présence dans le journal sans littéral source est donc normale.
Le blocage qui suit est précisément l'ancien `gitDiffCheck` chargé en mémoire,
sur la lecture synchrone de `stdout` de `git diff --check`, avec `stderr` non
drainé et sans timeout.

Aucun fichier de code n'a été modifié par la mission
`RUNTIME-VALIDATION-TRACE-001`. Le seul fichier produit est le présent rapport.

D05 : PASS

D06 : PASS

D07 : PASS

GLOBAL : PASS
