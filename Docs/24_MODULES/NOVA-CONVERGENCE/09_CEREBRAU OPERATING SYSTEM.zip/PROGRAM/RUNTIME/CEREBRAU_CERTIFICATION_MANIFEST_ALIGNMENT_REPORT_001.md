# CEREBRAU — Certification Manifest Alignment Report 001

## 1. Identification

| Champ | Valeur |
|---|---|
| Mission | `RUNTIME-CERTIFICATION-MANIFEST-ALIGNMENT-001` |
| Programme | `PROGRAM-CEREBRAU-RUNTIME` |
| Lot | `RUNTIME-ALIGNMENT-001` |
| Type | `REMEDIATION` |
| Date de validation | 2026-07-26 |
| Decision | `PASS` |
| Runtime | `SUCCESS` |
| OfficialStatus | `READY_FOR_REVIEW` |

Cette mission corrige exclusivement le runtime CEREBRAU, ses manifests réutilisables et ses tests. Aucun code métier VEEDDA, aucune implémentation D01–D07, aucune autorité finale et aucun contenu de décision clos n'ont été modifiés.

## 2. Cause racine

Le runtime validait l'existence du manifeste et du prompt séparément, sans contrat sémantique commun. Le manifeste générique `ORCH-001 / LOT-001` pouvait donc être réutilisé avec un prompt portant une autre mission.

Deux défauts amplifiaient cette divergence :

1. l'absence de `changesExpected` était convertie implicitement en `true` dans l'admission, le verrouillage, la Campaign et la classification ;
2. la classification appliquait `NO_CHANGE` à toute mission sans delta lorsque `changesExpected=true`, sans tenir compte d'un type `AUDIT` ou `CERTIFICATION`.

La conclusion textuelle de Codex ne pouvait pas réparer ce défaut : le transcript est non autoritatif et devait le rester.

## 3. Flux runtime avant et après

### Avant

1. lecture du manifeste générique ;
2. admission gouvernée avec `changesExpected=true` par défaut si le champ manque ;
3. validation séparée de l'existence du prompt ;
4. exécution Codex ;
5. delta Git nul ;
6. classification `NO_CHANGE` ;
7. `OutputEvidence.status=INVALID` ;
8. rejet par `FinalAuthority`.

### Après

1. lecture du manifeste ;
2. échec immédiat si `missionType` ou `changesExpected` manque ou est invalide ;
3. lecture UTF-8 stricte du prompt ;
4. extraction obligatoire d'un bloc JSON unique `CEREBRAU_MISSION_CONTRACT` ;
5. comparaison structurée de `missionId`, `missionType`, `lot`, `changesExpected`, `readOnly` et, lorsqu'elle est déclarée, `architecturalDecision` ;
6. contrôle des déclarations explicites équivalentes présentes dans le corps du prompt ;
7. contrôle de la règle canonique du type de mission ;
8. pour `CERTIFICATION`, présence obligatoire d'au moins une validation structurée marquée `required=true` ;
9. exécution Codex seulement après succès du preflight ;
10. classification selon le type, l'attente de delta, le delta observé et les validations ;
11. création des preuves structurées ;
12. décision inchangée de `FinalAuthority`.

## 4. Contrat et règles explicites

### 4.1 Types canoniques

| MissionType | changesExpected | readOnly |
|---|---:|---:|
| `IMPLEMENTATION` | `true` | `false` |
| `REMEDIATION` | `true` | `false` |
| `AUDIT` | `false` | `true` |
| `CERTIFICATION` | `false` | `true` |

Le manifeste doit porter explicitement `missionType` et un booléen `changesExpected`. Il n'existe plus de conversion silencieuse d'une valeur absente vers `true`.

Les anciens types explicites restent lisibles, mais leur prompt doit désormais fournir le même contrat structuré. Pour ces types, `readOnly` est déterminé par l'inverse de `changesExpected`.

### 4.2 Classification

| Faits objectifs | Classification |
|---|---|
| exécution annulée | `CANCELLED` |
| ExitCode non nul | `FAILED` |
| validation obligatoire en échec avec delta | `PARTIAL` |
| validation obligatoire en échec sans delta | `BLOCKED` |
| `IMPLEMENTATION` ou `REMEDIATION`, validations réussies, delta nul | `NO_CHANGE` |
| `AUDIT` ou `CERTIFICATION`, validations réussies, delta nul, revue requise | `READY_FOR_REVIEW` |
| `AUDIT`, validations réussies, delta nul, sans revue requise | `SUCCESS` |
| mission read-only avec delta inattendu | `PARTIAL` |
| validations réussies et comportement de delta conforme | `READY_FOR_REVIEW` ou `SUCCESS` selon la revue |

Un delta nul est donc un comportement attendu pour `AUDIT` et `CERTIFICATION`, mais demeure un défaut de résultat pour `IMPLEMENTATION` et `REMEDIATION`.

### 4.3 Preuves de certification

Les validations du manifeste sont exécutées par le runtime et projetées dans :

- `OfficialReport.Validations` ;
- les entrées `VALIDATION:<name>` de `OutputEvidence` ;
- l'empreinte SHA-256 de chaque résultat de validation ;
- `FinalAuthority.validationResults`.

Le texte `CERTIFIED PASS`, le dernier message Codex et le transcript ne sont pas utilisés pour accepter la mission. `Codex.TranscriptAuthoritative` reste `false` et `FinalAuthority.transcriptUsed` reste `false`.

## 5. Fichiers modifiés

### Runtime

- `tools/cerebrau/Test-CerebrauMission.ps1`
- `tools/cerebrau/Invoke-CerebrauMission.ps1`
- `tools/cerebrau/Cerebrau.Reporting.psm1`
- `tools/cerebrau/Cerebrau.Governance.psm1`
- `tools/cerebrau/Cerebrau.Campaign.psm1`

### Manifests et prompts actifs/réutilisables

- `tools/cerebrau/mission.json`
- `tools/cerebrau/prompt.md` — ajout du contrat structuré, sans réécriture du corps de mission préexistant
- `tools/cerebrau/campaigns/demo/demo-a.json`
- `tools/cerebrau/campaigns/demo/demo-a.prompt.md`
- `tools/cerebrau/campaigns/demo/demo-b.json`
- `tools/cerebrau/campaigns/demo/demo-b.prompt.md`
- `tools/cerebrau/campaigns/demo/demo-independent.json`
- `tools/cerebrau/campaigns/demo/demo-independent.prompt.md`

### Tests

- `tools/cerebrau/Test-CerebrauReporting.ps1`
- `tools/cerebrau/Test-CerebrauRuntimeE2E.ps1`
- `tools/cerebrau/Test-CerebrauContextRuntime.ps1`
- `tools/cerebrau/tests/campaign/TestSupport.ps1`

### Livrable

- `Docs/PROGRAM/RUNTIME/CEREBRAU_CERTIFICATION_MANIFEST_ALIGNMENT_REPORT_001.md`

## 6. Tests exécutés

| Commande | Résultat exact |
|---|---|
| `tools/cerebrau/Test-CerebrauSyntax.ps1` | `SUCCESS`, 23 fichiers analysés, 0 erreur |
| `tools/cerebrau/Test-CerebrauMission.ps1` sur le manifeste actif et les trois manifests demo | 4/4 `VALID` |
| `tools/cerebrau/Test-CerebrauReporting.ps1` | `SUCCESS`, 18/18, 0 échec |
| `tools/cerebrau/Test-CerebrauGovernance.ps1` | ExitCode 0, `SUCCESS`, 27/27, 0 échec |
| `tools/cerebrau/Test-CerebrauContextRuntime.ps1` | `SUCCESS`, 14/14, 0 échec |
| `tools/cerebrau/Test-CerebrauRuntimeE2E.ps1` | `SUCCESS`, 34/34, 0 échec |
| `tools/cerebrau/Test-CerebrauCampaign.ps1` | `SUCCESS`, 9/9 suites, 0 échec |
| `git diff --check -- tools/cerebrau` | ExitCode 0 |

Preuves E2E directement liées à la mission :

| Scénario | Résultat exact |
|---|---|
| certification, validations réussies, delta nul | `READY_FOR_REVIEW`; OutputEvidence `VALID`; Authority `PENDING_REVIEW` |
| audit, delta nul, revue non requise | `SUCCESS`; OutputEvidence `VALID`; Authority `ACCEPTED` |
| implementation, delta nul | `NO_CHANGE` |
| `changesExpected` absent | preflight `CEREBRAU_MISSION_PROPERTY_MISSING:changesExpected` |
| MissionId prompt contradictoire | preflight `CEREBRAU_MANIFEST_PROMPT_MISSION_ID_MISMATCH`; aucune entrée Codex créée |
| mission read-only avec delta | `PARTIAL`; OutputEvidence `INVALID`; Authority `REJECTED` |
| certification sans validation obligatoire | preflight `CEREBRAU_CERTIFICATION_REQUIRED_VALIDATION_MISSING` |
| transcript prétendant un résultat contraire au Git | Git conservé comme autorité ; `READY_FOR_REVIEW` sur le delta réel |

## 7. Analyse de régression

- `Resolve-CerebrauFinalAuthorityDecision` n'a pas été affaibli ni contourné.
- Les statuts `NO_CHANGE`, `PARTIAL`, `BLOCKED`, `FAILED` et `CANCELLED` restent rejetés ou non applicables selon la politique existante.
- Les contrôles Git avant/après, allowed paths, forbidden paths, preuves d'entrée, preuves de sortie, locks, freeze et Campaign restent actifs.
- Une écriture inattendue pendant une mission read-only est maintenant rejetée plus strictement.
- La Campaign ne remplace plus silencieusement une absence de `changesExpected` par `true`.
- Le prompt réellement transmis reste identique octet par octet à la source validée, hors enveloppes runtime documentées (`CERTIFIED_FACTS` et contexte optionnel).
- Les tests de Campaign, contexte, gouvernance, capture des flux et autorité continuent de passer.
- Les modifications métier préexistantes du worktree n'ont pas été touchées.
- Aucun commit et aucun push n'ont été effectués.

## 8. Limites restantes

1. Les manifests historiques non canoniques dont les prompts ne possèdent pas encore `CEREBRAU_MISSION_CONTRACT` sont désormais refusés en preflight. Cette incompatibilité est intentionnelle et fail-closed. Les artefacts D01–D04 clos n'ont pas été modifiés ; un éventuel rejeu exigera une migration documentaire autorisée séparément.
2. Le contrat compare l'identité et l'intention déclarées ; il ne tente pas d'inférer la sémantique arbitraire de toute phrase du prompt.
3. Les validations disponibles restent celles de la liste d'autorisation runtime actuelle. Ajouter un nouveau type de validation exige une évolution explicite de cette liste.
4. Cette mission n'accorde aucune autorité automatique à la chaîne `CERTIFIED PASS`.

## 9. Décision finale

Les divergences Manifest/Prompt sont bloquées avant Codex, les attentes de delta sont explicites, les missions read-only sont classifiées sur leurs validations plutôt que sur l'existence d'un delta, et `FinalAuthority` demeure l'autorité finale.

**Decision: PASS**

**Runtime: SUCCESS**

**OfficialStatus: READY_FOR_REVIEW**
