# CEREBRAU Runtime — architecture finale autoritative

## 1. Identification

| Champ | Valeur |
|---|---|
| Document | `CEREBRAU_RUNTIME_FINAL_ARCHITECTURE_001` |
| Mission | `CEREBRAU-RUNTIME-FINALIZATION-001` |
| Programme | `VEEDDA` |
| Objet officiel de gouvernance | `WAVE` |
| Work Packages | Non officiels |
| Point d'entrée de production | `tools/cerebrau/Invoke-CerebrauMission.ps1` |
| Décideur final | `Resolve-CerebrauFinalAuthorityDecision` dans `Cerebrau.Governance.psm1` |
| Date | `2026-07-23` |

Ce document décrit le code exécutable livré. Il ne crée pas une autorité concurrente aux décisions de gouvernance existantes.

## 2. Chaîne autoritative unique

```text
Mission Manifest
  -> GOVERNED_ADMISSION
     -> Recovery Lane contract, si déclaré
     -> Freeze contract, si déclaré
  -> validation ordinaire du manifeste
  -> résolution du profil CEREBRAU
  -> lock unitaire
  -> snapshot et INPUT_EVIDENCE
  -> Context Assembly optionnel
  -> Codex
  -> snapshot et delta
  -> validations post-exécution
  -> TECHNICAL_CLASSIFICATION
  -> OUTPUT_EVIDENCE
  -> FINAL_AUTHORITY_DECISION
  -> rapport officiel et fingerprint
  -> libération vérifiée du lock
```

`Invoke-CerebrauMission.ps1` reste le seul point d'entrée d'exécution unitaire. `Invoke-CerebrauCampaign.ps1` et `Cerebrau.Campaign.psm1` restent un orchestrateur amont. Ils appellent le Runtime unitaire et importent en priorité `FinalMissionState`.

Le package `server/cerebrau-runtime/orchestrator-runtime` est explicitement déclaré `NON_AUTHORITATIVE_DOMAIN_MODEL`. Il demeure un modèle de domaine et un workflow en mémoire. Ses libellés `ACCEPTED` et `REJECTED` ne constituent pas une décision officielle CEREBRAU et ne sont reliés à aucune chaîne de production.

## 3. Séparation classification et décision

Le champ historique `Status` du rapport reste un alias de classification pour compatibilité. Il n'est pas la décision finale.

### 3.1 Matrice des classifications techniques

| Classification | Condition structurée |
|---|---|
| `CANCELLED` | interruption contrôlée |
| `FAILED` | exit code Codex non nul ou échec technique |
| `PARTIAL` | validation requise échouée avec delta |
| `BLOCKED` | validation requise échouée sans delta |
| `NO_CHANGE` | changements requis mais delta vide |
| `READY_FOR_REVIEW` | exécution et validations valides, revue humaine requise |
| `SUCCESS` | exécution et validations valides, revue humaine non requise |

### 3.2 Matrice des décisions finales

| Classification / preuve | Revue | `authorityDecision` | `finalMissionState` |
|---|---|---|---|
| `CANCELLED` | toute | `NOT_APPLICABLE` | `CANCELLED` |
| `FAILED` | toute | `NOT_APPLICABLE` | `FAILED` |
| validation requise invalide | toute | `REJECTED` | `REJECTED` |
| Output Evidence invalide | toute | `REJECTED` | `REJECTED` |
| `PARTIAL`, `BLOCKED`, `NO_CHANGE` | toute | `REJECTED` | `REJECTED` |
| résultats valides | obligatoire, aucune revue | `PENDING_REVIEW` | `READY_FOR_REVIEW` |
| résultats valides | revue structurée acceptée et liée au fingerprint | `ACCEPTED` | `ACCEPTED` |
| résultats valides | revue structurée rejetée et liée au fingerprint | `REJECTED` | `REJECTED` |
| `SUCCESS` et preuves valides | non obligatoire | `ACCEPTED` | `ACCEPTED` |

Une décision humaine structurée doit contenir `decision`, `authority`, `reportFingerprint` et `decidedAt`. Une empreinte différente est refusée.

Le transcript Codex est marqué `TranscriptAuthoritative=false`. Le décideur reçoit uniquement classification, validations, état des preuves, exigence de revue et éventuelle décision structurée. Il ne reçoit ni ne parse le transcript.

## 4. Admission et Recovery Lane

La Recovery Lane est évaluée à la frontière `GOVERNED_ADMISSION`, avant `MISSION_VALIDATED` et avant Codex. Elle n'est donc pas rendue inaccessible par le preflight Campaign ou par l'admission ordinaire.

Classes autorisées :

- `READ_ONLY`;
- `EVIDENCE_PRODUCTION`;
- `AUDIT`;
- `CERTIFICATION_REMEDIATION`.

Contrat obligatoire :

| Champ | Contrôle |
|---|---|
| `recoveryLaneClass` | valeur dans les quatre classes autorisées |
| `recoveryReason` | motif explicite et non vide |
| `blockedRule` | règle précise à lever ou prouver |
| `requiredEvidence` | tableau typé, distinct des sorties à produire |
| `authorizedScope` | tableau non vide de patterns relatifs |
| `authorizedFiles` | vide pour `READ_ONLY`, non vide pour une classe d'écriture |
| `forbiddenFiles` | tableau de patterns relatifs |
| `authority` | autorité déclarée |
| `expirationOrAttemptLimit` | expiration future ou 1 à 10 tentatives |
| `inputFingerprint` | SHA-256 calculé sur les entrées, hors valeur circulaire du fingerprint |

Contrôles supplémentaires :

- chaque fichier autorisé doit être couvert à la fois par `authorizedScope` et `allowedPaths`;
- un fichier couvert par `forbiddenFiles` ou `forbiddenPaths` est refusé;
- les patterns des domaines fonctionnels, de `server/offer`, de `supabase` et des documents Offer sont refusés;
- `READ_ONLY` ne peut déclarer aucun fichier inscriptible;
- une remédiation de certification doit séparer `baselinePath` et `outputReportPath`;
- aucune Recovery Lane n'autorise une décision de Gate, une auto-certification ou une mise en production directe;
- tout paramètre incomplet, classe inconnue, scope dépassé, fichier interdit ou fingerprint divergent est refusé.

## 5. Non Self-Blocking Principle

Le principe est implémenté sans bypass global :

1. la Recovery Lane est autonome de Campaign;
2. elle est évaluée avant l'admission ordinaire;
3. une sortie à produire n'est pas enregistrée comme précondition d'entrée;
4. une certification de remédiation exige une baseline distincte de sa sortie;
5. les exceptions Freeze sont explicites et liées à la classe Recovery;
6. l'exception conserve les scopes et fichiers interdits;
7. aucune exception ne modifie automatiquement une décision de gouvernance;
8. les deux orchestrateurs actifs ou référencés exposent leur frontière d'autorité;
9. les scénarios automatisés `NSB-T01` à `NSB-T12` vérifient ces invariants.

## 6. Registre Input Evidence / Output Evidence

### 6.1 Input Evidence

Le registre `input-evidence.json` est créé après le snapshot initial et avant Codex. Il contient :

- les entrées `inputEvidence` du manifeste, chacune avec chemin relatif et SHA-256;
- le manifeste;
- l'état Git de référence;
- la branche et le dépôt par le contexte d'admission;
- l'indication d'activation du Context Assembly;
- l'empreinte du registre.

Une entrée absente ou dont le hash diverge provoque un refus avant exécution.

### 6.2 Output Evidence

Le registre `output-evidence.json` est créé uniquement après Codex, le delta et les validations. Il contient :

- fichiers créés, modifiés et supprimés;
- SHA-256 des fichiers encore présents;
- résultats structurés de validation;
- classification technique;
- statut global `VALID` ou `INVALID`;
- empreinte du registre.

Le rapport officiel ajoute :

- `InputEvidence`;
- `OutputEvidence`;
- `TechnicalClassification`;
- `FinalAuthority`;
- `AuthorityDecision`;
- `FinalMissionState`;
- `ReportFingerprint`.

Une Input Evidence ne peut pas être ajoutée aux fichiers produits. Une Output Evidence n'est jamais valide avant le delta et sa validation.

## 7. Locks

### 7.1 Lock unitaire

Le lock JSON contient :

```text
missionId
programId
processId
host
startedAt
repository
branch
inputFingerprint
scopeFingerprint
```

Il est créé atomiquement avec `FileMode.CreateNew`. Un lock actif refuse une double exécution. Un lock d'un autre host ne peut pas être déclaré orphelin localement. Un lock local n'est récupéré qu'après preuve d'absence du processus. Il est alors archivé avec suffixe `orphaned.<timestamp>.json`, jamais supprimé silencieusement.

Une dérive d'input ou de scope refuse la reprise. Un rebind n'est possible qu'avec une structure explicite `lockRebindAuthorization` contenant autorité et motif. La libération vérifie mission, processus et fingerprint avant suppression.

### 7.2 Lock Campaign

Le lock Campaign utilise le même contrat, avec :

- `missionId = CAMPAIGN:<campaignId>`;
- `inputFingerprint = CampaignFingerprint`;
- `scopeFingerprint` calculé sur les scopes de ressources.

Un lock orphelin avec fingerprint différent est refusé. Le Runtime TypeScript libère également son lock sur `FAILED`, en plus de `ACCEPTED`, `REJECTED` et `CANCELLED`.

## 8. Freeze générique

Aucune politique métier globale de Freeze n'a été trouvée dans le Runtime exécutable. Le code implémente uniquement le mécanisme générique d'application d'une déclaration autoritative.

Modes reconnus :

| Mode | Effet générique |
|---|---|
| `FULL_FREEZE` | mission normale refusée |
| `WRITE_FREEZE` | mission normale avec écritures refusée |
| `SCOPE_FREEZE` | mission touchant un scope gelé refusée |
| `RELEASE_FREEZE` | mutation normale refusée pendant la phase de levée |

Une exception exige :

- une Recovery Lane valide;
- `freeze.exception.recoveryLaneClass` identique;
- une autorité identique à l'autorité du Freeze;
- un motif explicite.

L'exception ne lève pas le Freeze, ne permet pas une release et ne dilate aucun scope.

## 9. Graphe global Campaign

`Test-CerebrauCampaignManifest` construit le graphe avant lock, état Campaign et exécution. Les nœuds sont typés :

- `AUTHORITY`;
- `MISSION`;
- `GATE`;
- `PREREQUISITE`;
- `INPUT_EVIDENCE`;
- `OUTPUT_EVIDENCE`.

Les arêtes décrivent :

- dépendance de mission;
- autorité;
- prérequis;
- preuve d'entrée;
- production de preuve;
- évaluation postérieure par une Gate.

Le validateur refuse :

- dépendance absente;
- référence de preuve ou prérequis absente;
- cycle mission;
- cycle global, notamment mission -> preuve requise -> mission productrice;
- incohérence Gate/Campaign;
- mission d'écriture sans critère de succès;
- mission d'écriture sans livrable vérifiable;
- autorité ou certification absente;
- conflit de rapport ou scope.

Les conflits de ressources sont enregistrés. La politique courante `maxConcurrency=1` les résout par sérialisation. Une valeur supérieure reste refusée.

Le graphe possède `GlobalGraphFingerprint`. Le `CampaignFingerprint` lie le manifeste et cette empreinte. Une reprise avec une empreinte différente est refusée comme manifeste modifié. Les fingerprints d'entrée unitaires lient Campaign, manifeste unitaire, prompt et preuves consommées.

## 10. Profils Codex

Le Runtime continue d'utiliser exclusivement :

- `profiles.json`;
- `Resolve-CerebrauProfile.ps1`;
- le champ `profile` du manifeste.

Pour une mission de finalisation avec écriture, raisonnement élevé et revue humaine, le profil existant `ARCHITECTURE` est le profil adapté. Aucun modèle n'est codé en dur dans le prompt et aucun profil nouveau n'a été créé.

## 11. Commandes

Depuis la racine du dépôt, avec Windows PowerShell :

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauMission.ps1 -MissionFile <mission.json>
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauMission.ps1 -MissionFile <mission.json> -ContextAssemblyEnabled
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauCampaign.ps1 -Action Start -CampaignFile <campaign.json>
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauCampaign.ps1 -Action Resume -CampaignFile <campaign.json>
```

Tests ciblés :

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauGovernance.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauNSB.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauRuntimeE2E.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauContextRuntime.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauCampaign.ps1
npx tsx --test server/cerebrau-runtime/**/*.test.ts
npm --prefix server run build:cerebrau-runtime
git diff --check
```

## 12. Limites explicites

- Le Runtime n'invente aucune politique métier de Freeze; il applique une déclaration fournie.
- Une revue humaine reste extérieure au processus Codex et doit être fournie sous forme structurée et liée au fingerprint du rapport.
- La compatibilité maintient `Status` comme alias de classification. Les consommateurs nouveaux doivent utiliser `TechnicalClassification` et `FinalMissionState`.
- Le Runtime TypeScript reste non connecté à la production. Sa correction de lock protège son modèle local mais ne lui confère aucune autorité.
- Le Context Assembly reste optionnel; son activation ne change pas le décideur final.
