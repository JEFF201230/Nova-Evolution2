# RUNTIME-GITDIFF-DEADLOCK-001 — Rapport de remédiation

## 1. Verdict

| Élément | Résultat |
|---|---|
| Mission | `RUNTIME-GITDIFF-DEADLOCK-001` |
| Type | `REMEDIATION` |
| Lot | `RUNTIME-REPORTING-001` |
| Statut | `SUCCESS` |
| Périmètre | Runtime CEREBRAU `gitDiffCheck` uniquement |

La validation `gitDiffCheck` ne peut plus attendre indéfiniment un processus
`git diff --check`, y compris lorsque ses sorties standard et d'erreur
dépassent simultanément la capacité des pipes redirigés.

## 2. Écart corrigé

L'implémentation antérieure appelait successivement :

1. `StandardOutput.ReadToEnd()` ;
2. `StandardError.ReadToEnd()` ;
3. `WaitForExit()`.

Si `git` remplissait `stderr` pendant que le parent attendait la fermeture de
`stdout`, chaque processus pouvait attendre l'autre sans limite.

## 3. Remédiation

`Invoke-CerebrauGitDiffCheck` :

- démarre les lectures `ReadToEndAsync()` de `stdout` et `stderr` avant
  l'attente du processus ;
- draine donc les deux flux simultanément ;
- impose un timeout explicite de `60000 ms` par défaut ;
- accepte `timeoutMilliseconds` sur la validation pour une borne plus stricte ;
- en cas de timeout, exécute `Kill()`, attend la terminaison avec une seconde
  borne explicite et appelle systématiquement `Dispose()` sans attendre les
  tâches de lecture sans limite ;
- renvoie une validation échouée avec
  `GIT_DIFF_CHECK_TIMEOUT:<durée>ms` au lieu de lever une erreur interrompant
  le reporting.

La boucle de validations continue normalement après ce résultat.

## 4. Tests ciblés

La suite `Test-CerebrauReporting.ps1` couvre désormais :

- un faux `git` écrivant plus de 2 Mio sur `stdout`, puis plus de 2 Mio sur
  `stderr`, scénario qui pouvait bloquer l'ancienne implémentation ;
- la terminaison avant le timeout avec les deux flux volumineux ;
- un processus `git` volontairement bloqué ;
- le message de timeout explicite ;
- l'absence du processus après la validation ;
- l'exécution d'une validation suivante, preuve que le reporting continue.

## 5. Validations exécutées

| Validation | Résultat |
|---|---|
| Parse PowerShell CEREBRAU | `PASS` |
| `Test-CerebrauReporting.ps1` | `23/23 PASS` |
| Exécution réelle bornée de `git diff --check` | `PASS` |
| `git diff --check` sur les fichiers PowerShell impactés | `PASS` |

Les avertissements Git de conversion LF/CRLF observés ne sont pas des erreurs
de whitespace et le code retour du contrôle ciblé est `0`.

## 6. Périmètre et préservation

Fichiers de la mission :

- `tools/cerebrau/Cerebrau.Reporting.psm1` ;
- `tools/cerebrau/Test-CerebrauReporting.ps1` ;
- `Docs/PROGRAM/RUNTIME/CEREBRAU_GITDIFF_DEADLOCK_REPORT_001.md`.

Aucun fichier VEEDDA n'a été modifié par cette mission. Les modifications
préexistantes du workspace ont été préservées. Aucun commit et aucun push
n'ont été effectués.

## 7. Décisions D05 à D07

| Décision | Objet ciblé | Verdict |
|---|---|---|
| D05 | Drainage concurrent et attente bornée de `gitDiffCheck` | `PASS` |
| D06 | Timeout, arrêt, nettoyage et poursuite du reporting | `PASS` |
| D07 | Tests, preuve documentaire et contrôle final du périmètre | `PASS` |

`GLOBAL : PASS`
