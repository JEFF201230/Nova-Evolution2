# CEREBRAU — Mission Builder Report 001

## 1. Identification

| Champ | Valeur |
|---|---|
| Mission | `RUNTIME-MISSION-BUILDER-001` |
| Programme | `PROGRAM-CEREBRAU-RUNTIME` |
| Lot | `RUNTIME-MISSION-BUILDER-001` |
| Type | `IMPLEMENTATION` |
| Objet officiel de gouvernance | `WAVE` |
| Work Packages | Non officiels |
| Date | 2026-07-26 |
| Décision | `PASS` |

La mission livre le générateur officiel de missions CEREBRAU et son test ciblé. Elle ne modifie ni les décisions D01 à D04 closes, ni le code métier, ni l’autorité finale du Runtime.

## 2. Livrables

| Fichier | Rôle |
|---|---|
| `tools/cerebrau/New-CerebrauMission.ps1` | Génération gouvernée d'un manifeste et de son prompt |
| `tools/cerebrau/Test-NewCerebrauMission.ps1` | Validation ciblée du builder |
| `Docs/PROGRAM/RUNTIME/CEREBRAU_MISSION_BUILDER_REPORT_001.md` | Contrat, preuves et décision |

## 3. Contrat du builder

Le builder produit exactement deux artefacts UTF-8 sans BOM :

- `<MissionId>.json` ;
- `<MissionId>.prompt.md`.

Le manifeste et le prompt partagent le même contrat structuré :

- `missionId` ;
- `missionType` ;
- `lot` ;
- `changesExpected` ;
- `readOnly` ;
- `architecturalDecision`, lorsqu'elle est déclarée.

Les types canoniques sont dérivés sans saisie contradictoire possible :

| `missionType` | `changesExpected` | `readOnly` |
|---|---:|---:|
| `IMPLEMENTATION` | `true` | `false` |
| `REMEDIATION` | `true` | `false` |
| `AUDIT` | `false` | `true` |
| `CERTIFICATION` | `false` | `true` |

Une mission d'écriture doit déclarer au moins un chemin autorisé et un livrable attendu. Une mission read-only ne peut déclarer ni chemin d'écriture ni livrable à produire.

Le profil est résolu par `Resolve-CerebrauProfile.ps1`. La branche est lue depuis Git et une branche explicitement contradictoire est refusée.

## 4. Garanties fail-closed

Le builder refuse avant génération :

- un dépôt absent ou non Git ;
- une branche non résolue ou contradictoire ;
- un profil inconnu ;
- une sortie ou un répertoire de rapport hors dépôt ;
- un chemin absolu, traversant `..` ou dupliqué ;
- une mission d'écriture sans scope ou sans livrable ;
- une mission read-only portant un scope d'écriture ;
- un type ou une commande de validation hors liste d'autorisation ;
- une certification sans validation obligatoire ;
- un second bloc `CEREBRAU_MISSION_CONTRACT` dans le corps fourni ;
- toute collision avec un manifeste ou un prompt existant.

Les fichiers existants ne sont jamais écrasés. Si l'écriture ou le preflight échoue, seuls les artefacts nouvellement créés par l'invocation sont retirés.

Après génération, `Test-CerebrauMission.ps1` valide obligatoirement le manifeste et le prompt. Le builder ne retourne `Status=VALID` qu'après ce preflight.

## 5. Utilisation

Exemple d'implémentation :

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File tools/cerebrau/New-CerebrauMission.ps1 `
  -MissionId RUNTIME-EXAMPLE-001 `
  -Program PROGRAM-CEREBRAU-RUNTIME `
  -Lot RUNTIME-EXAMPLE-001 `
  -Title "Exemple de mission" `
  -MissionType IMPLEMENTATION `
  -Profile ARCHITECTURE `
  -AllowedPaths "tools/cerebrau/example.ps1" `
  -ExpectedFiles "tools/cerebrau/example.ps1"
```

Par défaut, les artefacts sont placés dans `tools/cerebrau/missions/generated` et le rapport d'exécution est déclaré sous `tools/cerebrau/reports/missions/<MissionId>`. `-OutputDirectory` et `-ReportDirectory` permettent de choisir d'autres descendants du dépôt.

Les paramètres `ReadOnlyPaths`, `ForbiddenPaths`, `DependsOn`, `Validations`, `ArchitecturalDecision`, `PromptBody` et `HumanReviewRequired` permettent de compléter le contrat sans désynchroniser le prompt.

## 6. Tests ciblés

`Test-NewCerebrauMission.ps1` crée un dépôt Git jetable et vérifie :

- les quatre types canoniques ;
- la dérivation `changesExpected/readOnly` ;
- l'unicité et la cohérence du contrat prompt ;
- la propagation de la décision architecturale ;
- le preflight officiel de chaque manifeste ;
- l'encodage UTF-8 sans BOM ;
- le refus d'écrasement et la préservation des hashes ;
- le refus des traversées de chemin ;
- le refus d'un scope d'écriture sur une mission read-only ;
- le refus d'une implémentation sans livrable ;
- le refus d'un marqueur de contrat injecté ;
- le refus d'une sortie hors dépôt.

Résultat ciblé : `SUCCESS`, 34/34 assertions, 0 échec.

## 7. Décisions D05 à D07

| Décision | Périmètre | Preuve | Verdict |
|---|---|---|---|
| D05 | Builder | Parse PowerShell et génération smoke-test validée par le preflight | `PASS` |
| D06 | Tests impactés | `Test-NewCerebrauMission.ps1` : 34/34 | `PASS` |
| D07 | Rapport et validation finale | Syntaxe, preflight actif et contrôle du diff | `PASS` |

## 8. Limites explicites

- Le builder génère une mission unitaire ; il ne crée pas une Campaign et ne remplace pas son graphe autoritatif.
- Il ne crée ni Gate, ni décision finale, ni certification automatique.
- Il ne déduit pas les preuves métier : les scopes, livrables et validations restent des entrées explicites.
- Il ne remplace pas `Invoke-CerebrauMission.ps1`, qui demeure le point d'entrée de production.

## 9. Décision finale

Le builder produit des couples manifeste/prompt canoniques, cohérents et prévalidés, sans écrasement implicite et sans possibilité de contredire les invariants `changesExpected/readOnly`.

**Decision: PASS**
