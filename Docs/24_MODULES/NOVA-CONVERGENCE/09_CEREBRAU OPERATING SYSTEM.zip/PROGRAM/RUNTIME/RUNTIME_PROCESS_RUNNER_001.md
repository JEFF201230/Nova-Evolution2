# RUNTIME-PROCESS-RUNNER-001 — Rapport de remédiation

## 1. Verdict

| Élément | Résultat |
|---|---|
| Mission | `RUNTIME-PROCESS-RUNNER-001` |
| Type | `REMEDIATION` |
| Programme | `PROGRAM-CEREBRAU-RUNTIME` |
| Lot | `RUNTIME-REPORTING-001` |
| Statut | `SUCCESS` |
| Objet de gouvernance | `WAVE` |

Le lancement des processus de `Cerebrau.Reporting.psm1` repose désormais sur
une seule implémentation : `Invoke-CerebrauProcess`.

## 2. Fonctions modifiées

| Fonction | Modification |
|---|---|
| `Invoke-CerebrauProcess` | Nouveau moteur unique : construction du processus, redirection, drainage asynchrone des deux flux, timeout, terminaison, collecte du code retour et nettoyage. |
| `Invoke-CerebrauNamedCommand` | Suppression de son moteur local et délégation à `Invoke-CerebrauProcess`. Le timeout par défaut est de `60000 ms`. |
| `Invoke-CerebrauGitDiffCheck` | Remplacement de son implémentation complète par un adaptateur vers `Invoke-CerebrauProcess`. |
| `Invoke-CerebrauValidation` | Les validations `gitDiffCheck` et `namedCommand` transmettent leur timeout au helper concerné ; leur résultat fonctionnel reste exposé par `Passed` et `Message`. |

`Test-CerebrauReporting.ps1` a uniquement été étendu pour couvrir la
mutualisation et les comportements de processus impactés.

## 3. Lignes supprimées et mutualisées

Le comptage des duplications supprimées est établi à partir des blocs de
lancement historiques de `HEAD` :

| Bloc historique supprimé | Lignes |
|---|---:|
| Moteur local de `Invoke-CerebrauNamedCommand` | 13 |
| Moteur local du cas `gitDiffCheck` de `Invoke-CerebrauValidation` | 14 |
| **Total de lignes d'implémentations concurrentes supprimées** | **27** |

Les responsabilités communes sont regroupées dans les 68 lignes de
`Invoke-CerebrauProcess` : préparation de `ProcessStartInfo`, démarrage,
lectures `ReadToEndAsync()`, attente bornée, terminaison, récupération des
sorties et du code retour, puis `Dispose()`.

Le `numstat` complet des deux fichiers impactés indique :

| Fichier | Ajouts | Suppressions |
|---|---:|---:|
| `tools/cerebrau/Cerebrau.Reporting.psm1` | 119 | 31 |
| `tools/cerebrau/Test-CerebrauReporting.ps1` | 172 | 6 |

Ces métriques de fichiers incluent des modifications préexistantes conservées
dans le workspace. Les 27 lignes ci-dessus constituent donc le comptage
attribuable aux deux moteurs historiques éliminés.

## 4. Duplications éliminées

Les éléments suivants n'existent plus dans `Invoke-CerebrauNamedCommand`,
`Invoke-CerebrauGitDiffCheck` ni dans les branches de validation :

- création locale d'un `ProcessStartInfo` ;
- démarrage local d'un `Process` ;
- lectures séquentielles `StandardOutput.ReadToEnd()` et
  `StandardError.ReadToEnd()` ;
- attente locale non bornée ;
- logique locale de timeout, terminaison et nettoyage.

`Invoke-CerebrauNamedCommand` et `Invoke-CerebrauGitDiffCheck` ne définissent
plus le cycle de vie d'un processus. Ils ne fournissent au moteur commun que
l'exécutable, les arguments, le répertoire, le timeout et le préfixe d'erreur.

## 5. Démonstration de la source unique de vérité

L'inspection statique finale de `Cerebrau.Reporting.psm1` donne :

| Construction recherchée | Occurrences | Localisation |
|---|---:|---|
| `ProcessStartInfo` | 1 | `Invoke-CerebrauProcess` |
| `[Diagnostics.Process]::new()` | 1 | `Invoke-CerebrauProcess` |
| `ReadToEndAsync()` | 2 | les deux flux dans `Invoke-CerebrauProcess` |
| `.ReadToEnd()` synchrone | 0 | aucune |
| appels de wrapper à `Invoke-CerebrauProcess` | 2 | commande nommée et Git diff |

Les tests analysent également l'AST du module et échouent si une autre
fonction que `Invoke-CerebrauProcess` contient un `ProcessStartInfo`. Ils
vérifient explicitement la délégation des deux wrappers et l'absence de
`.ReadToEnd()` synchrone.

Il n'existe donc plus qu'un seul moteur d'exécution des processus dans le
module Reporting.

## 6. Comportement conservé et sécurisé

- les commandes nommées autorisées restent inchangées ;
- `gitDiffCheck` exécute toujours `git diff --check` dans le dépôt demandé ;
- les sorties standard et d'erreur restent réunies dans `Message` ;
- `Passed` reste déterminé par le code retour ;
- le message Git existant `GIT_DIFF_CHECK_TIMEOUT:<durée>ms` est conservé ;
- les deux flux sont drainés simultanément ;
- chaque processus est attendu au plus `60000 ms` par défaut, ou selon
  `timeoutMilliseconds` ;
- un timeout produit un échec explicite, termine le processus et laisse la
  boucle de validations continuer.

## 7. Validations exécutées

| Validation | Résultat |
|---|---|
| Compilation/parse PowerShell CEREBRAU (`Test-CerebrauSyntax.ps1`) | `PASS` — code retour `0` |
| Tests Reporting (`Test-CerebrauReporting.ps1`) | `30/30 PASS` |
| Commande nommée avec stdout/stderr volumineux | `PASS` |
| Timeout et terminaison d'une commande nommée | `PASS` |
| Git diff avec stdout/stderr volumineux | `PASS` |
| Timeout, terminaison Git et poursuite des validations | `PASS` |
| Preuve AST du moteur unique | `PASS` |
| `git diff --check` ciblé | `PASS` |
| `git diff --check` complet du workspace suivi | `PASS` |

Les avertissements Git de conversion LF/CRLF ne constituent pas des erreurs de
whitespace ; les contrôles ont retourné le code `0`.

## 8. Périmètre et préservation

Fichiers de la mission :

- `tools/cerebrau/Cerebrau.Reporting.psm1` ;
- `tools/cerebrau/Test-CerebrauReporting.ps1` ;
- `Docs/PROGRAM/RUNTIME/RUNTIME_PROCESS_RUNNER_001.md`.

Le contrat des missions, leur runtime, le journal d'exécution et les rapports
existants n'ont pas été modifiés. Les autres modifications déjà présentes dans
le workspace ont été préservées. Aucun commit et aucun push n'ont été
effectués.

## 9. Décisions D05 à D07

| Décision | Objet ciblé | Verdict |
|---|---|---|
| D05 | Moteur commun et délégation de `Invoke-CerebrauNamedCommand` | `PASS` |
| D06 | Délégation de `Invoke-CerebrauGitDiffCheck` et suppression du dernier moteur concurrent | `PASS` |
| D07 | Tests anti-régression, validations finales et preuve documentaire | `PASS` |

`GLOBAL : PASS`
