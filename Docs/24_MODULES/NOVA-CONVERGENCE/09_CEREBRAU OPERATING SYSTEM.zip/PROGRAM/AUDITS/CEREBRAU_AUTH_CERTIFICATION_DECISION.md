# CEREBRAU — Décision de certification AUTH

## Décision

**NO GO maintenu — AUTH Security Certification : NON CERTIFIABLE dans l’état démontré par le dépôt.**

Cette décision ne nie pas l’existence d’AUTH. Au contraire : l’authentification Supabase est implémentée, utilisée et revalidée sur plusieurs domaines. L’échec porte sur la preuve et la réalité de l’autorisation de bout en bout.

## Motif déterminant

La chaîne requise est :

`Utilisateur → Supabase Auth → JWT → middleware → guard/RBAC → route → service → Supabase → RLS → table`.

Elle se rompt dans plusieurs chemins indépendants :

* Edge QF/simulation : `user_id` ou `organization_id` du body est utilisé avec `service_role` sans liaison au sujet JWT (`supabase/functions/compute-qf/index.ts`, `compute-rights/index.ts`, `save-simulation/index.ts`).
* RLS : les migrations n’activent explicitement RLS que pour les sept tables Offer; la protection des tables budgets/subventions/QF n’est pas démontrée.
* Service role : Express, Offer et les bridges admin bypassent RLS; l’isolement tenant dépend donc de contrôles applicatifs non uniformes.
* Front/route : `/superadmin` n’a pas de guard; LifeHub/salarié peut désactiver la garde de rôle via mode DEV ou `VITE_USE_MES_VIGILE`.
* Gouvernance : plusieurs middlewares et vocabulaires RBAC coexistent; la configuration Edge distante n’est pas prouvée (`supabase/config.toml` ne couvre que quatre fonctions).

## Qualification des affirmations du précédent rapport

| Affirmation | Statut |
|---|---|
| Context Engine certifié et NO GO levé | **Non ré-audité ici; compatible avec le périmètre précédent** |
| AUTH transverse confirmé | **CONFIRMED** |
| AUTH n’existe pas / n’est pas utilisé | **REFUTED** |
| Tous les domaines partagent une authentification Supabase | **PARTIALLY CONFIRMED** : Supabase domine; legacy non monté et état Edge distant non prouvé |
| Un middleware/guard/RBAC commun protège tous les modules | **REFUTED** |
| RLS couvre toutes les tables sensibles | **REFUTED au niveau des migrations** |
| Le NO GO sécurité doit être maintenu | **CONFIRMED** |

## Nature des écarts

* **Architecturaux :** autorités multiples et service role utilisé comme chemin normal.
* **Fonctionnels :** confusion possible entre sujet JWT et identifiant de payload; filtres tenant absents sur certaines routes.
* **Configuration/déploiement :** couverture `verify_jwt` Edge incomplète et flags de garde dépendants de l’environnement; à confirmer sur l’instance.
* **Documentaires :** la preuve d’état distant RLS/grants manque, mais cette lacune s’ajoute à des défauts techniques démontrés; elle n’est pas la seule cause du NO GO.

## Conditions minimales de levée

La certification peut passer GO sans régression si les actions suivantes sont réalisées et testées :

1. Rejeter toute divergence `payload.user_id/organization_id` vs sujet JWT; ajouter tests cross-user et cross-tenant.
2. Établir une matrice RLS complète depuis l’instance cible et l’appliquer aux tables exposées; auditer chaque `SECURITY DEFINER`.
3. Centraliser le middleware d’authentification et le registre RBAC, tout en conservant des adaptateurs temporaires testés pour Offer/QF.
4. Protéger chaque route privilégiée côté serveur et supprimer les bypass DEV en build de production.
5. Vérifier la configuration JWT de chaque Edge Function déployée et fournir les preuves (config + tests 401/403).
6. Rejouer une suite négative : token absent/invalide/expiré, rôle insuffisant, autre organisation, identifiant usurpé, accès direct PostgREST.

Jusqu’à production de ces preuves et correction des ruptures C01–C05/C08, toute décision GO serait prématurée. Les éléments positifs (AuthProvider, `getUser`, Offer/QF middleware et tests existants) justifient une requalification en **AUTH existant mais non certifiable**, pas une levée du NO GO.
