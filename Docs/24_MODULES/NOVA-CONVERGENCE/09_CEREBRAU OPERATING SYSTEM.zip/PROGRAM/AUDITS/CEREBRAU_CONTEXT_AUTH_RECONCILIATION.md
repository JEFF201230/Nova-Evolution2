# CEREBRAU Context / AUTH — Réconciliation

> Mission : `CEREBRAU-MISSION-AUDIT-CONTEXT-AUTH-001`
> Type : `AUDIT_READ_ONLY / RECONCILIATION`
> Date : `2026-07-23`

## 1. Objet et rapports antérieurs retenus

La mission ne nomme pas un fichier unique comme « précédent rapport ». La réconciliation porte donc sur les affirmations pertinentes et explicitement vérifiables des sources antérieures les plus directes :

1. `Docs/PROGRAM/CONTEXT_ACCELERATOR_ASSEMBLY_REPORT.md` du 22 juillet 2026 ;
2. `Docs/PROGRAM/CONTEXT_ASSEMBLY_BRICK_IMPLEMENTATION_REPORT.md` ;
3. `Docs/PROGRAM/CONTEXT_ASSEMBLY_PAIRED_BENCHMARK_REPORT.md` ;
4. `Docs/REPORTS/VEEDDA_URB_001_ARCHITECTURE_INVENTORY.md` ;
5. `Docs/AUDITS/VEEDDA_AUDIT_001/DPDS_AUDIT_005_MVP_FUNCTIONAL_COVERAGE.md` ;
6. `Docs/VEEDDA_FULL_SYSTEM_CARTOGRAPHY/VEEDDA_FULL_SYSTEM_CARTOGRAPHY_REPORT.md`.

Les rapports 2 et 3 matérialisent un changement postérieur au rapport 1 : une brique Context Assembly a été ajoutée au runtime Mission. La réconciliation distingue systématiquement cette brique du Context Engine TypeScript.

## 2. Réconciliation des affirmations Context

| ID | Affirmation antérieure | Verdict courant | Preuve fichier / symbole | Dépendances et consommateurs | Impact certification | Recommandation |
|---|---|---|---|---|---|---|
| `CTX-R01` | Le Context Engine est exécutable | ✅ **CONFIRMED** | `server/cerebrau-context/index.ts:5`, `context.service.ts:24-78`; 35/35 tests, compilation PASS | Node, Git, Docs | existence prouvée | Lever le NO GO d'existence |
| `CTX-R02` | Dix providers existent dans un ordre fixe | ✅ **CONFIRMED** | `providers/index.ts:13-24`, `context.service.ts:11-22` | Project à Component | architecture prouvée | Maintenir le constat |
| `CTX-R03` | Le moteur retourne `CerebrauProjectState`, alertes, sources manquantes, date | ✅ **CONFIRMED** | `context.types.ts:93`, `context.service.ts:34-53` | consommateurs API/tests | contrat prouvé | Maintenir |
| `CTX-R04` | Le moteur est en lecture seule, sans persistance/vectorisation/écriture | ✅ **CONFIRMED** | imports providers limités à `fs/path/child_process`; test MVP lecture seule | fichiers locaux | périmètre MVP cohérent | Maintenir |
| `CTX-R05` | Le Context Engine est consommé par le Knowledge Center | ✅ **CONFIRMED** | `server/routes.ts:608-638`, `GdbcseKnowledgeCenter.tsx:110-113` | Auth → API → GDBCSE | usage productif repository | Lever le NO GO d'usage total |
| `CTX-R06` | Le Campaign Runner n'appelle pas le Context Engine TypeScript | ✅ **CONFIRMED** | absence d'import/appel ; seules références dans `server/routes.ts` et tests | runtime Mission séparé | pas d'intégration du moteur COS-200 | Maintenir le NO GO ciblé |
| `CTX-R07` | Le runtime Mission n'a aucune intégration automatique de contexte | ❌ **REFUTED**, devenu obsolète | `Invoke-CerebrauMission.ps1:247-260`, `Cerebrau.Campaign.psm1:748-749` | `Cerebrau.ContextAssembly.psm1` | une intégration optionnelle existe | Remplacer par « Context Assembly optionnel » |
| `CTX-R08` | Aucun switch binaire d'assemblage n'existe | ❌ **REFUTED** | paramètres `-ContextAssemblyEnabled` dans Mission et Campaign | propagation Start/Resume | benchmark possible | Lever ce blocker |
| `CTX-R09` | Le seul canal automatique est Certified Facts | ❌ **REFUTED** aujourd'hui | bloc `<CEREBRAU_MISSION_CONTEXT>` préfixé au prompt | Mission Context Assembly | canal supplémentaire réel | Requalifier |
| `CTX-R10` | `CerebrauProjectState` n'est pas transmis à Codex | ✅ **CONFIRMED** | payload PowerShell contient références/scopes/hashes, aucun appel TS | Context Assembly | ne pas confondre les sorties | Maintenir |
| `CTX-R11` | L'assemblage automatique est impossible sans modification | ❌ **REFUTED** aujourd'hui | brique implémentée après le rapport | trois points de raccordement | ancien constat historiquement exact, plus courant | Marquer superseded |
| `CTX-R12` | Aucun nouveau runtime n'est requis | ✅ **CONFIRMED** | extension additive du runtime existant | Mission/Campaign | architecture additive | Maintenir |
| `CTX-R13` | Benchmark non exécuté/non prêt | ❌ **REFUTED** sur l'exécution | six runs A/B documentés | Campaign/Mission/Codex | benchmark exécuté | Remplacer par résultat réel |
| `CTX-R14` | Impact causal non prouvé | ✅ **CONFIRMED** | benchmark : équivalence fonctionnelle `NO`, variance forte | runs A/B | interdit certification production | Maintenir NO GO |
| `CTX-R15` | Context Assembly prêt production | ❌ **REFUTED** | rapport benchmark : `READY FOR PRODUCTION = NO` | mode B optionnel | production non certifiée | Maintenir NO GO |
| `CTX-R16` | Registry/Factory/Router du Context Engine | ⚠️ **PARTIALLY CONFIRMED** seulement par rôle | tableau `contextProviders`, fonction de composition, route monolithique | aucun composant dédié | terminologie à borner | Ne pas certifier ces abstractions |

## 3. Réconciliation des affirmations AUTH

| ID | Affirmation antérieure | Verdict courant | Preuve fichier / symbole | Consommateurs | Impact certification | Recommandation |
|---|---|---|---|---|---|---|
| `AUTH-R01` | Auth est prouvée, connectée et consommée | ⚠️ **PARTIALLY CONFIRMED** | `AuthContext.tsx`, `server/routes.ts:32-63` | client principal + API | fournisseur commun, couverture non uniforme | Conserver avec réserve |
| `AUTH-R02` | Auth est un module de premier niveau | ❌ **REFUTED** | aucun package/dossier top-level ; `routes/auth.ts` obsolète | transversal dispersé | ownership non canonique | Maintenir NO GO architecture |
| `AUTH-R03` | Supabase Auth est la source principale | ✅ **CONFIRMED** | client Supabase, `auth.getUser` Express/Offer/QF | Dashboard, GDBCSE, DBS, LifeHub, Offer | base de convergence | Maintenir |
| `AUTH-R04` | Tous les modules utilisent un point d'entrée commun | ❌ **REFUTED** | `authenticateUser`, Offer middleware, QF middleware, Document adapter, guards multiples | tous domaines | erreurs/politiques divergentes | Maintenir NO GO |
| `AUTH-R05` | Le routage par rôle existe | ✅ **CONFIRMED** | `AuthRedirect`, `CseProtected`, `SalarieGuard` | interfaces | contrôle UX présent | Ne pas assimiler à sécurité serveur |
| `AUTH-R06` | Les routes GDBCSE sont gardées | ✅ **CONFIRMED** | `App.tsx:192-196` | GDBCSE | contrôle client CSE | Maintenir, compléter par serveur |
| `AUTH-R07` | La route Superadmin est gardée | ❌ **REFUTED** | `App.tsx:191` monte directement `DashboardAdmin` | Dashboard Admin | faille de garde UI | Maintenir NO GO |
| `AUTH-R08` | LifeHub est toujours protégé | ❌ **REFUTED** | `LifeHubRouteShell` retourne le contenu en DEV | neuf routes LifeHub | bypass explicite | Maintenir NO GO |
| `AUTH-R09` | API Express historique utilise un JWT Supabase vérifié | ✅ **CONFIRMED** | `authenticateUser` → `supabaseAdmin.auth.getUser` | treize routes applicatives | AuthN fiable au point API | Maintenir |
| `AUTH-R10` | Les routes API sont uniformément RBAC/tenant | ❌ **REFUTED** | budgets sans rôle explicite ; subventions sans filtre tenant | Finance/GDBCSE | cross-tenant potentiel | Maintenir NO GO |
| `AUTH-R11` | Offer possède une auth et un RBAC dédiés | ✅ **CONFIRMED** | `SupabaseOfferAuthenticator`, `authenticationMiddleware`; 9 tests PASS | 40 opérations Offer | composant robuste isolé | Lever réserve Offer unitaire, pas globale |
| `AUTH-R12` | QF Ops lie l'acteur au JWT | ✅ **CONFIRMED** | `QfOperationsRouter.ts:118-179` | six commandes | réduit usurpation actorId | Maintenir, tester tenant E2E |
| `AUTH-R13` | Document Core dérive tenant et permissions | ✅ **CONFIRMED** | `document.auth.middleware.ts`; 3 tests PASS | sept routes | contrôle de frontière présent | Maintenir |
| `AUTH-R14` | Les Edge Functions lient JWT et payload | ❌ **REFUTED** pour QF/Rights/save-simulation | handlers `service_role`, `user_id/organization_id` payload, pas de `getUser` | QF, droits, simulation | critique cross-user/tenant | Maintenir NO GO |
| `AUTH-R15` | La configuration JWT des Edge est complète | ❌ **REFUTED** dans le dépôt | quatre blocs seulement dans `supabase/config.toml` | 17 handlers trouvés | déploiement non certifiable | Maintenir NO GO |
| `AUTH-R16` | RLS protège toutes les tables centrales | ❌ **REFUTED** dans les migrations locales | RLS explicite uniquement Offer | PostgREST/direct client | sécurité DB non reconstructible | Maintenir NO GO |
| `AUTH-R17` | Les chemins Prisma/JWT locaux sont actifs | ❌ **REFUTED** | contrôleur et routes users sans montage | aucun consommateur actif trouvé | dette latente, pas runtime courant | Isoler/retirer avant certification |
| `AUTH-R18` | Auth production est certifiée | ❌ **REFUTED** | aucune preuve E2E tenant globale ; findings ci-dessus | système entier | bloquant | Maintenir NO GO |

## 4. Chaîne d'autorité réconciliée

### 4.1 Context

```text
COS-200 / documents de gouvernance
  -> Context Providers TypeScript
  -> Context Engine TypeScript
  -> Knowledge Center API
  -> GDBCSE

Mission/Campaign
  -> Context Assembly PowerShell optionnel
  -> références minimales hashées
  -> Codex

Les deux chaînes coexistent ; elles ne sont pas la même implémentation.
```

### 4.2 AUTH

```text
Supabase Auth = fournisseur d'identité dominant
profiles = rôle et organisation utilisés par les APIs

mais

AuthContext / guards
authenticateUser
OfferAuthenticator
QfOperations authenticateQfRequest
DocumentCoreAuthMiddleware
Edge gateways/handlers
RLS/policies

forment plusieurs frontières, sans façade ni matrice d'autorité unique.
```

## 5. Effet sur les conclusions de certification

| Décision | État réconcilié |
|---|---|
| Context Engine absent | **À annuler** |
| Context Engine non implémenté | **À annuler** |
| Context Engine sans consommateur | **À annuler** |
| Context Engine utilisé par les missions | **Non prouvé / faux pour le moteur TypeScript** |
| Contexte Mission absent | **À annuler** : Context Assembly optionnel existe |
| Context Assembly production-ready | **NO GO maintenu** |
| AUTH capacité transverse | **Confirmée** |
| AUTH domaine top-level | **Réfutée** |
| AUTH point d'entrée unique de tous les modules | **Réfutée** |
| Fournisseur d'identité commun | **Partiellement confirmé : Supabase dominant** |
| Sécurité tenant/RBAC/RLS certifiée | **NO GO maintenu** |

## 6. Décision finale

```text
CONTEXT ENGINE EXISTENCE = CONFIRMED
CONTEXT ENGINE IMPLEMENTATION = CONFIRMED
CONTEXT ENGINE APPLICATION USE = CONFIRMED
CONTEXT ENGINE MISSION USE = REFUTED
MISSION CONTEXT ASSEMBLY = CONFIRMED, DISTINCT COMPONENT

AUTH TRANSVERSE CAPABILITY = CONFIRMED
AUTH TOP-LEVEL DOMAIN = REFUTED
AUTH COMMON PROVIDER = PARTIALLY CONFIRMED
AUTH SINGLE ENTRY POINT = REFUTED
AUTH END-TO-END CERTIFICATION = NO GO

CONTEXT EXISTENCE NO GO = LIFT
CONTEXT MISSION/PRODUCTION NO GO = MAINTAIN
AUTH/SECURITY NO GO = MAINTAIN
```

La conclusion antérieure doit donc être requalifiée, pas inversée globalement : le dépôt possède deux capacités de contexte réelles et distinctes, tandis que l'authentification repose majoritairement sur Supabase sans constituer encore un domaine canonique ni une autorité uniforme certifiable.
