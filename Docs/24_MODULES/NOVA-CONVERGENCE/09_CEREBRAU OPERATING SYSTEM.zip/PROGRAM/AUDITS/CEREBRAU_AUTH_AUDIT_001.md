# CEREBRAU AUTH — Audit 001

> Mission : `CEREBRAU-MISSION-AUDIT-CONTEXT-AUTH-001`
> Type : `AUDIT_READ_ONLY`
> Date d'observation : `2026-07-23`
> Référentiel : code et migrations du dépôt ; aucun environnement Supabase distant inspecté.

## 1. Verdict exécutif

| Affirmation | Verdict | Conclusion |
|---|---|---|
| AUTH existe comme capacité transverse | ✅ **CONFIRMED** | Session, identité, rôles et Bearer Supabase traversent les principales surfaces. |
| AUTH existe comme domaine de premier niveau | ❌ **REFUTED** | Aucun `client/src/auth`, `server/auth` ou package AUTH canonique. Les éléments sont dispersés. |
| AUTH est le point d'entrée commun de tous les modules | ❌ **REFUTED** | Supabase Auth est le fournisseur dominant, mais les guards, middlewares, Edge Functions et accès PostgREST ne passent pas par une façade unique. |
| Tous les modules utilisent le même fournisseur d'identité | ⚠️ **PARTIALLY CONFIRMED** | Les chemins actifs principaux utilisent Supabase Auth ; des chemins legacy Prisma/JWT subsistent mais ne sont pas montés. |
| Tous les modules utilisent le même middleware/guard | ❌ **REFUTED** | Au moins quatre adaptateurs backend actifs et plusieurs guards frontend divergents. |
| RBAC et isolation tenant sont uniformes | ❌ **REFUTED** | Matrices de rôles différentes, routes sans rôle explicite, service role et couverture RLS locale partielle. |

**Verdict sécurité/certification : `NO GO` maintenu.**

Le fournisseur d'identité commun est réel, mais l'autorité identité/tenant n'est ni centralisée ni démontrée de bout en bout sur toutes les routes et toutes les fonctions privilégiées.

## 2. Architecture AUTH observée

```text
Supabase Auth
  ├─ Client React
  │    ├─ AuthProvider / AuthContext
  │    ├─ ProtectedRoute
  │    ├─ CseProtected
  │    ├─ SalarieProtected / SalarieGuard
  │    └─ accès directs Supabase/PostgREST/Edge
  ├─ API Express historique
  │    └─ authenticateUser() -> auth.getUser(token) -> profiles.role
  ├─ Offer API
  │    └─ SupabaseOfferAuthenticator -> profile organization_id + role
  ├─ QF Operations
  │    └─ authenticateQfRequest -> auth.getUser -> binding actorId
  ├─ Document Core
  │    └─ authenticateUser injecté -> tenant profile -> permissions document
  └─ Edge Functions
       ├─ gateway verify_jwt lorsque configuré/déployé
       └─ handlers service_role, liaison sujet JWT variable
```

## 3. Composants AUTH exacts

| Couche | Fichier / symbole | Fonction | Statut |
|---|---|---|---|
| Client session | `client/src/context/AuthContext.tsx` — `AuthProvider`, `useAuth` | `signInWithPassword`, `signUp`, `signOut`, `getSession`, listener, profil | Actif |
| Client Supabase | `client/src/lib/supabaseClient.ts` | client anon, session persistée, callback URL | Actif |
| Client HTTP | `client/src/lib/proxyClient.ts` | récupère la session et injecte Bearer | Actif |
| Guard générique | `client/src/lib/protected-route.tsx` | session et rôles optionnels | Actif |
| Guard CSE | `client/src/lib/cse-protected.tsx` | rôles CSE/Superadmin | Actif pour `/gdbcse` |
| Guards salarié | `SalarieProtected.tsx`, `SalarieGuard.tsx` | session et rôle bénéficiaire/routage | Actifs, avec bypass/configurations |
| API historique | `server/routes.ts:32-63` — `authenticateUser` | vérifie le JWT Supabase et lit `profiles.role` | Actif |
| Middleware alternatif | `server/middleware/auth.middleware.ts` — `authMiddleware` | décode le JWT puis `admin.getUserById` | Non monté |
| Offer | `SupabaseOfferAuthenticator`, `authenticationMiddleware` | token, tenant, rôle, contexte Offer | Actif |
| QF Ops | `QfOperationsRouter.ts` — `authenticateQfRequest` | token et binding `actorId` | Actif |
| Document Core | `document.auth.middleware.ts` | réutilise `authenticateUser`, résout tenant et permissions | Actif |
| Routes AUTH historiques | `server/routes/auth.ts` | fichier explicitement obsolète, aucune route | Inactif |
| Contrôleur Prisma/JWT | `server/controllers/auth.controller.ts` | JWT local avec fallback `secret_dev` | Non monté/legacy |
| Routes users Prisma | `server/routes/users.ts` | CRUD non protégé | Non monté/orphelin |

## 4. Routes frontend

Toutes les déclarations du routeur principal ont été classées.

### 4.1 Routes publiques ou non gardées au routeur

| Route | Contrôle |
|---|---|
| `/auth` | publique, redirige un utilisateur déjà connu selon son rôle |
| `/reset-password` | publique |
| `/superadmin` | **aucun guard de route** ; le composant vérifie ponctuellement Supabase, mais le rôle Superadmin n'est pas imposé par `App.tsx` |
| `/subventions` | redirection non gardée vers une route salariée |
| redirections `/dashboard-salarie/qf/*`, `/salarie/resume-budget`, `/salarie/espace` | pas de contrôle propre ; destination normalement gardée |
| fallback 404 | public |

### 4.2 Routes protégées

| Famille | Routes | Guard |
|---|---|---|
| Générique | `/interactive`, `/avantages/:id` | `ProtectedRoute` |
| GDBCSE | `/gdbcse` | `CseProtected` : `ADMIN`, `TRESORIER`, `SECRETAIRE`, `SUPERADMIN` |
| Bridge QF | `/bridge/qf-accompagnement`, `/bridge/qf-avantages` | `SalarieProtected` sauf si `VITE_USE_MES_VIGILE=true` |
| Mon Espace | `/mon-espace-salarie` | `SalarieProtected` |
| Dashboard/DBS | `/dashboard-salarie`, `/catalogue`, `/nouvelle-demande`, `/demandes` | `SalarieGuard` |
| Parcours salarié | `/salarie`, `/bienvenue`, `/accueil`, `/fiche`, `/regles-calcul`, `/quotient-familial`, `/comment-calcul`, `/justificatifs` | `SalarieProtected` |
| LifeHub | `/lifehub`, `/demarches`, `/dossier/:id`, sous-onglets history/messages/budget, `/messages`, `/agenda`, `/coaching` | `SalarieProtected` seulement hors `import.meta.env.DEV` |

### 4.3 Divergences de guards

- `LifeHubRouteShell` retourne directement le contenu en développement.
- `SalarieProtected` retourne directement le contenu si `VITE_USE_MES_VIGILE=true`, après contrôle de session mais sans contrôle de rôle.
- `SalarieGuard` impose le rôle.
- `SalarieStepGuard` ne fait plus de contrôle d'étape et devient un rendu direct après chargement.
- `ProtectedRoute` accepte des rôles optionnels ; les deux usages courants n'en fournissent pas.
- `/superadmin` n'emploie aucun de ces guards.

Les guards protègent l'interface, pas l'autorité serveur. Ils ne doivent pas être considérés comme barrière de sécurité suffisante.

## 5. Routes Express et contrôles

### 5.1 Route publique

| Route | Auth |
|---|---|
| `GET /` | aucune, health textuel |

### 5.2 API historique `server/routes.ts`

| Route | AuthN | RBAC / tenant |
|---|---|---|
| `GET /api/cerebrau/knowledge-center` | `authenticateUser` | rôles `ADMIN/SECRETAIRE/TRESORIER/SUPERADMIN` |
| `GET /api/profile/me` | `authenticateUser` | sujet forcé à `user.id` |
| `POST /api/organizations` | `authenticateUser` | liaison `organizations.user_id = auth.id`, aucun rôle |
| `POST /api/budgets` | `authenticateUser` | tenant dérivé du profil, aucun rôle explicite |
| `POST /api/budgets/validate` | `authenticateUser` | tenant dérivé ; aucun rôle explicite prouvé |
| `POST /api/budgets/:id/close` | `authenticateUser` | tenant + rôles de clôture via `evaluateBudgetClosure` |
| `GET /api/budgets/latest` | `authenticateUser` | tenant dérivé |
| `GET /api/budgets/legacy` | `authenticateUser` | tenant dérivé |
| `GET /api/budgets/:id/lifecycle` | `authenticateUser` | budget filtré par tenant |
| `GET /api/financial/grand-livre/asc` | `authenticateUser` | profil/tenant + budget |
| `GET /api/subventions` | `authenticateUser` | `SUPERADMIN` ou `ADMIN`, mais requête non filtrée par tenant |
| `PATCH /api/subventions/:id` | `authenticateUser` | `SUPERADMIN` ou `ADMIN`, mais mutation non filtrée par tenant |
| `GET /api/mes/vigile` | `authenticateUser` | sujet authentifié ; EBS reconstruit pour ce sujet |

Toutes utilisent le même fournisseur Supabase et la même fonction locale, mais cette fonction est déclarée dans le routeur monolithique et n'est pas un middleware partagé exporté.

### 5.3 Offer API

Base : `/api/v1/offer`.

| Surface | Routes | Auth |
|---|---|---|
| Contrat | `GET /openapi.json` | publique avant le middleware |
| Commandes, 25 | `POST /commands/{CreateDispositif, UpdateDispositif, ActivateDispositif, DeactivateDispositif, ArchiveDispositif, CreateOffer, UpdateOfferDraft, CreateOfferVersion, SubmitOfferForReview, RequestOfferChanges, ValidateOffer, PublishOffer, SuspendOffer, ResumeOffer, CloseOffer, ArchiveOffer, CloneOffer, CreateOperation, UpdateOperationDraft, ScheduleOperation, OpenOperation, SuspendOperation, ResumeOperation, CloseOperation, ArchiveOperation}` | JWT Supabase, tenant profil, rôle Offer autorisé |
| Requêtes, 15 | `GET /queries/{ListDispositifs, GetDispositif, ListOffers, GetOfferDetail, ListOfferVersions, ListOffersByStatus, ListOperationsByOffer, ListOpenOperations, ListUpcomingOperations, ListCompletedOperations, GetOperationDetail, ListOfferTransitions, SearchOfferAudit, ListOfferDistributionFacts, GetOfferAdministrationProjection}` | même middleware |

Le middleware refuse rôles inconnus/interdits et construit un `OfferRequestContext` immuable. Les tests ciblés observés passent `9/9`.

### 5.4 QF Operations

Base : `/api/v1/qf`.

Routes : `POST /approve`, `/reject`, `/pause`, `/resume`, `/documents`, `/publish`.

Toutes passent par `authenticateQfRequest`, qui appelle `supabaseAdmin.auth.getUser`. `executeRoute` impose ensuite `payload.actorId === identité JWT`; l'autorité organisation/user/dossier est relue par la couche métier. Ce système est Supabase-compatible mais indépendant de `authenticateUser`.

### 5.5 Document Core

Montage réel : `app.use("/documents", ...)` puis routes internes :

- `POST /documents` ;
- `POST /documents/:id/binary` ;
- `GET /documents` ;
- `GET /documents/:id` ;
- `GET /documents/:id/download` ;
- `PATCH /documents/:id` ;
- `DELETE /documents/:id`.

Les URLs Express résultantes sont donc `/documents/documents...`. Toutes passent par `createDocumentCoreAuthMiddleware`, qui réutilise `authenticateUser`, résout `organization_id`, puis mappe :

- `SUPERADMIN/ADMIN` → `DOCUMENT_ADMIN` ;
- `SECRETAIRE/TRESORIER` → `DOCUMENT_CONTRIBUTOR` ;
- autres → `DOCUMENT_VIEWER`.

Les routes PATCH/DELETE retournent `notImplemented`. Le middleware passe `3/3` tests sous Vitest.

### 5.6 Routes non montées

- `server/routes/auth.ts` n'expose aucune route et exporte `null`.
- `server/routes/users.ts` expose théoriquement `POST /` et `GET /` sans auth, mais aucun import/montage n'a été trouvé.
- `server/controllers/auth.controller.ts` produit un JWT local Prisma, mais aucun montage n'a été trouvé.

Elles constituent une dette de réactivation, pas un chemin runtime courant.

## 6. Edge Functions Supabase

### 6.1 Inventaire

Fonctions racines :

- `compute-qf`, `compute-rights`, `salarie-fiche`, `save-simulation` ;
- `simulate-v2-4`, `simulate-v2-5`, `simulate-v2-6`.

Versions historiques :

- `simulate-subvention-model`, `simulate-v1`, `simulate-v1-backup`, `simulate-v1-stable` ;
- `simulate-v2`, `simulate-v2-1-test`, `simulate-v2-2-test`, `simulate-v2-3-test`, sous-copie `simulate-v2-2-test`, `simulate-v2-test`.

### 6.2 Contrôles

| Groupe | Gateway versionné | Contrôle dans le handler | Risque |
|---|---|---|---|
| `salarie-fiche` | aucun bloc explicite dans `config.toml` | Header requis + `auth.getUser()` + sujet JWT utilisé | Contrôle handler présent |
| `save-simulation` | `verify_jwt=true` | aucun `getUser`; `organization_id` vient du payload ; client `service_role` | binding tenant absent dans le handler |
| `compute-qf`, `compute-rights` | aucun bloc explicite | aucun `getUser`; `user_id` vient du payload ; client `service_role` | binding sujet absent |
| simulations racines/historiques | configuration explicite seulement pour quelques anciennes fonctions | pas de binding utilisateur trouvé ; service role ou fallback anon | autorité variable/non démontrée |

`supabase/config.toml` ne contient que quatre blocs explicites : trois anciennes simulations et `save-simulation`, tous avec `verify_jwt=true`. L'état de déploiement des autres fonctions est inconnu. Même lorsqu'une gateway vérifie le JWT, un handler `service_role` doit encore lier l'appelant au `user_id` ou `organization_id` ciblé.

## 7. Sessions, JWT et providers

| Sujet | Réalité observée |
|---|---|
| Session client | Supabase JS, `persistSession=true`, `detectSessionInUrl=true` |
| Login/signup/logout | Supabase Auth dans `AuthContext` |
| Refresh | listener `onAuthStateChange`, événement `TOKEN_REFRESHED` |
| Transport | Bearer `session.access_token` via `proxyFetch` ou appels locaux |
| Validation API principale | `supabaseAdmin.auth.getUser(token)` |
| Validation Offer | même API via gateway injectée |
| Validation QF Ops | même API directement |
| JWT local | `jsonwebtoken` existe pour tests Offer et contrôleur legacy non monté |
| Cookie serveur | aucun mécanisme de session cookie applicatif canonique prouvé |

## 8. Rôles et RBAC

Rôles applicatifs observés : `SUPERADMIN`, `ADMIN`, `TRESORIER`, `SECRETAIRE`, `BENEFICIAIRE`.

La source courante côté API principale est `profiles.role`, non les seules métadonnées JWT. Offer fusionne les metadata comme claims mais résout l'autorité effective dans `profiles`. Les guards client utilisent le profil retourné par `/api/profile/me`.

La politique n'est pas uniforme :

- GDBCSE autorise quatre rôles CSE ;
- subventions Express n'autorise que `SUPERADMIN/ADMIN` ;
- Document Core applique trois niveaux de permissions ;
- Offer a son propre catalogue autorisé/interdit ;
- QF Ops lie l'acteur mais délègue la portée à `VeeddaIdentityScopeReader` ;
- plusieurs routes budget vérifient le tenant mais aucun rôle explicite ;
- le client peut accéder directement à PostgREST, soumis aux policies déployées.

Il existe donc du RBAC, mais pas un moteur RBAC transverse unique.

## 9. RLS et autorité base

Dans les migrations versionnées, l'activation RLS explicite n'a été trouvée que pour sept tables Offer :

`offer_dispositif`, `offer_offer`, `offer_offer_version`, `offer_operation`, `offer_idempotency`, `offer_audit_entry`, `offer_outbox`.

Quatre policies SELECT tenant existent pour les quatre premières. Les grants retirent les mutations `anon/authenticated`, accordent SELECT limité à `authenticated` et les droits complets à `service_role`.

Aucune activation RLS versionnée n'a été trouvée pour les tables financières et QF créées localement, notamment :

- `budgets`, `subventions`, `budget_ledger`, `subvention_payments`, `budget_status_events` ;
- `qf_operational_dossier`, `qf_business_decision`, `qf_analysis_snapshot`, `qf_dossier_event`, `qf_outbox_event`.

Cela ne prouve pas que le runtime distant n'a aucune RLS ; cela prouve que le dépôt ne permet pas de la reconstruire/certifier pour ces objets. Les clients `service_role` contournent en outre RLS et reportent toute l'autorité sur le code serveur.

## 10. Consommateurs par domaine

| Domaine | Consommation AUTH | Verdict |
|---|---|---|
| Dashboard Admin | appels directs `auth.getUser/getSession`, route `/superadmin` non gardée par rôle | 🟠 Partiel |
| GDBCSE | `CseProtected`, sessions Bearer, route API protégée | ✅ Oui, mais politiques internes variables |
| Dashboard salarié / DBS | `SalarieGuard`, `AuthContext`, accès PostgREST direct et `/api/mes/vigile` | 🟠 Oui, dépend de RLS non versionnée |
| Mon Espace | `SalarieProtected`, nombreux `auth.getUser` | 🟠 Oui |
| LifeHub | `AuthContext` + Bearer ; guard bypassé en DEV | 🟠 Partiel |
| EBS | pas d'auth interne ; reçoit l'identité depuis `/api/mes/vigile` | ✅ Auth à la frontière API |
| Offer | authenticator et RBAC dédiés Supabase | ✅ Oui |
| QF Operations | authentification Supabase et actor binding | ✅ Oui |
| Document Core | adaptateur Supabase partagé + tenant + permissions | ✅ Oui |
| Context Engine / Knowledge Center | auth et rôles dans `server/routes.ts` | ✅ Oui au point d'exposition |
| Edge QF/Rights/Simulation | gateway/handler hétérogènes, service role | ❌ Non uniforme |
| Frontend secondaire `frontend/` | placeholder React, aucune capacité AUTH prouvée | ❌ Hors système AUTH principal |
| CEREBRAU Mission/PROGRAM | orchestration locale, pas un consommateur de l'auth applicative | Non applicable |

## 11. Findings de certification

| ID | Finding | Statut | Impact |
|---|---|---|---|
| `AUTH-001` | Supabase Auth est le fournisseur commun dominant | ✅ CONFIRMED | base de convergence existante |
| `AUTH-002` | Domaine AUTH top-level | ❌ REFUTED | ownership et contrat non matérialisés |
| `AUTH-003` | Middleware unique | ❌ REFUTED | comportements et erreurs divergents |
| `AUTH-004` | `/superadmin` protégé par rôle au routeur | ❌ REFUTED | exposition UI non autorisée possible ; les opérations restent dépendantes de leurs contrôles propres |
| `AUTH-005` | LifeHub toujours protégé | ❌ REFUTED | bypass explicite en DEV |
| `AUTH-006` | Binding JWT/payload Edge | ❌ REFUTED pour QF/Rights/save-simulation | risque cross-user/cross-tenant avec service role |
| `AUTH-007` | RLS repository complète | ❌ REFUTED | seules tables Offer explicitement couvertes |
| `AUTH-008` | Offer auth/RBAC | ✅ CONFIRMED | conception et tests ciblés solides |
| `AUTH-009` | QF Ops actor binding | ✅ CONFIRMED | 401/403 explicites dans le code |
| `AUTH-010` | Routes users/auth legacy actives | ❌ REFUTED | non montées, mais dette présente |
| `AUTH-011` | Subventions Express filtrées tenant | ❌ REFUTED | lecture/mutation admin sans filtre organisation |
| `AUTH-012` | Guards frontend suffisants comme sécurité | ❌ REFUTED | sécurité serveur/RLS indispensable |

## 12. Recommandations et décision NO GO

Sans modifier le code dans cette mission, les conditions minimales de levée sont :

1. désigner un contrat d'autorité unique identité + rôle + organisation ;
2. centraliser ou rendre contractuellement équivalents les adaptateurs Express, Offer, QF Ops et Document Core ;
3. protéger `/superadmin` par session et rôle au routeur ;
4. supprimer ou borner formellement les bypass DEV/Vigile ;
5. dériver `user_id` et `organization_id` des JWT dans toutes les Edge Functions privilégiées ;
6. filtrer les routes subventions par tenant, sauf décision Superadmin explicite et auditée ;
7. versionner et tester RLS/grants/policies pour toutes les tables exposées ;
8. tester la matrice rôle × tenant × objet, y compris cross-user/cross-tenant ;
9. retirer ou isoler le contrôleur JWT local et les routes users orphelines ;
10. prouver le déploiement réel des configurations `verify_jwt`.

```text
AUTH TRANSVERSE CAPABILITY = YES
AUTH TOP-LEVEL DOMAIN = NO
COMMON IDENTITY PROVIDER = PARTIAL YES
COMMON AUTH ENTRY POINT FOR ALL MODULES = NO
UNIFORM RBAC = NO
RLS REPOSITORY COVERAGE = NO
AUTH CERTIFICATION = NO GO
RECOMMENDATION = MAINTAIN NO GO
```
