# CEREBRAU — AUTH / RLS Audit 001

**Méthode :** lecture des migrations SQL versionnées et des clients Supabase; aucune connexion à une base distante n’a été effectuée. Les conclusions « absent » signifient donc absent du dépôt, pas nécessairement absent de l’instance.

## 1. Inventaire versionné

### Tables créées

`budgets`, `subventions`, `subvention_models`, `subvention_factors`, `subvention_model_factors`, `budget_ledger`, `subvention_payments`, `budget_status_events`, `ledger_accounts`, `ledger_account_mapping`, `qf_operational_dossier`, `qf_business_decision`, `qf_analysis_snapshot`, `qf_dossier_event`, `qf_outbox_event`, et les sept tables Offer : `offer_dispositif`, `offer_offer`, `offer_offer_version`, `offer_operation`, `offer_idempotency`, `offer_audit_entry`, `offer_outbox`.

### `ENABLE ROW LEVEL SECURITY` explicite

La seule migration contenant `alter table ... enable row level security` est `supabase/migrations/20260717000000_create_offer_infrastructure.sql:183-189`, pour les sept tables Offer. Aucune instruction équivalente n’a été trouvée dans les migrations des tables budgets, subventions, ledger, paiements, événements d’état ou QF listées ci-dessus.

**Résultat : PARTIALLY CONFIRMED** pour « RLS protège toutes les données » : démontré pour Offer dans le dépôt, non démontré pour les autres domaines.

## 2. Policies et privilèges Offer

La migration Offer définit uniquement quatre policies SELECT :

* `offer_dispositif_tenant_select`;
* `offer_offer_tenant_select`;
* `offer_offer_version_tenant_select`;
* `offer_operation_tenant_select`.

Chaque policy est `to authenticated using (public.offer_has_tenant_access(organization_id))`. La fonction lit `auth.jwt()` (`organization_id`, `business_role`) et n’autorise que `SUPER_ADMIN`, `ADMIN`, `SECRETAIRE` (`:162-180`). Les mutations anon/authenticated sont révoquées (`:200-202`), les écritures sont accordées à `service_role` (`:203-204`), et les projections sont réservées à `service_role` (`:228-229`).

**Limites démontrées :** aucune policy INSERT/UPDATE/DELETE pour authenticated; l’API Offer doit donc être l’unique chemin d’écriture. Comme l’API utilise le client service role, Postgres ne réévalue pas ces policies sur ce chemin. La sécurité tenant est alors applicative et doit être testée séparément.

## 3. SECURITY DEFINER et RPC

Les migrations suivantes déclarent des RPC `SECURITY DEFINER` :

`20260222173757_rpc_approve_subvention.sql`, `20260222181344_patch_rpc_approve_subvention_statut_montant.sql`, `20260222184447_rpc_pay_subvention.sql`, `20260222191528_refactor_ledger_reserve_release_v2.sql`, `20260222193508_rpc_refund_subvention.sql`, `20260222195900_patch_rpc_pay_idempotence_v24.sql`, `20260222201000_patch_rpc_approve_idempotence_v23.sql`, `20260222204500_patch_pay_subvention_operation_id_v28.sql`, `20260222211000_patch_pay_subvention_use_subvention_payments_v30.sql`, `20260612000100_patch_pay_subvention_created_by.sql`.

Ces fonctions utilisent `auth.uid()` dans plusieurs contrôles et révoquent l’exécution publique pour l’accorder à `authenticated`. Cela constitue une intention de sécurité positive (**PARTIALLY CONFIRMED**), mais le dépôt ne contient pas une matrice prouvant, pour chaque RPC, le contrôle organisation/rôle et l’absence de chemin de contournement. La fonction trigger Offer `offer_reject_audit_mutation()` est `SECURITY DEFINER` avec `search_path = public` et empêche UPDATE/DELETE sur l’audit (`20260717000000_create_offer_infrastructure.sql:157-160`); elle est correctement restreinte par `revoke`.

## 4. Bypass service_role et clients

* `server/src/supabase/supabaseAdmin.ts` crée le client service role.
* Les routes Express, Offer, Employee Business State et plusieurs Edge Functions l’utilisent pour lire/écrire. `service_role` bypass RLS par conception.
* `compute-qf` et `compute-rights` sélectionnent l’utilisateur avec le `user_id` du body, sans `auth.getUser`; `save-simulation` prend `organization_id` du body. C’est un bypass de liaison sujet, indépendant de la présence d’une policy.
* Le client navigateur `client/src/lib/supabaseClient.ts` est anon et plusieurs écrans utilisent `supabase.from(...)` directement. Pour eux, RLS est la barrière effective; or les migrations métier ne prouvent pas son activation.

## 5. Verdicts RLS

| Affirmation | Verdict | Preuve et impact |
|---|---|---|
| Toutes les tables métier ont RLS | **REFUTED (au niveau du dépôt)** | Seules les sept tables Offer ont `ENABLE RLS`; risque de lecture/écriture cross-tenant si l’instance suit les migrations. |
| Offer est tenant-isolé | **PARTIALLY CONFIRMED** | Quatre SELECT policies et fonctions JWT existent; écritures service role et absence de policies mutation rendent l’isolement dépendant de l’API. |
| Les `SECURITY DEFINER` sont contrôlées | **PARTIALLY CONFIRMED** | `auth.uid()`/grants sont présents, mais inventaire de contrôles par rôle/organisation non complet. |
| `service_role` est sans risque | **REFUTED** | Il bypass RLS; tout identifiant fourni par le client doit être rebondi sur le JWT, ce qui n’est pas le cas des Edge QF/simulation. |
| L’état distant est certifié par les fichiers locaux | **REFUTED** | Aucun dump/schema distant n’a été utilisé dans cette mission. |

## 6. Actions minimales pour GO

1. Produire depuis l’instance cible un dump des tables, `relrowsecurity`, policies, grants et fonctions; comparer à ce dépôt.
2. Activer et tester RLS sur chaque table exposée au client anon, avec policies SELECT/INSERT/UPDATE/DELETE tenant explicites.
3. Pour chaque `SECURITY DEFINER`, fixer `search_path`, révoquer `public`, vérifier `auth.uid()` et le rôle/tenant, puis ajouter des tests négatifs.
4. Interdire les identifiants `user_id`/`organization_id` divergents du sujet JWT; préférer `auth.uid()` ou un contexte serveur dérivé du token.
5. Réduire le service role aux opérations backend nécessaires et documenter les exceptions avec tests d’autorisation.
