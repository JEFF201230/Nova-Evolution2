# CEREBRAU — AUTH Certification Audit 001

**Type :** AUDIT_READ_ONLY · **Date :** 2026-07-23  
**Périmètre :** runtime Express/Vite/React, Supabase Auth/JWT, middleware, guards, RBAC, Edge Functions, GDBCSE, DBS, LifeHub, Offer, Employee Business State et QF.

## 1. Conclusion exécutable

AUTH existe et authentifie effectivement une partie de l’application. Le dépôt démontre une identité Supabase commune pour le client et plusieurs routes Express. Il ne démontre toutefois pas une chaîne d’autorisation uniforme et complète. Le NO GO de certification est donc **CONFIRMED** : il résulte de défauts de contrôle réels (liaison sujet/payload, appels `service_role` qui contournent RLS, routes non protégées ou garde désactivable), aggravés par des preuves de déploiement incomplètes. Ce n’est pas un simple défaut documentaire.

## 2. Où AUTH démarre et qui fournit/renouvelle le token

| Étape | Preuve (fichier : symbole) | Constat |
|---|---|---|
| Connexion | `client/src/context/AuthContext.tsx:46` `AuthProvider`; `signInMutation` vers `supabase.auth.signInWithPassword` | Supabase Auth émet le JWT et la session. |
| Persistance/renouvellement | `client/src/lib/supabaseClient.ts` (`persistSession:true`, `detectSessionInUrl:true`); `AuthContext.tsx:100-137` `getSession`, `onAuthStateChange`, événements `TOKEN_REFRESHED` | Le client écoute les renouvellements et conserve la session. |
| Transport | `client/src/lib/proxyClient.ts:29-42`, `client/src/lib/apiClient.ts:47` | Le bearer courant est injecté dans les appels API. Des écrans appellent cependant directement `supabase.from(...)`. |
| Validation Express | `server/routes.ts:32-63` `authenticateUser` | `supabaseAdmin.auth.getUser(token)` valide la signature/expiration via Supabase, puis charge `profiles.id, role`. |
| Variante non montée | `server/middleware/auth.middleware.ts:5` `authMiddleware` | Décode d’abord le JWT (`jwt.decode`) puis appelle `admin.getUserById`; aucun montage trouvé : double autorité potentielle, mais non active. |
| Variante legacy | `server/controllers/auth.controller.ts` | Prisma/bcrypt/JWT local et secret de repli `JWT_SECRET || "secret_dev"`; aucun montage trouvé. |

**Réponse aux questions d’authentification :** le fournisseur de token est Supabase; le renouvellement est côté SDK Supabase; la validation active est `supabaseAdmin.auth.getUser`; la couverture des routes est hétérogène et ne se réduit pas à un middleware unique.

## 3. Routes, consommateurs et ruptures de chaîne

### 3.1 Express actif

`server/routes.ts` protège par `authenticateUser` (puis contrôles de rôle locaux) notamment `/api/profile/me`, `/api/organizations`, `/api/budgets*`, `/api/financial/grand-livre/asc`, `/api/subventions*`, `/api/mes/vigile` et `/api/cerebrau/knowledge-center`. Le montage documenté associe également `createDocumentCoreAuthMiddleware` à `/documents` et `composeOfferApi` à `/api/v1/offer`.

`GET /` est public. `server/routes/auth.ts` exporte un routeur obsolète sans routes. `server/routes/users.ts` expose des opérations Prisma non protégées et n’est pas monté/importé dans le dépôt : **surface orpheline à traiter comme non certifiable tant que son exclusion du runtime n’est pas prouvée**.

### 3.2 GDBCSE, Dashboard, DBS, LifeHub

* **GDBCSE** : `client/src/lib/cse-protected.tsx:CseProtected` contrôle les rôles `ADMIN/TRESORIER/SECRETAIRE/SUPERADMIN`; les appels API obtiennent le même `supabase.auth.getSession`. Le backend revalide néanmoins le bearer avec `authenticateUser`. Chemin fonctionnel cohérent, mais fondé sur le rôle de `profiles` sans portée organisationnelle systématique.
* **Dashboard** : `/superadmin` dans `client/src/App.tsx` est déclaré directement vers `DashboardAdmin` sans `ProtectedRoute`/`CseProtected`. C’est une rupture de garde front (le serveur doit rester l’autorité).
* **DBS/salarié** : `/dashboard-salarie*` passe par `SalarieGuard`; plusieurs composants (`client/src/salarie/accueil.tsx`, `regles-calcul.tsx`, `client/src/lib/veedda-sdk/qf.ts`) lisent/écrivent directement via le client anon. La sécurité dépend donc de RLS déployée, non d’Express.
* **LifeHub** : `LifeHubRouteShell` dans `client/src/App.tsx` retourne le contenu directement en mode DEV; `VITE_USE_MES_VIGILE=true` fait également retourner les enfants dans `SalarieProtected` après un simple contrôle de session. La route `/api/mes/vigile` revalide côté serveur, mais l’autorisation UI est contournable en configuration.
* **Employee Business State** : `server/employee-business-state/lifehub-bridge.ts:85,102` projette par `user_id` avec le client admin; cette projection ne remplace pas une politique de tenant.

### 3.3 Offer, QF et Edge Functions

* **Offer** : `server/offer-api/middleware/OfferMiddleware.ts:authenticationMiddleware` exige Bearer, appelle `SupabaseOfferAuthenticator`, vérifie `AUTHORIZED_OFFER_ROLES/FORBIDDEN_OFFER_ROLES` et construit `OfferRequestContext` (organisation + acteur). Le montage est `/api/v1/offer`; `GET /openapi.json` reste public. C’est la chaîne la plus complète, mais ses écritures utilisent l’infrastructure `service_role` et bypassent RLS.
* **QF Operations** : `server/qf-operations/api/QfOperationsRouter.ts:createQfOperationsRouter` installe `authenticateQfRequest` sur tout le routeur. Ce middleware appelle `supabaseAdmin.auth.getUser`, place `res.locals.qfActorId`; `executeRoute` exige `payload.actorId === JWT actor`. Le contrôle d’acteur est démontré pour ces six commandes.
* **Edge `salarie-fiche`** : `supabase/functions/salarie-fiche/index.ts` exige l’en-tête Authorization et appelle `supabase.auth.getUser()` avec le header propagé.
* **Edge `compute-qf` et `compute-rights`** : `supabase/functions/compute-qf/index.ts:424-445` et `compute-rights/index.ts:254-275` créent un client `SUPABASE_SERVICE_ROLE_KEY`, prennent `body.user_id`, puis requêtent/écrivent selon cette valeur; aucun `getUser()` ni comparaison au sujet JWT n’est présent.
* **Edge `save-simulation`** : prend `organization_id` du body avec service role. Les autres variantes de simulation sont nombreuses; `supabase/config.toml` ne configure explicitement `verify_jwt=true` que pour `simulate-v1-backup`, `simulate-v1-stable`, `simulate-v2-test` et `save-simulation`. La couverture des fonctions réellement déployées n’est pas prouvée.

## 4. Autorisation : RBAC, guards et doublons

Il existe au moins quatre implémentations concurrentes :

1. rôle `profiles.role` dans `authenticateUser` et des tableaux de rôles inline dans `server/routes.ts`;
2. guards React (`ProtectedRoute`, `CseProtected`, `SalarieGuard`, `SalarieProtected`, `SalarieStepGuard`);
3. RBAC Offer (`AUTHORIZED_OFFER_ROLES`, `FORBIDDEN_OFFER_ROLES`, rôle métier et organisation issus du profil);
4. contrôles QF (`actorId`, `organizationId`, validations de scope).

Le front est donc un contrôle d’ergonomie, pas une autorité suffisante. Les contrôles Express ne sont pas uniformes (certaines routes utilisent `service_role` sans tenant filter). Les rôles legacy (`ADMIN`, `SUPERADMIN`, etc.) et métiers Offer (`SUPER_ADMIN`, etc.) ne sont pas normalisés dans un registre partagé. **AUTH transverse : CONFIRMED; RBAC transverse unique : REFUTED.**

## 5. Chaîne complète et point de rupture

`Utilisateur → AuthProvider/Supabase → JWT → middleware → guard/RBAC → route → controller/service → Supabase → RLS → table`.

* GDBCSE/API budgets : chaîne complète jusqu’à la route, mais `supabaseAdmin` en service role contourne RLS; la preuve de tenant est insuffisante.
* DBS direct PostgREST : garde React puis anon client; la chaîne se rompt à la preuve RLS (tables métier hors migrations RLS explicites).
* LifeHub : rupture possible au guard en DEV/`VITE_USE_MES_VIGILE`; le backend revalide toutefois `/api/mes/vigile`.
* Offer : middleware et RBAC présents; la persistance service role contourne les policies et la protection dépend du code applicatif.
* Edge QF/simulation : rupture critique entre JWT et payload (`user_id`/`organization_id` contrôlés par le demandeur).
* `/superadmin` : rupture avant middleware, au routage client.

## 6. Anomalies classées

| ID | Classification | Preuve | Impact / criticité |
|---|---|---|---|
| AUTH-C01 | **CONFIRMED** | `App.tsx` route `/superadmin` sans guard | Accès UI à une surface privilégiée; moyen (le backend peut refuser, mais la certification exige une défense en profondeur). |
| AUTH-C02 | **CONFIRMED** | `SalarieProtected.tsx`, `LifeHubRouteShell`, `VITE_USE_MES_VIGILE` | Bypass de contrôle de rôle en DEV/config; moyen à élevé selon exposition. |
| AUTH-C03 | **CONFIRMED** | `compute-qf/index.ts`, `compute-rights/index.ts`, `save-simulation/index.ts` | Confusion de sujet : un utilisateur authentifié peut fournir l’identifiant d’un autre; service role amplifie l’impact. **Élevé.** |
| AUTH-C04 | **CONFIRMED** | `server/routes.ts` `/api/subventions` GET/PATCH sélection/update sans filtre organisation | Risque inter-tenant si l’appel est accepté par rôle; **élevé**. |
| AUTH-C05 | **CONFIRMED** | Express/Offer/QF utilisent plusieurs middlewares et conventions de rôle | Autorité non unique, dérive de politiques; élevé pour certification, moyen en exploitation. |
| AUTH-C06 | **PARTIALLY CONFIRMED** | `supabase/config.toml` ne couvre que quatre fonctions; état distant absent | JWT gateway possiblement manquant sur fonctions non listées; impact élevé, mais déploiement réel non démontré. |
| AUTH-C07 | **PARTIALLY CONFIRMED** | `server/middleware/auth.middleware.ts`, `auth.controller.ts`, `routes/users.ts` non montés | Code legacy dangereux s’il est exposé; preuve d’exposition absente. |
| AUTH-C08 | **CONFIRMED** | nombreux appels anon directs côté client; RLS explicite limitée aux tables Offer | La sécurité DBS dépend de contrôles DB non présents dans le dépôt; élevé. |
| AUTH-C09 | **CONFIRMED** | fonctions `SECURITY DEFINER` (RPC subventions) | Les RPC exécutent avec privilèges élevés; leurs vérifications `auth.uid()` existent, mais la revue doit couvrir chaque chemin et privilège. Risque élevé si une variante est permissive. |
| AUTH-C10 | **REFUTED** | `AuthContext` + `authenticateUser` + Offer/QF tests | L’affirmation « AUTH n’existe pas/n’est pas utilisé » est fausse. |

## 7. Verdict de certification

* Existence et usage d’AUTH : **CONFIRMED**.
* Supabase comme fournisseur dominant : **CONFIRMED**; unicité de l’autorité runtime : **PARTIALLY CONFIRMED** (legacy non monté, état de déploiement non prouvé).
* Tous les domaines utilisent la même chaîne complète : **REFUTED**.
* Autorisation, RBAC, liaison sujet/tenant et RLS certifiables : **REFUTED**.
* NO GO sécurité : **CONFIRMED**.

Le NO GO doit être maintenu. Une levée GO exige au minimum : (1) lier chaque payload sensible au sujet JWT et refuser toute divergence; (2) supprimer les accès service role non nécessaires ou les encapsuler dans des fonctions vérifiées; (3) publier un inventaire RLS/policies pour chaque table métier et tester les tenants; (4) monter un middleware/registre RBAC unique et protéger toutes les routes privilégiées, y compris `/superadmin`; (5) figer les flags DEV et prouver `verify_jwt` pour chaque Edge déployée; (6) fournir la matrice de tests négatifs et la preuve de configuration distante. Ces actions sont ciblées et ne nécessitent ni migration aveugle ni régression fonctionnelle si elles sont introduites avec tests de non-régression.
