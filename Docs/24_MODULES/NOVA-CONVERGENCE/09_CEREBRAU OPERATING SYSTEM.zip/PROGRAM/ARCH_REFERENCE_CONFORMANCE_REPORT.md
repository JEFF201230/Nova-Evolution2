# ARCH-REFERENCE-CONFORMANCE-001

## Référence

Source d'index : `V2_OFFICIAL_DOCUMENT_REFERENCE.md`.

Décisions contrôlées : `OFFER_ARCHITECTURE_BOARD_DECISIONS_001.md`, D01 à
D10. Aucun domaine non référencé par ces décisions n'a été exploré.

## Synthèse

| Décision | Statut |
|---|---|
| D01 — `PUBLISHED` | `DOUBLE VERITE` |
| D02 — Cycle Offer/Version/Operation | `CONTRADICTION` |
| D03 — Contrat OfferVersion v2 | `CONTRADICTION` |
| D04 — Préconditions serveur | `CONTRADICTION` |
| D05 — Diffusion/outbox | `DERIVE` |
| D06 — Workbench/habilitations | `CONTRADICTION` |
| D07 — Rights/EBS | `CONTRADICTION` |
| D08 — Budget/Ledger | `CONFORME` au protocole de coexistence courant |
| D09 — Dotation | `CONFORME` : aucune responsabilité Dotation déplacée |
| D10 — Transition legacy | `CONFORME` : aucun retrait prématuré constaté |

## Divergences prouvées

### 1. Distribution Offer

Architecture :

Seul `ACTIVE` autorise la distribution, l'exposition salarié et l'ouverture
d'une Operation. `PUBLISHED` est exclusivement administratif.

Implémentation :

L'état `ACTIVE` et `ActivateOffer` existent, mais
`ListOfferDistributionFacts`, `ListOpenOperations`, `OpenOperation` et
`ResumeOperation` continuent à prendre `PUBLISHED` comme autorité.

Statut :

DOUBLE VERITE

Justification :

Le cycle d'écriture reconnaît `ACTIVE`, tandis que les lectures de
distribution et les préconditions d'Operation reconnaissent `PUBLISHED`.

Fichiers concernés :

- `server/offer-infrastructure/projections/PostgresOfferReadModel.ts`
- `server/offer-application/services/AuthoritativePreconditionResolver.ts`
- `server/offer-domain/types/states.ts`

### 2. Automate Offer

Architecture :

`ResumeOffer` retourne vers `ACTIVE`; une Offer active peut être suspendue et
la fermeture reste terminale.

Implémentation :

`SUSPENDED + ResumeOffer` retourne vers `PUBLISHED`. L'état `ACTIVE` ne
déclare aucune transition, y compris `SuspendOffer` et `CloseOffer`.

Statut :

CONTRADICTION

Justification :

Les transitions exécutables contredisent directement D02.

Fichier concerné :

- `server/offer-domain/state-machine/OfferStateMachine.ts`

### 3. Activation et contrat OfferVersion

Architecture :

Une OfferVersion activable fige les identifiants produit, règles Rights,
Budget et handoff Dotation typés. L'activation exige leurs références
autoritatives utilisables.

Implémentation :

`OfferVersionDefinition` conserve `family` et `parameters` génériques sans les
champs typés D03. `ActivateOffer` vérifie seulement l'état `PUBLISHED` et la
date d'effet ; aucune référence Rights, Budget ou Dotation n'est exigée.

Statut :

CONTRADICTION

Justification :

Une Version non conforme au contrat minimal D03 peut atteindre `ACTIVE`.

Fichiers concernés :

- `server/offer-domain/value-object/OfferVersion.ts`
- `server/offer-domain/aggregate/OfferAggregate.ts`

### 4. Résolution des blocages

Architecture :

Les blocages de reprise sont résolus depuis des repositories autoritatifs dans
la transaction.

Implémentation :

Pour `ResumeOffer`, le resolver charge l'Offer puis impose
`blockingConditionRemains: false` sans lire de source de blocage.

Statut :

CONTRADICTION

Justification :

L'absence de blocage est fabriquée par l'Application au lieu d'être prouvée
par une autorité référencée.

Fichier concerné :

- `server/offer-application/services/AuthoritativePreconditionResolver.ts`

### 5. Exploitation de l'outbox

Architecture :

Un dispatcher supervisé publie les événements Offer avec livraison
`at-least-once`.

Implémentation :

`OutboxDispatcher` existe et implémente la reprise, mais aucune composition
runtime de production ne l'instancie ; il est seulement exporté et référencé
par les tests.

Statut :

DERIVE

Justification :

Le composant prévu existe sans montage opérationnel, donc la diffusion
supervisée D05 n'est pas réalisée.

Fichiers concernés :

- `server/offer-infrastructure/events/OutboxDispatcher.ts`
- `server/offer-infrastructure/index.ts`

### 6. Habilitations Offer

Architecture :

Les capacités `OFFER_EDITOR`, `OFFER_VALIDATOR`, `OFFER_PUBLISHER`,
`OFFER_OPERATOR` et `OFFER_AUDITOR` séparent les responsabilités.

Implémentation :

Une allowlist unique `SUPER_ADMIN`, `ADMIN`, `SECRETAIRE` autorise
indifféremment l'administration de toutes les commandes. Aucune capacité
normative D06 n'est matérialisée.

Statut :

CONTRADICTION

Justification :

La responsabilité par action est remplacée par une autorisation globale.

Fichiers concernés :

- `server/offer-domain/types/roles.ts`
- `server/offer-domain/policy/RoleAuthorizationPolicy.ts`
- `server/offer-application/authorization/Authorization.ts`

### 7. Autorité Rights/EBS

Architecture :

Rights dérive toute disponibilité d'une OfferVersion active et traçable. EBS
ne force jamais `available=true`.

Implémentation :

`compute-rights` calcule depuis `qf_history` et `rights_config` sans
`offerId` ni `offerVersionId`. La projection EBS transforme ensuite chaque
droit en avantage avec `available: true`.

Statut :

CONTRADICTION

Justification :

Une disponibilité peut être produite sans OfferVersion active et EBS prend
une décision que D07 lui interdit.

Fichiers concernés :

- `supabase/functions/compute-rights/index.ts`
- `server/employee-business-state/projections/lifehub.helpers.ts`

## Décision finale

ARCHITECTURE NON CONFORME
