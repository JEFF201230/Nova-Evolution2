# PROGRAM GATE EXECUTION ORDER

## Gates immédiatement exécutables

| Ordre | Gate | LOT | État | Dépend de | Débloque | Action suivante |
|---|---|---|---|---|---|---|
| `P1` | `L01-G04` | `LOT-001` | `NO_GO` | `AUCUNE` | `L01-G06` | Faire statuer la décision de statut unique du PROGRAM. |
| `P1` | `L01-G05` | `LOT-001` | `NO_GO` | `AUCUNE` | `INCONNU` | Faire statuer les preuves de preflight CEREBRAU disponibles. |
| `P1` | `L02-G03` | `LOT-002` | `NO_GO` | `AUCUNE` | `L02-G05`<br>`L02-G06`<br>`L09-G02` | Faire statuer le registre des objets critiques qualifiés. |
| `P1` | `L02-G04` | `LOT-002` | `NO_GO` | `AUCUNE` | `L02-G06` | Faire statuer le registre de résolution des imports. |

## Gates exécutables après les premières ouvertures ou preuves directes

| Ordre | Gate | LOT | État | Dépend de | Débloque | Action suivante |
|---|---|---|---|---|---|---|
| `P2` | `L01-G06` | `LOT-001` | `NO_GO` | `L01-G04` | `INCONNU` | Enregistrer la première décision formelle de Gate. |
| `P2` | `L02-G05` | `LOT-002` | `NO_GO` | `L02-G03` | `L02-G06`<br>`L09-G04` | Compléter les producteurs et consommateurs des objets critiques. |
| `P2` | `L09-G02` | `LOT-009` | `NO_GO` | `L02-G03` | `INCONNU` | Qualifier les legacy atteignant un workflow MVP. |
| `P2` | `L03-G05` | `LOT-003` | `NO_GO` | `PRQ-EXT-001` | `L03-G07` | Obtenir la preuve des déploiements frontend et backend. |
| `P2` | `L03-G06` | `LOT-003` | `NO_GO` | `PRQ-EXT-002` | `L04-G03`<br>`L06-G05` | Obtenir les archives et hashes des Edge Functions déployées. |
| `P2` | `L05-G04` | `LOT-005` | `NO_GO` | `PRQ-REF-001` | `L05-G05`<br>`L05-G07`<br>`L06-G02`<br>`L08-G01` | Obtenir la référence contractuelle du producteur dossier-analyse QF. |
| `P2` | `L06-G01` | `LOT-006` | `NO_GO` | `PRQ-EXT-003` | `L06-G06` | Obtenir les tests 401 et 403 de l'API QF observable. |
| `P2` | `L07-G06` | `LOT-007` | `NO_GO` | `PRQ-EXT-004` | `L07-G04` | Obtenir le contrat Document Core corrigé et ses tests. |

## Gates de consolidation repository et runtime

| Ordre | Gate | LOT | État | Dépend de | Débloque | Action suivante |
|---|---|---|---|---|---|---|
| `P3` | `L02-G06` | `LOT-002` | `NO_GO` | `L02-G03`<br>`L02-G04`<br>`L02-G05` | `L04-G03` | Faire statuer la certification repository. |
| `P3` | `L03-G07` | `LOT-003` | `NO_GO` | `L03-G05` | `L04-G03` | Compléter la matrice d'existence des variables par runtime. |
| `P3` | `L06-G02` | `LOT-006` | `NO_GO` | `L05-G04` | `L06-G03`<br>`L06-G06` | Valider le rôle approbateur et ses tests d'autorisation. |
| `P4` | `L04-G03` | `LOT-004` | `NO_GO` | `L02-G06`<br>`L03-G04`<br>`L03-G06`<br>`L03-G07` | `L04-G04`<br>`L04-G05`<br>`L06-G04`<br>`L08-G04`<br>`L09-G03`<br>`L09-G04` | Faire statuer les autorités des concepts critiques. |
| `P4` | `L06-G03` | `LOT-006` | `NO_GO` | `L03-G04`<br>`L06-G02` | `L05-G06`<br>`L06-G06` | Produire les preuves RLS, grants, policies et tests des tables QF. |

## Gates Sources of Truth, sécurité et legacy

| Ordre | Gate | LOT | État | Dépend de | Débloque | Action suivante |
|---|---|---|---|---|---|---|
| `P5` | `L04-G04` | `LOT-004` | `NO_GO` | `L04-G03` | `L04-G06` | Valider le writer autorisé unique de chaque SOT critique. |
| `P5` | `L04-G05` | `LOT-004` | `NO_GO` | `L04-G03` | `L04-G06` | Rattacher les consommateurs critiques à leurs contrats et SOT. |
| `P5` | `L05-G06` | `LOT-005` | `NO_GO` | `L06-G03` | `L05-G07` | Faire statuer la preuve du writer unique QF. |
| `P5` | `L06-G04` | `LOT-006` | `NO_GO` | `L04-G03` | `L06-G06` | Valider la sécurité de `qf_history` et son writer autorisé. |
| `P5` | `L06-G05` | `LOT-006` | `NO_GO` | `L03-G06` | `L06-G06` | Valider le binding identité des Edge Functions QF. |
| `P5` | `L09-G03` | `LOT-009` | `NO_GO` | `L03-G04`<br>`L04-G03` | `INCONNU` | Statuer sur les objets runtime-only critiques. |
| `P5` | `L09-G04` | `LOT-009` | `NO_GO` | `L02-G05`<br>`L04-G03` | `INCONNU` | Statuer sur les objets repository-only critiques. |
| `P6` | `L04-G06` | `LOT-004` | `NO_GO` | `L04-G04`<br>`L04-G05` | `INCONNU` | Valider la non-autorité des projections et fixtures. |
| `P6` | `L06-G06` | `LOT-006` | `NO_GO` | `L06-G01`<br>`L06-G02`<br>`L06-G03`<br>`L06-G04`<br>`L06-G05` | `L05-G05`<br>`L07-G03`<br>`L08-G01` | Faire statuer la matrice sécurité complète. |

## Gates transactions et consommateurs

| Ordre | Gate | LOT | État | Dépend de | Débloque | Action suivante |
|---|---|---|---|---|---|---|
| `P7` | `L07-G03` | `LOT-007` | `NO_GO` | `L06-G06` | `L07-G04`<br>`L07-G05` | Produire les tests d'idempotence séquentielle et concurrente. |
| `P7` | `L08-G01` | `LOT-008` | `NO_GO` | `L05-G04`<br>`L06-G06` | `L08-G02`<br>`L08-G06` | Valider le read model QF sans fixture productive. |
| `P8` | `L07-G04` | `LOT-007` | `NO_GO` | `L07-G03`<br>`L07-G06` | `L07-G07`<br>`L08-G02` | Produire les tests de failpoints et rollback. |
| `P8` | `L07-G05` | `LOT-007` | `NO_GO` | `L07-G03` | `L05-G05` | Produire le test de double approbation concurrente. |
| `P9` | `L07-G07` | `LOT-007` | `NO_GO` | `L07-G04` | `L05-G05`<br>`L08-G04` | Valider le contrat et les métriques de l'outbox. |
| `P9` | `L08-G02` | `LOT-008` | `NO_GO` | `L08-G01`<br>`L07-G04` | `L08-G03`<br>`L08-G06` | Valider l'appel UI vers API et l'absence de faux commit. |
| `P10` | `L05-G05` | `LOT-005` | `NO_GO` | `L05-G04`<br>`L06-G06`<br>`L07-G05`<br>`L07-G07` | `L05-G07` | Fermer les frontières critiques QF. |
| `P10` | `L08-G03` | `LOT-008` | `NO_GO` | `L08-G02` | `L08-G06` | Produire les tests UI des erreurs contractuelles. |
| `P10` | `L08-G04` | `LOT-008` | `NO_GO` | `L07-G07`<br>`L04-G03` | `L08-G05`<br>`L08-G06` | Valider le contrat décision QF vers calcul des droits. |
| `P11` | `L08-G05` | `LOT-008` | `NO_GO` | `L08-G04` | `L08-G06` | Valider la propagation versionnée et fraîche vers EBS et LifeHub. |
| `P12` | `L08-G06` | `LOT-008` | `NO_GO` | `L08-G01`<br>`L08-G02`<br>`L08-G03`<br>`L08-G04`<br>`L08-G05` | `L05-G07` | Produire le test E2E vertical et son rollback. |
| `P13` | `L05-G07` | `LOT-005` | `NO_GO` | `L05-G04`<br>`L05-G05`<br>`L05-G06`<br>`L08-G06` | `INCONNU` | Faire statuer la décision de fermeture de la zone QF. |

## Gates de certification finale

| Ordre | Gate | LOT | État | Dépend de | Débloque | Action suivante |
|---|---|---|---|---|---|---|
| `P14` | `L10-G02` | `LOT-010` | `NO_GO` | `Preuve LOT-001 à LOT-009 = GO` | `L10-G06` | Consolider les décisions des neuf LOTS amont. |
| `P14` | `L10-G03` | `LOT-010` | `NO_GO` | `Preuve LOT-005 à LOT-008 = GO` | `L10-G06` | Faire statuer la preuve de chaîne MVP QF. |
| `P14` | `L10-G04` | `LOT-010` | `NO_GO` | `Preuve LOT-005 à LOT-009 = GO` | `L10-G06` | Faire statuer la matrice et les résultats des tests MVP. |
| `P14` | `L10-G05` | `LOT-010` | `NO_GO` | `Preuve LOT-001 à LOT-009 = GO` | `L10-G06` | Faire statuer le registre des risques critiques. |
| `P15` | `L10-G06` | `LOT-010` | `NO_GO` | `L10-G01`<br>`L10-G02`<br>`L10-G03`<br>`L10-G04`<br>`L10-G05` | `INCONNU` | Soumettre le dossier final à la signature des rôles requis. |

