# PROGRAM-EXECUTION-BY-EXCEPTION-001 — Modèle opératoire

## 1. Décision

Le PROGRAM VEEDDA peut être exploité en mode **Execution By Exception** sans nouveau logiciel.

Le mode retenu repose exclusivement sur les capacités déjà présentes :

- l'objet officiel `Wave` et la chaîne `Program → Wave → Squad Opening Order → Mission Order` ;
- le Campaign Runner et son DAG de Mission Orders ;
- le runtime unitaire `Invoke-CerebrauMission.ps1` ;
- les validations déclaratives des Mission Orders ;
- les snapshots Git, hashes SHA-256, rapports officiels et journaux existants ;
- les prérequis, preuves partagées, fingerprints, Resource Locks et événements Campaign ;
- la Doctrine de certification et sa propagation `Gate → LOT → PROGRAM`.

Les Work Packages ne sont ni utilisés ni reconnus comme objets de gouvernance. Ils ne participent à aucune règle, aucun calcul ni aucun verdict du présent modèle.

Le modèle conserve les décisions humaines qui engagent une autorité, un risque, une dérogation ou la certification finale. Il supprime les demandes humaines qui ne font que constater un résultat déjà déterminé par un contrat, un hash, une preuve ou un test.

## 2. Périmètre et faits d'entrée

Les faits certifiés fournis à la mission prévalent :

| Fait | Valeur appliquée |
|---|---|
| Objet officiel de gouvernance | `WAVE` |
| Work Packages | `NOT_OFFICIAL` |
| Fondation | `READY` |
| Modèle Wave canonique | `YES` |
| Contrat `MM-L01-03` canonique | `YES` |

Population de calcul pour les LOTS restants :

- `LOT-003` à `LOT-010`, soit 8 LOTS de livraison restants ;
- 36 Gates encore `NO_GO` dans cette population ;
- 36 Mission Orders correspondantes selon la cardinalité officielle Gate/Mission 1:1 ;
- `MM-L03-01`, déjà terminée et rattachée à une Gate `GO_WITH_DEROGATION`, est exclue du reste à faire ;
- les Gates déjà `GO` sont exclues et ne sont pas rejouées.

Références vérifiées :

- `Docs/09_CEREBRAU OPERATING SYSTEM/00_GOVERNANCE/PROGRAM_WAVE_ORCHESTRATION.md` ;
- `Docs/09_CEREBRAU OPERATING SYSTEM/05_RULES/ORCHESTRATION_GOVERNANCE.md` ;
- `Docs/09_CEREBRAU OPERATING SYSTEM/03_CODEX_EXECUTION_MVP/CAMPAIGN_RUNNER_MVP.md` ;
- `Docs/PROGRAM/PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md` ;
- `Docs/PROGRAM/PROGRAM_MASTER_GATES_REGISTER.md` ;
- `Docs/PROGRAM/PROGRAM_GATE_EXECUTION_ORDER.md` ;
- `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md` ;
- `tools/cerebrau/campaign-manifest.schema.json` ;
- `tools/cerebrau/campaign-state.schema.json` ;
- `tools/cerebrau/Cerebrau.Campaign.psm1` ;
- `tools/cerebrau/Invoke-CerebrauMission.ps1` ;
- `tools/cerebrau/Cerebrau.Reporting.psm1`.

## 3. Principes opératoires

### EBE-01 — Une autorisation porte sur un ensemble déclaré

Le Program Director autorise une Campaign dont le Manifest contient à l'avance les Mission Orders, dépendances, prérequis, preuves, scopes, modes d'exécution et exigences de revue. Cette autorisation vaut attribution explicite de toutes les missions déclarées ; elle ne vaut ni approbation anticipée de leurs résultats ni décision de Gate.

Une Mission Order absente du Manifest n'est jamais lancée.

### EBE-02 — Le silence signifie « continuer », jamais « approuver »

L'absence d'intervention humaine autorise uniquement la poursuite de l'ordonnancement lorsque les contrôles existants sont positifs. Elle ne crée pas une décision métier, une dérogation, une acceptation de risque, une Gate ou une certification.

### EBE-03 — Résultat déterministe = zéro contact

Une Mission Order est exploitable sans revue humaine individuelle lorsque son contrat déclare la revue non requise et que le runtime existant retourne `SUCCESS` après :

- code de sortie nul ;
- validations requises toutes passées ;
- livrables attendus présents ;
- périmètre de fichiers respecté ;
- hashes de baseline et de preuves conformes ;
- dépendances et prérequis satisfaits ;
- absence de conflit de lock, de scope, d'autorité ou de décision.

Le champ existant `humanReviewRequired=false` fait produire `SUCCESS` par le reporting unitaire ; le champ Campaign existant `reviewRequired=false` doit lui correspondre. Il ne s'agit ni d'un nouveau moteur ni d'une nouvelle règle logicielle.

Le contrat canonique `MM-L01-03` n'est pas modifié : sa revue humaine reste requise. Il constitue un cas de gouvernance explicite, pas le modèle par défaut des missions déterministes restantes.

### EBE-04 — La revue humaine est une exception nommée

La revue humaine reste obligatoire pour :

- un choix d'autorité ou de règle métier non déjà décidé ;
- une dérogation et son acceptation de risque ;
- une contradiction entre preuves ou décisions actives ;
- un risque juridique, sécurité, données, disponibilité ou criticité `C3/C4` ;
- une opération irréversible ou hors de l'autorisation déjà donnée ;
- la certification finale du PROGRAM ;
- toute Mission Order dont le contrat canonique exige explicitement une revue.

### EBE-05 — Les décisions de Gate restent explicites mais sont regroupées

La Doctrine exige une décision explicite, enregistrée et signée pour chaque Gate. Cette exigence est conservée. En régime normal, les décisions déterministes d'un même LOT sont préparées automatiquement à partir des preuves et soumises en **un seul paquet de décision LOT**. Une séance humaine peut signer plusieurs lignes Gate sans fusionner leurs identités, preuves ou décisions.

### EBE-06 — Continuer les branches saines

La politique d'exploitation normale est `CONTINUE_INDEPENDENT`. Une exception locale met en quarantaine la Mission Order concernée et ses descendants ; toute branche dont les dépendances, preuves, prérequis et locks restent valides continue.

`STOP_ALL` est réservé à une Campaign dont le périmètre est explicitement atomique ou à une exception globale définie à la section 8.

## 4. Cartographie des validations humaines actuelles

Légende :

- **Obligatoire** : l'exigence de contrôle demeure ;
- **Automatisable** : le résultat peut être établi par une capacité existante ;
- **Supprimable** : le contact ou document humain séparé peut disparaître, pas nécessairement le contrôle ;
- **Fusionnable** : plusieurs actes peuvent être réalisés en un seul paquet sans fusionner les objets officiels.

| Niveau / passage | Validation actuelle | Obligatoire | Automatisable avec l'existant | Supprimable | Fusionnable | Régime EBE |
|---|---|---:|---:|---:|---:|---|
| Program → Wave | Décision d'ouverture du Program | Oui | Partiellement | Non | Oui | Une décision initiale ; les critères d'entrée sont pré-calculés |
| Program → Wave | Ouverture de Wave par le Program Director | Oui | Partiellement | Non | Oui | Une autorisation par Wave, portant sur ses Campaigns déclarées |
| Program → Wave | Contrôle des prérequis, risques, ownership et voie d'escalade | Oui | Oui | Contact humain oui | Oui | Preflight et preuves hashées ; humain uniquement si résultat non déterministe |
| Wave → Squad | Squad Opening Order | Oui selon le modèle canonique | Partiellement | Non | Oui | Un ordre peut couvrir le périmètre stable d'une Squad pour la Wave |
| Wave → Campaign | Campaign Start Order / PDS | Oui pour une Campaign non démarrée | Partiellement | Non | Non entre Campaigns distinctes | Un seul ordre initial par Campaign ; aucun ordre par Mission |
| Campaign → Mission | Présence de la Mission dans le Manifest | Oui | Oui | Revue humaine oui | Sans objet | Validation de schéma et références |
| Campaign → Mission | Dépendances du DAG satisfaites | Oui | Oui | Oui | Sans objet | Ready set existant |
| Campaign → Mission | Prérequis externes satisfaits | Oui | Oui si preuve déclarée | Oui si binaire | Oui | `externalPrerequisites` + EvidenceId |
| Campaign → Mission | Preuves d'entrée présentes et intègres | Oui | Oui | Oui | Oui | `sharedEvidence`, SHA-256 et consumers |
| Campaign → Mission | Branche, dépôt, autorité et fingerprint conformes | Oui | Oui | Oui | Oui | Preflight Campaign existant |
| Campaign → Mission | Scope et ownership compatibles | Oui | Oui | Oui | Oui | Contrat de mission, path-scope et Resource Lock |
| Mission → Mission | Lancement de la mission suivante | Oui comme décision d'ordonnancement | Oui | Oui | Sans objet | Déclenchement par le ready set, sans ordre humain |
| Mission → Mission | Validation technique de la mission terminée | Oui | Oui | Oui | Oui | Rapport unitaire, tests, delta Git et hashes |
| Mission → Mission | Revue humaine de toute mission `READY_FOR_REVIEW` | Non pour un résultat purement déterministe ; oui si le contrat l'exige | Oui pour la partie factuelle | Oui pour les missions zéro-contact | Oui | Revue seulement pour les exceptions et contrats explicitement humains |
| Mission → Gate | Vérification que le livrable et les preuves existent | Oui | Oui | Oui | Oui | `fileExists`, tests, rapport officiel et Evidence Index |
| Mission → Gate | Qualification `GO/NO_GO` par règles fermées | Oui | Oui comme proposition déterministe | Contact séparé oui | Oui par LOT | La valeur est calculée ; la signature doctrinale reste regroupée |
| Mission → Gate | Acceptation d'une dérogation ou d'un risque | Oui | Non | Non | Oui si même autorité et même séance | Exception humaine obligatoire |
| Gate → LOT | Consolidation des décisions Gate | Oui | Oui | Rapport manuel séparé oui | Oui | Propagation doctrinale automatique, validation LOT groupée |
| LOT → Wave | Synchronization Gate | Oui si requise par la Wave | Oui pour cohérence, tests et locks | Réunion systématique oui | Oui | Réunion seulement en cas d'écart ; sinon paquet de preuves |
| Wave → Program | Fermeture de Wave | Oui | Partiellement | Non | Oui | Un acte sur rapport consolidé, pas une revue par mission |
| Program | Freeze, reprise après Freeze, Merge Window sensible | Oui lorsqu'applicable | Détection oui, décision non | Non | Non | Exception humaine |
| Program | Certification finale | Oui | Préparation oui, décision non | Non | Oui avec le paquet final | Signature finale humaine |

## 5. Remplacement de chaque famille de décision humaine

| Décision ou contrôle humain actuel | Remplacement autorisé | Capacité existante utilisée | Résultat EBE |
|---|---|---|---|
| Mission déclarée et attribuable | Règle contractuelle | Manifest Campaign + Manifest Mission | Démarrage interdit si contrat incomplet |
| Ordre des missions | Règle contractuelle + événement Campaign | `dependsOn`, priorité, ready set, `MISSION_READY` | Enchaînement automatique |
| Dépendance satisfaite | Contrôle automatique | État `SUCCEEDED` des prédécesseurs | Mission aval éligible |
| Prérequis externe satisfait | Preuve | `externalPrerequisites.status`, EvidenceId, assertedBy/At | Éligibilité sans réunion |
| Authenticité de l'autorité Campaign | Hash | `authority.sourceSha256` | Échec de preflight en cas de drift |
| Intégrité d'une preuve | Hash | `sourceSha256`, Evidence Index | Réutilisation ou blocage de la branche affectée |
| Identité des entrées d'une mission | Hash | Campaign fingerprint, hash du Manifest, hash du prompt, fingerprint d'entrée | Reprise sûre et détection de drift |
| Présence et format des livrables | Contrôle automatique | validations `fileExists`, `json`, `utf8` | PASS/FAIL factuel |
| Respect du périmètre | Contrôle automatique + preuve | snapshots avant/après, delta Git, `pathScope`, `gitDiffCheck` | Rejet automatique hors scope |
| Conformité fonctionnelle ou technique | Test | validations nommées, suites unitaires/intégration/E2E existantes | PASS/FAIL factuel |
| Non-régression | Test + preuve | commandes de test déclarées et rapport officiel | Pas de revue manuelle si tout est PASS |
| Collision de ressources | Resource Lock | scopes de mission, lock de Campaign, règles d'ownership | Mission concurrente bloquée |
| Avancement et traçabilité | Événement Campaign | journal JSONL et projections d'état | Aucun rapport d'avancement manuel |
| Reprise après interruption technique | Événement + état | journal, état persistant, `CAMPAIGN_RESUMED` | Reprise sans rejouer les succès |
| Mission valide suivante | Événement Campaign | `MISSION_FINISHED` puis `READY_SET_COMPUTED` | Exécution automatique de la mission éligible suivante |
| Gate déterministe | Règle doctrinale + preuves + tests | sections 6 à 9 de la Doctrine | Proposition de décision reproductible |
| Consolidation LOT | Règle doctrinale | propagation `Gate → LOT` | Calcul sans comité intermédiaire |
| Choix d'autorité, dérogation ou risque | Aucun remplacement automatique | Paquet de preuves existant | Intervention humaine conservée |
| Certification PROGRAM | Aucun remplacement automatique | Dossier final, hashes, rapports, décisions LOT | Signature humaine conservée |

Un hash prouve l'intégrité d'un contenu, jamais sa vérité métier. Un test prouve son assertion et son périmètre, jamais une autorité non attribuée. Le modèle interdit ces substitutions abusives.

## 6. Cycle d'exécution par exception

1. Le Program Director ouvre la Wave et autorise la Campaign déclarée.
2. Le Campaign Runner exécute son preflight existant : autorité, branche, dépôt, schéma, DAG, Gate refs, Mission files, profils, scopes, prérequis et hashes.
3. Le Runner calcule le ready set.
4. La première Mission Order éligible est exécutée par `Invoke-CerebrauMission.ps1`.
5. Le runtime produit snapshots, delta, validations, rapport officiel et statut.
6. Si le statut est `SUCCESS`, la Mission Order devient `SUCCEEDED`; le Runner recalcule immédiatement le ready set et lance la suivante.
7. Si une exception locale survient, la mission et ses descendants sont bloqués ; les branches indépendantes continuent.
8. Si une exception globale survient, la Campaign s'arrête et produit son état, son journal et son rapport existants.
9. À la fin d'un LOT, les lignes Gate sont consolidées dans un paquet unique. Les décisions déterministes sont signées en lot ; les exceptions sont arbitrées explicitement.
10. La propagation `Gate → LOT → PROGRAM` est recalculée selon la Doctrine.
11. La Wave se ferme uniquement lorsque les conditions officielles de sortie sont satisfaites et les locks libérés.

### États sans intervention humaine

`PENDING → READY → RUNNING → SUCCEEDED → READY_SET_COMPUTED → mission suivante`

### États d'exception

`BLOCKED_PREREQUISITE`, `BLOCKED_EVIDENCE`, `BLOCKED_DEPENDENCY`, `AWAITING_REVIEW`, `PARTIAL`, `FAILED`, `STALE`, `CANCELLED`, `ROLLED_BACK`, `INTERRUPTED`.

Ces états ne conduisent pas tous à l'arrêt global : la politique `CONTINUE_INDEPENDENT` maintient les branches saines.

## 7. Rapports et preuves conservés

Sont conservés, car ils sont déjà produits automatiquement et nécessaires à l'audit :

- rapport officiel unitaire et son hash ;
- journal d'exécution unitaire ;
- snapshots et delta Git ;
- état et journal Campaign ;
- Evidence Index ;
- rapport consolidé Campaign ;
- décisions Gate explicites ;
- paquet de décision LOT ;
- dossier et décision finale PROGRAM.

Sont supprimés comme livrables humains séparés en régime normal :

- rapports d'avancement intermédiaires ;
- compte rendu de lancement de chaque Mission Order ;
- rapport manuel de vérification qui répète les validations du rapport officiel ;
- rapport manuel de résultat qui répète les livrables et le delta ;
- rapport de synchronisation sans divergence ;
- rapport de reprise lorsque le journal Campaign établit déjà la reprise ;
- décision de passage à la mission suivante.

La suppression porte sur les doublons documentaires, jamais sur les preuves, journaux, décisions officielles ou rapports machine existants.

## 8. Événements arrêtant automatiquement la Campaign

La liste suivante est fermée. Aucun autre événement ne doit arrêter globalement la Campaign.

1. **Autorité invalide** : hash d'autorité différent, source d'autorité absente, décision PROGRAM déclarée incompatible ou référence Gate/Mission incohérente.
2. **Manifest ou DAG invalide** : schéma/version invalide, doublon d'identité, dépendance inconnue, cycle, mission ou prompt absent, profil non résolu, dépôt ou branche incompatibles.
3. **État d'audit non fiable** : état ou journal corrompu, séquence invalide, fingerprint de Campaign incompatible, rapport persistant obligatoire absent ou invalide.
4. **Concurrence globale** : lock de Campaign détenu par un processus actif ou conflit de Resource Lock touchant le périmètre atomique commun à toute la Campaign.
5. **Drift global de preuve** : preuve d'autorité ou preuve partagée critique devenue absente ou `STALE` et consommée par toutes les branches restantes.
6. **Violation de sécurité ou de périmètre globale** : écriture hors scope, accès interdit, secret exposé, risque d'intégrité ou de données `C4`, ou résultat de test critique démontrant que poursuivre aggraverait l'impact.
7. **Contradiction d'autorité** : décisions actives incompatibles sur la même clé doctrinale, autorité décisionnelle absente, ou règle applicable indéterminable.
8. **Freeze ou contrôle explicite** : `PROGRAM FREEZE`, requête `STOP` ou `CANCEL` émise par une autorité compétente.
9. **Politique atomique déclenchée** : échec, `PARTIAL` ou annulation d'une Mission Order dans une Campaign explicitement autorisée avec `STOP_ALL`.
10. **Aucune branche saine restante** : ready set vide alors qu'au moins une mission obligatoire reste bloquée, stale, en attente de revue ou en échec.

Ne doivent pas arrêter globalement la Campaign :

- la réussite d'une Mission Order ;
- l'attente d'une dépendance sur une seule branche ;
- un prérequis absent pour une seule branche ;
- une preuve invalide consommée par une seule branche ;
- l'échec d'une branche indépendante sous `CONTINUE_INDEPENDENT` ;
- la production normale d'un rapport ;
- une Synchronization Gate sans divergence ;
- l'absence d'accusé humain entre deux missions déterministes.

## 9. Exceptions nécessitant une décision humaine

| Exception | Autorité minimale | Décision attendue |
|---|---|---|
| Choix d'autorité d'un concept critique | Architecture/métier compétente | Autorité et contrat d'écriture |
| Choix du rôle approbateur QF | Autorité métier + sécurité | Rôle autorisé et limites |
| Maintenir, migrer ou retirer un objet runtime-only | Architecture + owner métier | Disposition et rollback |
| Déployer ou abandonner un objet repository-only | Architecture + owner métier | Disposition et preuve consommateur |
| Dérogation `C1/C2` | Autorité prévue par la Doctrine | Acceptation bornée et révision |
| Dérogation `C3` transverse | Comité PROGRAM + Program Director | Acceptation explicite du risque |
| Risque sécurité, juridique, données ou disponibilité | Autorité spécialisée + niveau doctrinal | Acceptation ou `NO_GO` |
| Criticité `C4` | Comité PROGRAM après nouvelle preuve | `NO_GO` puis éventuelle réouverture |
| Contradiction de preuve ou de décision | Autorité propriétaire du périmètre | Révision traçable |
| Mission canonique avec revue obligatoire | Autorité déclarée par la Mission Order | `APPROVE` ou `REJECT` |
| Certification finale | Comité PROGRAM + Program Director | Verdict final signé |

## 10. Application aux 36 Mission Orders restantes

### 10.1 Zéro-contact attendu

Les missions de collecte de preuve, hash, test, conformité de scope, consolidation arithmétique et contrôle d'interface peuvent être zéro-contact lorsque leurs critères sont binaires et préexistants.

Exemples dans le registre restant : preuves runtime `MM-L03-02` à `04`, contrôles de writer/interface, tests sécurité, idempotence, rollback, concurrence, UI, E2E, fraîcheur et consolidation de résultats.

### 10.2 Décision humaine attendue

Les missions portant un choix non déductible restent humaines, notamment :

- `MM-L04-01` — autorité des concepts critiques ;
- `MM-L06-02` — rôle approbateur métier ;
- `MM-L09-02` — disposition des objets runtime-only ;
- `MM-L09-03` — disposition des objets repository-only ;
- `MM-L10-04` — acceptation des risques résiduels, si nécessaire ;
- `MM-L10-05` — certification finale.

Les certifications intermédiaires (`MM-L05-04`, `MM-L06-06`, `MM-L10-01`, `MM-L10-03`) restent des identités officielles, mais leur préparation peut être automatique et leur signature fusionnée avec le paquet LOT correspondant.

## 11. Évaluation quantitative

### 11.1 Convention de comptage

Le calcul porte sur `LOT-003` à `LOT-010` et leurs 36 couples Gate/Mission encore ouverts. Il mesure des objets ou contacts logiques, pas les deux formats JSON/Markdown d'un même rapport machine.

Les délais externes des cinq prérequis publiés sont exclus : le modèle ne peut accélérer l'obtention d'un accès, d'un artefact distant ou d'une décision d'un tiers.

### 11.2 Missions de gouvernance

Le modèle officiel impose une relation Gate/Mission 1:1. Aucune des 36 Mission Orders officielles n'est supprimée par cette doctrine :

- structure officielle : `36 → 36`, réduction **0 %** ;
- missions/actes de gouvernance nécessitant une intervention dédiée : estimation `10 → 5` grâce à l'automatisation des consolidations et au regroupement des certifications, réduction **50 %**.

La réduction de 50 % est opérationnelle ; elle ne renumérote, ne fusionne et ne supprime aucune Gate ou Mission Order.

### 11.3 PDS

Le corpus PROGRAM ne démontre qu'un PDS opérationnel de démarrage, `PDS-CAMPAIGN-START-ORDER-001`, déjà effectif. Le modèle le réutilise et ne crée aucun PDS supplémentaire pour passer d'une mission à la suivante :

- PDS existants nécessaires à la Campaign courante : `1 → 1` ;
- réduction factuelle : **0 %** ;
- PDS additionnels par Mission Order restante : **0**.

Il serait non probant d'annoncer une réduction par rapport à 36 PDS individuels, car ce stock n'existe pas dans le référentiel courant.

### 11.4 Rapports

Baseline logique conservatrice pour 36 missions :

- 36 rapports officiels unitaires ;
- 36 rapports humains séparés de décision/vérification Gate ;
- 8 rapports de consolidation LOT ;
- 1 rapport final PROGRAM ;
- total : 81 rapports logiques.

Cible EBE :

- 36 rapports officiels unitaires automatiques ;
- 8 rapports Campaign/LOT consolidés ;
- 1 rapport final PROGRAM ;
- total : 45 rapports logiques.

Calcul : `(81 - 45) / 81 = 44,4 %`, soit une réduction attendue de **44 %**. Les 36 suppressions sont exclusivement des rapports intermédiaires redondants.

### 11.5 Validations humaines

Baseline :

- 36 revues humaines de Mission Order ;
- 36 passages humains Gate ;
- 8 décisions de consolidation LOT ;
- 1 décision finale PROGRAM ;
- total : 81 interventions.

Cible EBE :

- 8 séances de décision LOT regroupant les Gates et les exceptions du LOT ;
- 1 décision finale PROGRAM ;
- total : 9 interventions planifiées hors exception imprévisible.

Calcul : `(81 - 9) / 81 = 88,9 %`, soit une réduction attendue de **89 %**.

Une exception réelle ajoute une intervention ; elle ne remet pas en cause le mode, puisqu'elle est précisément son objet.

### 11.6 Temps de livraison

Le planning publié donne une borne historique de 15 jours ouvrés théoriques, 30 jours réalistes et 60 jours pessimistes, hors délais externes. Le modèle ne réduit pas le temps d'exécution technique ; il réduit les files d'attente entre missions, revues et Gates.

Estimation centrale :

- baseline réaliste : 30 jours ouvrés ;
- cible EBE : 20 jours ouvrés ;
- gain : 10 jours ouvrés ;
- accélération : `(30 - 20) / 30 = 33,3 %`, soit **33 %**.

Fourchette prudente : 8 à 15 jours ouvrés gagnés lorsque les prérequis externes sont disponibles avant leur branche consommatrice. Aucun gain n'est imputé à un délai externe non maîtrisé.

### 11.7 Synthèse

| Indicateur | Baseline | Cible | Réduction / gain |
|---|---:|---:|---:|
| Mission Orders officielles restantes | 36 | 36 | 0 % |
| Actes/missions de gouvernance à intervention dédiée | 10 | 5 | 50 % |
| PDS existants nécessaires à la Campaign courante | 1 | 1 | 0 % |
| PDS additionnels par mission | 0 | 0 | 0 |
| Rapports logiques | 81 | 45 | 44 % |
| Interventions humaines planifiées | 81 | 9 | 89 % |
| Délai réaliste hors prérequis externes | 30 j | 20 j | 10 j / 33 % |

## 12. Conditions d'adoption

L'adoption est valide si les conditions suivantes sont appliquées comme règles d'exploitation, sans développement :

1. une seule source d'autorité Gate/Mission/Dépendance est utilisée ;
2. toute Campaign utilise le Runner, le runtime unitaire, les schémas et les rapports existants ;
3. `CONTINUE_INDEPENDENT` est la politique normale hors périmètre explicitement atomique ;
4. les contrats déterministes utilisent les champs de revue existants pour produire `SUCCESS` sans revue individuelle ;
5. les contrats canoniques exigeant une revue, dont `MM-L01-03`, restent inchangés ;
6. les décisions Gate restent explicites et traçables, même lorsqu'elles sont signées dans un paquet LOT ;
7. aucune preuve, aucun hash, aucun test et aucun événement ne se substitue à une décision d'autorité ;
8. seules les exceptions de la section 8 arrêtent globalement la Campaign ;
9. aucune branche saine n'est arrêtée par l'exception d'une branche indépendante ;
10. aucun Work Package n'est introduit dans la gouvernance ou le calcul.

## 13. Verdict

EXECUTION BY EXCEPTION FEASIBLE = YES

NEW SOFTWARE REQUIRED = NO

EXISTING COMPONENTS SUFFICIENT = YES

EXPECTED GOVERNANCE REDUCTION = 50 %

EXPECTED HUMAN INTERVENTION REDUCTION = 89 %

EXPECTED DELIVERY ACCELERATION = 33 %

RECOMMEND ADOPTION = YES
