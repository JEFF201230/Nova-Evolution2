# PROGRAM-CEREBRAU-CERTIFIED-FACTS-MVP-001

## Résultat

Le registre minimal de faits certifiés est créé dans `tools/cerebrau/certified-facts.json` et le runtime unitaire CEREBRAU l'injecte automatiquement en tête du prompt transmis au modèle.

L'injection est limitée à `tools/cerebrau/Invoke-CerebrauMission.ps1`. Le contenu brut UTF-8 du registre est placé dans un bloc `<CERTIFIED_FACTS>...</CERTIFIED_FACTS>` avant le prompt de mission.

Lorsque le fichier n'existe pas, la branche d'injection n'est pas exécutée et la valeur du prompt reste inchangée.

## Validation

Un test minimal éphémère, retiré après exécution afin de respecter le périmètre des livrables, a capturé l'entrée réellement transmise à un faux exécutable Codex :

- avec registre : statut `SUCCESS`, registre présent au début, prompt complet exact ;
- sans registre : statut `SUCCESS`, prompt transmis strictement identique au prompt source.

Résultat du test ciblé : `2/2 PASS`.

La suite existante `tools/cerebrau/Test-CerebrauRuntimeE2E.ps1` a également été exécutée dans son scénario sans registre : `15/15 PASS`.

Contrôles complémentaires : syntaxe PowerShell valide, JSON valide et `git diff --check` sans erreur.

## Critères de réussite

CERTIFIED FACTS FILE CREATED = YES

AUTOMATIC PROMPT INJECTION = YES

RUNTIME COMPATIBILITY = PASS

BEHAVIOR WITHOUT FILE = IDENTICAL

REGRESSION DETECTED = NO

## Périmètre

Aucun profil, moteur d'orchestration, Campaign Runner, composant Governance, Gate, Campaign, Manifest ou mécanisme de persistance supplémentaire n'a été modifié. Aucun commit et aucun push n'ont été effectués.
