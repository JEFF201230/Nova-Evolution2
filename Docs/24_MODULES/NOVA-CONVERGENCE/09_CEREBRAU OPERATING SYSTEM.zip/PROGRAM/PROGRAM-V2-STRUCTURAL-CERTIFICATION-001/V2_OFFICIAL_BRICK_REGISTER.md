# Registre Officiel des Briques V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Mission | `PROGRAM-V2-STRUCTURAL-CERTIFICATION-001` |
| Type | Certification structurelle documentaire |
| Date de certification | 2026-07-24 |
| Objet officiel de gouvernance | `WAVE` |
| Autorité | Program Director |
| Statut du registre | Référentiel officiel V2 |

## 1. Décision de registre

Le présent document est le registre officiel et unique des briques V2 identifiées dans le corpus approuvé par le Program Director.

Il ne crée aucune architecture, ne modifie aucun contrat et ne requalifie aucune décision. Il consolide les définitions déjà approuvées, leur rattachement documentaire et leur statut d'implémentation déclaré par les documents officiels.

Toutes les briques enregistrées ci-dessous obtiennent automatiquement :

- `REVUE PROGRAM = VALIDÉE` ;
- `STRUCTURAL VALIDATION = PASS`.

Elles sont donc figées dans la limite exacte de leur définition officielle.

## 2. Règle de granularité

Est enregistrée comme brique toute unité structurelle :

- nommée et classifiée par la doctrine V2 ou par les décisions `D01` à `D10` ;
- dotée d'une responsabilité, d'une frontière ou d'un cycle propre ;
- rattachable à une définition officielle unique.

Ne sont pas promus en briques autonomes :

- les champs, statuts et propriétés internes ;
- les exemples de clés `ELIGIBILITY`, `RIGHTS`, `QF_INPUT`, `BUDGET_RESOLUTION`, `EXECUTION` et `DOCUMENT_REQUIREMENTS` ;
- les DTO, rapports, commandes et événements qui matérialisent une brique sans posséder d'autorité autonome ;
- les rôles du Workbench ;
- les espaces d'écran et les étapes UX ;
- les exemples de payload ou placeholders ;
- les objets existants seulement conservés par V2 : `Offer`, `OfferVersion`, `Operation`, `Dispositif`, `FundingPolicy`, Rights, Budget, Ledger, Execution, EBS, QF et Simulation.

Cette règle empêche de créer une architecture secondaire à partir de détails d'implémentation.

## 3. Ordre de préséance

L'unicité des définitions est déterminée dans l'ordre suivant :

1. faits certifiés de la mission ;
2. décisions du Program Director / Architecture Board du 23 juillet 2026 ;
3. décisions finales de `PROGRAM-OFFER-COMPOSITION-001` ;
4. doctrines détaillées Business Component, composition et Workbench ;
5. corpus Offer canonique existant, pour la fondation conservée ;
6. rapports de réconciliation et d'exécution, uniquement comme preuves de statut.

Une formulation ancienne explicitement supersédée reste une preuve historique et ne constitue pas une seconde définition active.

## 4. Registre

### V2-BR-001 — BusinessComponent

| Champ | Certification |
|---|---|
| Classification officielle | Aggregate Root dans le bounded context Offer |
| Définition figée | Descripteur métier réutilisable, identifié, versionné et gouverné dans Offer ; il expose une capacité composable et son contrat sans absorber le domaine ni le runtime référencés. |
| Frontière figée | Ni bounded context, ni microservice, ni moteur, ni source de vérité d'un domaine voisin. |
| Documents de définition | `OFC-03`, `OFC-04`, `OFC-05` |
| Définition officielle unique | Oui — définition tactique et sémantique identiques ; les documents détaillés complètent la même racine d'agrégat. |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-002 — ComponentVersion

| Champ | Certification |
|---|---|
| Classification officielle | Entity interne de BusinessComponent |
| Définition figée | Version adressable du contrat de composant ; cycle `DRAFT -> VALIDATED -> PUBLISHED -> SUPERSEDED`, contenu immuable dès validation et sélectionnable selon les règles publiées. |
| Frontière figée | Son numéro versionne le contrat de composition, jamais l'implémentation du domaine externe. |
| Documents de définition | `OFC-03`, `OFC-04`, `OFC-05` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-003 — OfferCharacteristic

| Champ | Certification |
|---|---|
| Classification officielle | Value Object de l'OfferVersion |
| Définition figée | Valeur typée décrivant un aspect intrinsèque de l'Offer, sans identité ni cycle autonome, figée dans la version publiée. |
| Frontière figée | Ne duplique aucune donnée souveraine et ne crée aucun référentiel parallèle. |
| Documents de définition | `OFC-01`, `OFC-03`, `OFC-05` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-004 — OfferComposition

| Champ | Certification |
|---|---|
| Classification officielle | Value Object de l'OfferVersion |
| Définition figée | Snapshot complet, ordonné, versionné et immuable des caractéristiques, versions exactes de composants, configurations, références et version du contrat de composition. |
| Frontière figée | Appartient à une seule OfferVersion ; aucune résolution implicite vers une version « latest ». |
| Documents de définition | `OFC-01`, `OFC-03`, `OFC-05` |
| Définition officielle unique | Oui — une seule place officielle : l'OfferVersion. |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-005 — ComponentConfiguration

| Champ | Certification |
|---|---|
| Classification officielle | Value Object |
| Définition figée | Configuration déclarative validée par le schéma de la ComponentVersion et figée dans l'OfferVersion. |
| Frontière figée | Aucun résultat individuel, secret, binaire, solde, calcul ou état souverain externe. |
| Documents de définition | `OFC-03`, `OFC-04`, `OFC-05` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-006 — ComponentReference

| Champ | Certification |
|---|---|
| Classification officielle | Value Object |
| Définition figée | Référence exacte et opaque vers un BusinessComponent, une ComponentVersion et un contrat identifiés. |
| Frontière figée | La référence ne transfère jamais la souveraineté de l'objet externe et n'est jamais résolue vers « latest ». |
| Documents de définition | `OFC-03`, `OFC-04`, `OFC-05` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-007 — CompositionContract

| Champ | Certification |
|---|---|
| Classification officielle | Contrat versionné |
| Définition figée | Forme stable de la composition : version, types, champs, cardinalités, références et règles de validation. |
| Frontière figée | Aucune autorité métier autonome et aucun algorithme QF, Rights, Budget, Ledger ou Simulation. |
| Documents de définition | `OFC-01`, `OFC-03`, `OFC-05` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-008 — CompositionRules

| Champ | Certification |
|---|---|
| Classification officielle | Contrat déclaratif versionné |
| Définition figée | Règles de complétude, cardinalité, dépendance, exclusion et cohérence interne de composition. |
| Frontière figée | Vocabulaire fermé, typé et auditable ; aucun script libre ni moteur de règles autonome. |
| Documents de définition | `OFC-01`, `OFC-03`, `OFC-04`, `OFC-05` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-009 — CompatibilityRules

| Champ | Certification |
|---|---|
| Classification officielle | Contrat déclaratif versionné |
| Définition figée | Contraintes explicites de compatibilité de versions, caractéristiques, familles, références, dépendances, exclusions et cardinalités. |
| Frontière figée | N'accorde aucun droit et n'exécute aucun domaine référencé. |
| Documents de définition | `OFC-01`, `OFC-03`, `OFC-04`, `OFC-05` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-010 — CompositionValidation

| Champ | Certification |
|---|---|
| Classification officielle | Domain Service pur et sans état souverain |
| Définition figée | Évalue de façon déterministe une composition contre ses contrats et règles et retourne un rapport versionné sans mutation. |
| Frontière figée | Ne calcule ni éligibilité, ni droit, ni montant, ni budget, ni QF, ni simulation ; ne produit aucun effet aval. |
| Documents de définition | `OFC-01`, `OFC-03`, `OFC-05` |
| Définition officielle unique | Oui — `CompositionValidationService` et son rapport sont les matérialisations de cette même brique. |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-011 — BusinessComponentLibraryProjection

| Champ | Certification |
|---|---|
| Classification officielle | Projection de lecture du Query Model Offer |
| Définition figée | Vue serveur reconstructible des BusinessComponents, de leurs versions, schémas, cycles et compatibilités. |
| Frontière figée | Ni Aggregate Root, ni registre souverain parallèle, ni catalogue frontend autoritatif. |
| Documents de définition | `OFC-01`, `OFC-03`, `OFC-04`, `OFC-05`, `OFC-06` |
| Définition officielle unique | Oui — « bibliothèque de composants » et `BusinessComponentLibraryProjection` désignent la même projection. |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-012 — CompositionWorkbench

| Champ | Certification |
|---|---|
| Classification officielle | Capacité applicative et UI Back Office |
| Définition figée | Atelier gouverné de composition et d'exploitation Offer, appuyé exclusivement sur les commandes, queries et projections serveur. |
| Frontière figée | Ni Aggregate, ni moteur, ni source de vérité ; aucune mutation directe de table et aucune décision métier individuelle. |
| Documents de définition | `OFC-01`, `OFC-03`, `OFC-06`, `BOARD-01` décision `D06` |
| Définition officielle unique | Oui — `D06` étend le périmètre opérateur de la définition Workbench sans créer une UI concurrente. |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-013 — Contrat typé OfferVersion v2

| Champ | Certification |
|---|---|
| Classification officielle | Contrat versionné de l'Entity OfferVersion |
| Définition figée | Contrat typé figeant l'identité produit, la période, les références de règles, Budget et Dotation, la version de schéma et le lineage, sans absorber leurs calculs. |
| Frontière figée | Les extensions non typées restent non souveraines ; les domaines Rights, Budget et Dotation conservent leurs autorités. |
| Documents de définition | `BOARD-01` décision `D03`, `OFC-03`, `OFC-05` |
| Définition officielle unique | Oui — le Board complète et gouverne le contrat de composition porté par OfferVersion. |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-014 — Offer Activation

| Champ | Certification |
|---|---|
| Classification officielle | Capacité de cycle de vie de l'Aggregate Offer |
| Définition figée | Activation explicite, idempotente et auditée d'une OfferVersion publiée, autorisée à partir de `effectiveAt`, matérialisée par `ActivateOffer`, `ACTIVE` et `OfferActivated`. |
| Frontière figée | Publication administrative, activation métier et ouverture d'Operation restent trois actes distincts ; aucun effet aval automatique. |
| Documents de définition | `BOARD-01` décisions `D01` et `D02`, `OFC-01`, `OFC-03` |
| Définition officielle unique | Oui — `BOARD-01` supersède explicitement toute ancienne équivalence `PUBLISHED = distribuable`. |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-015 — Résolution autoritative des préconditions serveur

| Champ | Certification |
|---|---|
| Classification officielle | Responsabilité de la couche Application dans la transaction de commande |
| Définition figée | Résolution serveur de toute preuve souveraine d'existence, état, complétude, séparation des tâches, référence, fenêtre et blocage à partir des repositories autoritatifs. |
| Frontière figée | Le client transmet une intention ; ses booléens ou compteurs ne constituent jamais une preuve métier. |
| Documents de définition | `BOARD-01` décision `D04`, `OFC-01`, `OFC-06` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune — les payloads historiques sont un écart d'implémentation, pas une définition concurrente. |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-016 — Diffusion Offer vers Rights/EBS par outbox et query autoritative

| Champ | Certification |
|---|---|
| Classification officielle | Contrat d'intégration hybride |
| Définition figée | Outbox pour notifier les changements de cycle, livraison at-least-once et query autoritative pour bootstrap, réparation et réconciliation. |
| Frontière figée | Rights conserve le calcul ; EBS reste une projection ; aucun second moteur dans Offer ou EBS. |
| Documents de définition | `BOARD-01` décision `D05`, `OFC-01`, `CAN-BASE` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PARTIALLY_IMPLEMENTED |

### V2-BR-017 — Lineage OfferVersion vers Rights

| Champ | Certification |
|---|---|
| Classification officielle | Contrat causal versionné inter-domaines |
| Définition figée | Toute nouvelle décision Rights disponible est dérivée d'une OfferVersion activée et conserve tenant, Offer, Version, règle, source QF, instant, verdict, motif et causalité. |
| Frontière figée | Rights reste le moteur d'éligibilité ; Offer ne calcule aucun droit ; EBS ne force jamais la disponibilité. |
| Documents de définition | `BOARD-01` décision `D07`, `OFC-01`, `OFC-03` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-018 — Lineage financier Offer/Budget/Ledger

| Champ | Certification |
|---|---|
| Classification officielle | Contrat causal inter-domaines |
| Définition figée | Toute nouvelle réservation, libération, subvention, attribution, consommation, écriture ou paiement conserve l'origine Offer, OfferVersion, Budget et, selon le cas, Operation et décision Rights. |
| Frontière figée | `budgets` reste l'autorité des enveloppes ; `budget_ledger` est la cible des nouveaux mouvements ; aucune origine historique n'est inventée. |
| Documents de définition | `BOARD-01` décision `D08`, `OFC-01`, `OFC-03` |
| Définition officielle unique | Oui — le choix `budget_ledger` gouverne la cible V2, sous les contrôles de données prévus. |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-019 — Bounded Context Dotation

| Champ | Certification |
|---|---|
| Classification officielle | Bounded context souverain distinct |
| Définition figée | Autorité d'attribution et de délivrance d'un avantage autorisé, consommant OfferVersion active, décision Rights et référence Budget, sans tenir de ledger parallèle. |
| Frontière figée | Ne définit ni catalogue produit, ni éligibilité, ni présentation EBS ; responsabilité d'architecture et de données : Domain Board Dotation/Finance. |
| Documents de définition | `BOARD-01` décision `D09` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune — l'interdiction de créer un second moteur dans Offer, Rights ou EBS est conservée. |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

### V2-BR-020 — Protocole de coexistence et de retrait du legacy

| Champ | Certification |
|---|---|
| Classification officielle | Protocole structurel de transition par consommateur |
| Définition figée | Inventaire, source cible et lineage, lecture comparée, correction, certification, bascule réversible, gel des écritures, observation puis retrait décidé par Gate. |
| Frontière figée | Ni bascule globale immédiate, ni double écriture permanente, ni suppression avant remplacement et preuve. |
| Documents de définition | `BOARD-01` décision `D10` |
| Définition officielle unique | Oui |
| Contradiction officielle active | Aucune |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | NOT_APPLICABLE |

### V2-BR-021 — AF_QF_RIGHTS

| Champ | Certification |
|---|---|
| Classification officielle | Artefact correctif borné de l'infrastructure QF/Rights |
| Définition figée | Périmètre unique couvrant `public.qf_active`, `public.qf_config`, `public.rights_config`, `public.user_rights_projection` et `public.compute_qf(uuid)`, avec DDL, sécurité, versionnement, tests et rollback attendus. |
| Frontière figée | Cinq objets seulement ; aucune modification Offer ou autre extension n'est implicite. |
| Documents de définition | `AF-01`, `AF-02`, `AF-03`, `AF-04`, `AF-05` |
| Définition officielle unique | Oui — les documents convergent sur le même périmètre de quatre tables et une RPC. |
| Contradiction officielle active | Aucune — l'absence d'artefact exécutable est un statut d'implémentation, pas une contradiction structurelle. |
| Revue PROGRAM | VALIDÉE |
| Structural Validation | PASS |
| Implementation | PLANNED |

## 5. Éléments explicitement non promus

Les éléments suivants restent rattachés à leur autorité officielle et ne deviennent pas de nouvelles briques V2 :

| Élément | Décision de rattachement |
|---|---|
| `FundingPolicy` | Value Object conservé dans OfferVersion ; jamais Aggregate ou BusinessComponent autonome. |
| `CompositionValidationReportV1` | Sortie contractuelle de `CompositionValidation`, pas service autonome. |
| `CharacteristicValueV1` | Représentation contractuelle d'`OfferCharacteristic`. |
| `ComponentReferenceV1` | Représentation contractuelle de `ComponentReference`. |
| `ComponentLifecycleStatus` | État interne de BusinessComponent. |
| `ComponentVersionState` | État interne de ComponentVersion. |
| `ExternalReferenceChecker` | Port de contrôle délégué, rattaché à la validation de composition. |
| `ListBusinessComponentDescriptors` | Label logique de lecture de la projection, pas nom physique figé. |
| `ValidateOfferComposition` | Label logique de prévalidation, pas nouvelle autorité. |
| `WAVE` | Objet officiel de gouvernance existant, non brique métier V2. |
| Work Packages et lots | Non officiels ; aucun rattachement de gouvernance créé. |

## 6. Clôture du registre

Le registre contient **21 briques structurelles V2**.

Répartition des statuts d'implémentation :

| Implementation | Nombre |
|---|---:|
| IMPLEMENTED | 0 |
| PARTIALLY_IMPLEMENTED | 1 |
| PLANNED | 19 |
| NOT_APPLICABLE | 1 |
| Total | 21 |

Ces statuts ne modifient pas la validation structurelle. Une brique peut être figée architecturalement tout en restant à implémenter.
