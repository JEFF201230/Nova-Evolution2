# Référentiel des Documents Officiels V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Mission | `PROGRAM-V2-STRUCTURAL-CERTIFICATION-001` |
| Date de contrôle d'existence | 2026-07-24 |
| Objet officiel de gouvernance | `WAVE` |
| Fonction | Index d'autorité, de définition et de preuve |

## 1. Règle d'autorité documentaire

Le corpus est organisé en quatre niveaux :

1. **Faits certifiés** : gouvernance et postulats non révisables.
2. **Décisions normatives actives** : définitions officielles et arbitrages du Program Director.
3. **Canon conservé** : fondation Offer existante, applicable lorsqu'elle n'est pas supersédée par V2.
4. **Preuves de statut** : rapports d'inventaire, réconciliation ou exécution utilisés pour qualifier l'implémentation, sans définir une architecture concurrente.

Les archives et documents explicitement supersédés sont exclus de l'autorité normative.

## 2. Documents normatifs actifs

Tous les chemins de cette section ont été vérifiés présents dans le dépôt.

| ID | Document | Rôle officiel | Existence |
|---|---|---|---|
| `CF-01` | [`tools/cerebrau/certified-facts.json`](../../../tools/cerebrau/certified-facts.json) | Faits certifiés : WAVE, Work Packages non officiels, fondation prête, modèles canoniques acquis | Oui |
| `BOARD-01` | [`OFFER_ARCHITECTURE_BOARD_DECISIONS_001.md`](../OFFER/OFFER_ARCHITECTURE_BOARD_DECISIONS_001.md) | Autorité postérieure pour `D01` à `D10`; résout et supersède les formulations antérieures identifiées | Oui |
| `OFC-01` | [`PROGRAM_OFFER_V2.md`](../../04_MODULES/OFFERS/PROGRAM_OFFER_V2.md) | Doctrine officielle V2 et modèle métier consolidé | Oui |
| `OFC-02` | [`PROGRAM_EXECUTIVE_SUMMARY_V2.md`](../../04_MODULES/OFFERS/PROGRAM_EXECUTIVE_SUMMARY_V2.md) | Décision exécutive et synthèse de classification | Oui |
| `OFC-03` | [`PROGRAM_OFFER_FINAL_DECISIONS.md`](../../04_MODULES/OFFERS/PROGRAM_OFFER_FINAL_DECISIONS.md) | Décisions finales de composition et classification tactique unique | Oui |
| `OFC-04` | [`PROGRAM_BUSINESS_COMPONENT_MODEL.md`](../../04_MODULES/OFFERS/PROGRAM_BUSINESS_COMPONENT_MODEL.md) | Définition détaillée de BusinessComponent, ComponentVersion, configurations, règles et projection | Oui |
| `OFC-05` | [`PROGRAM_OFFER_COMPOSITION_ARCHITECTURE.md`](../../04_MODULES/OFFERS/PROGRAM_OFFER_COMPOSITION_ARCHITECTURE.md) | Architecture détaillée de composition, validation, contrats et ports | Oui |
| `OFC-06` | [`PROGRAM_OFFER_WORKBENCH.md`](../../04_MODULES/OFFERS/PROGRAM_OFFER_WORKBENCH.md) | Définition applicative et UX du Workbench | Oui |
| `OFC-07` | [`PROGRAM_OFFER_IMPACT_ANALYSIS.md`](../../04_MODULES/OFFERS/PROGRAM_OFFER_IMPACT_ANALYSIS.md) | Impacts autorisés de la cible approuvée ; ne crée pas de nouvelle définition | Oui |
| `OFC-08` | [`PROGRAM_OFFER_MIGRATION_GUIDE.md`](../../04_MODULES/OFFERS/PROGRAM_OFFER_MIGRATION_GUIDE.md) | Trajectoire additive d'implémentation ; ne crée pas de Work Package officiel | Oui |

## 3. Canon Offer conservé

Le groupe `CAN-BASE` désigne les documents canoniques actifs de `Docs/21_DOMAIN_MODELS`. Ils définissent la fondation Offer conservée. V2 les étend ; `BOARD-01` gouverne les points explicitement supersédés.

| ID | Document | Existence |
|---|---|---|
| `CAN-00` | [`README.md`](../../21_DOMAIN_MODELS/README.md) | Oui |
| `CAN-01` | [`CANONICAL_OFFER_GLOSSARY.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_GLOSSARY.md) | Oui |
| `CAN-02` | [`CANONICAL_OFFER_DOMAIN_MODEL.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_DOMAIN_MODEL.md) | Oui |
| `CAN-03` | [`CANONICAL_OFFER_CONTEXT_MAP.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_CONTEXT_MAP.md) | Oui |
| `CAN-04` | [`CANONICAL_OFFER_ARCHITECTURE.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_ARCHITECTURE.md) | Oui |
| `CAN-05` | [`CANONICAL_OFFER_AGGREGATES.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_AGGREGATES.md) | Oui |
| `CAN-06` | [`CANONICAL_OFFER_STATE_MACHINE.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_STATE_MACHINE.md) | Oui |
| `CAN-07` | [`CANONICAL_OFFER_COMMAND_MODEL.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_COMMAND_MODEL.md) | Oui |
| `CAN-08` | [`CANONICAL_OFFER_QUERY_MODEL.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_QUERY_MODEL.md) | Oui |
| `CAN-09` | [`CANONICAL_OFFER_EVENT_CATALOG.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_EVENT_CATALOG.md) | Oui |
| `CAN-10` | [`CANONICAL_OFFER_API_CONTRACT.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_API_CONTRACT.md) | Oui |
| `CAN-11` | [`CANONICAL_OFFER_TRACEABILITY_MATRIX.md`](../../21_DOMAIN_MODELS/CANONICAL_OFFER_TRACEABILITY_MATRIX.md) | Oui |

`CAN-BASE` est un alias documentaire pour `CAN-00` à `CAN-11`. Il ne constitue ni un nouveau document, ni une nouvelle autorité.

## 4. Documents AF_QF_RIGHTS

| ID | Document | Fonction dans le référentiel | Existence |
|---|---|---|---|
| `AF-01` | [`OFFER_G1_REMEDIATION_PLAN_001.md`](../OFFER/OFFER_G1_REMEDIATION_PLAN_001.md) | Définit `AF-QF-RIGHTS` comme artefact correctif borné aux quatre tables et à la RPC | Oui |
| `AF-02` | [`OFFER_G1_EXECUTION_BACKLOG_001.md`](../OFFER/OFFER_G1_EXECUTION_BACKLOG_001.md) | Fixe les critères documentaires de préparation, sécurité, test et rollback | Oui |
| `AF-03` | [`OFFER_G1_LOT01_EXECUTION_REPORT_001.md`](../OFFER/OFFER_G1_LOT01_EXECUTION_REPORT_001.md) | Confirme le périmètre requis et l'absence de chemin exécutable résolu | Oui |
| `AF-04` | [`OFFER_AF_QF_RIGHTS_INVESTIGATION_REPORT_001.md`](../OFFER/OFFER_AF_QF_RIGHTS_INVESTIGATION_REPORT_001.md) | Investigation dédiée ; conclut à l'absence d'implémentation repository et prescrit un PDS unique | Oui |
| `AF-05` | [`OFFER_G1_DATA_INVENTORY_REPORT_001.md`](../OFFER/OFFER_G1_DATA_INVENTORY_REPORT_001.md) | Décrit le contrat live observé et les critères de rapprochement | Oui |

Les cinq documents portent le même périmètre :

1. `public.qf_active` ;
2. `public.qf_config` ;
3. `public.rights_config` ;
4. `public.user_rights_projection` ;
5. `public.compute_qf(uuid)`.

Ils ne définissent aucune sixième cible et ne créent aucune architecture concurrente.

## 5. Documents de preuve de statut

Les documents suivants sont recevables pour qualifier un statut d'implémentation ou expliquer la résolution d'une divergence. Ils ne prennent pas le pas sur `BOARD-01`.

| ID | Document | Usage autorisé | Existence |
|---|---|---|---|
| `EVD-01` | [`OFFER_CANONICAL_DECISION_MATRIX.md`](../../04_MODULES/OFFERS/OFFER_CANONICAL_DECISION_MATRIX.md) | État documentaire détaillé des décisions et implémentations au 22 juillet | Oui |
| `EVD-02` | [`OFFER_CANONICAL_RECONCILIATION_REPORT.md`](../../04_MODULES/OFFERS/OFFER_CANONICAL_RECONCILIATION_REPORT.md) | Constat antérieur au Board ; contradictions historiques et écarts d'implémentation | Oui |
| `EVD-03` | [`VEEDDA_OFFER_ROOT_RECONCILIATION_REPORT.md`](../VEEDDA_OFFER_ROOT_RECONCILIATION_REPORT.md) | État de la fondation Offer et des raccordements | Oui |
| `EVD-04` | [`OFFER_PA_CERTIFICATION_SUMMARY_001.md`](../OFFER/OFFER_PA_CERTIFICATION_SUMMARY_001.md) | État de preuve des actions G1 | Oui |
| `EVD-05` | [`OFFER_DEPLOYMENT_AUTHORITY_VERIFICATION_001.md`](../OFFER/OFFER_DEPLOYMENT_AUTHORITY_VERIFICATION_001.md) | Autorité de déploiement et maintien du seuil G1 | Oui |
| `EVD-06` | [`OFFER_G1_FINAL_EXECUTION_ROADMAP_001.md`](../OFFER/OFFER_G1_FINAL_EXECUTION_ROADMAP_001.md) | Séquence technique future, sans statut de Work Package officiel | Oui |

## 6. Documents complémentaires de doctrine V2

| ID | Document | Usage autorisé | Existence |
|---|---|---|---|
| `SUP-01` | [`PROGRAM_OFFER_IMPACT_ANALYSIS.md`](../../04_MODULES/OFFERS/PROGRAM_OFFER_IMPACT_ANALYSIS.md) | Traçabilité des surfaces affectées | Oui |
| `SUP-02` | [`PROGRAM_OFFER_MIGRATION_GUIDE.md`](../../04_MODULES/OFFERS/PROGRAM_OFFER_MIGRATION_GUIDE.md) | Séquence additive et non-régression | Oui |
| `SUP-03` | [`OFFER_CANONICAL_RECONCILIATION_RESUME_REPORT.md`](../../04_MODULES/OFFERS/OFFER_CANONICAL_RECONCILIATION_RESUME_REPORT.md) | Résumé de preuve, non définition | Oui |

`SUP-01` et `SUP-02` correspondent aussi à `OFC-07` et `OFC-08`. Le double référencement indique un double usage, pas une duplication documentaire.

## 7. Documents exclus de l'autorité normative

### 7.1 Archives explicitement remplacées

Le dossier [`Docs/21_DOMAIN_MODELS/_ARCHIVE`](../../21_DOMAIN_MODELS/_ARCHIVE) contient les brouillons canoniques et l'ancienne architecture Offer. Le fichier `CAN-00` les classe explicitement `SUPERSEDED`.

Ils restent consultables pour la traçabilité mais :

- ne définissent aucune brique active ;
- ne peuvent pas contredire une décision V2 ;
- ne peuvent pas être utilisés pour réouvrir le chantier d'architecture.

### 7.2 PDF historiques du PROGRAM Offer

Les fichiers suivants existent, mais `OFC-01` les qualifie d'archives historiques auxquelles aucune preuve technique nouvelle n'est attribuée :

| Document | Existence | Autorité normative V2 |
|---|---|---|
| [`22_07_26_PROGRAM OFFER V2.pdf`](<../../04_MODULES/OFFERS/22_07_26_PROGRAM OFFER V2.pdf>) | Oui | Non |
| [`22_07_26_OFFERS_ Program - Synthèse Exécutive.pdf`](<../../04_MODULES/OFFERS/22_07_26_OFFERS_ Program - Synthèse Exécutive.pdf>) | Oui | Non |
| [`22_07_26_SYNTHESE_Program Offer.pdf`](<../../04_MODULES/OFFERS/22_07_26_SYNTHESE_Program Offer.pdf>) | Oui | Non |

Les sources Markdown normatives associées sont `OFC-01` à `OFC-06`.

## 8. Matrice d'autorité par famille de briques

| Famille | Autorité de définition | Canon conservé | Preuve de statut |
|---|---|---|---|
| Composition et composants | `OFC-03` à `OFC-06` | `CAN-BASE` | `EVD-01`, `EVD-02` |
| OfferVersion v2 et Activation | `BOARD-01/D01-D03` | `CAN-06` à `CAN-11` | `EVD-01`, `EVD-03` |
| Préconditions serveur | `BOARD-01/D04` | `CAN-07`, `CAN-10` | `EVD-01` |
| Diffusion Offer/Rights/EBS | `BOARD-01/D05`, `BOARD-01/D07` | `CAN-08`, `CAN-09` | `EVD-01`, `EVD-03` |
| Workbench | `OFC-06`, `BOARD-01/D06` | `CAN-07`, `CAN-08`, `CAN-10` | `EVD-01` |
| Finance | `BOARD-01/D08` | `OFC-01`, `OFC-03` | `EVD-02`, `EVD-03` |
| Dotation | `BOARD-01/D09` | Aucun canon concurrent | `EVD-02` |
| Transition legacy | `BOARD-01/D10` | Aucun canon concurrent | `EVD-02`, `EVD-03` |
| AF_QF_RIGHTS | `AF-01` à `AF-05` | Autorités QF/Rights conservées | `AF-03`, `AF-04`, `EVD-04` |

## 9. Résultat du contrôle d'existence et d'unicité

```text
REFERENCED_SOURCE_PATHS_MISSING = 0
ACTIVE_NORMATIVE_DEFINITION_CONFLICTS = 0
SUPERSEDED_SOURCES_USED_AS_AUTHORITY = 0
OFFICIAL_GOVERNANCE_OBJECTS_CREATED = 0
WORK_PACKAGES_CREATED = 0
DOCUMENT_REFERENCE_STATUS = PASS
```

Le présent référentiel est l'index documentaire officiel à utiliser avec le registre et la matrice. Une future mission doit partir de ces identifiants et ne doit pas reconstituer une autre hiérarchie de sources.
