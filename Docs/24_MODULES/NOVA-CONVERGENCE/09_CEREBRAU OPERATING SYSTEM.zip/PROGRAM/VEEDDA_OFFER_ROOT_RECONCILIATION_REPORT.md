# PROGRAM-VEEDDA-OFFER-ROOT-RECONCILIATION-001

> Type : PROGRAM / FINAL_RECONCILIATION / READ_ONLY / DEVELOPMENT_READY  
> Généré le : 2026-07-22 (Europe/Paris)  
> Dépôt observé : `C:\DEV\veedda-cseV7-core`  
> HEAD observé : `706bf1fae540e1798e3b827fbb162cac20b3b019`  
> Périmètre d'écriture : ce rapport uniquement

## 1. Executive verdict

La doctrine imposée n'est pas implémentée de bout en bout. Le dépôt possède un bounded context Offer réutilisable, testé et exposé par HTTP pour `Create → Draft → Review → Validate → Publish`, mais il s'arrête à `Offer PUBLISHED`. Il ne possède ni état `Offer ACTIVE`, ni commande `ActivateOffer`, ni événement `OfferActivated`. L'ADMIN n'a aucune interface Offer. Rights, EBS, Dashboard salarié, LifeHub, Subvention, Budget et Ledger restent raccordés à des sources distinctes et ne sont pas causalement rattachés à une Offre active et à sa version.

Le développement peut commencer immédiatement après validation humaine de ce rapport. Aucun audit supplémentaire n'est requis avant le premier lot. Le premier lot unique est `DEV-OFFER-ACTIVATION-001`, extension bornée du domaine Offer existant afin d'ajouter la transition `PUBLISHED → ACTIVE` et sa preuve persistée/API.

Les suites ciblées exécutées pendant cette mission confirment la base réutilisable : Domain/Application, **21/21 tests PASS** (`npx.cmd vitest run server/offer-domain/test server/offer-application/test`) ; API Node, **9/9 tests PASS** (`npx.cmd tsx --test server/offer-api/test/offer-api.test.ts server/offer-api/test/architecture.test.ts`). Le premier lancement Vitest incluant deux suites Node natives a signalé deux fichiers « no test suite found » tout en exécutant 21 tests positifs ; la relance avec le runner déclaré par ces fichiers est positive. Aucun test PostgreSQL n'a été lancé faute de nécessité pour cet audit en lecture seule.

## 2. Doctrine canonique utilisée

**DECISION — autorité de cette mission.** L'Offre et une Version identifiable sont la racine obligatoire de toute disponibilité, demande, attribution, réservation, distribution et opération financière. L'ADMIN est le point zéro. La chaîne imposée est :

`CSE → ADMIN → Offre → Version → Validation → Publication → Activation → Éligibilité → Employee Business State → Interfaces salariées → Exécution métier → Budget → Ledger → Paiement ou distribution`.

Les quatre familles retenues sont `REIMBURSEMENT`, `ALLOCATION`, `COFUNDED_TITLE` et `ASC_SERVICE`. L'EBS consolide et distribue ; il ne crée ni Offre, ni droit, ni activation, ni vérité Budget/Ledger. Les interfaces consomment l'état métier et ne maintiennent aucune vérité concurrente.

**LEGACY — contradiction documentaire explicitement neutralisée.** Le précédent modèle Offer rendait une Offre `PUBLISHED` directement distribuable et autorisait une Operation sur une Offre `PUBLISHED` (`Docs/21_DOMAIN_MODELS/CANONICAL_OFFER_STATE_MACHINE.md:47,66-83,104-109`). Cette sémantique est exactement reflétée dans le code. Elle ne satisfait plus la DECISION de la présente mission, qui exige une activation distincte. Elle est donc une base réutilisable, pas l'autorité métier finale.

**Sources antérieures rapprochées.** Le rapport de consolidation Offer certifiait la documentation avec réserves d'implémentation et plaçait Budget, Ledger, Rights et EBS hors du bounded context (`Docs/21_DOMAIN_MODELS/DPDS_OFFER_DOMAIN_COMPLETION_001_REPORT.md:8-15,130-149`). La couche API a été certifiée `SUCCESS_WITH_RESERVATIONS` avec 25 commandes et 15 requêtes (`Docs/21_DOMAIN_MODELS/TIMS_OFFER_API_LAYER_001_REPORT.md:3-9,130-144`). La décision ultérieure `GO_API_OFFER` autorise explicitement les intégrations contre Offer (`Docs/21_DOMAIN_MODELS/GCMS_OFFER_API_BOUNDARY_DECISION_001_REPORT.md:293-307,317-333`). La photographie runtime DPDS du même HEAD et du 2026-07-19 confirme les objets legacy distants, notamment les deux ledgers et les trois surcharges d'approbation/paiement (`Docs/PROGRAMS/PROGRAM-VEEDDA-DPDS/DPDS-000A/DPDS_000A_RUNTIME_OBSERVATION_REPORT.md:1-12,58-85,121-151`).

## 3. Matrice synthétique des douze domaines

| Domaine | Question | Réponse | Source de vérité actuelle | Preuve principale | Écart canonique | Sévérité | Correctif MVP | Dépendance | Ordre de développement |
|---|---|---|---|---|---|---|---|---|---:|
| ADMIN | Q1 | NO | Routes GDBCSE + API Offer non consommée | `client/src/App.tsx:154-196`; `server/routes.ts:537-566` | Aucun écran/commande Offer côté ADMIN | P0 | Workbench ADMIN sur l'API existante | Activation + contrat Version | 3 |
| Offer | Q2 | PARTIAL | `offer_offer`, `offer_offer_version`, agrégat Offer | `states.ts:4-8`; `OfferAggregate.ts:30-105` | `ACTIVE`, `ActivateOffer`, `OfferActivated` absents | P0 | Étendre le cycle existant | aucune | 1 |
| Eligibility / Rights | Q3 | NO | `qf_history + rights_config` | `compute-rights/index.ts:269-357,458-570` | Aucune Offre/version active dans le calcul | P0 | Alimenter Rights depuis Version active | 1-2 | 4 |
| EBS | Q4 | PARTIAL | Projection transitoire profile/QF/rights/subventions | `lifehub-bridge.ts:64-226` | Avantages dérivés de Rights, pas d'Offer | P0 | Agréger les faits Offer actifs | 4 | 5 |
| Dashboard salarié | Q5 | PARTIAL | EBS + Supabase direct + constantes | `DashboardSalarie.tsx:312,393-463,1184-1224,1574` | Plusieurs vérités concurrentes | P1 | Consommer EBS, supprimer l'autorité locale | 5 | 6 |
| LifeHub | Q6 | NO | EBS + Document Core + transformations locales | `useLifeHubDashboardData.ts:148-154,416-465,625-718` | Progression/compteurs dérivés hors vérité Offer | P1 | Projections EBS explicites et seules autoritaires | 5 | 6 |
| Remboursement | Q7 | NO | `subventions` + RPC financières | `create_subventions.sql:1-19`; `DashboardSalarie.tsx:430-463` | Création directe sans Offre/version | P0 | Commande backend avec origine figée | 2,4,6 | 7 |
| Dotation | Q8 | NOT_IMPLEMENTED | Affichages/taxonomies/simulations | `OFFER_DOTATION_TAXONOMY.md:5-19,134-141` | Aucun domaine Attribution exécutable | P1 | Adapter ALLOCATION sur Offer | 4-8 | 9 |
| Titres cofinancés | Q9 | NOT_IMPLEMENTED | Simulation locale et Edge Functions de simulation | `GdbcseSimulation.tsx:140-189,5680-5708` | Aucune commande/réservation/distribution | P1 | Flux produit par produit sur Offer | 4-8 | 10 |
| Services ASC | Q10 | NOT_IMPLEMENTED | Éditorial + Operation Offer générique | `OfferAggregate` Operation test `domain-foundation.test.ts:45-55` | Aucun booking/stock/consommation | P2 | Réutiliser Offer Operation pour ASC | 4-8 | 11 |
| Budget | Q11 | NO | `budgets`, statuts/votes/flags, `budget_ledger` | `server/routes.ts:831-1042,1080-1165` | Offre/version sans `budget_id` typé | P0 | Référence Budget figée dans Version | 1 | 2 |
| Ledger | Q12 | NO | `budget_ledger`; `ledger_entries` legacy runtime | `create_budget_ledger.sql:1-16`; runtime DPDS `:66-78,125-149` | Aucun `offer_id`/`offer_version_id` | P0 | Propager l'origine, verrouiller les producteurs | 7 | 8 |

## 4. Réponse détaillée Q1 — ADMIN

### Réponse par opération

| Opération | Réponse | Preuve et rôle réel |
|---|---|---|
| CREATE | **NO** | **FACT.** `CreateOffer` existe dans le backend (`offer.commands.ts:5`; `CommandExecutionService.ts:69-82`) et est exposé par le routeur générique (`OfferRouter.ts:18`), mais aucune route/page/formulaire/hook/service de `client/src` ne consomme `/api/v1/offer` ou `CreateOffer`. |
| VERSION | **NO** | **FACT.** `CreateOfferVersion` et `UpdateOfferDraft` existent (`offer.commands.ts:6-7`), sans interface ADMIN. |
| VALIDATE | **NO** | **FACT.** `ValidateOffer` existe (`offer.commands.ts:10`; `OfferAggregate.ts:87-89`), sans bouton, formulaire ou service frontend. |
| PUBLISH | **NO** | **FACT.** `PublishOffer` existe et persiste Offre/Version `PUBLISHED` (`OfferAggregate.ts:91-99`), sans consommateur ADMIN. |
| ACTIVATE | **NOT_IMPLEMENTED** | **FACT.** Aucun état, commande, événement, handler, endpoint ou test `ActivateOffer`; seuls `ActivateDispositif` et `DispositifActivated` existent (`types/catalog.ts:1-15`). |

**FACT.** L'utilisateur `ADMIN`, `TRESORIER` ou `SECRETAIRE` est redirigé vers `/gdbcse`, tandis que `/superadmin` charge `DashboardAdmin` (`client/src/App.tsx:154-196`). Les recherches exhaustives de routes, composants, formulaires, hooks, services et appels Offer dans `client/src` ne retournent aucun consommateur. L'API existe réellement : le serveur compose l'infrastructure, authentifie par Supabase, résout rôle/organisation puis monte `/api/v1/offer` (`server/routes.ts:537-566`); le routeur expose un POST pour chaque commande cataloguée (`server/offer-api/routes/OfferRouter.ts:10-22`).

**FACT.** Les tests prouvent l'API et le domaine, pas l'interface ADMIN : `domain-foundation.test.ts:24-42` couvre validation/publication/ségrégation ; les tests HTTP couvrent les 25 commandes. **GAP.** Le point zéro ADMIN canonique n'existe donc pas comme parcours opérationnel.

## 5. Réponse détaillée Q2 — Offer

**Réponse : PARTIAL.** `Create → DRAFT → IN_REVIEW → VALIDATED → PUBLISHED` est implémenté. `PUBLISHED → ACTIVE → OfferActivated` est absent.

- **FACT — agrégat/statuts.** `OFFER_STATES = DRAFT, PUBLISHED, SUSPENDED, CLOSED, ARCHIVED`; `OFFER_VERSION_STATES = DRAFT, IN_REVIEW, VALIDATED, PUBLISHED, SUPERSEDED` (`server/offer-domain/types/states.ts:4-8`). `ACTIVE` existe uniquement pour Dispositif (`:1-2`).
- **FACT — transitions.** `OfferStateMachine` fait `DRAFT → PUBLISHED`, puis suspension/reprise/fermeture/archivage; la Version fait `DRAFT → IN_REVIEW → VALIDATED → PUBLISHED` (`OfferStateMachine.ts:4-22`).
- **FACT — commandes/événements.** Le catalogue expose 25 commandes et 25 événements sans activation Offer (`server/offer-domain/types/catalog.ts:1-15`; `offer.commands.ts:5-17`; `offer-events.ts:10-22`).
- **FACT — persistance.** Les CHECK SQL acceptent les mêmes états et excluent `ACTIVE` pour `offer_offer` (`20260717000000_create_offer_infrastructure.sql:19-32`) ; Version est persistée séparément (`:37-62`). Repository et transaction outbox enregistrent l'agrégat et l'événement (`PostgresRepositories.ts:16-19`; `PostgresOutbox.ts:6-7`).
- **FACT — API.** Les commandes cataloguées sont montées automatiquement (`OfferRouter.ts:18`); l'OpenAPI n'expose donc aucune activation.
- **FACT — consommateurs.** `ListOfferDistributionFacts` distribue actuellement les Offres et Versions `PUBLISHED`, éventuellement avec Operation `OPEN` (`PostgresOfferReadModel.ts:230-260`). Ni Rights ni EBS ne consomment cette requête. L'`OutboxDispatcher` existe (`OutboxDispatcher.ts:6-11`) mais `createOfferInfrastructure` ne le construit ni ne le démarre (`CompositionRoot.ts:9`); aucun publisher métier n'est raccordé dans `server/routes.ts`.
- **FACT — tests.** Le test de cycle attend Offre/Version `PUBLISHED` (`domain-foundation.test.ts:24-36`). Aucun test d'activation ne peut exister sans commande.

Réponses explicites :

| Point | Réponse |
|---|---|
| `ACTIVE` existe dans Offer | **NO** |
| `ActivateOffer` existe | **NO** |
| `OfferActivated` existe | **NO** |
| activation persistée | **NO** |
| activation exposée par API | **NO** |
| activation déclenchable par ADMIN | **NO** |
| effets d'activation vers Rights/EBS | **NO** |

**GAP P0.** La publication joue encore le rôle d'activation dans le modèle legacy. La DECISION exige deux transitions distinctes.

## 6. Réponse détaillée Q3 — Eligibility / Rights

**Réponse : NO.** Les droits ne dépendent d'aucune Offre, publiée ou active.

### Flux réel complet

`MonEspacePage → supabase.functions.invoke("compute-rights", { user_id }) → qf_history(latest) + rights_config(active latest) → calculateRights(tranche, taux, rules) → rights_history append → user_rights_projection upsert → MonEspace/EBS`.

- **FACT — déclencheur.** Le navigateur déclenche directement l'Edge Function (`client/src/mon-espace-salarie/pages/MonEspacePage.tsx:171-207`) ; le SDK offre le même wrapper (`client/src/lib/veedda-sdk/rights.ts:5-17`).
- **FACT — entrée.** `{user_id, as_of?, force?}` (`compute-rights/index.ts:20-24,207-267`).
- **FACT — lectures.** Dernier `qf_history` du salarié (`:269-330`), puis dernière `rights_config` active (`:332-357`).
- **FACT — calcul.** `calculateRights` applique la tranche et le taux aux règles JSON (`:161-205,458-490`). Le hash d'entrée couvre utilisateur, snapshot QF et configuration Rights, pas Offer/Budget (`:137-155`).
- **FACT — écritures.** Idempotence dans `rights_history`, insertion append-only, puis upsert `user_rights_projection` (`:386-456,497-570`). Aucun événement Offer ou Rights n'est publié.
- **FACT — consommateurs.** Mon Espace relit directement `user_rights_projection` (`MonEspacePage.tsx:190-198,407-442`) ; EBS lit la même projection (`lifehub-bridge.ts:95-107`).

### Rôle prouvé des sources demandées

| Source | Rôle réel |
|---|---|
| `budget_cse_profile` | **NOT_IMPLEMENTED.** Aucune occurrence dans code, migrations, tests ou documents autoritatifs inspectés; absent aussi de l'inventaire runtime DPDS. |
| `budgets` | Aucun rôle dans `compute-rights`; utilisé séparément par UI, simulation, demande et finance. |
| `rights_config` | Source directe des règles de calcul. |
| `qf_history` | Source directe du dernier QF/tranche/taux. |
| `qf_foyer` | Aucun accès direct par Rights; source du domaine QF opérationnel. |
| `user_qf_input` | Aucun accès direct; influence potentiellement `qf_history` via le calcul QF. |
| Offer / OfferVersion | Aucun accès, import, FK, endpoint ou événement consommé. |
| catalogue d'avantages | N'entre pas dans le moteur; les interfaces ont cependant leurs catalogues locaux concurrents. |
| constantes frontend | N'entrent pas dans `calculateRights`; elles déterminent toutefois des plafonds/affichages ailleurs. |

Réponses : Offre **NO** ; Offre publiée **NO** ; Offre active **NO** ; budget **NO** ; `budget_cse_profile` **NO** ; constantes frontend dans le moteur **NO** ; sources concurrentes dans le produit **YES**. La source de vérité actuelle du calcul est `qf_history + rights_config`; la vérité affichée est fragmentée entre cette projection, des constantes et des catalogues frontend. **GAP P0.**

## 7. Réponse détaillée Q4 — Employee Business State

**Réponse : PARTIAL.** L'EBS n'invente pas un droit autoritatif, mais il ne fait pas qu'une copie : il agrège, normalise, transforme et calcule des projections transitoires, notamment progression et avantages disponibles.

- **FACT — types/validator/registry/mapper/runtime.** Le runtime collecte les drafts des providers, les fusionne, normalise et valide avant retour (`server/employee-business-state/runtime.ts:25-64`; `mapper.ts:91-151`; `validator.ts:201`; `registry.ts:88-89`).
- **FACT — producteur LifeHub.** `createLifeHubEmployeeBusinessState` lit `profiles`, dernier `qf_history` valide, `user_rights_projection` et `subventions` en parallèle (`lifehub-bridge.ts:64-140`), construit sections/benefits/progression (`:143-210`), puis exécute la DistributionLayer (`:213-226`).
- **FACT — transformations.** `buildRightsBenefits` transforme chaque item Rights en benefit et lui assigne `available: true` (`projections/lifehub.helpers.ts:173-195`). `buildProgressionSummaryProjection` calcule trois étapes et un pourcentage (`progression-projection.ts:8-46`).
- **FACT — persistance.** Aucune table EBS et aucun write DB : l'état est produit à la requête. Le endpoint `/api/mes/vigile` construit simultanément un résultat Vigile et l'EBS (`server/routes.ts:1717-1764`).
- **FACT — distribution/consommateurs.** `EmployeeBusinessStateDistributionLayer.run()` fournit l'état au endpoint; `useLifeHubDashboardData` le consomme (`:625-651`). Dashboard salarié et toutes les pages LifeHub réutilisent ce hook.
- **GAP.** Les « offres disponibles » ne viennent pas de `offer_offer`/`offer_offer_version` ni de `ListOfferDistributionFacts`; elles viennent de `user_rights_projection` et sont toutes marquées disponibles.

Réponses explicites : producteur = serveur EBS LifeHub à la requête ; sources = profiles/QF projection Rights/subventions ; calcule **YES**, uniquement des projections ; crée des droits autoritatifs **NO** ; crée des objets d'état dérivés **YES** ; transforme **YES** ; agrège **YES** ; persiste **NO** ; distribue **YES** ; consommateurs réels = Dashboard salarié et pages LifeHub ; `progressionSummary` produit/consommé **YES** ; offres disponibles depuis Offer **NO**.

## 8. Réponse détaillée Q5 — Dashboard salarié

**Réponse : PARTIAL.** Il consomme l'EBS, mais n'affiche pas uniquement l'EBS.

Sources exactes :

- **FACT — EBS.** `useLifeHubDashboardData()` est appelé (`DashboardSalarie.tsx:312`).
- **LEGACY — demandes.** Lecture directe de `subventions` par `beneficiaire_id` (`:393-417`).
- **LEGACY — création.** Recherche directe d'un budget actif puis insertion directe de `subventions` avec `budget_id`, catégorie, montant, description et bénéficiaire (`:430-463`); le panier répète ce chemin (`:609-649`).
- **LEGACY — budget affiché.** `INTERNAL_PLAFONDS` est importé (`:91`) et sert à recalculer consommé/en attente/restant dans le navigateur (`:1184-1224`).
- **LEGACY — catalogue.** `CATALOGUE_AVANTAGES` est défini localement (`:123-225`) et affiché (`:1574`); `client/src/config/avantages.ts:24-270` constitue un autre catalogue statique.
- **LEGACY — autre interface salariée.** `MonEspacePage` déclenche directement Rights et relit sa projection (`MonEspacePage.tsx:171-207,407-442`).
- **FACT — tests.** Aucune suite métier Dashboard/compute-rights/EBS n'a été retrouvée; le seul test client comportant `subventions` est un test de dialogue sans chaîne Offer (`client/src/__dialog_trace.test.tsx:36`).

**GAP P1.** Les droits, plafonds, avantages, progression, demandes et statuts proviennent de plusieurs sources et peuvent diverger. Le Dashboard n'est pas une autorité unique, mais il fabrique encore une vérité de présentation concurrente.

## 9. Réponse détaillée Q6 — LifeHub

**Réponse : NO.** LifeHub consomme principalement l'EBS, mais pas exclusivement et il recalcule des projections locales.

- **FACT — routes.** Toutes les routes demandées existent dans `client/src/lifehub/routes/lifeHubRoutes.ts:1-11` et sont montées par `client/src/App.tsx:242-286`.
- **FACT — EBS.** Pages hub, démarches, dossier, messages, agenda et coaching appellent `useLifeHubDashboardData` (`LifeHubPages.tsx:220-221,333,586,620,652`). Le hook appelle `/api/mes/vigile` (`useLifeHubDashboardData.ts:625-651`).
- **FACT — source hors EBS.** La page dossier appelle aussi `useLifeHubDossierDocuments` (`LifeHubPages.tsx:326-365`), qui lit Document Core directement (`useLifeHubDossierDocuments.ts:95-160`).
- **FACT — recalculs.** Le hook possède `STATUS_PROGRESS` (`useLifeHubDashboardData.ts:148-154`), transforme les demandes, filtre/compte les avantages disponibles (`:416-465`), produit un agenda vide et du coaching statique (`:717-718`).
- **FACT — absence de catalogue Offer.** Aucun appel Offer depuis les pages/hook; les avantages sont les benefits EBS issus de Rights.

Causes prouvées des incohérences :

1. **Progression 100 %.** `progression-projection.ts:8-46` compte seulement profil, QF et « documents »; le booléen documents reprend `profile.dossierComplete`, sans interroger Document Core. Trois booléens vrais donnent 100 %.
2. **Nombre d'avantages incohérent.** EBS transforme chaque ligne de projection Rights en benefit avec `available: true` (`lifehub.helpers.ts:173-195`), puis le hook compte ces lignes (`useLifeHubDashboardData.ts:447-465`). Aucun filtrage par Offre active/version/période n'existe.
3. **État de vérification divergent.** Le endpoint construit un raw Vigile séparé avec données incomplètes, puis construit l'EBS depuis les tables (`server/routes.ts:1726-1764`). L'interface combine ainsi deux projections ayant des producteurs et règles différentes.

**GAP P1.** Les divergences sont déterminées; aucune investigation supplémentaire n'est nécessaire avant correction.

## 10. Réponse détaillée Q7 — Remboursement

**Réponse : NO.** Une demande peut être créée directement sans Offre ni Version.

### Flux réel

`DashboardSalarie → Supabase direct INSERT subventions → ADMIN GET/PATCH /api/subventions → approve_subvention → budget_ledger RESERVE → pay_subvention → subvention_payments + RELEASE + DEBIT → v_grand_livre_asc`.

- **FACT — UI/table.** L'insert direct est prouvé dans `DashboardSalarie.tsx:430-463,634-649`. La table possède `beneficiaire_id`, `budget_id`, montant, statut, catégorie, description/motif/opérateur, mais aucun Offer/version/organisation/règles (`20260222000001_create_subventions.sql:1-19`).
- **FACT — API/workflow.** ADMIN lit et modifie les demandes (`server/routes.ts:1585-1693`). `APPROVED` et `PAID` appellent les RPC; les autres statuts sont écrits directement.
- **FACT — contrôle/réservation.** La version repo d'`approve_subvention(uuid)` verrouille la demande, contrôle `PENDING` et le solde, écrit `RESERVE`, puis `APPROVED` (`20260222201000_patch_rpc_approve_idempotence_v23.sql:7-89`). Le runtime observé comporte trois surcharges, ce qui explique que l'appel serveur à trois arguments puisse fonctionner dans l'instance malgré la divergence versionnée (`DPDS_000A_RUNTIME_OBSERVATION_REPORT.md:123-127`).
- **FACT — paiement.** `pay_subvention(uuid,uuid,uuid)` écrit `subvention_payments`, `RELEASE`, `DEBIT`, puis `PAID` (`20260612000100_patch_pay_subvention_created_by.sql:8-118`).
- **FACT — remboursement financier.** `refund_subvention` crédite le ledger et peut passer à `REFUNDED` (`20260222193508_rpc_refund_subvention.sql:1-77`), mais le PATCH courant ne l'appelle pas.
- **FACT — dossier/justificatifs.** Document Core rattache les documents au business object `DEMANDE`/`SUBVENTION`, sans Offre/version (`useLifeHubDossierDocuments.ts:95-160`).

Champs canoniques : `offer_id` **NO** ; `offer_version_id` **NO** ; salarié **PARTIAL** via `beneficiaire_id` ; organisation **PARTIAL** par relation de profil/budget, pas figée sur la demande ; `budget_id` **YES** ; famille/type **PARTIAL** via catégorie libre ; règles figées/référencées **NO**. **GAP P0.**

## 11. Réponse détaillée Q8 — Dotation

**Réponse : NOT_IMPLEMENTED.** Aucun domaine exécutable d'attribution Dotation/ALLOCATION n'existe.

- **FACT — doctrine documentaire antérieure.** La taxonomie définit ALLOCATION, mais reconnaît qu'aucun agrégat, table, API ou catalogue d'événements Dotation n'est démontré (`Docs/21_DOMAIN_MODELS/OFFER_DOTATION_TAXONOMY.md:5-19,134-141`).
- **DEAD / UNUSED pour l'exécution.** Noël, naissance, mariage/PACS et retraite existent comme contenu statique (`client/src/config/avantages.ts:189-220`; `MonEspacePage.tsx:93-97`; `bridge-qf/pages/QfAvantages.tsx:203-233`). Ils n'ont aucun producteur métier.
- **FACT — simulation.** Les simulateurs peuvent produire des résultats hypothétiques, sans réservation ni impact réel; l'UI dit explicitement que les simulations sont sans impact budget (`GdbcseSimulation.tsx:6088-6095`).
- **FACT — persistance réelle.** Aucune commande d'attribution, table d'allocation, réservation, distribution ou écriture Ledger rattachée à une Offer n'a été trouvée. Les tables runtime `subvention_simulations`/`simulations` sont des simulations, pas des attributions (`DPDS_000A_RUNTIME_OBSERVATION_REPORT.md:60-105`).

Distinction : simulation **YES** ; affichage frontend **YES** ; configuration éditoriale **YES** ; persistance d'attribution **NO** ; attribution réelle **NO** ; réservation **NO** ; distribution **NO** ; Ledger **NO**. **GAP P1.**

## 12. Réponse détaillée Q9 — Titres cofinancés

**Réponse globale : NOT_IMPLEMENTED.** Les trois produits sont des capacités de simulation, pas des commandes exécutables.

| Produit | Réponse | Faits |
|---|---|---|
| CESU | **NOT_IMPLEMENTED** | Carte fixe UI (`GdbcseSimulation.tsx:140-177`), règles locales (`deviceBusinessRules.ts:39-52`) et calcul de simulation Edge; aucun ordre/réservation/distribution/ledger. |
| Ticket Restaurant | **NOT_IMPLEMENTED** | Carte fixe UI (`GdbcseSimulation.tsx:143,176`), règles locales (`deviceBusinessRules.ts:1-20`); aucun ordre persistant. |
| Chèque Vacances | **NOT_IMPLEMENTED** | Carte fixe UI (`GdbcseSimulation.tsx:142,175`), règles locales (`deviceBusinessRules.ts:21-38`); aucun ordre persistant. |

**FACT.** `simulate-v2-4/5/6` valide un `budgetId`, lit modèles/facteurs et `v_budget_cse_legal`, puis calcule des résultats (`supabase/functions/simulate-v2-6/index.ts:479-727`). `save-simulation` insère dans `simulations` (`supabase/functions/save-simulation/index.ts:24-25`). L'UI appelle cette fonction (`GdbcseSimulation.tsx:5680-5708`) et précise l'absence d'impact réel (`:6088-6095`).

Pour chaque produit : Offre **NO** ; Version **NO** ; règle de participation exécutable **NO** (constante de simulation seulement) ; salarié **PARTIAL** dans les inputs de simulation ; budget **PARTIAL** pour simulation ; réservation **NO** ; distribution **NO** ; Ledger **NO**. **GAP P1.**

## 13. Réponse détaillée Q10 — Services ASC

**Réponse : NOT_IMPLEMENTED.** Aucun modèle exécutable de réservation/consommation ASC n'est raccordé à une Offre active.

- **FACT — brique réutilisable.** `offer_operation` exige `offer_id`, `offer_version_id` et conserve le numéro de version (`20260717000000_create_offer_infrastructure.sql:64-88`). Son test de cycle conserve ces références (`domain-foundation.test.ts:45-55`).
- **LEGACY sémantique.** Une Operation peut être créée/ouverte lorsque l'Offre est seulement `PUBLISHED` (`PostgresOfferReadModel.ts:148-156`; ancien state machine documentaire `:104-109`).
- **DEAD / UNUSED pour ASC réel.** Les occurrences billetterie/loisirs/voyages sont éditoriales (`bridge-qf/pages/QfAvantages.tsx:146-166`) ou des fixtures Offer (`server/offer-domain/test/fixtures.ts:20-23`).
- **FACT — absences.** Aucun agrégat/service/table/commande consommée pour catalogue marchand, réservation, stock, prestataire, consommation ou paiement ASC; aucun appel frontend à l'API Offer.

`Offer Operation` est la brique à réutiliser; elle ne constitue pas encore un service ASC. **GAP P2.**

## 14. Réponse détaillée Q11 — Budget

**Réponse : NO.** Le budget des flux actuels n'est ni défini ni référencé par une Version d'Offre.

- **FACT — cycle réel.** `POST /api/budgets` crée Budget et événement DRAFT (`server/routes.ts:831-899`). `/api/budgets/validate` bascule les anciens `ACTIVE` en `LEGACY_ACTIVE`, puis active la cible avec `vote_status=VALIDATED`, `is_active=true`, `status=ACTIVE` et journalise (`:915-1042`). La clôture exige `LEGACY_ACTIVE`, puis écrit `CLOSED` (`:1080-1165`).
- **FACT — modèle concurrent.** L'état est réparti entre `status`, `vote_status` et `is_active`; le Dashboard salarié cherche `is_active` et `APPROVED|VALIDATED`, avec deux variantes de filtre (`DashboardSalarie.tsx:434-441,615-622`).
- **FACT — runtime.** L'instance observée expose les index `one_active_budget_per_org` et `ux_budgets_one_active_validated_per_org_year`, non définis dans les migrations présentes (`DPDS_000A_RUNTIME_REPOSITORY_DIFF.md:52-62`). Le dépôt et le runtime ne portent donc pas la même définition versionnée.
- **FACT — Offer.** `OfferVersionDefinition` contient titre, description, famille, `parameters`, population cible et références externes, sans `budgetId` typé (`OfferVersion.ts:7-14`). Les tables Offer n'ont aucune colonne Budget (`20260717000000_create_offer_infrastructure.sql:19-88`). Un UUID glissé dans `parameters` ne constituerait ni FK ni contrat validé.
- **FACT — Rights/demandes.** Rights ne lit aucun Budget. Une Subvention fige bien `budget_id` et les RPC réutilisent ce champ (`create_subventions.sql:4-7`; RPC approve/pay).

Réponses : Offre référence Budget **NO** ; Version fige Budget **NO** ; Rights lit Budget **NO** ; demande conserve Budget **YES** ; dotation conserve Budget **NOT_IMPLEMENTED** ; plusieurs budgets concurrents **YES au niveau des consommateurs et représentations**, même si les index runtime réduisent certaines coexistences actives ; plusieurs vérités budgétaires **YES** (`status`, `vote_status`, `is_active`, filtres frontend, définition runtime non versionnée). `budget_cse_profile` n'existe pas. **GAP P0.**

## 15. Réponse détaillée Q12 — Ledger

**Réponse : NO.** Aucune opération financière n'est traçable jusqu'à une Offre/version d'origine.

- **FACT — `budget_ledger`.** Colonnes : budget, subvention nullable, type, montant, operation, acteur, label/metadata, sans Offer/version (`20260222000000_create_budget_ledger.sql:1-16`).
- **FACT — paiement.** `subvention_payments` lie paiement, subvention, budget et opération, sans Offer/version (`20260222205500_create_subvention_payments_v29.sql:6-31`).
- **FACT — mutations.** Approbation écrit `RESERVE`; paiement écrit `RELEASE` et `DEBIT`; remboursement écrit `CREDIT` (RPC citées en Q7).
- **FACT — vues.** `v_grand_livre_asc` joint `budget_ledger → budgets → subventions → subvention_payments → profiles`, sans Offer (`20260615_create_grand_livre_asc_views.sql:18-123`). Le Cockpit et l'historique consomment `budget_ledger` (`GdbcseFinancialCockpit.tsx:218,1494,3096`; `legacyData.service.ts:78-127`).
- **LEGACY runtime actif.** La base observée contient aussi `ledger_entries`, la fonction `create_ledger_entry` et le trigger `trigger_ledger_subvention` sur `subventions`, alors qu'aucune migration ou consommation applicative correspondante n'existe dans le dépôt (`DPDS_000A_RUNTIME_OBSERVATION_REPORT.md:66-78,123-149`). C'est un second Ledger concurrent et runtime-only.
- **FACT — orphelins.** `budget_ledger.subvention_id` est nullable; les crédits budget sont intentionnellement sans demande. Toutes les lignes sont orphelines vis-à-vis d'Offer parce qu'aucun chemin de jointure vers Offer n'existe. Les demandes et paiements ne conservent pas cette origine.

Par flux : remboursement financier **budget/subvention seulement** ; dotation **NOT_IMPLEMENTED** ; titres **NOT_IMPLEMENTED** ; ASC **NOT_IMPLEMENTED** ; paiement **subvention/budget seulement** ; annulation/release/réservation **subvention/budget seulement**. `ledger` contient `offer_id` **NO** ; `offer_version_id` **NO** ; jointure fiable **NO** ; demande/dossier/paiement conservent l'origine Offer **NO** ; écritures orphelines Offer possibles **YES, actuellement systématiques** ; Ledgers concurrents **YES**. **GAP P0.**

## 16. Chaîne réelle actuelle

```mermaid
flowchart TD
  A[ADMIN / GDBCSE] --> B[Budgets API]
  A --> C[Subventions ADMIN]
  O[Offer API sans UI] --> O1[Offer DRAFT]
  O1 --> O2[Version IN_REVIEW]
  O2 --> O3[Version VALIDATED]
  O3 --> O4[Offer + Version PUBLISHED]
  O4 --> O5[Operation OPEN / DistributionFacts]
  O5 -. aucun consommateur .-> X[Fin de chaîne Offer]

  QI[user_qf_input / QF] --> QH[qf_history]
  QH --> R[compute-rights]
  RC[rights_config] --> R
  R --> RH[rights_history]
  R --> RP[user_rights_projection]
  RP --> E[EBS transitoire]
  P[profiles] --> E
  S[subventions] --> E
  E --> LH[LifeHub]
  E --> DS[Dashboard salarié]
  DS -->|INSERT direct| S
  DS --> K[Constantes plafonds + catalogues]
  S --> AP[approve_subvention]
  AP -->|RESERVE| BL[budget_ledger]
  S --> PP[pay_subvention]
  PP --> SP[subvention_payments]
  PP -->|RELEASE + DEBIT| BL
  BL --> GL[v_grand_livre_asc / Cockpit]
  S -->|trigger runtime legacy| LE[ledger_entries]
```

**FACT.** Offer, Rights/EBS et Subvention/Budget/Ledger sont trois chaînes exécutables parallèles. Leur seule proximité est organisationnelle; aucune FK, commande ou événement ne les réunit.

## 17. Chaîne cible canonique

```mermaid
flowchart TD
  CSE[CSE] --> ADMIN[ADMIN]
  ADMIN --> O[Offer]
  O --> V[Version figée]
  V --> VAL[Validation]
  VAL --> PUB[Publication]
  PUB --> ACT[Activation]
  ACT --> ELIG[Éligibilité / Rights]
  ELIG --> EBS[Employee Business State]
  EBS --> UI[Dashboard salarié / LifeHub]
  UI --> EXE[Exécution par famille]
  EXE --> B[Budget référencé par la Version]
  B --> L[Ledger avec origine Offer + Version]
  L --> OUT[Paiement ou distribution]
```

## 18. Écarts bloquants MVP

### P0

1. **GAP-OFFER-ACTIVE** — aucun état/commande/événement/persistance/API `ACTIVE`.
2. **GAP-OFFER-VERSION-CONTRACT** — la Version ne fige pas de référence Budget ni le contrat exécutable requis par famille.
3. **GAP-ADMIN-OFFER** — aucune UI ADMIN pour créer/versionner/valider/publier/activer.
4. **GAP-RIGHTS-OFFER** — Rights lit QF + `rights_config`, jamais une Version active.
5. **GAP-EBS-OFFER** — EBS publie des benefits Rights tous disponibles, sans faits Offer.
6. **GAP-REIMBURSEMENT-ORIGIN** — création directe de `subventions` sans Offre/version/règles.
7. **GAP-BUDGET-ORIGIN** — Budget non référencé par la Version; consommateurs fondés sur trois indicateurs d'état.
8. **GAP-LEDGER-ORIGIN** — aucune origine Offer/version et deux ledgers runtime concurrents.

### P1

1. **GAP-EMPLOYEE-UI-AUTHORITY** — Dashboard et LifeHub maintiennent calculs/projections locales.
2. **GAP-ALLOCATION** — aucune attribution exécutable.
3. **GAP-COFUNDED** — CESU, Ticket Restaurant et Chèque Vacances limités à la simulation.
4. **GAP-TEST-E2E** — aucune preuve d'intégration Offer → Rights → EBS → demande → finance.

### P2

1. **GAP-ASC-SERVICE** — Operation Offer existe, mais sans booking/stock/prestataire/consommation.
2. **GAP-RUNTIME-REPO** — index, tables, triggers et surcharges runtime non intégralement versionnés.

### Hors MVP

- Rattacher rétroactivement une ancienne écriture à une Offre lorsque l'information historique n'a jamais été capturée. Ces lignes doivent rester explicitement `LEGACY_ORIGIN_UNKNOWN`, sans origine inventée.
- Refaire l'architecture Offer, Rights, EBS, Budget ou Ledger. Les composants existants suffisent comme bases; seule leur extension/raccordement est requis.

## 19. Plan de développement directement exécutable

L'ordre ci-dessous est impératif. Un lot ne passe GO que si sa preuve est produite et ses dépendances sont GO.

### DEV-OFFER-ACTIVATION-001 — ordre 1 — 3 jours ouvrés

- **Objectif :** ajouter `PUBLISHED → ACTIVE → OfferActivated` dans Domain/Application/API/Infrastructure existants.
- **Zones :** `server/offer-domain`, `server/offer-application`, `server/offer-api`, `server/offer-infrastructure`, nouvelle migration additive Offer, tests Offer.
- **Réutiliser :** agrégat, state machines, catalogues, idempotence, optimistic locking, audit, outbox, router/OpenAPI.
- **Interdits :** nouvelle architecture/runtime; UI; Rights; EBS; Subvention; Budget/Ledger legacy.
- **Dépendance :** aucune.
- **Tests :** transition valide/invalide, rôles/SOD, idempotence, concurrence, persistence mapper, CHECK DB, HTTP/OpenAPI, audit/outbox.
- **Preuve :** une commande authentifiée persiste `ACTIVE` et un unique `OfferActivated` atomique.
- **GO / NO_GO :** GO si toutes couches et tests concordent; NO_GO si `PUBLISHED` reste interprété comme actif ou si l'événement n'est pas atomique.
- **Risques/compatibilité :** les consommateurs legacy continuent à lire `PUBLISHED`; aucune bascule consommateur dans ce lot.

### DEV-OFFER-VERSION-EXECUTION-CONTRACT-002 — ordre 2 — 4 jours ouvrés

- **Objectif :** rendre explicites et validés dans `OfferVersionDefinition` la famille canonique, `budgetId`, plafonds, règles, justificatifs, périodes et conditions d'activation.
- **Zones :** value objects/validators/mappers/API schemas/colonnes ou JSONB Offer versionné; migration additive; fixtures/tests.
- **Réutiliser :** `parameters`, `externalReferences`, `TargetPopulation`, validation stricte et Version immuable.
- **Interdits :** nouvelle base, nouveau moteur, logique Rights/finance.
- **Dépendance :** 001.
- **Tests/preuve :** quatre familles acceptées; contrat incomplet refusé; version publiée/active immuable; `budgetId` UUID validé et organisation cohérente.
- **GO / NO_GO :** GO si la Version suffit à reproduire les règles applicables; NO_GO si des paramètres critiques restent seulement frontend.
- **Risques/compatibilité :** lecture tolérante des Versions legacy, marquées non activables jusqu'à complétude.

### DEV-ADMIN-OFFER-WORKBENCH-003 — ordre 3 — 5 jours ouvrés

- **Objectif :** fournir à ADMIN le parcours create/edit version/submit/validate/publish/activate.
- **Zones :** routes/layout GDBCSE, pages/composants/formulaires/hooks/services API Offer, tests UI/contrat.
- **Réutiliser :** `/api/v1/offer`, OpenAPI, rôles existants, design GDBCSE.
- **Interdits :** Supabase direct sur tables Offer; duplication de state machine; activation frontend optimiste non confirmée.
- **Dépendances :** 001-002.
- **Tests/preuve :** chaque opération déclenche la commande attendue; erreurs de version/SOD visibles; rechargement depuis query Offer.
- **GO / NO_GO :** GO si les cinq opérations Q1 sont exécutables par ADMIN; NO_GO si une mutation contourne l'API.
- **Risques/compatibilité :** aucune modification des pages salariées.

### DEV-RIGHTS-ACTIVE-OFFER-004 — ordre 4 — 5 jours ouvrés

- **Objectif :** calculer l'éligibilité/droits à partir d'une Version `PUBLISHED` appartenant à une Offre `ACTIVE`, avec QF comme donnée d'entrée et Budget/règles issus de la Version.
- **Zones :** read model/distribution Offer, publisher outbox existant, `compute-rights` ou service Rights existant, hashes/history/projection, tests.
- **Réutiliser :** `ListOfferDistributionFacts`, `offer_outbox`, `rights_config` seulement comme compatibilité legacy explicite, `qf_history`, idempotence Rights.
- **Interdits :** nouveau moteur Rights/cache; constante frontend; activation implicite par publication.
- **Dépendances :** 001-002.
- **Tests/preuve :** absence d'Offer active = aucun droit; activation crée/recalcule; suspension/clôture retire la disponibilité; hash inclut Offer/version/règles.
- **GO / NO_GO :** GO si toute projection Rights porte `offer_id`/`offer_version_id`; NO_GO si `rights_config` seul peut encore créer un droit canonique.
- **Risques/compatibilité :** projections legacy conservées et étiquetées, jamais confondues avec origine Offer.

### DEV-EBS-OFFER-DISTRIBUTION-005 — ordre 5 — 4 jours ouvrés

- **Objectif :** consolider les faits Offer/Version et Rights sourcés, sans créer de disponibilité arbitraire.
- **Zones :** EBS types/validator/registry/provider/mapper/adapter/runtime/DistributionLayer, LifeHub bridge, tests.
- **Réutiliser :** DistributionLayer, `ListOfferDistributionFacts`, provenance EBS, projections existantes.
- **Interdits :** persistance EBS, moteur d'éligibilité dans EBS, `available: true` inconditionnel.
- **Dépendance :** 004.
- **Tests/preuve :** provenance Offer complète, progression indépendante des documents réels, suspension propagée, aucun calcul de droit dans EBS.
- **GO / NO_GO :** GO si l'EBS est un agrégateur déterministe; NO_GO s'il fabrique une offre/droit.
- **Risques/compatibilité :** maintenir les sections EBS existantes avec nouveaux champs optionnels pendant migration UI.

### DEV-EMPLOYEE-UI-AUTHORITY-006 — ordre 6 — 4 jours ouvrés

- **Objectif :** rendre Dashboard salarié et LifeHub consommateurs de l'EBS canonique pour droits, disponibilité et progression.
- **Zones :** `DashboardSalarie`, `MonEspacePage`, hooks/pages LifeHub, catalogues/plafonds frontend, tests React.
- **Réutiliser :** hook EBS et Document Core pour les seuls documents.
- **Interdits :** création de droit, catalogues parallèles, compute-rights direct navigateur, calcul local de plafond/disponibilité.
- **Dépendance :** 005.
- **Tests/preuve :** mêmes Offer/version sur les deux interfaces; compteurs et progression issus des projections nommées; données Document Core non assimilées au profil.
- **GO / NO_GO :** GO si aucune vérité métier concurrente n'est utilisée; NO_GO si une constante décide d'un droit.
- **Risques/compatibilité :** garder le contenu éditorial sans lui donner valeur métier.

### DEV-REIMBURSEMENT-OFFER-LINEAGE-007 — ordre 7 — 6 jours ouvrés

- **Objectif :** créer une demande REIMBURSEMENT uniquement depuis une Offre active/version, avec salarié, organisation, budget et règles figées.
- **Zones :** migration additive `subventions`, commande/service/API backend, Dashboard, Document Core references, workflow/RPC/tests.
- **Réutiliser :** `subventions`, RPC reserve/pay/refund, Document Core, Offer query, Budget actif.
- **Interdits :** insert Supabase direct; nouvelle table de demande concurrente; backfill inventé.
- **Dépendances :** 002,004-006.
- **Tests/preuve :** FK/cohérence tenant; demande sans Offer refusée; règles/version immuables; dossier/documents conservent origine; reserve/pay conservent budget d'origine.
- **GO / NO_GO :** GO si toute nouvelle demande est traçable; NO_GO si un chemin direct reste accessible.
- **Risques/compatibilité :** champs Offer nullable seulement pour lignes historiques; nouvelles lignes obligatoires via contrainte différée après bascule.

### DEV-BUDGET-LEDGER-OFFER-LINEAGE-008 — ordre 8 — 5 jours ouvrés

- **Objectif :** propager l'origine Offer/version de la demande aux réservations, releases, paiements, remboursements et vues.
- **Zones :** Budget binding, `budget_ledger`, `subvention_payments`, RPC, vues, services/Cockpit, triggers runtime legacy à neutraliser comme producteurs indépendants, tests SQL/intégration.
- **Réutiliser :** `budget_ledger` comme journal de mutation actuel; `v_grand_livre_asc`; operation_id/idempotence.
- **Interdits :** troisième ledger; suppression des écritures historiques; origine rétroactive inventée.
- **Dépendance :** 007.
- **Tests/preuve :** jointure Offer fiable pour tous mouvements nouveaux; compensation/retry/idempotence; lignes legacy explicitement sans origine; `ledger_entries` ne produit pas une seconde vérité.
- **GO / NO_GO :** GO si aucune nouvelle écriture financière Offer-orpheline n'est possible; NO_GO si deux producteurs mutables subsistent.
- **Risques/compatibilité :** vues UNION/flags legacy pendant transition, sans réécriture du passé.

### DEV-ALLOCATION-OFFER-009 — ordre 9 — 7 jours ouvrés

- **Objectif :** implémenter éligibilité → attribution → réservation → distribution → Ledger pour ALLOCATION.
- **Zones :** adaptateur d'exécution sur Offer, persistance Attribution, Budget/Ledger, EBS/UI, tests par motif MVP retenu.
- **Réutiliser :** Offer/version/eligibility/EBS/Budget/Ledger construits en 001-008.
- **Interdits :** attribution directe, catalogue événementiel frontend autoritaire.
- **Dépendance :** 008.
- **Tests/preuve :** une attribution unique porte Offer/version/salarié/budget/distribution/ledger.
- **GO / NO_GO :** GO sur traçabilité complète; NO_GO sur simple simulation.
- **Risques/compatibilité :** contenus statiques restent éditoriaux jusqu'à migration produit par produit.

### DEV-COFUNDED-TITLES-OFFER-010 — ordre 10 — 8 jours ouvrés

- **Objectif :** implémenter séparément CESU, Ticket Restaurant, Chèque Vacances avec participation, commande, réservation, distribution, Ledger.
- **Zones :** adaptateurs produits, modèles de commande/distribution, Budget/Ledger, EBS/UI, tests.
- **Réutiliser :** moteur de simulation comme prévision uniquement; chaîne 001-009.
- **Interdits :** transformer une simulation en attribution réelle; règle locale non versionnée.
- **Dépendance :** 008.
- **Tests/preuve :** matrices distinctes par produit et conservation des deux parts.
- **GO / NO_GO :** GO produit par produit; aucun GO groupé si un produit manque.
- **Risques/compatibilité :** simulations restent sans impact financier.

### DEV-ASC-SERVICE-OFFER-011 — ordre 11 — 8 jours ouvrés

- **Objectif :** raccorder réservation/consommation ASC à Offer active et Operation ouverte.
- **Zones :** `offer_operation`, adaptateurs catalogue/réservation/stock/prestataire, Budget/Ledger conditionnel, EBS/UI/tests.
- **Réutiliser :** Operation et ses références Offer/version.
- **Interdits :** catalogue parallèle; réservation sur Offer seulement publiée.
- **Dépendance :** 008.
- **Tests/preuve :** réservation et consommation portent Offer/version/Operation; stock et annulation atomiques; Ledger lorsque financier.
- **GO / NO_GO :** GO si exécution prouvée; NO_GO sur écran de démonstration seul.
- **Risques/compatibilité :** fixtures et contenus éditoriaux ne sont pas migrés comme données métier.

Estimation séquentielle totale : **59 jours ouvrés**. Les lots 009, 010 et 011 peuvent être parallélisés seulement après GO du lot 008; leur ordre logique reste 009 → 010 → 011 pour la livraison.

## 20. Premier lot de développement à lancer

| Champ | Valeur |
|---|---|
| MissionId proposé | `DEV-OFFER-ACTIVATION-001` |
| Objectif exact | Ajouter à l'agrégat Offer la transition explicite et auditable `PUBLISHED → ACTIVE`, la commande `ActivateOffer`, l'événement `OfferActivated`, leur persistance et leur exposition HTTP. |
| Périmètre autorisé | Domain, Application, API, Infrastructure Offer; migration additive de CHECK/état; tests ciblés. |
| Fichiers candidats | `server/offer-domain/types/states.ts`, `types/catalog.ts`, `command/offer.commands.ts`, `event/offer-events.ts`, `state-machine/OfferStateMachine.ts`, `aggregate/OfferAggregate.ts`, policies/validators; `server/offer-application/application/CommandExecutionService.ts` et contrats/handlers; `server/offer-api` validation/OpenAPI/fixtures; `server/offer-infrastructure` rows/mappers/repository; migration additive; tests des quatre couches. |
| Composants obligatoires à réutiliser | Agrégat Offer, optimistic locking, idempotence, audit, transactional outbox, catalogues de commandes/événements, routeur générique et OpenAPI. |
| Interdictions | Aucun nouveau moteur/runtime/gouvernance; aucune UI; aucun changement Rights/EBS/Subvention/Budget/Ledger; ne pas assimiler Publish et Activate; ne pas modifier les données legacy. |
| Tests | Domain transitions et refus; rôles/SOD; Application dispatch/idempotence; persistence mapping/concurrence/CHECK; API validation/auth/OpenAPI; audit + outbox atomiques; non-régression des 21 + 9 tests actuels. |
| Critères de réussite | `ACTIVE` dans modèle et DB; `ActivateOffer` autorisée seulement depuis `PUBLISHED`; `OfferActivated` unique et atomique; GET retourne `ACTIVE`; commande authentifiée et tenant-safe; publication seule ne rend pas l'Offre active; suites ciblées vertes. |
| Critères d'arrêt | Invariant Version publiée non garanti; migration non additive; outbox non atomique; transition possible depuis DRAFT/SUSPENDED/CLOSED/ARCHIVED; régression des cycles existants; besoin de toucher un domaine hors périmètre. |
| Livrable attendu | Code/migration/tests Offer du lot, rapport de preuve de test et delta strictement borné; aucune bascule de consommateur. |

Ce lot est le plus petit incrément cohérent parce qu'il ferme l'unique transition racine manquante avant toute consommation aval. Il est isolable, compatible avec les données `PUBLISHED` existantes, exploite exclusivement les quatre couches Offer certifiées et ne force aucune reconstruction générale.

## Verdict final

TWELVE QUESTIONS ANSWERED = YES

ADMIN OFFER MANAGEMENT IMPLEMENTED = NO

OFFER ACTIVE LIFECYCLE IMPLEMENTED = NO

RIGHTS DERIVED FROM ACTIVE OFFER = NO

EBS RESPONSIBILITY CLARIFIED = YES

DASHBOARD DATA AUTHORITY CLARIFIED = YES

LIFEHUB DATA AUTHORITY CLARIFIED = YES

REIMBURSEMENT TRACEABLE TO OFFER = NO

ALLOCATION TRACEABLE TO OFFER = NO

COFUNDED_TITLES TRACEABLE TO OFFER = NO

ASC_SERVICES TRACEABLE TO OFFER = NO

BUDGET TRACEABLE TO OFFER = NO

LEDGER TRACEABLE TO OFFER = NO

MVP BLOCKERS IDENTIFIED = YES

DEVELOPMENT ORDER DEFINED = YES

FIRST DEVELOPMENT LOT READY = YES

ADDITIONAL AUDIT REQUIRED BEFORE DEVELOPMENT = NO

CODE MODIFIED = NO

COMMIT = NO

PUSH = NO
