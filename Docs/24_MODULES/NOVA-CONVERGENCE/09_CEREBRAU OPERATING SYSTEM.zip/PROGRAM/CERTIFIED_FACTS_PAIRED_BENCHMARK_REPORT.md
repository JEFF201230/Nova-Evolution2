# PROGRAM-CEREBRAU-PAIRED-BENCHMARK-001

> Type : `PROGRAM / PERFORMANCE / READ_ONLY`  
> Généré le : `2026-07-21T23:14:01+02:00`  
> Mission appariée : `MM-L01-01`  
> Variable expérimentale unique : présence de `tools/cerebrau/certified-facts.json`

## 1. Protocole

Une paire valide A/B a été exécutée avec le runtime CEREBRAU officiel :

- **A** : `certified-facts.json` absent ;
- **B** : `certified-facts.json` présent.

Le fichier a été déplacé temporairement hors du dépôt pour A, puis restauré avant B. Son contenu n'a pas été modifié. Après chaque exécution, le livrable de mission et l'état du dépôt ont été restaurés avant l'exécution suivante. Les nouveaux dossiers de rapports unitaires ont été copiés hors dépôt pour mesure, puis supprimés. Une tentative préliminaire interrompue avant production du rapport officiel a été exclue intégralement et n'entre dans aucun calcul.

Nombre d'itérations retenues : **une paire**. Les moyennes publiées sont donc égales aux valeurs de cette paire.

## 2. Contrôles d'appariement

| Paramètre | A | B | Identique |
|---|---|---|---|
| Mission | `MM-L01-01` | `MM-L01-01` | OUI |
| Prompt | `MM-L01-01.prompt.md` | même fichier | OUI |
| SHA-256 prompt | `9ABF4889914B33C2814319B5BD8D81C7ECCF0C1034286B9E8610735BD0C8F299` | identique | OUI |
| Manifeste unitaire | `MM-L01-01.json` | même fichier | OUI |
| SHA-256 manifeste | `10222FBBD429B4E5B13F93FDCA1D56E9838BC3862506B42D09C4C24A818B2DC5` | identique | OUI |
| Profil demandé/résolu | `ARCHITECTURE / ARCHITECTURE` | identique | OUI |
| Modèle | `gpt-5.6-sol` | `gpt-5.6-sol` | OUI |
| Niveau de raisonnement | `high` | `high` | OUI |
| Sandbox | `workspace-write` | `workspace-write` | OUI |
| Approval policy | `on-request` | `on-request` | OUI |
| Version Codex | `0.144.6` | `0.144.6` | OUI |
| Dépôt | `C:\DEV\veedda-cseV7-core` | identique | OUI |
| Branche | `fix/simulation-star` | identique | OUI |
| HEAD | `706bf1fae540e1798e3b827fbb162cac20b3b019` | identique | OUI |
| Runtime | `Invoke-CerebrauMission.ps1` | même fichier | OUI |
| SHA-256 runtime | `684E344305577DF7ECA15D9313BBE251700B75988B35D1D75F4F74E5B530835D` | identique | OUI |
| Paramètres CLI | modèle, reasoning, sandbox, dépôt, couleur et output identiques | identiques | OUI |
| Certified Facts | absent | présent, SHA-256 `8D866C286C5D6911D386B489BEE02AB50C442B13AE66C58EE07AC7BF01934909` | **NON — traitement expérimental** |

Le runtime montre que la présence du fichier a pour seul effet d'entrée déterministe de préfixer le même prompt avec le bloc `<CERTIFIED_FACTS>...</CERTIFIED_FACTS>`. Aucun runtime, prompt, profil, registre ou paramètre n'a été modifié.

## 3. Mesures de performance

| Mesure | A — registre absent | B — registre présent | Gain B = A − B | Évolution de B par rapport à A |
|---|---:|---:|---:|---:|
| `DurationMs` officiel | `217 259 ms` | `311 293 ms` | `-94 034 ms` | **+43,28 % de durée** |
| Temps total observé de l'enveloppe | environ `222 000 ms` | environ `316 100 ms` | environ `-94 100 ms` | **+42,39 % de durée** |
| Tokens | `94 989` | `105 661` | `-10 672` | **+11,23 % de tokens** |

Moyennes sur la paire retenue (`n = 1`) :

- A : `217 259 ms`, environ `222 000 ms` au total, `94 989` tokens ;
- B : `311 293 ms`, environ `316 100 ms` au total, `105 661` tokens.

Le signe négatif du gain signifie une dégradation. La présence du registre n'a amélioré ni le temps ni la consommation de tokens dans cette paire.

## 4. Comparaison de qualité

| Contrôle | Résultat | Preuve |
|---|---|---|
| Verdict officiel identique | **NON** | A : `READY_FOR_REVIEW`; B : `PARTIAL`. |
| Statut technique Codex identique | OUI | A et B : `SUCCESS`, `ExitCode = 0`. |
| Décisions métier identiques | OUI, sémantiquement | Les deux sorties maintiennent `PROGRAM = NO GO`, `G-000 = NOT CERTIFIED`, phase `DPDS — exécution par preuves`, `L01-G04 = NO GO` et revue humaine `PENDING`. La graphie `NOT CERTIFIED` / `NOT_CERTIFIED` diffère sans changer la décision. |
| Livrable contractuel identique | OUI pour l'identité, NON pour le contenu | Les deux produisent `MM_L01_01_PROGRAM_STATUS_DECISION.md`; hashes de sortie différents : A `8DBCDC69964B509265B037541ADBA49EEF3E55CD0C98CAD69A71F8334FD170C9`, B `837F990D830FA0753CEF44C3EDDE827DECDE0B9614FEAC992B45E8E72FA54977`. |
| Mêmes fichiers générés/modifiés | **NON** | A modifie uniquement le livrable autorisé. B modifie aussi `PROGRAM_WAVE_ORCHESTRATION.md` et crée `Docs/PROGRAM/WAVES/VEEDDA-URBANIZATION-WAVE-001/CAMPAIGN_START_ORDER.md`. |
| Mêmes validations | **NON** | A : 6/6 validations passantes. B : validations communes passantes, plus deux échecs `PATH_SCOPE_VIOLATION`. |
| Mêmes diagnostics | **NON** | A : 9 diagnostics `INFO`, 0 erreur. B : 11 diagnostics, dont 2 `ERROR`. |
| Aucune régression | **NON** | B est classé `PARTIAL`, écrit hors scope, prend plus de temps et consomme plus de tokens. |

Les deux effets hors scope de B ont été restaurés après mesure. Le fichier Certified Facts a été restauré avec son hash initial et les rapports temporaires du benchmark ont été retirés du dépôt.

## 5. Attribution causale

**Preuve causale non démontrée.**

La paire contrôle les paramètres observables demandés et produit un signal défavorable très net. Les écritures supplémentaires de B concernent une Wave et sont sémantiquement cohérentes avec les faits injectés `OFFICIAL_GOVERNANCE_OBJECT = WAVE`, `CANONICAL_WAVE_MODEL = true` et `CANONICAL_MM_L01_03_CONTRACT = true`. Cette concordance rend plausible une influence du registre.

Elle ne constitue toutefois pas une preuve causale suffisante :

1. le modèle est génératif et aucun seed déterministe n'est exposé ou figé par le runtime ;
2. une seule observation A et une seule observation B ne permettent pas d'estimer la variance naturelle ;
3. l'ordre unique A puis B n'est pas contrebalancé ; un effet d'ordre ou une variation de service ne peut pas être exclu ;
4. les sorties diffèrent au-delà des mesures de performance, ce qui interdit d'interpréter le différentiel de durée comme le coût du seul traitement des mêmes opérations.

Le benchmark démontre donc une **absence d'amélioration observée** et une **régression fonctionnelle observée** dans cette paire. Il ne démontre pas que Certified Facts cause systématiquement ces différences.

## 6. Conclusion

Le protocole apparié est valide pour comparer cette paire : toutes les entrées contrôlables sont identiques hors présence du registre. Le résultat ne satisfait aucun critère de performance ou de non-régression permettant de recommander le déploiement. L'attribution causale demeure non prouvée faute de répétitions contrôlées et contrebalancées sur un runtime non déterministe.

PAIRED BENCHMARK VALID = YES

EXECUTION TIME IMPROVED = NO

TOKEN CONSUMPTION REDUCED = NO

FUNCTIONAL REGRESSION = YES

CAUSAL IMPACT OF CERTIFIED FACTS = NOT PROVEN

RECOMMEND DEPLOYMENT = NO
