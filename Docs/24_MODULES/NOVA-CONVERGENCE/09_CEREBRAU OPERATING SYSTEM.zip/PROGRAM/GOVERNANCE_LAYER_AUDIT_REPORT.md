# PROGRAM-GOVERNANCE-AUDIT-002 — Niveau officiel de gouvernance des campagnes

## Sources officielles retenues

- `Docs/09_CEREBRAU OPERATING SYSTEM/00_GOVERNANCE/PROGRAM_WAVE_ORCHESTRATION.md` ;
- `Docs/09_CEREBRAU OPERATING SYSTEM/05_RULES/ORCHESTRATION_GOVERNANCE.md` ;
- `Docs/09_CEREBRAU OPERATING SYSTEM/03_CODEX_EXECUTION_MVP/CAMPAIGN_RUNNER_MVP.md` ;
- `Docs/PROGRAM/PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md` ;
- `Docs/PROGRAM/PROGRAM_MASTER_GATES_REGISTER.md` ;
- `Docs/PROGRAM/PROGRAM_GATE_EXECUTION_ORDER.md` ;
- `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md` ;
- `Docs/PROGRAMS/PROGRAM-CEREBRAU-CAMPAIGN-RUNNER-DESIGN-001/CAMPAIGN_RUNNER_ARCHITECTURE.md` ;
- `Docs/PROGRAMS/PROGRAM-CEREBRAU-CAMPAIGN-RUNNER-DESIGN-001/CAMPAIGN_RUNNER_EXECUTION_MODEL.md` ;
- `Docs/PROGRAMS/PROGRAM-CEREBRAU-CAMPAIGN-RUNNER-DESIGN-001/CAMPAIGN_RUNNER_MANIFEST_SPEC.md` ;
- `Docs/PROGRAMS/PROGRAM-CEREBRAU-CAMPAIGN-RUNNER-DESIGN-001/CAMPAIGN_RUNNER_SEQUENCE_DIAGRAM.md` ;
- `Docs/PROGRAMS/PROGRAM-CEREBRAU-CAMPAIGN-RUNNER-DESIGN-001/CAMPAIGN_RUNNER_STATE_MACHINE.md` ;
- `tools/cerebrau/campaign-manifest.schema.json`.

Les rapports d'audit antérieurs ne sont utilisés comme preuve dans aucune conclusion ci-dessous.

## GOV-001 — Objet officiel autorisant l'exécution des campagnes

**Objet de gouvernance officiel : `Wave`.**

Preuves documentaires :

- Une `Wave` est définie comme « une tranche d'exécution d'un Program » regroupant des Squads et des Mission Orders compatibles : `PROGRAM_WAVE_ORCHESTRATION.md`, section 2.2, lignes 41 à 53.
- Son ouverture dépend de l'ouverture du Program, des dépendances, des Entry Gates, des Squads, des locks, de l'ownership et du plan de synchronisation : même document, section 5, lignes 190 à 202.
- Son passage à `RUNNING` exige des Mission Orders émises, des statuts de Squad valides, les Resource Locks et des dépendances cohérentes : même document, « Wave Activation Rule », lignes 206 à 227.
- Le Program Director décide de l'ouverture et de la fermeture d'une Wave : même document, section 3, lignes 150 à 164.

**Objet technique d'exécution d'une Campaign : `Campaign Manifest`.**

Preuves documentaires :

- Le manifeste est une instruction d'orchestration fermée qui référence des missions existantes : `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, lignes 5 à 12.
- Le Runner transforme un manifeste validé en appels unitaires au runtime de mission : `CAMPAIGN_RUNNER_ARCHITECTURE.md`, lignes 5 à 16.
- Le preflight interdit tout appel au runtime si une validation obligatoire échoue : `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, section 5, lignes 156 à 173.

Le corpus établit donc un niveau de gouvernance (`Wave`) et un contrat technique (`Campaign Manifest`). Il ne déclare pas que les deux termes sont synonymes.

## GOV-002 — Objet officiel ouvrant ou fermant une Phase

**Réponse : `Wave`.**

Preuves :

- Le vocabulaire officiel définit `Wave`, pas `Phase`, comme tranche d'exécution : `PROGRAM_WAVE_ORCHESTRATION.md`, lignes 23 à 53.
- Le cycle de vie officiel d'une Wave est `PLANNED`, `OPEN`, `IN_PROGRESS`, `SYNC`, `MERGE_WINDOW`, `CERTIFICATION`, `CLOSED` : même document, section 2.8, lignes 110 à 120.
- Le Program Director décide de l'ouverture, de la fermeture et de l'ouverture de la Wave suivante : même document, lignes 150 à 164.
- Le Program Director est le seul habilité à déclarer `WAVE COMPLETE` : même document, lignes 247 à 266.

Le corpus canonique ne définit aucun objet de cycle de vie nommé `Phase`. La Master Gates Matrix contient un champ documentaire `Phase = DPDS — exécution par preuves`, sans règle d'ouverture ou de fermeture associée : `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md`, lignes 3 à 13.

## GOV-003 — Décision de démarrage d'une campagne

Faits établis :

- Au niveau gouvernance, le **Program Director** décide de l'ouverture de la Wave : `PROGRAM_WAVE_ORCHESTRATION.md`, lignes 150 à 164.
- La Wave ne peut passer à `RUNNING` que si la règle d'activation est satisfaite : même document, lignes 206 à 227.
- Au niveau Campaign Runner, l'**Operator** transmet `start campaign.json` au CLI : `CAMPAIGN_RUNNER_SEQUENCE_DIAGRAM.md`, lignes 3 à 25.
- Le démarrage technique n'atteint l'état prêt qu'après validation du manifeste, des manifestes unitaires, du DAG, des références de Gate, de la branche et des hashes d'autorité/preuves : même document, lignes 18 à 25 ; `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, lignes 156 à 173.
- Le schéma de campagne impose une référence d'autorité, mais ne contient aucun champ désignant un décideur humain de démarrage : `campaign-manifest.schema.json`, lignes 6 à 24.

Le décideur officiel d'ouverture du niveau de gouvernance est le **Program Director**. L'Operator déclenche l'exécution technique d'une Campaign ; le Validator contrôle son admissibilité. Aucun rôle distinct nommé « décideur de campagne » n'est défini dans les sources officielles examinées.

## GOV-004 — Validation des Gates

Faits et preuves :

- Le Responsable de Gate définit le périmètre, rassemble les exigences et présente le dossier : `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md`, section 10.1, lignes 463 à 480.
- Le Gardien des preuves contrôle origine, date, portée et intégrité documentaire : même section, ligne 470.
- Pour une Gate `GO` sans écart, l'autorité minimale est « Responsable de Gate + gardien des preuves + comité » : même document, section 10.4, lignes 508 à 518.
- Les autorités spécialisées s'ajoutent pour sécurité, juridique, données ou disponibilité : même document, ligne 516.
- Le Campaign Runner contrôle seulement l'existence et la cardinalité `MissionId→GateId`; il ne prend aucune décision `GO/NO GO` : `CAMPAIGN_RUNNER_ARCHITECTURE.md`, lignes 43 à 50.
- Une revue Campaign atteste uniquement qu'un résultat unitaire peut satisfaire une dépendance d'orchestration ; elle ne valide aucune Gate : `CAMPAIGN_RUNNER_STATE_MACHINE.md`, ligne 93 ; `CAMPAIGN_RUNNER_SEQUENCE_DIAGRAM.md`, lignes 45 à 65.

## GOV-005 — Autorité prononçant GO / NO GO

Faits et preuves :

- Le **Comité de certification** prononce `GO`, `GO_WITH_DEROGATION` ou `NO_GO` : `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md`, ligne 476.
- Une Gate `GO` sans écart exige au minimum Responsable de Gate, Gardien des preuves et Comité : même document, lignes 508 à 513.
- Les dérogations `C1`, `C2`, `C3` et transversales mobilisent les niveaux d'autorité définis aux lignes 513 à 516.
- La décision PROGRAM relève du Comité PROGRAM et du Program Director : même document, ligne 518.
- Le Program Director détient l'autorité finale sur le Program et prononce la certification finale ainsi que le passage à `COMPLETE` ou `REWORK` : `PROGRAM_WAVE_ORCHESTRATION.md`, lignes 150 à 168.
- Une décision ou un état Campaign ne vaut jamais décision de Gate, LOT ou PROGRAM : `CAMPAIGN_RUNNER_ARCHITECTURE.md`, lignes 101 à 107 ; `CAMPAIGN_RUNNER_STATE_MACHINE.md`, lignes 29 à 31.

## GOV-006 — Sources of Truth des décisions

| Nature | Source officielle | Preuve documentaire |
|---|---|---|
| Document normatif | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md` | Se déclare référentiel normatif applicable à toutes les Gates et tous les LOTS ; lignes 3 à 17. |
| Matrice d'orchestration | `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md` | Se déclare référentiel unique de pilotage par LOTS et Gates ; lignes 3 à 17. Elle est déclarée source unique LOT/Gate/Mission/Dépendance pour le Campaign Runner ; ligne 147. |
| Registre de décisions Gate | `PROGRAM_MASTER_GATES_REGISTER.md` | Porte une décision et une référence doctrinale par Gate ; lignes 1 à 18. La Master Gates Matrix le référence pour les décisions courantes ; lignes 511 à 515. |
| Ordre des Gates | `PROGRAM_GATE_EXECUTION_ORDER.md` | Référencé par la Master Gates Matrix pour l'ordre courant des Gates restantes ; lignes 505 à 509 de la matrice. |
| Manifeste Campaign | `Campaign Manifest` conforme à `campaign-manifest.schema.json` | Instruction d'orchestration fermée ; `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, lignes 5 à 12. Son bloc `authority` référence la baseline, son hash et son rapport de certification ; lignes 32 à 40. |
| État technique Campaign | `campaign-events.jsonl` et `campaign-state.json` | Autorité de l'espace Campagne/tentative uniquement ; `CAMPAIGN_RUNNER_STATE_MACHINE.md`, lignes 3 à 12. |

Le manifeste et l'état Campaign ne sont pas des Sources of Truth des décisions de Gate. Le `programDecision` du manifeste est déclaré et n'est jamais recalculé par le Runner : `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, lignes 32 à 40.

## GOV-007 — Dépendances officielles Phase / Campagne / Micro-mission / Gate

### Phase

- Aucun objet canonique `Phase` n'est défini dans `PROGRAM_WAVE_ORCHESTRATION.md`.
- L'objet officiel de tranche d'exécution est `Wave` : lignes 41 à 53.
- La Wave suivante dépend de la fermeture de la précédente, de la levée ou du bornage des risques, des dépendances inter-Squads, des locks, des merges, des rapports et de l'accord du Program Director : même document, lignes 280 à 292.

### Campagne

- Une Campaign dépend d'un manifeste valide, de manifestes unitaires présents, de l'autorité et des preuves conformes à leurs hashes et d'un verrou disponible : `CAMPAIGN_RUNNER_EXECUTION_MODEL.md`, lignes 7 à 13.
- Son DAG est construit uniquement depuis les identifiants et dépendances explicites du manifeste validé : même document, lignes 20 à 42.
- Le manifeste exige `programId`, un bloc `authority`, des prérequis, des preuves et une liste `missions` : `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, lignes 14 à 40.
- Aucun champ `waveId` ou `phaseId` n'existe dans la structure normative du manifeste : même document, lignes 14 à 40 et 78 à 91 ; `campaign-manifest.schema.json`, lignes 6 à 24 et 76 à 97.

### Micro-mission

- Une micro-mission produit une preuve manquante pour une Gate identifiée : `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md`, ligne 27.
- Le registre officiel fournit Mission, Gate, statut, rapport, décision, preuve et dépendance : même document, section 16, lignes 342 à 360.
- Dans une Campaign, les dépendances entre missions sont les `MissionId` déclarés dans `dependsOn` : `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, lignes 78 à 91.

### Gate

- La cardinalité autoritative Gate → Mission est 1:1 pour les 44 missions de remédiation/certification : `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md`, lignes 342 à 344.
- Le manifeste porte la Gate propriétaire dans `gateId` et contrôle cette cardinalité contre la matrice : `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, lignes 81 à 91 et 156 à 173.
- Le Runner utilise la Gate comme référence et ne modifie aucun statut de Gate : `CAMPAIGN_RUNNER_ARCHITECTURE.md`, lignes 45 à 50.

### Relation Wave / Campaign

Le modèle officiel établit `Program → Wave → Squad Opening Order → Mission Orders → Reports → Certification` : `PROGRAM_WAVE_ORCHESTRATION.md`, lignes 296 à 352. Le modèle Campaign établit `Operator → Campaign CLI → Validator → Scheduler → Unit Mission Executor` : `CAMPAIGN_RUNNER_ARCHITECTURE.md`, lignes 20 à 39. Aucun document officiel examiné ne définit une relation de cardinalité ou d'identité entre `Wave` et `Campaign`.

## GOV-008 — Objet officiel au-dessus des campagnes

**OUI.**

Preuves :

- `Wave` est la tranche officielle d'exécution regroupant des Mission Orders compatibles : `PROGRAM_WAVE_ORCHESTRATION.md`, lignes 41 à 53.
- Le schéma officiel d'orchestration place `Wave` au-dessus de `Squad Opening Order` et de `Mission Orders` : même document, lignes 336 à 352.
- Son ouverture, son activation, sa fermeture et le passage à la suivante sont gouvernés : même document, lignes 190 à 292.

Cette réponse identifie le niveau officiel au-dessus de l'exécution groupée des missions. Le corpus ne déclare pas une Campaign égale à une Wave.

## GOV-009 — Nom officiel exact

**Wave**

Preuve terminologique : `PROGRAM_WAVE_ORCHESTRATION.md`, titre « 2.2 Wave », lignes 41 à 53.

## GOV-010 — Suffisance du modèle officiel pour le MVP

**OUI.**

Justification documentaire :

- Le modèle canonique définit déjà Program, Wave, Squad, Mission Order, Entry Gate, Exit Gate et Synchronization Gate : `PROGRAM_WAVE_ORCHESTRATION.md`, lignes 23 à 108.
- Il définit le cycle de vie d'une Wave, son autorité d'ouverture/fermeture, ses conditions d'activation et ses conditions de clôture : même document, lignes 110 à 164 et 190 à 292.
- La Master Gates Matrix se déclare référentiel unique de pilotage par LOTS et Gates et source autoritative LOT/Gate/Mission/Dépendance du Runner : `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md`, lignes 3 à 17 et 142 à 149.
- La matrice constate que le référentiel de pilotage est établi et référence le Master Gates Register, le Gate Execution Order et la Doctrine : même document, lignes 505 à 515.
- Le Campaign Runner dispose d'un manifeste fermé, d'un preflight, d'un DAG, d'états techniques, de preuves hashées et d'un runtime unitaire : `CAMPAIGN_RUNNER_MVP.md`, lignes 5 à 13 et 27 à 79.
- Les limites du Campaign Runner n'empêchent pas l'utilisation complète du MVP pour orchestrer les missions existantes : même document, ligne 106.

## Contradictions et limites documentaires constatées

1. Le modèle canonique gouverne une `Wave`, tandis que le modèle Campaign Runner gouverne une `Campaign`; aucune règle officielle ne déclare leur identité ni leur cardinalité.
2. L'exemple normatif de manifeste utilise `campaignId = VEEDDA-URBANIZATION-WAVE-001`, mais la structure normative ne contient aucun champ `waveId` : `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, lignes 14 à 40 et 97 à 121.
3. La Master Gates Matrix porte une décision PROGRAM `NO_GO`, tout en autorisant l'exécution de missions de preuve en lecture seule lorsque leurs dépendances le permettent : `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md`, lignes 12, 21 à 28 et 511 à 515. Le Runner déclare le `programDecision` sans le recalculer : `CAMPAIGN_RUNNER_MANIFEST_SPEC.md`, lignes 32 à 40.
4. Une approbation Campaign débloque seulement l'ordonnancement ; elle ne valide pas la Gate correspondante : `CAMPAIGN_RUNNER_SEQUENCE_DIAGRAM.md`, lignes 45 à 65.

## Verdict final

**OFFICIAL GOVERNANCE OBJECT = Wave**

Justification factuelle : `Wave` est le nom exact de la tranche d'exécution officielle d'un Program. Elle regroupe les Mission Orders, possède un cycle de vie gouverné et son ouverture, sa fermeture ainsi que l'ouverture de la suivante relèvent du Program Director. Le Campaign Manifest reste le contrat technique fermé consommé par le Runner et ne porte aucune décision de Gate.

**MVP GOVERNANCE = SUFFICIENT**

Justification factuelle : la gouvernance officielle dispose déjà du niveau `Wave`, des Gates, des Mission Orders, des autorités de décision, de la matrice autoritative, du registre des décisions et du manifeste technique de campagne. Aucun objet supplémentaire n'est requis par les documents officiels pour gouverner l'orchestration MVP existante.
