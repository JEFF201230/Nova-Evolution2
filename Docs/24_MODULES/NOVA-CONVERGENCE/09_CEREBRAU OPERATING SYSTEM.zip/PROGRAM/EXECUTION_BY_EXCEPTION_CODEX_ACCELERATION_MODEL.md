# PROGRAM-EXECUTION-BY-EXCEPTION-CODEX-ACCELERATION-001

## 1. Statut et décision

| Attribut | Valeur |
|---|---|
| Type | `PROGRAM / ARCHITECTURE / GOVERNANCE / READ_ONLY` |
| Modèle | `Execution By Exception + Codex Runtime = Operating Model V2` |
| Objet officiel de gouvernance | `WAVE` |
| Work Packages | `NOT_OFFICIAL` — exclus du modèle et de tout calcul |
| Fondation | `READY` |
| Modèle Wave | canonique |
| Contrat `MM-L01-03` | canonique et inchangé |
| Population | 36 Mission Orders officielles restantes |
| Développement requis | aucun |

Le runtime Codex existant peut être utilisé comme accélérateur d'exécution à l'intérieur des Mission Orders déjà autorisées. Il n'est ni un objet de gouvernance, ni une autorité, ni un moteur de Campaign, ni un mécanisme de certification.

Le présent modèle ne change aucune Doctrine, Gate, Mission Order, Campaign, preuve, empreinte ou décision. Il décrit exclusivement une manière d'exploiter les composants existants : le Campaign Runner ordonnance, `Invoke-CerebrauMission.ps1` enferme l'exécution unitaire, Codex réalise le travail technique autorisé, puis les validations et rapports officiels existants qualifient le résultat.

Les 36 Mission Orders restent 36 objets distincts. Une exécution intégrée signifie regrouper plusieurs étapes techniques **dans le périmètre d'une même Mission Order** ; elle ne signifie jamais fusionner des Mission Orders, des Gates ou leurs identités.

## 2. Base probatoire et limites

Le modèle est fondé sur les artefacts présents suivants :

- `Docs/PROGRAM/EXECUTION_BY_EXCEPTION_OPERATING_MODEL.md` : modèle EBE, population de 36 Mission Orders, règles d'exception et estimation de livraison `30 j → 20 j` ;
- `Docs/PROGRAM/PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md` : primauté de la preuve, non-substitution, décision de Gate et propagation `Gate → LOT → PROGRAM` ;
- `Docs/09_CEREBRAU OPERATING SYSTEM/00_GOVERNANCE/PROGRAM_WAVE_ORCHESTRATION.md` : chaîne officielle `Program → Wave → Squad Opening Order → Mission Order` ;
- `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/PROGRAM-VEEDDA-URBANIZATION_EXECUTION_PLAN_CERTIFICATION_REPORT.md` : identités, dépendances, résultats et critères des Mission Orders ;
- `Docs/PROGRAMS/PROGRAM-CEREBRAU-CAMPAIGN-RUNNER-DESIGN-001/CAMPAIGN_RUNNER_EXECUTION_MODEL.md` et `Docs/09_CEREBRAU OPERATING SYSTEM/03_CODEX_EXECUTION_MVP/CAMPAIGN_RUNNER_MVP.md` : DAG, ready set, reprise, preuves partagées, états et rapports Campaign ;
- `tools/cerebrau/campaign-manifest.schema.json` : politiques, dépendances, preuves, modes d'exécution, Resource Scopes et revue ;
- `tools/cerebrau/Cerebrau.Campaign.psm1` : appel unitaire, états, fingerprints, journal, Evidence Index, rapport et reprise ;
- `tools/cerebrau/Invoke-CerebrauMission.ps1` : une invocation `codex exec` par Mission Order, snapshots avant/après, delta, validations, classification et rapport officiel ;
- `tools/cerebrau/Cerebrau.Reporting.psm1` : validations autoritatives, statuts officiels et transcript Codex non autoritatif ;
- `Docs/PROGRAM/CERTIFIED_FACTS_BENCHMARK_REPORT.md` et `Docs/PROGRAM/CERTIFIED_FACTS_PAIRED_BENCHMARK_REPORT.md` : mesures disponibles et absence de preuve causale généralisable.

Limites factuelles :

- toutes les Mission Orders restantes ne disposent pas encore d'un manifeste unitaire exécutable dans le dépôt ;
- le Runner impose actuellement `maxConcurrency = 1` ; aucune accélération par parallélisme n'est retenue ;
- l'Evidence Index réutilise une preuve par identité et SHA-256, mais ne met pas en cache une analyse sémantique ;
- le runtime préfixe les Certified Facts au prompt sans supprimer automatiquement le texte ou les contrôles redondants ;
- aucun benchmark apparié ne compare, sur la même Mission Order, une exécution en étapes Codex séparées à une exécution intégrée ;
- le transcript Codex est explicitement non autoritatif.

Par conséquent, toute valeur non démontrée est indiquée `UNKNOWN`.

## 3. Responsabilités respectives

### 3.1 CEREBRAU

CEREBRAU est l'enveloppe de gouvernance et d'exécution contrôlée. Ses responsabilités exclusives sont :

1. porter la chaîne officielle `Program → Wave → Campaign → Mission Order` ;
2. conserver l'autorité, la Doctrine, les Gates et les décisions `Gate → LOT → PROGRAM` ;
3. vérifier qu'une Mission Order existe, est autorisée, attribuable et présente dans le Campaign Manifest ;
4. valider le Manifest, le DAG, les dépendances, les prérequis externes, les preuves et leurs hashes ;
5. calculer le ready set et sélectionner la prochaine Mission Order éligible ;
6. faire respecter les politiques Campaign, les Resource Locks/scopes, le dépôt, la branche et les chemins autorisés ;
7. résoudre le profil, le modèle, le sandbox et la politique d'approbation depuis les contrats existants ;
8. appeler Codex une seule fois dans l'enveloppe d'une Mission Order ;
9. capturer les snapshots Git avant/après et calculer le delta attribué à la tentative ;
10. exécuter les validations déclarées par la Mission Order ;
11. classifier le résultat officiel (`SUCCESS`, `READY_FOR_REVIEW`, `PARTIAL`, `FAILED`, etc.) ;
12. produire et hasher le rapport officiel, le journal, l'état Campaign et l'Evidence Index ;
13. bloquer, reprendre ou poursuivre les branches selon les états et politiques existants ;
14. demander l'intervention humaine lorsque le contrat ou une exception l'exige ;
15. préserver l'identité et la traçabilité de chaque Mission Order et de chaque Gate.

CEREBRAU ne réalise pas à la place de Codex le raisonnement technique, la recherche dans le dépôt, l'édition des fichiers autorisés ou l'exécution interactive des commandes nécessaires à la mission.

### 3.2 Codex

Codex est l'exécuteur technique borné d'une Mission Order. Ses responsabilités sont :

1. lire le prompt et les faits fournis par l'enveloppe CEREBRAU ;
2. inspecter les sources et preuves accessibles dans le périmètre autorisé ;
3. analyser le problème et produire l'Impact Analysis nécessaire à l'objectif ;
4. proposer ou effectuer les modifications explicitement autorisées ;
5. exécuter les commandes de compilation, de vérification et de test disponibles et autorisées ;
6. corriger, dans la même tentative, les défauts techniques observables tant que l'objectif, le scope, les locks et les interdictions restent inchangés ;
7. créer les livrables et éléments d'evidence demandés par la Mission Order ;
8. restituer un résultat technique à l'enveloppe CEREBRAU.

Codex n'a aucune autorité pour :

- créer ou modifier une Doctrine, une Wave, une Campaign, une Mission Order, une Gate ou un registre officiel ;
- modifier un scope, une dépendance, un Resource Lock, une politique de revue ou un hash de baseline ;
- attribuer un owner, accepter un risque, accorder une dérogation ou prendre une décision métier ;
- déclarer une Gate `GO`, certifier un LOT ou certifier le PROGRAM ;
- transformer son transcript ou son appréciation en preuve autoritative ;
- lancer de sa propre initiative une autre Mission Order ou une autre Campaign.

### 3.3 Frontière sans recouvrement

| Objet ou acte | Gouvernance CEREBRAU | Exécution Codex | Autorité finale | Recouvrement |
|---|---|---|---|---|
| Program, Wave, Campaign | définit, ouvre, ordonne et ferme | lit le contexte utile | Program Director / autorités prévues | aucun |
| Mission Order | autorise l'objectif, le scope, les preuves et la revue | exécute le contrat reçu | CEREBRAU pour l'éligibilité ; humain si revue requise | aucun |
| DAG et mission suivante | calcule le ready set | ne choisit pas la mission suivante | Campaign Runner | aucun |
| Resource Locks/scopes | déclare, contrôle, acquiert et libère | respecte les limites reçues | Campaign Runner / contrat | aucun |
| Analyse | borne les sources et attendus | réalise l'analyse | Codex pour la production technique, jamais pour la décision | aucun |
| Impact Analysis | impose le périmètre et les interdictions | identifie les effets techniques | Codex, sous contrôle du scope | aucun |
| Modification | autorise les chemins et le mode | édite seulement les chemins autorisés | Codex exécute ; CEREBRAU contrôle le delta | aucun |
| Compilation/tests exploratoires | autorise l'exécution | lance et interprète les commandes | Codex pour le diagnostic | aucun |
| Validation officielle | exécute les validations déclarées après Codex | peut pré-vérifier, ne prononce pas le résultat officiel | `Invoke-CerebrauMission.ps1` / reporting | aucun |
| Evidence | vérifie identité, provenance, présence et hash | produit les livrables demandés | CEREBRAU qualifie l'intégrité ; l'autorité qualifie le sens | aucun |
| Official Report | génère, persiste et hashe | fournit le résultat technique ; transcript non autoritatif | runtime CEREBRAU | aucun |
| Gate / dérogation / risque | prépare la chaîne probatoire et conserve la décision | peut préparer un dossier, jamais décider | autorité humaine désignée | aucun |
| Certification | propage selon la Doctrine | aucune autorité | comité / Program Director | aucun |

La frontière est donc fonctionnelle : **CEREBRAU autorise, borne, ordonnance, contrôle, enregistre et escalade ; Codex analyse, modifie et vérifie techniquement dans l'autorisation reçue.**

## 4. Cycle Operating Model V2

```text
Program
  ↓ autorise et fixe les objectifs
Wave
  ↓ porte le périmètre officiel et les ouvertures
Campaign
  ↓ valide le Manifest, le DAG, les hashes, les prérequis et les locks
Mission Order
  ↓ fixe objectif, scope, livrables, validations et revue
Codex Runtime
  ↓ une invocation bornée par Invoke-CerebrauMission.ps1
Analyse
  ↓ compréhension des sources et écarts
Impact Analysis
  ↓ fichiers, contrats, risques techniques et tests affectés
Modification
  ↓ uniquement si le mode et les chemins l'autorisent
Compilation
  ↓ commandes existantes autorisées
Tests
  ↓ tests ciblés puis non-régression disponibles
Validation
  ↓ validations déclarées exécutées par le runtime CEREBRAU
Evidence
  ↓ livrables, résultats, snapshots, delta et hashes
Official Report
  ↓ rapport unitaire officiel + journal + référence/hash Campaign
SUCCESS
  ↓ seulement si classification officielle et revue applicable satisfaites
Mission suivante
  ↓ recalcul du ready set par le Campaign Runner
```

### 4.1 Déroulement précis

| Étape | Responsable | Entrée | Sortie ou contrôle | En cas d'écart |
|---|---|---|---|---|
| Program | gouvernance | objectifs et Doctrine | autorité PROGRAM | aucune exécution sans autorité |
| Wave | gouvernance | ouverture officielle | périmètre de Wave | blocage d'ouverture |
| Campaign | Campaign Runner | Campaign Manifest | preflight et ready set | arrêt ou branche bloquée selon l'écart |
| Mission Order | CEREBRAU | manifeste et prompt canoniques | contrat unitaire validé | aucun appel Codex |
| Codex Runtime | `Invoke-CerebrauMission.ps1` | contrat, profil, Certified Facts, prompt | tentative instrumentée | `FAILED` ou `CANCELLED` |
| Analyse | Codex | dépôt et preuves autorisées | diagnostic interne à la tentative | correction possible dans le même scope |
| Impact Analysis | Codex | diagnostic et dépendances | plan d'impact borné | escalade si autorité/scope manque |
| Modification | Codex | plan autorisé | fichiers du scope modifiés | delta hors scope → résultat non acceptable |
| Compilation | Codex | commandes existantes | résultat de build/typecheck disponible | correction ou échec technique |
| Tests | Codex | suites existantes | résultats de tests disponibles | correction ou échec technique |
| Validation | CEREBRAU runtime | delta et validations déclarées | PASS/FAIL officiel par validation | `PARTIAL`/`BLOCKED` selon le delta |
| Evidence | Codex + CEREBRAU, sans fusion d'autorité | livrables + faits runtime | fichiers, delta, hashes, journal | preuve absente/stale → blocage |
| Official Report | CEREBRAU Reporting | faits d'exécution et validations | JSON/Markdown officiels hashés | rapport de secours ou échec |
| SUCCESS | CEREBRAU | code 0, validations requises PASS, scope conforme, revue non requise ou approuvée | état terminal unitaire/Campaign | revue ou exception |
| Mission suivante | Campaign Runner | états persistés et dépendances | nouveau ready set | seules les branches éligibles continuent |

`SUCCESS` ne signifie pas automatiquement `GO`. Une Mission Order peut réussir techniquement tout en laissant la décision de Gate, la dérogation ou la certification à l'autorité humaine compétente.

## 5. Étapes intégrables dans une seule Mission Order

Le runtime observé n'instrumente pas séparément les phases internes de raisonnement de Codex. Il prouve une seule invocation `codex exec` par tentative, et non une série de prompts officiels par phase. Les regroupements ci-dessous identifient donc toutes les étapes fonctionnelles du cycle demandé qui peuvent être enchaînées dans cette invocation ; ils ne supposent pas l'existence de prompts officiels séparés que le dépôt ne démontre pas.

### 5.1 Règle d'intégration

Une séquence est intégrable si, et seulement si, toutes ses étapes :

- servent le même objectif et la même Gate de la Mission Order existante ;
- restent dans les mêmes `allowedPaths`, `forbiddenPaths` et Resource Scopes ;
- utilisent les mêmes prérequis, preuves, hashes, profil et mode d'exécution ;
- n'introduisent aucune décision métier, dérogation ou autorité nouvelle ;
- conservent tous les livrables et toutes les validations déclarés ;
- peuvent être attribuées au même snapshot avant/après et au même rapport officiel.

Si une de ces conditions échoue, Codex doit s'arrêter ou restituer l'exception. Il ne doit pas étendre la Mission Order.

### 5.2 Regroupements autorisés

| Étapes aujourd'hui distinguables | Exécution intégrée dans une Mission Order | Gain attendu | Risque | Impact sur la traçabilité |
|---|---|---|---|---|
| Lecture du contexte → analyse → Impact Analysis | une seule exploration du dépôt et des preuves avant action | moins de rechargements de contexte ; pourcentage `UNKNOWN` | omission d'un impact si le périmètre est trop large | positif si les sources et conclusions figurent dans le livrable ; transcript toujours non autoritatif |
| Impact Analysis → plan de modification → modification | passage direct du diagnostic à l'édition dans le même scope | suppression d'un handoff humain possible ; pourcentage `UNKNOWN` | modification prématurée si une décision d'autorité manque | neutre : même AttemptId, snapshot avant/après et delta ; arrêt obligatoire sur décision manquante |
| Modification → compilation/typecheck → correction locale | boucle technique interne à la même invocation Codex | moins de prompts intermédiaires potentiels ; pourcentage `UNKNOWN` | boucle longue ou correction dépassant l'objectif | positif : résultat final attribué à la tentative ; commandes exploratoires non autoritatives sauf validation déclarée |
| Modification → tests ciblés → correction → non-régression | boucle de vérification interne avant restitution | détection plus précoce des défauts ; pourcentage `UNKNOWN` | temps machine accru ou couverture incomplète | positif si les validations requises sont ensuite rejouées par le runtime officiel |
| Analyse de preuves → production du livrable evidence | analyse et rédaction sans dossier intermédiaire séparé | moins de duplication documentaire ; pourcentage `UNKNOWN` | confusion entre interprétation et fait | neutre si provenance, statut probatoire et hash restent explicites |
| Résultat Codex → snapshot après → delta → validations → Official Report | pipeline déjà intégré par `Invoke-CerebrauMission.ps1` | gain structurel déjà disponible, sans développement ; incrément `0 %` par rapport au runtime actuel | un résultat Codex techniquement réussi peut échouer aux validations | fortement positif : séparation entre transcript, validations et rapport officiel |
| `SUCCESS` → persistance → ready set → mission suivante | enchaînement déjà assuré par le Campaign Runner | suppression du prompt humain de passage ; temps gagné `UNKNOWN` | propagation si un état était mal qualifié | positif : événement terminal, état persisté, rapport hashé et nouveau ready set |

### 5.3 Étapes non intégrables

Ne peuvent pas être absorbés comme simples étapes Codex :

- l'ouverture ou la fermeture d'une Wave ;
- la création ou la modification d'une Campaign ou d'une Mission Order ;
- une décision d'autorité métier ;
- l'acceptation d'une dérogation ou d'un risque ;
- une décision de Gate ;
- une certification LOT ou PROGRAM ;
- l'approbation d'une Mission Order dont le contrat exige une revue, notamment `MM-L01-03` ;
- l'obtention d'un prérequis externe ;
- toute action située hors scope, hors lock ou hors mode d'exécution.

## 6. Matrice Mission Type → capacités Codex

Les pourcentages par type sont `UNKNOWN` faute de chronométrage apparié par type. Les niveaux d'accélération ci-dessous décrivent seulement le mécanisme effectivement disponible.

| Mission Type | Codex Capabilities | Expected Acceleration | Human Review Required | Execution Mode |
|---|---|---|---|---|
| Collecte / observation de preuves | recherche, lecture, extraction, comparaison, préparation d'un livrable | mécanisme disponible ; `% = UNKNOWN` | selon le contrat ; oui si la preuve porte une décision | `READ_ONLY_EVIDENCE` ou `DOCUMENTARY_WRITE` |
| Réconciliation repository/runtime | comparaison de sources, qualification d'écarts, hashes et rédaction | mécanisme disponible ; `% = UNKNOWN` | oui pour toute disposition ou divergence approuvée | `READ_ONLY_EVIDENCE` / `DOCUMENTARY_WRITE` |
| Correction documentaire | analyse, Impact Analysis, édition bornée, contrôles de format | mécanisme disponible ; `% = UNKNOWN` | valeur du champ existant `humanReviewRequired` | `DOCUMENTARY_WRITE` |
| Correction de code ou contrat technique | analyse, édition, compilation, tests et correction locale | mécanisme disponible ; `% = UNKNOWN` | oui si critique, irréversible ou exigé par le contrat | `RUNTIME_MUTATION` |
| Sécurité / RLS / grants / identité | analyse et exécution des tests autorisés, production de résultats | préparation accélérable ; décision non automatisable ; `% = UNKNOWN` | **oui** pour règle, rôle, risque ou dérogation | `RUNTIME_MUTATION` ou `READ_ONLY_EVIDENCE` selon le contrat |
| Idempotence / concurrence / rollback / outbox | exécution de suites existantes, analyse des résultats, correction autorisée | mécanisme disponible ; `% = UNKNOWN` | selon criticité et contrat ; décision de risque humaine | `RUNTIME_MUTATION` |
| UI / API / E2E / fraîcheur | inspection multi-couches, modification bornée, tests existants | mécanisme disponible ; `% = UNKNOWN` | selon le contrat et le résultat | `RUNTIME_MUTATION` |
| Qualification d'autorité ou de legacy | inventaire, scénarios et dossier de décision | accélération de préparation seulement ; `% = UNKNOWN` | **oui** | `READ_ONLY_EVIDENCE` / `DOCUMENTARY_WRITE` |
| Consolidation technique | lecture des rapports et hashes, calcul, matrice et dossier | mécanisme disponible ; `% = UNKNOWN` | oui si l'acte emporte décision de Gate/LOT | `DOCUMENTARY_WRITE` |
| Certification finale | assemblage et contrôle de complétude du dossier | préparation seulement ; `% = UNKNOWN` | **oui — obligatoire** | `READ_ONLY_EVIDENCE` / `DOCUMENTARY_WRITE` |

La présence d'une capacité Codex ne rend pas automatiquement une Mission Order exécutable. Le manifeste unitaire, le prompt, les prérequis, les preuves, les validations et l'autorité doivent déjà exister et être valides.

## 7. Évaluation des 36 Mission Orders restantes

### 7.1 Population et hypothèses interdites

- Population officielle conservée : `36 → 36` Mission Orders, réduction `0 %`.
- Une Mission Order entraîne une invocation Codex par tentative dans le runtime actuel.
- La Campaign reste séquentielle (`maxConcurrency = 1`) ; aucun gain de parallélisme n'est compté.
- Aucun temps d'attente externe n'est attribué à Codex.
- Aucune réduction n'est imputée à la suppression d'une Gate, d'une revue obligatoire, d'une preuve ou d'un rapport officiel.
- Les statistiques observées sur des missions non équivalentes ne sont pas extrapolées aux 36 missions.

### 7.2 Réduction du temps d'exécution

`UNKNOWN`.

Le runtime mesure `DurationMs`, mais aucune paire ne compare la même Mission Order exécutée en étapes séparées puis intégrées. Le benchmark apparié disponible mesure uniquement l'effet de la présence des Certified Facts sur une mission : avec `n = 1`, il observe une durée supérieure de `43,28 %`, des écritures hors scope et une sortie différente ; le rapport conclut que l'impact causal n'est pas prouvé. Le benchmark observationnel favorable compare des missions différentes et refuse lui aussi toute attribution causale.

Ces données démontrent la capacité de mesure, pas un pourcentage d'accélération Codex généralisable.

### 7.3 Réduction des itérations

`UNKNOWN`.

Le Campaign Runner sait compter les tentatives, revues, reprises et abandons. Les 36 missions restantes n'ont toutefois pas une baseline complète d'itérations par mission et ne disposent pas toutes d'un manifeste exécutable. Une boucle analyse–modification–test peut rester dans une seule invocation, mais son effet sur le nombre de tentatives officielles n'est pas démontré.

### 7.4 Réduction des prompts

Deux mesures doivent être séparées :

| Mesure | Baseline | Cible V2 | Réduction |
|---|---:|---:|---:|
| Prompts officiels transmis par `Invoke-CerebrauMission.ps1`, une tentative réussie par Mission Order | 36 | 36 | `0 %` |
| Prompts humains intermédiaires entre analyse, impact, modification, compilation et tests | `UNKNOWN` | au plus un lancement par tentative, puis exécution intégrée | `UNKNOWN` |

Le modèle ne peut annoncer une réduction des prompts officiels : l'enveloppe actuelle est déjà à une invocation Codex par Mission Order. Le gain recherché concerne les handoffs interactifs à l'intérieur d'une mission, dont le nombre historique n'est pas publié.

### 7.5 Réduction des reprises

`UNKNOWN`.

La politique existante `REUSE_TERMINAL_ATTEMPTS` évite de rejouer les succès lors d'une reprise de Campaign, et les fingerprints détectent le drift. C'est une capacité réelle. Le nombre de reprises qui auraient eu lieu sans cette capacité et la distribution des échecs sur les 36 missions sont inconnus ; aucun taux ne peut être calculé.

### 7.6 Réduction des analyses redondantes

`UNKNOWN`.

Le partage de preuves par SHA-256 évite de recollecter ou recopier une preuve identique au niveau Campaign. Il ne prouve pas que Codex évite de relire ou réanalyser son contenu. Les Certified Facts sont ajoutés au prompt, sans suppression automatique de sections. La quantité d'analyse sémantique évitée n'est donc ni instrumentée ni démontrée.

### 7.7 Synthèse quantitative

| Indicateur pour 36 Mission Orders | Baseline démontrée | Cible démontrable | Réduction attendue |
|---|---:|---:|---:|
| Mission Orders officielles | 36 | 36 | `0 %` |
| Invocations/prompts officiels, sous hypothèse d'une tentative réussie par mission | 36 | 36 | `0 %` |
| Temps technique cumulé | `UNKNOWN` | `UNKNOWN` | `UNKNOWN` |
| Itérations/tentatives | `UNKNOWN` | `UNKNOWN` | `UNKNOWN` |
| Prompts humains intermédiaires | `UNKNOWN` | `UNKNOWN` | `UNKNOWN` |
| Reprises évitées | `UNKNOWN` | `UNKNOWN` | `UNKNOWN` |
| Analyses sémantiques redondantes évitées | `UNKNOWN` | `UNKNOWN` | `UNKNOWN` |
| Accélération de livraison EBE, hors délais externes | 30 jours ouvrés | 20 jours ouvrés | `33 %` |

Le `33 %` est l'estimation centrale déjà justifiée par le modèle EBE pour la réduction des files d'attente, revues et passages entre missions. Il s'agit de l'accélération totale conservée par Operating Model V2, et non d'un gain technique additionnel attribuable causalement à Codex. Le gain Codex incrémental reste `UNKNOWN`.

## 8. Operating Model V2 cible

### 8.1 Formule

```text
Execution By Exception
  +
Codex Runtime existant, borné par chaque Mission Order
  =
Operating Model V2
```

### 8.2 Règles opératoires

1. Le Program Director autorise la Wave et les Campaigns selon les actes existants.
2. Le Campaign Manifest reste la liste fermée des Mission Orders exécutables.
3. Le Campaign Runner contrôle autorité, hashes, dépendances, prérequis, preuves, modes, scopes et revues.
4. Chaque Mission Order est exécutée par un appel à `Invoke-CerebrauMission.ps1`.
5. Codex traite dans la même invocation toutes les étapes techniques compatibles avec le contrat unitaire.
6. Codex s'arrête dès qu'une décision d'autorité, un nouveau scope, une dérogation ou un prérequis absent est nécessaire.
7. Le runtime calcule indépendamment le delta, exécute les validations et produit l'Official Report.
8. Le Campaign Runner persiste le résultat, référence les rapports/hashes et recalcule le ready set.
9. Une mission `SUCCESS` sans revue requise permet l'enchaînement automatique ; une revue requise reste bloquante conformément au contrat.
10. Les exceptions locales bloquent la branche concernée ; les branches indépendantes suivent la politique Campaign existante.
11. Les décisions de Gate, LOT et PROGRAM restent explicites et humaines lorsque la Doctrine l'exige.
12. Aucun Work Package n'entre dans le modèle de gouvernance ou d'exécution.

### 8.3 Invariants non modifiés

| Invariant | État dans Operating Model V2 |
|---|---|
| Doctrine | inchangée |
| Gates | identités, critères, décisions et propagation inchangés |
| Mission Orders | identités, contrats, scopes et revues inchangés |
| Certification | autorité et processus inchangés |
| Objets officiels | `Program`, `Wave`, `Campaign`, `Mission Order`, `Gate`, `LOT` inchangés |
| Campaign Runner | réutilisé tel quel |
| Runtime unitaire | `Invoke-CerebrauMission.ps1` réutilisé tel quel |
| Codex | runtime existant réutilisé tel quel |
| Resource Locks/scopes | réutilisés tels quels |
| Campaign Manifest | réutilisé tel quel |
| Hashes et preuves | conservés, jamais remplacés par le transcript |
| Rapports officiels | conservés et hashés |

### 8.4 Conditions de recommandation

Operating Model V2 est recommandé comme règle d'exploitation, sans développement, sous les conditions suivantes :

- aucune Mission Order n'est élargie ou fusionnée ;
- aucune accélération n'est obtenue en supprimant une validation ou une revue obligatoire ;
- les étapes techniques intégrées restent dans un objectif, un scope et un jeu de locks uniques ;
- toute commande de compilation ou test nécessaire au verdict officiel est couverte par une validation déclarée existante ;
- les prérequis externes et décisions humaines restent hors du calcul d'accélération Codex ;
- les métriques Campaign existantes sont utilisées pour établir ultérieurement une baseline appariée, sans modifier le runtime ;
- les pourcentages `UNKNOWN` ne sont remplacés qu'après comparaison de missions équivalentes avec mêmes entrées, mêmes critères, mêmes profils et mêmes sorties attendues.

## 9. Conclusion

Codex est compatible avec Execution By Exception parce qu'il intervient exclusivement comme exécuteur technique sous un contrat CEREBRAU déjà autorisé. L'intégration réduit les handoffs possibles à l'intérieur d'une Mission Order et permet une boucle continue d'analyse, modification et vérification, tandis que CEREBRAU conserve intégralement le contrôle de l'éligibilité, du scope, des validations, de la preuve, du rapport et de l'escalade.

La capacité est disponible sans nouveau logiciel. Son bénéfice opérationnel est réel dans la continuité d'exécution, mais son gain technique chiffré sur les 36 Mission Orders n'est pas démontré par les mesures présentes. Le seul pourcentage de livraison réutilisable est l'estimation EBE existante de `33 %`, sans sur-attribution à Codex.

CODEX CAN BE USED AS EXECUTION ACCELERATOR = YES

NEW SOFTWARE REQUIRED = NO

MISSION MODEL CHANGES REQUIRED = NO

GOVERNANCE MODEL CHANGES REQUIRED = NO

EXPECTED EXECUTION TIME REDUCTION = UNKNOWN %

EXPECTED ITERATION REDUCTION = UNKNOWN %

EXPECTED DELIVERY ACCELERATION = 33 %

OPERATING MODEL V2 RECOMMENDED = YES
