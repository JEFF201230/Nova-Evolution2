# PROGRAM GATE CERTIFICATION CARDS

---

## Gate

`{{NOM_DE_LA_GATE}}`

---

## Objectif

{{OBJECTIF_EN_UNE_PHRASE}}

---

## Preuves requises

- {{PREUVE_REQUISE_1}}
- {{PREUVE_REQUISE_2}}
- {{PREUVE_REQUISE_3}}
- {{PREUVE_REQUISE_4}}
- {{PREUVE_REQUISE_5}}

---

## Preuves disponibles

✓ {{REFERENCE_PREUVE_1}}

✓ {{REFERENCE_PREUVE_2}}

✓ {{REFERENCE_PREUVE_3}}

✓ {{REFERENCE_PREUVE_4}}

✓ {{REFERENCE_PREUVE_5}}

---

## Doctrine

`PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md`

---

## Décision

`{{DECISION}}`

---

## Justification

{{FAIT_1}}

{{FAIT_2}}

{{FAIT_3}}

{{FAIT_4}}

{{FAIT_5}}

