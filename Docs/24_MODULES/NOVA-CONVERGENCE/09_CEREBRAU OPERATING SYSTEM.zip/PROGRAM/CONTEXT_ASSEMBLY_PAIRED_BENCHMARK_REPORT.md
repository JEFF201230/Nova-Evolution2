# Context Assembly — rapport de benchmark apparié réel

## 1. Statut et conclusion exécutive

Le benchmark réel a été exécuté le 22 juillet 2026 sur la séquence obligatoire `A1 B1 | B2 A2 | A3 B3`. Les six runs ont lancé le vrai exécutable Codex. Aucun fake Codex, smoke test ou résultat simulé n'a été substitué à un run.

Le mode B présente un temps total externe moyen inférieur de `32 142,666 ms` (`10,900 %`) au mode A. Ce résultat brut n'établit toutefois pas un effet causal : la troisième paire n'est pas fonctionnellement équivalente (`A3 = BLOCKED`, aucun livrable ; `B3 = READY_FOR_REVIEW`, livrable produit), et l'écart-type des différences appariées de durée totale est `227 820,816 ms`, très supérieur au gain moyen.

**CAUSAL IMPACT PROVEN = NO.**

## 2. Protocole réellement exécuté

Source du protocole : `Docs/PROGRAM/CONTEXT_ASSEMBLY_PAIRED_BENCHMARK_PROTOCOL.md`.

Préflight exécuté avant S0 :

| Contrôle | Résultat |
|---|---:|
| `Test-CerebrauSyntax.ps1` | PASS |
| `Test-CerebrauMission.ps1` | PASS |
| `Test-CerebrauReporting.ps1` | PASS |
| `Test-CerebrauExceptionCapture.ps1` | PASS |
| `Test-CerebrauRuntimeE2E.ps1` | PASS |
| `Test-CerebrauCampaign.ps1` | PASS |
| `Test-CerebrauContextAssembly.ps1` | PASS |
| `Test-CerebrauContextRuntime.ps1` | PASS |
| Campaign `Validate` | `VALID`, ExitCode `0` |
| `codex --version` | `codex-cli 0.144.6` |

Commandes réellement utilisées :

```powershell
# A — historique
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauCampaign.ps1 -CampaignFile tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json -Action Start

# B — seule différence CLI
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauCampaign.ps1 -CampaignFile tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json -Action Start -ContextAssemblyEnabled
```

Avant chaque run, les 2 237 fichiers suivis ou non suivis de S0 ont été contrôlés par chemin, taille et SHA-256. Branche, HEAD et sortie `git status --porcelain=v1 -uall` ont aussi été comparés à S0. Après capture des rapports, le delta du run et les deux répertoires de rapports générés ont été retirés, les fichiers S0 modifiés ont été restaurés depuis leur sauvegarde byte-for-byte, puis les mêmes contrôles ont été rejoués. Les six contrôles post-run ont réussi.

Les rapports Campaign et Mission ignorés qui existaient avant le benchmark ont été déplacés hors du dépôt avant S0, puis restaurés à l'identique à la fin : 5 fichiers / 32 721 octets pour la Campaign et 7 fichiers / 1 981 632 octets pour la Mission.

## 3. Mission choisie

Mission : `MM-L01-03`, « Première ligne conforme du registre de Gate ».

Justification : c'est la Mission unique du Campaign Manifest officiel `VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001`, elle est compatible avec les deux modes, ses quatre baselines correspondent aux hashes déclarés, son périmètre d'écriture est borné à deux chemins documentaires et cet état est restaurable. Aucune Mission artificielle n'a été créée.

La divergence de `A3` ne rend pas le lancement techniquement artificiel : elle résulte de l'interprétation non déterministe, par le même modèle, du contrôle d'entrée n°4 relatif à l'ordre distinct de Campaign. Cette divergence est conservée comme résultat réel.

## 4. État Git de référence S0

| Propriété | Valeur |
|---|---|
| Repository | `C:\DEV\veedda-cseV7-core` |
| Branche | `fix/simulation-star` |
| HEAD | `706bf1fae540e1798e3b827fbb162cac20b3b019` |
| Worktree | dirty intentionnel, capturé et restaurable |
| Fichiers suivis/non suivis hashés | 2 237 |
| Manifest S0 externe SHA-256 | `585860DFDB4657FD24CBFB473852FB911040A6AD17C9A93513C0DFDC46FC7646` |
| Rapports Campaign au S0 | absents |
| Rapports unitaires MM-L01-03 au S0 | absents |
| Livrable MM-L01-03 au S0 | absent |
| Rapport de benchmark au S0 | absent |

État porcelain de référence, forme compacte :

```text
 M "Docs/09_CEREBRAU OPERATING SYSTEM/00_GOVERNANCE/PROGRAM_WAVE_ORCHESTRATION.md"
 M client/src/App.tsx
 M server/robot/at/atActionRunner.ts
 M server/robot/at/atTransitionResult.ts
 M server/robot/at/emailHub.safe.ts
 M server/robot/at/robotATLogRepository.pg.ts
 M tools/cerebrau/Cerebrau.Reporting.psm1
 M tools/cerebrau/Invoke-CerebrauMission.ps1
 M tools/cerebrau/Resolve-CerebrauProfile.ps1
 M tools/cerebrau/mission.json
 M tools/cerebrau/prompt.md
?? "Docs/09_CEREBRAU OPERATING SYSTEM/03_CODEX_EXECUTION_MVP/CAMPAIGN_RUNNER_MVP.md"
?? "Docs/09_CEREBRAU OPERATING SYSTEM/03_CODEX_EXECUTION_MVP/CAMPAIGN_RUNNER_MVP_ONE_SHOT_REPORT.md"
?? Docs/PROGRAM/
?? Docs/PROGRAMS/
?? Docs/REPORTS/
?? LOT-003_LEDGER_GOVERNANCE_DECISION.md
?? MM_FIX_001_REPORT.md
?? MM_FIX_002_REPORT.md
?? MM_FOUNDATION_CAMPAIGN.json
?? MM_FOUNDATION_REPORT.md
?? SUPABASE_FORENSIC_AUDIT_REPORT.md
?? mission-result.txt
?? tools/cerebrau/Cerebrau.Campaign.psm1
?? tools/cerebrau/Cerebrau.ContextAssembly.psm1
?? tools/cerebrau/Invoke-CerebrauCampaign.ps1
?? tools/cerebrau/Invoke-GovernanceInheritanceDemonstration.ps1
?? tools/cerebrau/Invoke-OperatingSystemGovernanceReconstruction.ps1
?? "tools/cerebrau/Nouveau Document texte (2).txt"
?? "tools/cerebrau/Nouveau Document texte.txt"
?? tools/cerebrau/Stop-CerebrauCampaign.ps1
?? tools/cerebrau/Test-CerebrauCampaign.ps1
?? tools/cerebrau/Test-CerebrauCampaignE2E.ps1
?? tools/cerebrau/Test-CerebrauCampaignManifest.ps1
?? tools/cerebrau/Test-CerebrauContextAssembly.ps1
?? tools/cerebrau/Test-CerebrauContextRuntime.ps1
?? tools/cerebrau/Test-OwnerRoleSourceOfTruth.ps1
?? tools/cerebrau/campaign-manifest.schema.json
?? tools/cerebrau/campaign-report.schema.json
?? tools/cerebrau/campaign-state.schema.json
?? tools/cerebrau/campaigns/
?? tools/cerebrau/certified-facts.json
?? tools/cerebrau/missions/
?? tools/cerebrau/tests/
```

Identité d'exécution identique sur les six runs :

| Paramètre | Valeur |
|---|---|
| Profil | `ARCHITECTURE` |
| Modèle | `gpt-5.6-sol` |
| Reasoning effort | `high` |
| Sandbox | `workspace-write` |
| Approval policy | `on-request` |
| Codex | `0.144.6` |
| Campaign fingerprint | `4B9BE442CA2B48EFD1F83DEA49D6D575580EC1EB814152A11A0CB57963AF4E3A` |

Hashes critiques S0 :

| Entrée | SHA-256 |
|---|---|
| Campaign Manifest | `062C7283770CF5047DD072D1A0AB8592AB09D4AEC5B09F3826B40A6454200277` |
| Mission Order MM-L01-03 | `77A8F1A56AA122390EC9480F22D2A287AA0ED5D2E4B6E9A4B04548F95A57FE9B` |
| Prompt source MM-L01-03 | `056936B6B1EB2E0FB4F5EEB6CC90D0BA90CF28BC65632E923D2CA1066E5C4E28` |
| `profiles.json` | `E88FF2362C5D61509AF153925473292E92C65245F8B5DD1D88862231DD24EC29` |
| `certified-facts.json` | `8D866C286C5D6911D386B489BEE02AB50C442B13AE66C58EE07AC7BF01934909` |
| Runtime Mission | `1707D60706F630CCEC3B464DE3A7687029CA7A73C3E9ED1D887D1D2CD9784FF3` |
| Runner Campaign | `A6ABB87C8B1DC21E059009BEB4CBF35B57756497D6DD5C8BE79909A9322AD060` |
| Module Campaign | `3EB017DB77183A324B2D8B2F6AE6BF400D33CCC18F834AE024F710A366DAAFED` |
| Module Context Assembly | `DAB748AEEB9D6A62C8E628579B170B6F20E1987CAE87C0FD9CDCE5178286A995` |
| Master Gates Matrix | `17B6F604BF246DD6486292C88C72B05E8389D4B67DF78C8CBB1825E9E67B4141` |
| Certification report | `1D6CE752F08F0237EEE6FB0C91D1EEDC20A42463715B6D0BE47718508F358AD9` |
| L01-G04 registration report | `B89A23667F6E7FBF70DE2D14719EF6CCA70E4600D5699DD6FFD8264025360A22` |
| Master Gates Register | `D19A4FDC635AB59BCF2FC8D7E702DAF316EFA23BD600690F71670EA21FD7D367` |

Les deux hashes de shared evidence sont restés identiques sur les six runs. Le hash global de l'evidence index varie, car il contient `observedAt`; cette différence a été normalisée. Les entrées fonctionnelles et leurs hashes restent identiques.

## 5. Identité des six runs

| Ordre | Run | Mode | Campaign Run ID | Unit Run ID | Début externe | Fin externe |
|---:|---|---|---|---|---|---|
| 1 | A1 | historique | `RUN-DC19070098BB4776B822F86633F945A1` | `bootstrap-20260722T120823845` | `2026-07-22T12:08:22.7329335+02:00` | `2026-07-22T12:13:34.5258229+02:00` |
| 2 | B1 | Context Assembly | `RUN-B6606E704C93405481CD2E703B1C83D0` | `bootstrap-20260722T121441928` | `2026-07-22T12:14:40.6739182+02:00` | `2026-07-22T12:18:56.1258671+02:00` |
| 3 | B2 | Context Assembly | `RUN-26DF16013CF74EA79797E9572C23E1D8` | `bootstrap-20260722T122014649` | `2026-07-22T12:20:13.4812022+02:00` | `2026-07-22T12:23:59.5618751+02:00` |
| 4 | A2 | historique | `RUN-8D3C371A5D864D5BAF5A8BB2FC8F8ED3` | `bootstrap-20260722T122448454` | `2026-07-22T12:24:47.2613390+02:00` | `2026-07-22T12:32:40.2392344+02:00` |
| 5 | A3 | historique | `RUN-DDF0413777874404BC448725F854A9B8` | `bootstrap-20260722T123337498` | `2026-07-22T12:33:36.4310560+02:00` | `2026-07-22T12:35:16.3013445+02:00` |
| 6 | B3 | Context Assembly | `RUN-8C726AFBD5A64FD5AA110554E613DE93` | `bootstrap-20260722T123614715` | `2026-07-22T12:36:13.6370825+02:00` | `2026-07-22T12:41:20.3180100+02:00` |

MissionId est `MM-L01-03` pour les six runs. Chaque run possède aussi un Attempt ID distinct, conservé dans son état Campaign et son bundle de rollback.

## 6. Métriques brutes

Définitions :

- `DurationMs` : `OfficialReport.Codex.DurationMs`, fenêtre historique inchangée ;
- `Codex stage` : différence entre les événements `CODEX_EXECUTION_STARTED` et `CODEX_EXECUTION_FINISHED` ;
- `Total externe` : chronométrage commun autour du processus Campaign complet ;
- `Context total` et `Context Codex` : champs propres aux métriques B, non substitués aux fenêtres communes.

| Run | Enabled | DurationMs | Codex stage ms | Total externe ms | Context assembly ms | Context Codex ms | Context total ms |
|---|---:|---:|---:|---:|---:|---:|---:|
| A1 | false | 305 205 | 298 946 | 311 787 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| B1 | true | 249 671 | 242 893 | 255 447 | 83 | 242 887 | 253 292 |
| B2 | true | 220 335 | 213 755 | 226 075 | 111 | 213 749 | 223 817 |
| A2 | false | 466 830 | 460 999 | 472 974 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| A3 | false | 93 434 | 87 438 | 99 865 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| B3 | true | 299 659 | 293 140 | 306 676 | 102 | 293 134 | 303 814 |

Métriques de sélection Context Assembly :

| Run | Sources | Source bytes | Payload bytes | Duplicates | Rejected | Functional payload SHA-256 |
|---|---:|---:|---:|---:|---:|---|
| A1 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| B1 | 11 | 108 846 | 13 232 | 8 | 0 | `0D299761739C25C99A0729B1BE670BD7B192EB2C8174CA3462F7C4FB0EE8313D` |
| B2 | 11 | 108 846 | 13 232 | 8 | 0 | `0D299761739C25C99A0729B1BE670BD7B192EB2C8174CA3462F7C4FB0EE8313D` |
| A2 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| A3 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE |
| B3 | 11 | 108 846 | 13 232 | 8 | 0 | `0D299761739C25C99A0729B1BE670BD7B192EB2C8174CA3462F7C4FB0EE8313D` |

Tokens officiels :

| Run | Input | Output | Total | Compteur agrégé affiché par la CLI `tokens used` |
|---|---|---|---|---:|
| A1 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | 85 696 |
| B1 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | 88 144 |
| B2 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | 73 781 |
| A2 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | 120 447 |
| A3 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | 45 675 |
| B3 | UNAVAILABLE | UNAVAILABLE | UNAVAILABLE | 88 450 |

Les rapports et `context-assembly-metrics.json` déclarent explicitement `TokensInput`, `TokensOutput` et `TokensTotal` à `UNAVAILABLE`. Le compteur agrégé directement affiché par la CLI est conservé comme observation brute séparée ; il n'est pas renommé ou estimé en tokens input/output/total.

## 7. Verdicts, livrables, diagnostics et Git delta

| Run | Verdict Mission | Codex | Campaign | Validations | Erreurs | Warnings | Créé / modifié | + / - lignes |
|---|---|---|---|---:|---:|---:|---|---:|
| A1 | `READY_FOR_REVIEW` | `SUCCESS/0` | `FAILED/4` | 7/7 | 0 | 0 | 1 / 1 | 89 / 1 |
| B1 | `READY_FOR_REVIEW` | `SUCCESS/0` | `FAILED/4` | 7/7 | 0 | 0 | 1 / 1 | 79 / 1 |
| B2 | `READY_FOR_REVIEW` | `SUCCESS/0` | `FAILED/4` | 7/7 | 0 | 0 | 1 / 1 | 92 / 1 |
| A2 | `READY_FOR_REVIEW` | `SUCCESS/0` | `FAILED/4` | 7/7 | 0 | 0 | 1 / 1 | 76 / 1 |
| A3 | `BLOCKED` | `SUCCESS/0` | `FAILED/4` | 2/5 | 3 | 0 | 0 / 0 | 0 / 0 |
| B3 | `READY_FOR_REVIEW` | `SUCCESS/0` | `FAILED/4` | 7/7 | 0 | 0 | 1 / 1 | 101 / 1 |

Pour les cinq runs réussis, les fichiers sont toujours :

- créé : `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/EVIDENCE/MM-L01-03/MM_L01_03_GATE_REGISTRATION_EVIDENCE.md` ;
- modifié : `Docs/PROGRAM/PROGRAM_MASTER_GATES_REGISTER.md` ;
- supprimé : aucun ;
- renommé : aucun ;
- branche ou HEAD modifié : non.

Les décisions fonctionnelles des cinq runs réussis sont identiques : Gate `L01-G06`, owner de rôle `Program Director`, décision `NO_GO` conservée, preuves et horodatage ajoutés, revue humaine `REQUIRED/PENDING`, autres Gates et décisions inchangées. Les validations UTF-8, périmètre, unicité et fichiers attendus passent.

`A3` prend une autre décision d'exécution : l'ordre distinct de Campaign est jugé non démontré par les sources exclusives. Il n'acquiert aucun lock, ne modifie pas le registre, ne crée pas le livrable, échoue les validations d'existence/UTF-8/fichier attendu et termine `BLOCKED`.

Le statut Campaign `FAILED/4` est commun aux six runs, y compris quand la Mission est `READY_FOR_REVIEW`. Il est conservé comme sortie brute du Runner et n'est pas normalisé en succès. Il n'est pas spécifique au switch.

Hashes après écriture :

| Run | Livrable SHA-256 | Registre SHA-256 |
|---|---|---|
| A1 | `303383C32492F622700B3836D49338596392F25C8693FE6158FF9E346689CCE4` | `A9C51A41548237903DC03316A9185AEF8595969DFA9461505B91547BD87C4BF5` |
| B1 | `842743B5493A0A31BDF9141B4714AE94FE28FEBBE0E098A17058C0DFEE77B3AF` | `140DFB1D4025278AFEFE8F6628DB2371F291BD68AFFFD2EBAF2363540D4BD5DE` |
| B2 | `97BDFE6E73A83B25D84582188ABBA5C62ACAA3311B103051EDBCCC0822686B04` | `82F5515C77091123F6256F3264D5A02F959224DC2F12DB3038DF9E17FB184C89` |
| A2 | `95C5852080A5067AF37DA3FEE8E600585B629ADC23B8BF7C90296A7F38178FC1` | `CC227D702D605E6BDB1927032516DBB55E896975025E9717999CBE32EA7E48E5` |
| A3 | UNAVAILABLE | registre inchangé : `D19A4F...7D367` |
| B3 | `ED91F817E9FD549FD178740C773FCCE7F83F431CD45746E438AAAC6831E24CD4` | `F18985F5AFB3867CBD0E6836057B03041634EE019440D2592AA2C320721EE866` |

Les hashes bruts des cinq sorties réussies diffèrent : les documents contiennent des horodatages et des formulations générées variables. Après normalisation des timestamps et de la variation rédactionnelle, leur signature fonctionnelle est identique. Cette normalisation ne peut pas rendre `A3` équivalent, car le livrable et le delta sont absents.

## 8. Métriques normalisées et équivalence fonctionnelle

Éléments exclus de l'identité fonctionnelle : timestamps, Run ID, Attempt ID, chemins des répertoires temporaires ou de rapports, durées, champs `observedAt`, hashes globaux d'artefacts contenant ces champs.

Éléments conservés : statut officiel, ExitCode Codex, décisions, validations, présence des livrables, chemins créés/modifiés/supprimés, faits métier du contenu, erreurs, warnings, branche/HEAD et régressions.

| Paire | A | B | Verdicts | Livrables/delta | Signature métier | Équivalente |
|---:|---|---|---|---|---|---:|
| 1 | A1 | B1 | identiques | identiques | identique après normalisation | YES |
| 2 | A2 | B2 | identiques | identiques | identique après normalisation | YES |
| 3 | A3 | B3 | `BLOCKED` / `READY_FOR_REVIEW` | absent / présent | divergente | **NO** |

Les trois runs B ont le même `FunctionalPayloadSha256`, les mêmes 11 sources et les mêmes hashes de sources. Les diagnostics de sélection sont identiques : 8 doublons retirés et 0 source rejetée. `RegressionsDetected` est vide dans les trois métriques B.

**FUNCTIONAL EQUIVALENCE = NO**, car une seule paire divergente suffit à invalider l'équivalence globale.

## 9. Calculs A/B

Écart-type : écart-type échantillon (`n - 1`). Gain absolu : `moyenne(A) - moyenne(B)`. Gain relatif : `gain absolu / moyenne(A) × 100`.

### 9.1 Fenêtres de performance communes

| Mesure | Mode | Moyenne | Médiane | Min | Max | Écart-type |
|---|---|---:|---:|---:|---:|---:|
| Official `DurationMs` | A | 288 489,667 | 305 205 | 93 434 | 466 830 | 187 258,364 |
| Official `DurationMs` | B | 256 555,000 | 249 671 | 220 335 | 299 659 | 40 107,560 |
| Codex stage journal | A | 282 461,000 | 298 946 | 87 438 | 460 999 | 187 325,310 |
| Codex stage journal | B | 249 929,333 | 242 893 | 213 755 | 293 140 | 40 157,528 |
| Total externe | A | 294 875,333 | 311 787 | 99 865 | 472 974 | 187 128,525 |
| Total externe | B | 262 732,667 | 255 447 | 226 075 | 306 676 | 40 791,433 |

| Mesure | Gain absolu moyen A-B | Gain relatif moyen |
|---|---:|---:|
| Official `DurationMs` | 31 934,667 ms | 11,070 % |
| Codex stage journal | 32 531,667 ms | 11,517 % |
| Total externe | 32 142,666 ms | 10,900 % |

### 9.2 Différences appariées

| Paire | Official A-B | Journal A-B | Total externe A-B | Équivalence |
|---:|---:|---:|---:|---:|
| 1 : A1/B1 | 55 534 ms | 56 053 ms | 56 340 ms | YES |
| 2 : A2/B2 | 246 495 ms | 247 244 ms | 246 899 ms | YES |
| 3 : A3/B3 | -206 225 ms | -205 702 ms | -206 811 ms | NO |

| Dispersion des différences | Moyenne | Médiane | Min | Max | Écart-type |
|---|---:|---:|---:|---:|---:|
| Official A-B | 31 934,667 | 55 534 | -206 225 | 246 495 | 227 280,765 |
| Journal A-B | 32 531,667 | 56 053 | -205 702 | 247 244 | 227 387,246 |
| Total externe A-B | 32 142,667 | 56 340 | -206 811 | 246 899 | 227 820,816 |

Le gain moyen ne dépasse pas raisonnablement la dispersion. Le run A3, plus court parce qu'il s'arrête sans écrire, rend aussi sa durée non comparable à B3.

### 9.3 Métriques propres à B

Ces mesures quantifient le coût et la stabilité de la brique. Elles n'ont pas d'équivalent A et aucun gain A-B n'est calculé.

| Mesure B | Moyenne | Médiane | Min | Max | Écart-type |
|---|---:|---:|---:|---:|---:|
| ContextAssemblyDurationMs | 98,667 | 102 | 83 | 111 | 14,295 |
| ContextSourceCount | 11 | 11 | 11 | 11 | 0 |
| ContextSourceBytes | 108 846 | 108 846 | 108 846 | 108 846 | 0 |
| ContextPayloadBytes | 13 232 | 13 232 | 13 232 | 13 232 | 0 |
| ContextDuplicateCount | 8 | 8 | 8 | 8 | 0 |
| ContextRejectedSourceCount | 0 | 0 | 0 | 0 | 0 |
| Context Codex duration | 249 923,333 | 242 887 | 213 749 | 293 134 | 40 157,528 |
| Context total duration | 260 307,667 | 253 292 | 223 817 | 303 814 | 40 457,319 |

### 9.4 Compteur CLI agrégé et métriques secondaires

Le compteur CLI `tokens used` donne A = moyenne `83 939,333`, médiane `85 696`, min `45 675`, max `120 447`, écart-type `37 416,940`; B = moyenne `83 458,333`, médiane `88 144`, min `73 781`, max `88 450`, écart-type `8 382,213`. L'écart moyen brut est `481` (`0,573 %`) en faveur de B, tandis que l'écart-type des différences appariées est `44 792,381`. Ce compteur n'est pas promu au statut `TokensTotal` officiel.

| Mesure secondaire | A moy./méd./min/max/σ | B moy./méd./min/max/σ | A-B moyen |
|---|---|---|---:|
| Insertions | 55 / 76 / 0 / 89 / 48,073 | 90,667 / 92 / 79 / 101 / 11,060 | -35,667 |
| Deletions | 0,667 / 1 / 0 / 1 / 0,577 | 1 / 1 / 1 / 1 / 0 | -0,333 |
| Validations passées | 5,333 / 7 / 2 / 7 / 2,887 | 7 / 7 / 7 / 7 / 0 | -1,667 |
| Validations totales | 6,333 / 7 / 5 / 7 / 1,155 | 7 / 7 / 7 / 7 / 0 | -0,667 |
| Warnings | 0 / 0 / 0 / 0 / 0 | 0 / 0 / 0 / 0 / 0 | 0 |
| Erreurs | 1 / 0 / 0 / 3 / 1,732 | 0 / 0 / 0 / 0 / 0 | 1 |
| Diagnostics | 9,333 / 10 / 8 / 10 / 1,155 | 10 / 10 / 10 / 10 / 0 | -0,667 |

Ces métriques secondaires reflètent principalement l'échec fonctionnel d'A3 et ne sont pas interprétées comme des gains de performance.

## 10. Limites

- Trois observations par condition seulement.
- Exécution d'un modèle génératif non déterministe : A3 diverge malgré S0 identique.
- La troisième paire ne compare pas le même travail fonctionnel ; sa durée est donc non comparable.
- Les hashes bruts des livrables réussis varient avec les timestamps et la rédaction ; l'équivalence sémantique est documentée, pas l'identité byte-for-byte.
- Les tokens input/output/total restent indisponibles dans les artefacts autoritatifs.
- Le statut Campaign `FAILED/4` commun aux six runs révèle une projection Campaign distincte du statut unitaire `READY_FOR_REVIEW`; aucune correction n'a été apportée pendant ce benchmark read-only.
- Le worktree S0 était dirty par état utilisateur préexistant. Il a été intégralement capturé, hashé et restauré, mais ce contexte doit être conservé lors de toute reproduction.

## 11. Attribution causale

Conditions requises :

| Condition | Résultat |
|---|---:|
| Six runs exécutés | YES |
| Une seule variable contrôlée modifiée | YES |
| S0 restauré entre les runs | YES |
| Équivalence fonctionnelle démontrée | **NO** |
| Gain supérieur à la dispersion | **NO** |
| Aucune régression/anomalie fonctionnelle dans le benchmark | **NO** |

Le mode B a produit trois résultats `READY_FOR_REVIEW` avec payload de contexte parfaitement stable. Le mode A en a produit deux, puis un `BLOCKED`. Cela peut motiver un benchmark fonctionnel distinct, mais ne permet pas d'attribuer causalement un gain de performance dans ce protocole, dont la comparabilité fonctionnelle est une précondition.

**CAUSAL IMPACT PROVEN = NO — causes exactes : divergence fonctionnelle A3/B3 et gain moyen inférieur à la dispersion appariée.**

## 12. Verdict final obligatoire

```text
SIX RUNS EXECUTED = YES
BENCHMARK EXECUTED = YES
ONLY VARIABLE CHANGED = YES
WORKTREE RESTORED BETWEEN RUNS = YES
FUNCTIONAL EQUIVALENCE = NO
NO REGRESSION = NO
PERFORMANCE IMPROVEMENT OBSERVED = YES
TOKENS IMPROVEMENT OBSERVED = UNAVAILABLE
CAUSAL IMPACT PROVEN = NO
CONTEXT ASSEMBLY READY FOR PRODUCTION = NO
COMMIT = NO
PUSH = NO
```

`PERFORMANCE IMPROVEMENT OBSERVED = YES` désigne uniquement la baisse brute des trois moyennes de durée. Elle n'est ni statistiquement robuste au regard de la dispersion, ni causalement attribuable, ni suffisante pour une décision de production.
