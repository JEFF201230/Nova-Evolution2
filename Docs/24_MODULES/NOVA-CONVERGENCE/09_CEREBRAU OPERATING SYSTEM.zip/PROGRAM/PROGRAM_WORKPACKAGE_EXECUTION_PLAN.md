# PROGRAM WORK PACKAGE EXECUTION PLAN

## WP-01

### Work Package

`WP-01 Gouvernance et preflight`

### Capability

`CAP-01 Gouvernance et certification`

### Grappe

`GX-01`, `GX-03`

### Micro-missions

`MM-L01-01`, `MM-L01-02`, `MM-L01-03`

### Gates couvertes

`L01-G04`, `L01-G05`, `L01-G06`

### Pré requis

`MM-L01-01 → MM-L01-03`

### Statut

`En cours`

### Critère de clôture

Les trois Gates `L01-G04` à `L01-G06` possèdent une décision conforme à la doctrine et leurs preuves référencées.

## WP-02

### Work Package

`WP-02 Repository certifiable`

### Capability

`CAP-02 Repository et drift`

### Grappe

`GX-01`, `GX-03`, `GX-04`

### Micro-missions

`MM-L02-01`, `MM-L02-02`, `MM-L02-03`, `MM-L02-04`

### Gates couvertes

`L02-G03`, `L02-G04`, `L02-G05`, `L02-G06`

### Pré requis

`MM-L02-01 → MM-L02-03`; `MM-L02-01`, `MM-L02-02`, `MM-L02-03 → MM-L02-04`

### Statut

`En cours`

### Critère de clôture

Les quatre Gates `L02-G03` à `L02-G06` possèdent une décision conforme à la doctrine et la décision repository est référencée.

## WP-03

### Work Package

`WP-03 Runtime et déploiements`

### Capability

`CAP-03 Runtime`

### Grappe

`GX-01`, `GX-02`, `GX-04`

### Micro-missions

`MM-L03-01`, `MM-L03-02`, `MM-L03-03`, `MM-L03-04`

### Gates couvertes

`L03-G04`, `L03-G05`, `L03-G06`, `L03-G07`

### Pré requis

`PRQ-EXT-001`, `PRQ-EXT-002`, `MM-L03-02 → MM-L03-04`

### Statut

`En cours`

### Critère de clôture

Les quatre Gates `L03-G04` à `L03-G07` possèdent une décision conforme à la doctrine et les preuves runtime sont référencées.

## WP-04

### Work Package

`WP-04 Autorités et SOT`

### Capability

`CAP-04 Architecture et Sources of Truth`

### Grappe

`GX-05`, `GX-06`, `GX-07`

### Micro-missions

`MM-L04-01`, `MM-L04-02`, `MM-L04-03`, `MM-L04-04`

### Gates couvertes

`L04-G03`, `L04-G04`, `L04-G05`, `L04-G06`

### Pré requis

`MM-L02-04`, `MM-L03-01`, `MM-L03-03`, `MM-L03-04`, `MM-L04-01 → MM-L04-02`, `MM-L04-01 → MM-L04-03`, `MM-L04-02`, `MM-L04-03 → MM-L04-04`

### Statut

`À faire`

### Critère de clôture

Les quatre Gates `L04-G03` à `L04-G06` possèdent une décision conforme à la doctrine et chaque autorité SOT est référencée.

## WP-05

### Work Package

`WP-05 Fermeture workflow QF`

### Capability

`CAP-05 Workflows et intégration`

### Grappe

`GX-02`, `GX-06`, `GX-11`; hors grappe : `MM-L05-04`

### Micro-missions

`MM-L05-01`, `MM-L05-02`, `MM-L05-03`, `MM-L05-04`

### Gates couvertes

`L05-G04`, `L05-G05`, `L05-G06`, `L05-G07`

### Pré requis

`PRQ-REF-001`, `MM-L06-03`, `MM-L06-06`, `MM-L07-03`, `MM-L07-05`, `MM-L08-06`

### Statut

`À faire`

### Critère de clôture

Les quatre Gates `L05-G04` à `L05-G07` possèdent une décision conforme à la doctrine et la décision de zone est référencée.

## WP-06

### Work Package

`WP-06 Sécurité QF`

### Capability

`CAP-06 Sécurité`

### Grappe

`GX-02`, `GX-04`, `GX-05`, `GX-06`, `GX-07`

### Micro-missions

`MM-L06-01`, `MM-L06-02`, `MM-L06-03`, `MM-L06-04`, `MM-L06-05`, `MM-L06-06`

### Gates couvertes

`L06-G01`, `L06-G02`, `L06-G03`, `L06-G04`, `L06-G05`, `L06-G06`

### Pré requis

`PRQ-EXT-003`, `MM-L03-01`, `MM-L03-03`, `MM-L04-01`, `MM-L05-01`, `MM-L06-01` à `MM-L06-05 → MM-L06-06`

### Statut

`À faire`

### Critère de clôture

Les six Gates `L06-G01` à `L06-G06` possèdent une décision conforme à la doctrine et la matrice sécurité est référencée.

## WP-07

### Work Package

`WP-07 Transactions et données`

### Capability

`CAP-07 Transactions et données`

### Grappe

`GX-02`, `GX-08`, `GX-09`, `GX-10`

### Micro-missions

`MM-L07-01`, `MM-L07-02`, `MM-L07-03`, `MM-L07-04`, `MM-L07-05`

### Gates couvertes

`L07-G03`, `L07-G04`, `L07-G05`, `L07-G06`, `L07-G07`

### Pré requis

`PRQ-EXT-004`, `MM-L06-06`, `MM-L07-01 → MM-L07-02`, `MM-L07-01 → MM-L07-03`, `MM-L07-04 → MM-L07-02`, `MM-L07-02 → MM-L07-05`

### Statut

`À faire`

### Critère de clôture

Les cinq Gates `L07-G03` à `L07-G07` possèdent une décision conforme à la doctrine et les preuves transactionnelles sont référencées.

## WP-08

### Work Package

`WP-08 UI et consommateurs`

### Capability

`CAP-05 Workflows et intégration`

### Grappe

`GX-08`, `GX-10`, `GX-11`; hors grappe : `MM-L08-05`, `MM-L08-06`

### Micro-missions

`MM-L08-01`, `MM-L08-02`, `MM-L08-03`, `MM-L08-04`, `MM-L08-05`, `MM-L08-06`

### Gates couvertes

`L08-G01`, `L08-G02`, `L08-G03`, `L08-G04`, `L08-G05`, `L08-G06`

### Pré requis

`MM-L04-01`, `MM-L05-01`, `MM-L06-06`, `MM-L07-02`, `MM-L07-05`, `MM-L08-01` à `MM-L08-05 → MM-L08-06`

### Statut

`À faire`

### Critère de clôture

Les six Gates `L08-G01` à `L08-G06` possèdent une décision conforme à la doctrine et la preuve E2E est référencée.

## WP-09

### Work Package

`WP-09 Legacy et drift`

### Capability

`CAP-02 Repository et drift`

### Grappe

`GX-03`, `GX-06`

### Micro-missions

`MM-L09-01`, `MM-L09-02`, `MM-L09-03`

### Gates couvertes

`L09-G02`, `L09-G03`, `L09-G04`

### Pré requis

`MM-L02-01`, `MM-L02-03`, `MM-L03-01`, `MM-L04-01`

### Statut

`À faire`

### Critère de clôture

Les trois Gates `L09-G02` à `L09-G04` possèdent une décision conforme à la doctrine et les décisions de drift sont référencées.

## WP-10

### Work Package

`WP-10 Certification PROGRAM`

### Capability

`CAP-01 Gouvernance et certification`

### Grappe

`GX-12`; hors grappe : `MM-L10-05`

### Micro-missions

`MM-L10-01`, `MM-L10-02`, `MM-L10-03`, `MM-L10-04`, `MM-L10-05`

### Gates couvertes

`L10-G02`, `L10-G03`, `L10-G04`, `L10-G05`, `L10-G06`

### Pré requis

`LOT-001` à `LOT-009 GO`, `L10-G01 GO`, `MM-L10-01` à `MM-L10-04 → MM-L10-05`

### Statut

`À faire`

### Critère de clôture

Les cinq Gates `L10-G02` à `L10-G06` possèdent une décision conforme à la doctrine et la décision finale est signée.

## Ordonnancement

### PHASE 1

`WP-01`, `WP-02`

Work Packages sans prérequis externe de package et déjà `En cours`.

### PHASE 2

`WP-03`

Ouverture conditionnée par `PRQ-EXT-001` et `PRQ-EXT-002` pour les missions concernées.

### PHASE 3

`WP-04`

Ouverture après les sorties requises de `WP-02` et `WP-03`.

### PHASE 4

`WP-05`, `WP-06`, `WP-07`, `WP-08`, `WP-09`

`WP-09` dépend des sorties requises de `WP-02` à `WP-04`; `WP-05` à `WP-08` forment un ensemble couplé par les dépendances directes existantes et sont pilotés dans cette phase par `GX-02`, puis `GX-05` à `GX-11` et les jonctions séquentielles référencées.

### PHASE 5

`WP-10`

Ouverture après les décisions requises de `LOT-001` à `LOT-009` et `L10-G01 GO`.

## Tableau de bord

| Indicateur | Valeur |
|---|---:|
| Work Packages totaux | 10 |
| Work Packages terminés | 0 |
| Work Packages en cours | 3 |
| Work Packages restants | 7 |
| Gates couvertes | 44 |
| Micro-missions couvertes | 44 |
| Avancement global | 0 % |

Avancement global : `Work Packages terminés / Work Packages totaux = 0 / 10 = 0 %`.

