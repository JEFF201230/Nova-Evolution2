# PROGRAM-MM-L01-03-PARTIAL-RECONCILIATION-001

## 1. Objet, périmètre et verdict exécutif

Le présent audit est exclusivement documentaire. Il n'a modifié ni contrat, ni prompt, ni Campaign Manifest, ni runtime, ni état Campaign, ni registre, ni Gate, ni preuve. Son unique écriture est ce rapport.

La cause racine est établie. `MM-L01-03` a bien été déclenchée automatiquement par la Campaign, mais son contrat de preuve ne lui permettait pas de reconnaître un `Campaign Start Order` distinct : le chemin de l'ordre est absent des sources exclusives du prompt, absent de `scopes.readOnly`, absent de `baselineEvidence`, sans hash déclaré, tandis que `Docs/PROGRAM/WAVES/**` est protégé contre toute modification. L'agent a donc appliqué le contrôle d'entrée 4 et s'est arrêté sans écriture métier.

Le statut officiel `PARTIAL`, plutôt que `BLOCKED`, a une cause technique additionnelle : le moteur Mission a observé trois changements globaux du workspace entre ses snapshots. Avec des validations requises en échec et un delta non vide, `Get-CerebrauClassification` retourne obligatoirement `PARTIAL` (`Cerebrau.Reporting.psm1`, lignes 285-296). Ces changements ne peuvent pas être attribués avec certitude à `MM-L01-03` ; son transcript affirme au contraire qu'elle n'a rien écrit.

La clôture Campaign échoue ensuite dans `Complete-CerebrauRollbackBundle`. Le rapport officiel contient des chemins hors `allowedPaths`; la règle des lignes 637-647 de `Cerebrau.Campaign.psm1` lève `CAMPAIGN_ROLLBACK_NOT_ELIGIBLE` avant l'émission de `MISSION_FINISHED`. L'état persistant reste donc la projection de séquence 8 : Campaign `RUNNING`, mission `RUNNING`, attempt `RUNNING`. Aucun lock Campaign n'existe encore : le moteur n'est pas en cours d'exécution, mais sa projection est restée dans un état intermédiaire.

Décision minimale : réconcilier le contrat Mission et la machine d'états, puis réconcilier et reprendre la même Campaign. Ne pas lancer une nouvelle Campaign et ne pas invoquer `Resume` avant cette réconciliation.

## 2. Sources auditées

Sources obligatoires lues :

- `Docs/PROGRAM/WAVES/VEEDDA-URBANIZATION-WAVE-001/CAMPAIGN_START_ORDER.md` ;
- `tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json` ;
- `tools/cerebrau/missions/veedda/MM-L01-03.json` ;
- `tools/cerebrau/missions/veedda/MM-L01-03.prompt.md` ;
- `tools/cerebrau/reports/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001/state/campaign-events.jsonl` ;
- `tools/cerebrau/reports/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001/state/campaign-state.json` ;
- `tools/cerebrau/reports/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001/evidence-index.json` ;
- `tools/cerebrau/reports/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001/rollback/ATT-31726B01C4B74D4785D43B04CB9B9E69/rollback-bundle.json` ;
- `Docs/09_CEREBRAU OPERATING SYSTEM/00_GOVERNANCE/PROGRAM_WAVE_ORCHESTRATION.md` ;
- tous les fichiers du rapport officiel `tools/cerebrau/reports/missions/veedda/MM-L01-03/bootstrap-20260721T231101091/` : `official-report.json`, `official-report.md`, `execution-journal.jsonl`, `codex-transcript.txt`, `mission-delta.json`, `workspace-before.json`, `workspace-after.json` ;
- code strictement nécessaire : `tools/cerebrau/Cerebrau.Campaign.psm1`, `tools/cerebrau/Invoke-CerebrauCampaign.ps1`, `tools/cerebrau/Invoke-CerebrauMission.ps1`, `tools/cerebrau/Cerebrau.Reporting.psm1`, ainsi que les tests Campaign Resume/Rollback.

Référence temporelle : les heures du journal Campaign sont en UTC. L'heure locale de Paris le 21 juillet 2026 est UTC+02:00.

## 3. Classification des constats

| ID | Classe | Constat | Preuve déterminante |
|---|---|---|---|
| C-01 | `FACT` | La Campaign a passé `READY -> RUNNING` et a déclenché `MM-L01-03` automatiquement. | Événements 5 à 8, run `RUN-451F65E20A4F4A269D948F668743595D`, attempt `ATT-31726B01C4B74D4785D43B04CB9B9E69`. |
| C-02 | `FACT` | Il n'existe pas d'événement nommé `MISSION_ORDER_ISSUED`; l'émission de l'ordre est matérialisée opérationnellement par `MISSION_READY`, `READY_SET_COMPUTED` puis `MISSION_STARTED`. | Journal Campaign, séquences 6, 7 et 8. |
| C-03 | `FACT` | Les quatre hashes `baselineEvidence` de `MM-L01-03.json` correspondent aux fichiers courants. | Recalcul SHA-256 et transcript de mission. |
| C-04 | `FACT` | Le Start Order n'est ni source exclusive du prompt, ni source `readOnly`, ni `baselineEvidence`; son hash n'est déclaré ni dans le contrat Mission ni dans les `sharedEvidence` du Campaign Manifest. | Comparaison des trois contrats. |
| C-05 | `FACT` | Le chemin du Start Order se trouve sous `Docs/PROGRAM/WAVES/**`, motif déclaré dans `forbiddenPaths`. Cette règle protège contre l'écriture; elle ne constitue pas une autorisation de lecture. | `MM-L01-03.json`. |
| C-06 | `FACT` | Le prompt exige néanmoins de confirmer un ordre distinct. Le JSON et le prompt sont donc incohérents sur la preuve nécessaire à ce contrôle. | Contrôle d'entrée 4 du prompt contre `scopes.readOnly` et `baselineEvidence` du JSON. |
| C-07 | `FACT` | Le transcript conclut qu'aucun ordre distinct n'est démontré par les sources autorisées et arrête la mission avant toute écriture. | `codex-transcript.txt`. |
| C-08 | `FACT` | Le livrable MM-L01-03 n'existe pas et le registre de Gates conserve le hash baseline `D19A4FDC...D367`; `L01-G06` reste `NO_GO`. | Rapport officiel, filesystem courant et recalcul SHA-256. |
| C-09 | `FACT` | Le statut officiel Mission est `PARTIAL`, avec ExitCode Codex 0, validations de livrable et de scope en échec. | `official-report.json` et `official-report.md`. |
| C-10 | `FACT` | `PARTIAL` résulte de la règle « validation requise en échec + delta non vide ». Sans delta, cette même exécution aurait été classée `BLOCKED`. | `Cerebrau.Reporting.psm1`, lignes 285-296. |
| C-11 | `FACT` | Le delta observé contient deux modifications et une suppression, toutes hors `allowedPaths`. | `mission-delta.json`. |
| C-12 | `UNKNOWN` | L'auteur des trois changements observés pendant la fenêtre de mission n'est pas démontré. Leur simple présence entre deux snapshots ne prouve pas que `MM-L01-03` les a écrits. | Les snapshots n'enregistrent pas l'identité du writer; le transcript nie toute écriture. |
| C-13 | `FACT` | La clôture du bundle refuse le premier chemin hors scope et lève `CAMPAIGN_ROLLBACK_NOT_ELIGIBLE` avant `MISSION_FINISHED`. | `Complete-CerebrauRollbackBundle`, lignes 637-647; appel ligne 755; ordre du delta officiel. |
| C-14 | `FACT` | Le bundle est `complete=false`, `delta=[]`; un rollback documentaire manuel est donc lui aussi non éligible avec le détail `BUNDLE_INCOMPLETE`. | Bundle courant et `Invoke-CerebrauDocumentaryRollback`, lignes 936-945. |
| C-15 | `FACT` | L'état persistant est toujours Campaign `RUNNING`, mission `RUNNING`, attempt `RUNNING`, séquence 8, sans événement ultérieur et sans lock actif. | `campaign-state.json`, dernier événement et absence de `campaign.lock`. |
| C-16 | `FACT` | Un `Resume` brut retrouverait le rapport officiel et récupérerait l'attempt en `PARTIAL`; la politique `REUSE_TERMINAL_ATTEMPTS` empêcherait ensuite une nouvelle exécution. | `Resolve-CerebrauInterruptedAttempts`, lignes 711-726; états terminaux ligne 8; ready-set lignes 572-595. |
| C-17 | `FACT` | Le runtime laisse une exception d'éligibilité rollback empêcher la persistance du résultat Mission. Il s'agit d'un défaut de clôture/projection, distinct du refus de rollback qui est, lui, protecteur et correct. | Séquencement des lignes 753-756 et état resté à la séquence 8. |
| C-18 | `FACT` | Le Start Order actuellement lisible a été créé sur le filesystem à `2026-07-21T21:16:17.6033479Z`, après le rapport officiel généré à `2026-07-21T21:12:47Z`, tout en déclarant un horodatage d'acte `2026-07-21T23:09:26+02:00`. | Métadonnées du fichier et contenu du Start Order. |
| C-19 | `FACT` | Le snapshot pré-exécution contenait déjà un fichier au même chemin, hash `75337A18...F5B221`; le snapshot post-exécution ne le contenait plus. Le fichier courant a un autre hash, `B30C1181...FEF5`. | `workspace-before.json`, `workspace-after.json`, hash courant. |
| C-20 | `UNKNOWN` | Le contenu et la validité de la version pré-exécution hashée `75337A18...F5B221` ne sont plus disponibles dans les artefacts conservés. Il est impossible de certifier qu'elle constituait l'ordre effectif actuel. | Seul son hash subsiste dans le snapshot; la sauvegarde temporaire a été supprimée par le runner. |
| C-21 | `HYPOTHESIS` | Une autre opération de gouvernance a probablement modifié les trois fichiers pendant l'attempt. | Convergence temporelle, mais aucune preuve d'identité de processus ou d'auteur. Cette hypothèse n'est pas utilisée comme cause établie. |

## 4. Contrôle 1 — Chronologie exacte

| Horodatage | Événement | État avant | État après | Source | Résultat / classification |
|---|---|---|---|---|---|
| `2026-07-21T23:09:26+02:00` déclaré | Campaign Start Order `PDS-CAMPAIGN-START-ORDER-001` | `NOT_STARTED` déclaré | `STARTED` déclaré | Start Order courant | Acte courant `EFFECTIVE` (`FACT` sur le contenu actuel). Sa matérialité à cet instant précis reste `UNKNOWN` au vu de C-18 à C-20. |
| `2026-07-21T21:11:00.7403918Z` | `PREFLIGHT_STARTED` seq. 1 | Campaign `NEW` | `VALIDATING` | Journal Campaign | Préflight lancé (`FACT`). |
| `2026-07-21T21:11:00.7683979Z` | `EVIDENCE_VERIFIED` seq. 2 | `VALIDATING` | `VALIDATING` | Journal Campaign | `EV-L01-G04-REGISTRATION` valide (`FACT`). |
| `2026-07-21T21:11:00.7945408Z` | `EVIDENCE_VERIFIED` seq. 3 | `VALIDATING` | `VALIDATING` | Journal Campaign | `EV-PROGRAM-CERTIFICATION-READINESS` valide (`FACT`). |
| `2026-07-21T21:11:00.8470271Z` | `PREFLIGHT_SUCCEEDED` seq. 4 | `VALIDATING` | `READY` | Journal Campaign | Campaign prête (`FACT`). |
| `2026-07-21T21:11:00.9045713Z` | `CAMPAIGN_STARTED` seq. 5 | `READY` | `RUNNING` | Journal Campaign | Moteur activé, run créé (`FACT`). |
| `2026-07-21T21:11:00.9468487Z` | `MISSION_READY` seq. 6 | Mission `PENDING` | `READY` | Journal Campaign | Dépendances/prérequis/2 shared evidences satisfaits (`FACT`). |
| `2026-07-21T21:11:00.9825304Z` | `READY_SET_COMPUTED` seq. 7 | Campaign `RUNNING`, mission `READY` | Inchangé; ready set = [`MM-L01-03`] | Journal Campaign | Ordre opérationnel déterminé, `maxConcurrency=1` (`FACT`). |
| `2026-07-21T21:11:01.0537788Z` | `MISSION_STARTED` seq. 8 | Mission `READY` | `RUNNING` | Journal Campaign | Attempt créé; hashes contrat/prompt enregistrés (`FACT`). |
| `2026-07-21T21:11:07.431Z` à `21:12:43.915Z` | Exécution et contrôle des sources exclusives | Mission projetée `RUNNING` | Arrêt logique sans écriture | Journal Mission et transcript | Contrôle 4 non démontré avec les sources autorisées (`FACT`). |
| `2026-07-21T21:12:43.927Z` à `21:12:47.122Z` | Snapshot après, validations, classification | Résultat technique ExitCode 0 | Rapport Mission `PARTIAL` | Journal Mission | Livrable absent, trois violations de scope, delta non vide (`FACT`). |
| `2026-07-21T21:12:47.126Z` à `21:12:47.172Z` | Rapport officiel généré | Rapport absent | `official-report.json/.md` présents | Journal Mission | Statut officiel `PARTIAL` persistant (`FACT`). |
| immédiatement après retour du runner; horodatage exact non persisté | Complétion du bundle / clôture Mission | In-memory attempt/mission affectés à `PARTIAL`; disque encore seq. 8 | Exception avant journalisation | Code lignes 753-756, delta, bundle | `CAMPAIGN_ROLLBACK_NOT_ELIGIBLE:Docs/09_CEREBRAU OPERATING SYSTEM/00_GOVERNANCE/PROGRAM_WAVE_ORCHESTRATION.md` (`FACT` déterminé par le premier chemin du delta). |
| horodatage d'une éventuelle commande manuelle non disponible | Rollback documentaire | Bundle incomplet | Refus, aucun changement d'état | Code lignes 936-945 | Toute tentative sur ce bundle produit `CAMPAIGN_ROLLBACK_NOT_ELIGIBLE:BUNDLE_INCOMPLETE` (`FACT` sur la règle; invocation et heure exactes `UNKNOWN`). |
| état audité | Projection finale | Campaign `RUNNING`, mission `RUNNING` | Inchangé depuis seq. 8 | État et journal Campaign | Projection intermédiaire abandonnée, pas moteur actif (`FACT`). |

### Vérification des faits d'entrée

| Fait d'entrée | Conclusion |
|---|---|
| `CAMPAIGN START ORDER CREATED = YES` | `FACT` pour l'artefact courant; sa version effective pendant l'attempt est `UNKNOWN`. |
| `CAMPAIGN STATUS = STARTED` | `FACT` au niveau de l'acte; le runtime projette ensuite `RUNNING`. |
| `CAMPAIGN ENGINE ACTIVATED = YES` | `FACT`, événement 5. |
| `MM-L01-03 EXECUTION ORDER ISSUED = YES` | `FACT` opérationnel par séquences 6-8; aucun événement littéral `MISSION_ORDER_ISSUED`. |
| `MM-L01-03 STARTED = YES` | `FACT`, événement 8. |
| `EXECUTION TRIGGER = CAMPAIGN MANIFEST` | `FACT`, ready set et invocation par `Invoke-CerebrauCampaign`. |
| `MM-L01-03 = PARTIAL` | `FACT` dans le rapport officiel Mission; non projeté dans l'état Campaign à cause du défaut de clôture. |
| aucune écriture métier effectuée | `FACT` pour le périmètre métier de `MM-L01-03`: registre inchangé et livrable absent. |
| erreur de clôture `CAMPAIGN_ROLLBACK_NOT_ELIGIBLE` | `FACT`, causée par le delta hors scope lors de la complétion du bundle. |
| moteur projeté `RUNNING` après séquence 8 | `FACT`. |

## 5. Contrôle 2 — Contrat de preuve

### 5.1 Comparaison exacte

| Élément | Prompt Mission | JSON Mission | Campaign Manifest | Réalité observée |
|---|---|---|---|---|
| Start Order requis | Oui, contrôle d'entrée 4 | Aucune propriété dédiée | Aucune `sharedEvidence` ou prerequisite dédiée | L'ordre courant existe au chemin attendu. |
| Chemin dans les sources | Absent des six sources exclusives | Absent de `scopes.readOnly` | Absent des preuves partagées | `Docs/PROGRAM/WAVES/VEEDDA-URBANIZATION-WAVE-001/CAMPAIGN_START_ORDER.md`. |
| Hash du Start Order | Absent | Absent de `baselineEvidence` | Absent | Hash courant `B30C1181B283862CD40B5C970F787B933CF25CC78CE778F123BBF098B900FEF5`. |
| Protection de chemin | Non exprimée | `Docs/PROGRAM/WAVES/**` dans `forbiddenPaths` | Non exprimée | Toute modification de l'ordre est correctement interdite à la Mission. |
| Événements de Campaign | Non listés comme source | Non listés comme source | Produits dans le répertoire d'état | Ils prouvent le déclenchement, mais pas l'existence d'un acte distinct antérieur. |

### 5.2 Baseline vérifiée

| EvidenceId | Hash déclaré | Hash recalculé | Résultat |
|---|---|---|---|
| `EV-L01-G04-REGISTRATION` | `B89A23667F6E7FBF70DE2D14719EF6CCA70E4600D5699DD6FFD8264025360A22` | identique | `VALID` |
| `EV-PROGRAM-CERTIFICATION-READINESS` | `1D6CE752F08F0237EEE6FB0C91D1EEDC20A42463715B6D0BE47718508F358AD9` | identique | `VALID` |
| `EV-MASTER-GATES-REGISTER` | `D19A4FDC635AB59BCF2FC8D7E702DAF316EFA23BD600690F71670EA21FD7D367` | identique | `VALID` |
| `EV-MASTER-GATES-MATRIX` | `17B6F604BF246DD6486292C88C72B05E8389D4B67DF78C8CBB1825E9E67B4141` | identique | `VALID` |

Les hashes de mission consignés à la séquence 8 correspondent également aux fichiers courants : JSON `77A8F1A5...FE9B`, prompt `056936B6...4E28`. Aucun hash contractuel déclaré n'a dérivé.

### 5.3 Cause du refus de preuve

Les causes établies sont cumulatives :

1. `FACT` — source nécessaire absente du corpus exclusif ;
2. `FACT` — chemin absent du scope de lecture contractuel ;
3. `FACT` — hash du Start Order non déclaré ;
4. `FACT` — incohérence entre l'obligation du prompt et les preuves du JSON ;
5. `FACT` — l'artefact courant est postérieur à la baseline et au rapport d'exécution ;
6. `UNKNOWN` — validité de la version différente présente au début de l'attempt.

Le motif `forbiddenPaths` n'est pas, à lui seul, la cause du refus de lecture : le runtime l'utilise pour contrôler les changements, pas les lectures. Il doit rester en place pour interdire toute modification de l'ordre par la Mission.

## 6. Contrôle 3 — Machine d'états et rollback

### 6.1 États réels et transitions

État persistant réel :

- Campaign : `RUNNING`, séquence 8, `activeRunId` encore renseigné ;
- Mission : `RUNNING`, `activeAttemptId` encore renseigné ;
- Attempt : `RUNNING`, `finishedAt=null`, `unitResult=null` ;
- rapport unitaire externe : `PARTIAL` ;
- bundle rollback : `complete=false`, zéro delta, une sauvegarde du registre ;
- lock Campaign : absent.

La transition calculée en mémoire est `RUNNING -> PARTIAL` (`Convert-CerebrauUnitStatus`, lignes 675-686), mais elle n'est écrite dans le journal qu'à `MISSION_FINISHED`, ligne 756. La ligne 755 complète d'abord le bundle et lève l'exception. La projection disque reste donc cohérente avec le dernier événement, mais incomplète par rapport au rapport unitaire.

### 6.2 Règles exactes de `CAMPAIGN_ROLLBACK_NOT_ELIGIBLE`

Le code possède plusieurs conditions portant ce code :

- création du bundle : scope non documentaire, ligne 612 ;
- clôture du bundle : chemin du delta hors `allowedPaths` ou hors `Docs/**`, ligne 641 ;
- rollback manuel : attempt introuvable, ligne 941 ;
- rollback manuel : mode non documentaire ou bundle absent, ligne 943 ;
- rollback manuel : bundle incomplet, ligne 945.

La séquence observée démontre la condition de ligne 641 pendant la clôture. Le premier chemin officiel est `Docs/09_CEREBRAU OPERATING SYSTEM/00_GOVERNANCE/PROGRAM_WAVE_ORCHESTRATION.md`, non couvert par les deux `allowedPaths` de la Mission. L'exception sort de `Invoke-CerebrauUnitMission`, car l'appel de ligne 755 est hors du bloc `try/catch` des lignes 742-752.

Une tentative ultérieure de rollback ne peut pas réussir : la clôture interrompue a laissé `complete=false`; la ligne 945 refuse donc le bundle avec `BUNDLE_INCOMPLETE`. Aucun rollback n'est nécessaire pour le métier, puisque le delta des deux chemins métier autorisés est nul.

### 6.3 Bloqué ou état intermédiaire

Le moteur n'est pas dans l'état métier `BLOCKED` et aucun processus ne détient son lock. Il est projeté dans un état intermédiaire `RUNNING` abandonné. Un `Resume` actuel importerait une seule fois le rapport récupérable et classerait l'attempt `PARTIAL`, conformément aux lignes 711-726. Mais `PARTIAL` est terminal et la politique `REUSE_TERMINAL_ATTEMPTS` le retire du ready set; la Campaign finirait `FAILED` sans rejouer la mission. La reprise brute n'est donc pas une reprise fonctionnelle.

### 6.4 Défaut runtime prouvé

`RUNTIME DEFECT PROVEN = YES` pour deux comportements précis :

1. une erreur de préparation du rollback empêche la persistance du résultat unitaire déjà officiel ;
2. aucune transition supportée ne permet d'invalider proprement un attempt `PARTIAL` après changement contrôlé du contrat/input fingerprint et de le remettre en attente.

Le refus de rollback hors scope n'est pas un défaut : c'est une protection correcte. Le défaut est son placement bloquant avant `MISSION_FINISHED` et l'absence de voie de réconciliation event-sourcée.

## 7. Contrôle 4 — Régression et intégrité

| Contrôle | Classe | Conclusion |
|---|---|---|
| Aucune Gate modifiée | `FACT` | Le registre a le même hash avant/après et `L01-G06` reste `NO_GO`. |
| Aucune preuve métier MM-L01-03 créée ou modifiée | `FACT` | Livrable absent; aucun fichier du répertoire Evidence MM-L01-03. |
| Aucune preuve quelconque du workspace modifiée | `UNKNOWN` / contrôle non certifiable | Le hash de `MM_L01_01_PROGRAM_STATUS_DECISION.md` a changé pendant la fenêtre. Son contenu antérieur n'est plus disponible; l'auteur et la portée sémantique sont inconnus. |
| Aucune décision de Gate modifiée | `FACT` | Le registre cible est inchangé. |
| Aucune décision documentaire quelconque modifiée | `UNKNOWN` | Un fichier nommé `MM_L01_01_PROGRAM_STATUS_DECISION.md` a changé; impossible de démontrer si la décision sémantique a changé. |
| Aucun hash contractuel altéré | `FACT` | Les quatre baseline hashes sont identiques; hashes mission/prompt égaux à la séquence 8; fingerprint Campaign inchangé. |
| Aucune écriture hors gouvernance | `FACT` | Les trois chemins du delta sont tous des documents de gouvernance; aucun code/runtime/client/server n'apparaît dans le delta de l'attempt. |
| Aucun commit | `FACT` | Branch et HEAD inchangés, `706bf1fae540e1798e3b827fbb162cac20b3b019`, dans les deux snapshots. |
| Aucun push | `FACT` dans le périmètre local auditable | Aucun reflog de branche ou remote-tracking après le 19 juillet 2026; branche locale égale à `origin/fix/simulation-star`. Aucun appel réseau n'a été réalisé par cet audit. |

Le contrôle d'intégrité global ne permet donc pas d'affirmer que le workspace entier n'a subi aucune écriture documentaire pendant l'attempt. Il permet en revanche d'établir qu'aucune écriture métier de `MM-L01-03`, aucune modification de Gate et aucun commit n'ont eu lieu.

## 8. Décision minimale de réconciliation

### 8.1 Fichiers et règles à corriger

Correction strictement nécessaire :

1. `tools/cerebrau/missions/veedda/MM-L01-03.json`
   - ajouter le Start Order à `scopes.readOnly` ;
   - ajouter une entrée `baselineEvidence`, par exemple `EV-CAMPAIGN-START-ORDER-001`, avec le chemin exact et un SHA-256 revu et figé ;
   - conserver `Docs/PROGRAM/WAVES/**` dans `forbiddenPaths`, car la Mission doit lire l'ordre mais ne jamais le modifier.
2. `tools/cerebrau/missions/veedda/MM-L01-03.prompt.md`
   - ajouter le Start Order aux `Sources exclusives` ;
   - préciser que le contrôle 4 vérifie l'ID de Campaign, l'ID de Wave, le statut `EFFECTIVE` et le hash déclaré dans `baselineEvidence`.
3. `tools/cerebrau/Cerebrau.Campaign.psm1`
   - rendre la clôture du bundle non bloquante pour la persistance de `MISSION_FINISHED` : enregistrer séparément le refus de rollback et le résultat unitaire ;
   - ajouter une transition de réconciliation auditée permettant `RUNNING récupéré -> PARTIAL -> STALE/PENDING` lorsqu'un nouveau fingerprint contractuel approuvé invalide l'attempt sans écriture métier ;
   - conserver l'attempt initial dans l'historique et interdire sa réexécution/réutilisation silencieuse.
4. Journal/état de `VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001`
   - ne pas éditer directement `campaign-state.json` ;
   - produire, par la nouvelle transition supportée, les événements de récupération, clôture technique, invalidation contractuelle et remise en attente ;
   - recalculer la projection depuis le journal.

Le hash courant du Start Order est `B30C1181B283862CD40B5C970F787B933CF25CC78CE778F123BBF098B900FEF5`. Il ne doit être inscrit dans la nouvelle baseline qu'après revue de l'acte courant et résolution de la divergence avec la version pré-exécution inconnue.

### 8.2 Artefacts qui ne doivent pas être corrigés

- Campaign Manifest : aucune modification minimale requise. Ajouter le Start Order aux `sharedEvidence` serait un durcissement utile pour de futures Campaigns, mais changerait le fingerprint de la Campaign courante et déclencherait `CAMPAIGN_RESUME_NOT_ALLOWED:MANIFEST_CHANGED`. Ce n'est pas nécessaire pour que la Mission reconnaisse sa preuve après réconciliation.
- Registre de gouvernance et `PROGRAM_MASTER_GATES_REGISTER.md` : aucune correction; la décision `L01-G06 = NO_GO` doit rester intacte jusqu'à une exécution et une revue valides.
- Start Order : aucune modification n'est prescrite par cet audit; sa version courante doit d'abord être revue et hashée.
- Gate, décision métier et preuve métier : aucune correction avant la reprise gouvernée de la Mission.

### 8.3 Pourquoi la correction ne change pas la décision métier

La correction ne transforme aucune Gate et ne pose aucun verdict `GO`. Elle rend uniquement une preuve de lancement lisible et vérifiable, puis remet l'orchestration dans un état cohérent. `L01-G06` reste `NO_GO`; seul un nouvel attempt réussi, suivi de la revue humaine contractuelle, pourra produire le livrable et modifier le registre dans le scope déjà autorisé.

### 8.4 Reprise sans double exécution

Ordre sûr de reprise :

1. ne pas exécuter `Start`, `Resume` ou `RollbackDocs` dans l'état actuel ;
2. faire approuver le Start Order courant et son hash ;
3. appliquer la nouvelle baseline Mission et le prompt réconcilié ;
4. appliquer la correction de clôture/réconciliation runtime ;
5. réconcilier l'attempt existant en conservant son rapport officiel et son statut historique `PARTIAL`, puis le marquer invalide pour le nouveau fingerprint ;
6. remettre `MM-L01-03` en attente par événement, sans effacer l'attempt initial ;
7. reprendre la même Campaign en mode `Resume` ; le ready set ne doit créer qu'un nouvel attempt ;
8. vérifier avant écriture que le registre porte toujours le hash `D19A4FDC...D367` et que le Start Order porte le hash de la nouvelle baseline.

Il n'y a pas de double exécution métier : le premier attempt n'a ni acquis de lock métier, ni modifié le registre, ni créé le livrable. Son identité et son rapport restent conservés à des fins d'audit.

### 8.5 Baseline et décision Campaign

- Nouvelle baseline contractuelle Mission : `YES`.
- Nouvelle baseline/fingerprint du Campaign Manifest : `NO` dans la correction minimale.
- Campaign à reprendre : `YES`, après réconciliation.
- Campaign à réconcilier : `YES`.
- Campaign à clôturer puis relancer : `NO`.
- Campaign à laisser inchangée : `NO`.
- Safe resume immédiat : `NO`.
- Safe resume après les corrections ci-dessus : `YES`.

## 9. Conclusion

Le Start Order n'a pas été reconnu parce que la preuve exigée par le prompt n'était pas intégrée au contrat de sources et de hashes de `MM-L01-03`. La Mission a correctement refusé d'écrire. Le label `PARTIAL` a été produit par une classification sensible au delta global du workspace, puis la Campaign a échoué à persister ce résultat parce que le bundle de rollback a refusé des changements hors scope. La correction minimale combine donc la réconciliation du JSON et du prompt Mission, une correction ciblée de la clôture/réconciliation de la machine d'états, et une réconciliation event-sourcée de la Campaign existante. Aucun changement de Gate, de décision métier, de registre ou de Campaign Manifest n'est requis.

MM-L01-03 PARTIAL ROOT CAUSE IDENTIFIED = YES

CAMPAIGN START ORDER PROOF RECOGNIZED BY CONTRACT = NO

CONTRACT RECONCILIATION REQUIRED = YES

CAMPAIGN STATE RECONCILIATION REQUIRED = YES

RUNTIME DEFECT PROVEN = YES

BUSINESS WRITE OCCURRED = NO

SAFE RESUME POSSIBLE = YES

MINIMAL CORRECTION IDENTIFIED = YES

DECISION = GO_FOR_RECONCILIATION
