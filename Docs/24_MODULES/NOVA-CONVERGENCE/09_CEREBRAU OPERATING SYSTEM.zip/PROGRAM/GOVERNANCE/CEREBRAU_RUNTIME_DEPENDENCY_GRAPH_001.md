# CEREBRAU — Runtime Dependency Graph 001

> Mission : `CEREBRAU-MISSION-RUNTIME-GOVERNANCE-001`  
> Nature : graphe architectural audité, en lecture seule  
> Date : `2026-07-23`  
> Objet officiel de gouvernance : `WAVE`  
> Work Packages : `NOT_OFFICIAL`

## 1. Convention

Une flèche `A → B` signifie : **A requiert B pour accomplir la fonction décrite**.

Les arêtes sont classées :

- `EXEC` : nécessaire au démarrage ou à l'exécution ;
- `VALID` : nécessaire à la validation ;
- `CERT` : nécessaire à une décision de certification ;
- `CTX` : nécessaire à l'assemblage de contexte ;
- `META` : identité ou projection sans pouvoir de blocage ;
- `GOV` : obligation documentaire ou autorisation ;
- `RECOVERY` : voie nécessaire à la levée d'un blocage.

## 2. Graphe courant

```mermaid
flowchart TD
  PD[Program Director]
  PROGRAM[PROGRAM]
  WAVE[Wave]
  SOO[Squad Opening Order]
  CSO[Campaign Start Order]
  CM[Campaign Manifest]
  CR[Campaign Runner PowerShell]
  MM[Mission Manifest]
  MR[Mission Runtime PowerShell]
  CODEX[Codex CLI]
  REP[Official Mission Reports]
  VAL[Mission Validations]
  EVI[Shared Evidence]
  AUTH[Authority Source + Hash]
  CERT[Authority Certification Report]
  GATE[Gate]
  REVIEW[Human Review]
  MCA[Mission Context Assembly]
  CE[Context Engine TypeScript]
  PP[PROGRAM Provider]
  ORTS[Orchestrator Runtime TypeScript]
  LOCK[Runtime Lock]

  PD -->|GOV| PROGRAM
  PROGRAM -->|GOV| WAVE
  WAVE -->|GOV| SOO
  PD -->|GOV| CSO
  CSO -->|GOV trigger exclusif courant| CM

  CR -->|EXEC| CM
  CR -->|EXEC preflight| AUTH
  CR -->|EXEC preflight| CERT
  CR -->|EXEC preflight| EVI
  CR -->|EXEC preflight| MM
  CR -->|EXEC| MR

  MR -->|EXEC| MM
  MR -->|EXEC| CODEX
  MR -->|VALID après exécution| VAL
  MR -->|produit| REP
  REP -->|entrée de revue| REVIEW
  REVIEW -->|CERT| GATE
  GATE -->|consolidation| PROGRAM

  MR -.->|CTX optionnel| MCA
  MCA -->|CTX en Campaign| CM
  MCA -->|CTX| AUTH
  MCA -->|CTX| CERT
  MCA -->|CTX| EVI

  CE -->|CTX lecture| PP
  PP -->|lecture documentaire| PROGRAM

  ORTS -->|EXEC| LOCK
  LOCK -->|condition de démarrage| ORTS
```

## 3. Frontières d'exécution

### 3.1 Runtime unitaire

```text
Mission Manifest
  → Test-CerebrauMission.ps1
  → profile
  → prompt
  → Codex
  → delta
  → validations
  → official-report
```

Propriété importante : les validations du livrable sont postérieures à l'exécution. Une mission n'a pas besoin que son livrable existe pour démarrer.

Le champ `program` est obligatoire dans le manifeste, mais la décision `GO/NO_GO` n'est jamais lue par le runtime unitaire.

### 3.2 Campaign Runner

```text
Campaign Manifest
  → repository + branch
  → authority source exists
  → authority hash matches
  → certification report exists
  → every unit manifest validates
  → mission DAG is acyclic
  → every shared evidence hash is valid
  → Campaign state/evidence index
  → ready set
  → Mission Runtime
```

Le preflight est global. Un échec sur un seul de ces objets se produit avant toute mission.

### 3.3 Context Engine et contexte Mission

```text
Context Engine TypeScript
  → 10 providers
  → PROGRAM Provider
  → documents locaux
  → CerebrauProjectState + alerts
```

Cette chaîne n'est pas appelée par le Campaign Runner.

```text
Mission Runtime
  → [option] Mission Context Assembly
  → Campaign/authority/certification/evidence references
  → payload injecté dans le prompt
```

L'option peut durcir les dépendances d'une mission de Campaign. Son absence conserve la voie unitaire minimale.

### 3.4 Orchestrator Runtime TypeScript

```text
MissionDefinition
  → READY
  → Agent
  → Lock
  → RUNNING
  → Report
  → Validations
  → ACCEPTED / REJECTED
```

`FAILED` n'est pas dans `TERMINAL_STATES`. La libération du lock n'est appelée que par `approveMission` et `rejectMission`. Le service observé n'expose pas de méthode publique de libération, expiration ou annulation.

## 4. Registre des arêtes bloquantes

| ID | Source | Cible | Type | Blocage actuel | Preuve |
|---|---|---|---|---|---|
| `EDGE-001` | Campaign Runner | Campaign Manifest | `EXEC` | Oui | `Invoke-CerebrauCampaign.ps1:17-22` |
| `EDGE-002` | Campaign Runner | Authority Source | `EXEC` | Oui, existence + hash | `Cerebrau.Campaign.psm1:303-306` |
| `EDGE-003` | Campaign Runner | Authority Certification Report | `EXEC` | Oui, existence | `Cerebrau.Campaign.psm1:304` |
| `EDGE-004` | Campaign Runner | Unit Mission Manifests | `EXEC` | Oui, toutes les unités | `Cerebrau.Campaign.psm1:335-369` |
| `EDGE-005` | Campaign Runner | Shared Evidence | `EXEC` | Oui au Start, hash strict | `Cerebrau.Campaign.psm1:382-389` |
| `EDGE-006` | Mission | Mission dependencies | `EXEC` | Oui, état `SUCCEEDED` uniquement | `Cerebrau.Campaign.psm1:579-580` |
| `EDGE-007` | Mission | External prerequisites | `EXEC` | Oui, `SATISFIED` | `Cerebrau.Campaign.psm1:582-583` |
| `EDGE-008` | Mission | Required evidence | `EXEC` | Oui, `VALID` | `Cerebrau.Campaign.psm1:585-587` |
| `EDGE-009` | Mission Runtime | Mission Manifest | `EXEC` | Oui | `Invoke-CerebrauMission.ps1:155-181` |
| `EDGE-010` | Mission Runtime | Program decision | `META` | Non | Absence de lecture ou de branchement `GO/NO_GO` |
| `EDGE-011` | Mission Runtime | Context Assembly | `CTX` | Seulement si switch activé | `Invoke-CerebrauMission.ps1:247-260` |
| `EDGE-012` | Context Assembly | Authority Certification | `CTX` | Oui en mode Campaign | `Cerebrau.ContextAssembly.psm1:169-171` |
| `EDGE-013` | Gate | Evidence | `CERT` | Oui pour décision | Doctrine §§7-9 |
| `EDGE-014` | PROGRAM | Gate decisions | `CERT` | Oui par propagation | Doctrine §6 |
| `EDGE-015` | Mission TS | Active lock | `EXEC` | Oui | `orchestrator-runtime.service.ts:458-466` |
| `EDGE-016` | Active lock | Terminal mission state | `RECOVERY` | Oui pour libération | `orchestrator-runtime.service.ts:603-624` |
| `EDGE-017` | Freeze lift | Program Director decision | `GOV` | Oui | `PROGRAM_WAVE_ORCHESTRATION.md:150-164,541-553` |
| `EDGE-018` | Mission during Freeze | Freeze state | `GOV` | Interdiction absolue | `PROGRAM_WAVE_ORCHESTRATION.md:545-551` |

## 5. Graphe des cycles d'auto-blocage

### `NSB-CYCLE-001` — Freeze

```mermaid
flowchart LR
  F[PROGRAM FREEZE] --> B[Mission, audit et certification interdits]
  B --> NP[Preuve de levée non produite]
  NP --> NL[FREEZE LIFTED non démontrable]
  NL --> F
```

Le texte donne l'autorité de levée au Program Director, mais aucune voie exécutable permettant de produire les faits nécessaires à cette décision.

### `NSB-CYCLE-002` — Certification préalable

```mermaid
flowchart LR
  P[Campaign preflight] --> R[Certification report doit exister]
  R --> X[Mission de certification peut démarrer]
  X --> O[Mission produit le certification report]
  O --> R
```

La boucle apparaît dès que `certificationReportPath` désigne une sortie absente ou à rafraîchir de la campagne courante.

### `NSB-CYCLE-003` — Preuve préalable

```mermaid
flowchart LR
  P[Campaign preflight] --> V[Shared Evidence VALID]
  V --> X[Mission de preuve READY]
  X --> O[Mission produit ou rafraîchit la preuve]
  O --> V
```

Le contrat ne distingue pas `INPUT_EVIDENCE` de `OUTPUT_EVIDENCE`.

### `NSB-CYCLE-004` — Lock TypeScript

```mermaid
flowchart LR
  E[ExecutionFailed] --> F[Mission FAILED]
  F --> L[Lock reste ACTIVE]
  L --> C[Mission corrective même scope refusée]
  C --> R[Correction impossible dans l'instance]
  R --> L
```

### `NSB-CYCLE-005` — Rayon global du preflight

```mermaid
flowchart LR
  U[Un manifeste unitaire invalide] --> P[Campaign preflight FAILED]
  P --> I[Mission indépendante non exécutée]
  I --> N[Aucune preuve/réconciliation par cette Campaign]
  N --> P
```

## 6. Graphe de mission courant

La section 16 de la Master Gates Matrix a été extraite sans interpréter les Work Packages :

```text
Nodes MM-*                 = 44
Explicit MM-* dependencies = 60
Strongly connected cycles  = 0
Self-edges                 = 0
```

Le design du Campaign Runner documente `103` arêtes en comptant également les prérequis externes et dépendances de niveau LOT. Le présent chiffre `60` est volontairement limité aux seules références `MM-* → MM-*` présentes dans les lignes du registre.

Les contrôles automatiques couvrent :

- mission inconnue ;
- auto-dépendance ;
- cycle de `dependsOn`;
- `gateId` dupliqué ;
- mismatch du mapping Matrix/Manifest.

Ils ne couvrent pas :

- Gate → preuve → mission → Gate ;
- certification → mission de certification ;
- Freeze → preuve de levée ;
- lock → mission corrective ;
- manifeste global → mission de réparation de ce manifeste ;
- dépendances entre deux moteurs d'orchestration.

## 7. Graphe cible minimal

```mermaid
flowchart TD
  GOV[PROGRAM / Wave Governance]
  DEC[Gate and Certification Decisions]
  ORCH[Campaign Orchestrator]
  RUN[Mission Runtime Core]
  RLANE[Recovery Lane]
  RO[READ_ONLY]
  PE[EVIDENCE_PRODUCTION]
  AU[AUDIT]
  CR[CERTIFICATION_REMEDIATION]
  OUT[Reports / Evidence Outputs]

  GOV -->|autorise le travail normal| ORCH
  ORCH --> RUN
  RUN --> OUT
  OUT --> DEC
  DEC --> GOV

  GOV -->|ne peut pas bloquer| RLANE
  DEC -->|ne peut pas bloquer| RLANE
  ORCH -->|ne peut pas bloquer| RLANE
  RLANE --> RO
  RLANE --> PE
  RLANE --> AU
  RLANE --> CR
  RO --> RUN
  PE --> RUN
  AU --> RUN
  CR --> RUN
```

La Recovery Lane n'accorde aucun droit général de mutation. Elle doit :

- être indépendante du statut PROGRAM ;
- être disponible sous Freeze ;
- limiter les scopes à la lecture, aux rapports, aux preuves et aux décisions de remédiation explicitement autorisées ;
- ne jamais modifier automatiquement une Gate ou une décision ;
- journaliser l'autorité, le motif de bypass, les fichiers et le résultat ;
- rester utilisable si une Campaign normale ou un manifeste unitaire sans rapport avec la remédiation est invalide.

## 8. Invariants à contrôler automatiquement

| Invariant | Formulation testable |
|---|---|
| `INV-NSB-001` | Une décision `NO_GO` ne change pas l'acceptation d'une mission `READ_ONLY`. |
| `INV-NSB-002` | Un Freeze accepte les classes `READ_ONLY`, `EVIDENCE_PRODUCTION`, `AUDIT`, `CERTIFICATION_REMEDIATION`. |
| `INV-NSB-003` | Une preuve produite par une mission n'est jamais une précondition de démarrage de cette même mission. |
| `INV-NSB-004` | Le rapport de certification produit par une Campaign n'est pas son `authority.certificationReportPath` préalable. |
| `INV-NSB-005` | Toute SCC du graphe typé contenant une arête bloquante est rejetée, sauf boucle de révision explicitement non bloquante. |
| `INV-NSB-006` | L'échec d'une unité ne bloque pas une mission de récupération sans dépendance vers cette unité. |
| `INV-NSB-007` | Tout lock possède release, expiry et recovery testées après succès, échec, crash et annulation. |
| `INV-NSB-008` | Le Mission Runtime Core n'importe ni ne consulte une décision PROGRAM pour exécuter. |
| `INV-NSB-009` | La validation d'une Gate est une sortie postérieure, jamais une précondition de sa mission de preuve. |
| `INV-NSB-010` | Un manifeste de récupération est autonome et ne dépend pas du manifeste qu'il répare. |

## 9. Conclusion du graphe

```text
LOCAL MISSION DAG = ACYCLIC
GLOBAL GOVERNANCE GRAPH = CAN SELF-BLOCK
RUNTIME CORE → PROGRAM DECISION = NO EDGE
CAMPAIGN ORCHESTRATOR → PROGRAM AUTHORITY/CERTIFICATION = BLOCKING EDGES
RECOVERY LANE = ABSENT
```

