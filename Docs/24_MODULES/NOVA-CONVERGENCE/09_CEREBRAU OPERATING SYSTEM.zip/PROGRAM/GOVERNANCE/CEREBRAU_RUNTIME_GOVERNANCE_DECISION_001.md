# CEREBRAU — Runtime Governance Decision 001

> Decision ID : `CEREBRAU-RUNTIME-GOVERNANCE-DECISION-001`  
> Source : `CEREBRAU-MISSION-RUNTIME-GOVERNANCE-001`  
> Date : `2026-07-23`  
> Statut : **APPROUVÉE PAR LE PROGRAM DIRECTOR / CERTIFICATION BOARD**
> Verdict d'audit associé : **NO GO**

## 1. Décision proposée

Il est proposé d'intégrer officiellement au Runtime et à la gouvernance CEREBRAU le principe suivant :

> **Non Self-Blocking Principle**  
> Aucune règle de gouvernance, Gate, dépendance, manifeste ou décision de certification ne doit empêcher le Runtime CEREBRAU d'exécuter les missions nécessaires à produire les preuves permettant de lever cette même règle, Gate, dépendance ou décision.

**Recommandation : ADOPTER.**
## Décision de l’autorité

```text
AUTHORITY = PROGRAM DIRECTOR / CERTIFICATION BOARD
DECISION = APPROVED
DECISION_DATE = 2026-07-23
NON_SELF_BLOCKING_PRINCIPLE = ADOPTED
CURRENT_IMPLEMENTATION_GUARANTEE = NOT_SATISFIED
CURRENT_RUNTIME_VERDICT = NO_GO

Cette proposition n'est pas déclarée active par le présent livrable. Son activation requiert une décision de l'autorité compétente et son inscription dans les sources normatives. L'audit n'a reçu aucune autorisation de modifier ces sources.

## 2. Motivation

Le principe doit être adopté parce que :

- le `PROGRAM = NO_GO` est déjà correctement séparé du statut opérationnel et n'empêche pas, à lui seul, le Runtime unitaire de fonctionner ;
- la doctrine Freeze supprime cette séparation et ne réserve aucune voie d'audit ou de preuve ;
- le Campaign preflight peut exiger la certification ou la preuve que sa propre campagne devrait produire ;
- un manifeste unitaire invalide ou un hash global périmé bloque actuellement toute une Campaign ;
- l'Orchestrator Runtime TypeScript peut conserver un lock après échec ;
- les détecteurs de cycles ne couvrent que `mission.dependsOn`, pas le graphe complet de gouvernance.

Sans principe normatif, une future évolution peut recréer le même problème même si les défauts actuels sont corrigés individuellement.

## 3. Portée normative proposée

Le principe s'applique à :

- PROGRAM ;
- Wave ;
- Squad et Squad Opening Order ;
- Mission Order ;
- Campaign et Campaign Manifest ;
- Mission Manifest ;
- Entry, Exit et Synchronization Gates ;
- décisions `GO`, `GO_WITH_DEROGATION`, `NO_GO` ;
- Freeze, locks et états de blocage ;
- preuves, validations et certifications ;
- Context Engine et Mission Context Assembly ;
- tous les orchestrateurs et runtimes CEREBRAU présents ou futurs.

Les Work Packages ne sont pas inclus comme objet officiel de gouvernance. Toute projection Work Package future devra, si elle devient officielle, respecter le même principe.

## 4. Règles minimales d'architecture

### `NSB-RULE-001` — Runtime Core indépendant

Le Mission Runtime Core ne doit importer, consulter ni recalculer une décision PROGRAM pour accepter une mission.

Le PROGRAM peut borner l'autorité, les scopes et la classe de mission. Il ne peut pas rendre indisponible le moteur minimal nécessaire à sa propre remédiation.

### `NSB-RULE-002` — Recovery Lane obligatoire

Une voie d'exécution distincte, gouvernée et toujours disponible doit accepter exactement les classes suivantes :

1. `READ_ONLY`;
2. `EVIDENCE_PRODUCTION`;
3. `AUDIT`;
4. `CERTIFICATION_REMEDIATION`.

Cette voie reste disponible sous `NO_GO`, `BLOCKED`, `REWORK`, `FAILED` et `PROGRAM FREEZE`.

### `NSB-RULE-003` — Least privilege de la Recovery Lane

La Recovery Lane ne constitue pas un bypass général.

Par défaut :

- repository, code, scripts, manifests, données et runtime métier sont `READ_ONLY`;
- seules les zones de rapport, preuve et décision explicitement autorisées sont inscriptibles ;
- aucune Gate, décision LOT ou décision PROGRAM n'est modifiée automatiquement ;
- l'autorité, le motif, le scope, les entrées, les sorties et le résultat sont journalisés.

### `NSB-RULE-004` — Séparation entrée/sortie

Toute preuve doit être typée :

- `INPUT_EVIDENCE` : existe avant la mission ;
- `OUTPUT_EVIDENCE` : est produite par la mission ;
- `DERIVED_EVIDENCE` : est calculée après exécution ;
- `CERTIFICATION_DECISION` : est une sortie d'autorité.

Une `OUTPUT_EVIDENCE` ou une `CERTIFICATION_DECISION` ne peut jamais être une précondition de démarrage de son propre producteur.

### `NSB-RULE-005` — Baseline de certification non réflexive

Le rapport utilisé comme baseline d'autorité d'une Campaign doit être distinct du rapport de certification produit par cette Campaign.

Formellement :

```text
Campaign.authorityCertificationReport
  !=
any Campaign.currentOutputCertificationReport
```

L'égalité de chemin, d'identifiant logique ou de rôle doit être rejetée.

### `NSB-RULE-006` — Graphe typé global

Le validateur doit construire un graphe couvrant :

- missions ;
- Gates ;
- preuves d'entrée et de sortie ;
- validations ;
- certifications ;
- manifestes ;
- prérequis ;
- Context Assembly ;
- locks ;
- Freeze et décisions de levée.

Toute composante fortement connexe contenant une arête bloquante doit être rejetée avant activation.

Le simple contrôle du DAG `mission.dependsOn` est nécessaire mais insuffisant.

### `NSB-RULE-007` — Précondition et postcondition explicites

Une Gate ne doit jamais dépendre de sa propre validation comme précondition.

Le contrat doit distinguer :

```text
Preconditions → Mission Execution → Outputs → Validation → Gate Decision
```

La décision de Gate est toujours postérieure aux preuves qu'elle évalue.

### `NSB-RULE-008` — Isolation du rayon de blocage

L'invalidité d'un manifeste, d'une preuve ou d'une mission ne doit bloquer que :

- le nœud affecté ;
- ses dépendants transitifs ;
- les ressources réellement en conflit.

Elle ne doit pas bloquer une mission indépendante de lecture, audit, preuve ou réparation.

### `NSB-RULE-009` — Manifestes autonomes de récupération

Un manifeste de récupération ne doit pas dépendre :

- du manifeste qu'il doit réparer ;
- du rapport qu'il doit produire ;
- de la certification qu'il doit réévaluer ;
- d'un hash global mutable sans mécanisme de rebind gouverné.

Un Mission Manifest normal peut être référencé par une Campaign, mais son exécution de récupération doit conserver une voie autonome.

### `NSB-RULE-010` — Locks récupérables

Tout lock doit avoir :

- une condition de libération ;
- une expiration bornée ;
- une détection d'owner mort ;
- une voie d'annulation autorisée ;
- une reprise après crash ;
- une preuve de libération après `FAILED`, `REJECTED`, `CANCELLED` et timeout.

Aucun lock ne doit empêcher l'audit read-only du lock lui-même.

### `NSB-RULE-011` — Freeze avec exceptions obligatoires

Un `PROGRAM FREEZE` peut interdire :

- merge ;
- mutation métier ;
- mutation de ressource critique ;
- ouverture normale d'une Wave.

Il ne peut pas interdire :

- observation read-only ;
- production de rapports de diagnostic ;
- collecte de preuves ;
- audit du Freeze ;
- mission de préparation de levée ;
- certification de remédiation.

### `NSB-RULE-012` — Séparation exécution/certification

La Recovery Lane peut produire un dossier de certification, mais ne peut pas s'auto-certifier.

La séparation actuelle entre exécution et validation finale est conservée :

- l'agent produit ;
- le Runtime rapporte ;
- le validateur contrôle ;
- l'autorité décide.

Le principe empêche le blocage de la production de preuve ; il ne réduit pas l'exigence d'autorité.

## 5. États et autorisations minimales

| État PROGRAM/Gouvernance | Mission normale | Read-only | Preuve | Audit | Certification de remédiation |
|---|---:|---:|---:|---:|---:|
| `OPEN / GO` | Oui | Oui | Oui | Oui | Oui |
| `OPEN / NO_GO` | Selon Gates | Oui | Oui | Oui | Oui |
| `REWORK` | Selon dépendances | Oui | Oui | Oui | Oui |
| `BLOCKED` | Non si dépendante | Oui | Oui si ciblée | Oui | Oui si ciblée |
| `PROGRAM FREEZE` | Non | **Oui** | **Oui, bornée** | **Oui** | **Oui, bornée** |
| `FAILED` Campaign | Non via la Campaign échouée | **Oui via Recovery Lane** | **Oui via Recovery Lane** | **Oui** | **Oui** |

## 6. Autorité et non-contournement

Le principe ne permet pas :

- de transformer un `NO_GO` en `GO` ;
- de modifier une Gate sans décision autorisée ;
- d'ignorer une preuve incompatible ;
- de contourner une revue humaine ;
- d'écrire hors scope ;
- de muter le Runtime métier sous couvert d'audit ;
- de remplacer une autorité documentaire par un transcript.

Il permet uniquement d'exécuter les travaux nécessaires pour rendre la décision future possible et probatoire.

## 7. Contrôles d'acceptation

La décision ne doit être déclarée implémentée qu'après réussite des scénarios suivants :

| Test | Précondition | Résultat requis |
|---|---|---|
| `NSB-T01` | `PROGRAM = NO_GO` | Mission `READ_ONLY` exécutée, rapports produits |
| `NSB-T02` | `PROGRAM FREEZE` | Audit du Freeze exécuté sans mutation métier |
| `NSB-T03` | Preuve de Gate absente | Mission de preuve démarre sans cette preuve comme entrée |
| `NSB-T04` | Rapport de certification absent | Mission de certification démarre avec baseline distincte |
| `NSB-T05` | Authority hash drift | Mission de diagnostic/rebind indépendante exécutée |
| `NSB-T06` | Un manifeste unitaire invalide | Mission indépendante de récupération reste exécutable |
| `NSB-T07` | Cycle Gate→preuve→mission→Gate | Activation rejetée avec chemin de cycle explicite |
| `NSB-T08` | Mission Runtime TS échoue | Lock libéré, expiré ou récupérable selon contrat |
| `NSB-T09` | Context Engine PROGRAM provider absent | Reconstruction retourne alertes sans indisponibilité globale |
| `NSB-T10` | Context Assembly Campaign échoue | Rapport d'échec produit et voie unitaire read-only disponible |
| `NSB-T11` | Mission de remédiation soumise | Elle ne modifie aucune décision de Gate automatiquement |
| `NSB-T12` | Deux orchestrateurs présents | Même matrice d'invariants NSB appliquée aux deux |

## 8. Conditions de passage

### De `NO GO` à `GO AVEC CONDITIONS`

Toutes les conditions suivantes sont requises :

1. principe approuvé dans la gouvernance officielle ;
2. Recovery Lane spécifiée avec autorité et scopes ;
3. Freeze amendé avec exceptions obligatoires ;
4. preuves entrée/sortie séparées ;
5. contrôle de cycle global spécifié ;
6. stratégie de recovery des locks approuvée ;
7. tests `NSB-T01` à `NSB-T08` automatisés et PASS.

### De `GO AVEC CONDITIONS` à `GO`

Toutes les conditions suivantes sont requises :

1. tests `NSB-T01` à `NSB-T12` PASS sur chaque runtime/orchestrateur actif ;
2. démonstration sur une Campaign `NO_GO` réelle ;
3. démonstration sous Freeze contrôlé ;
4. absence d'écriture hors scopes de récupération ;
5. revue humaine et décision d'autorité ;
6. graphe de dépendances publié et sans SCC bloquante.

## 9. Décision recommandée

```text
NON SELF-BLOCKING PRINCIPLE = ADOPT
CURRENT GUARANTEE = NOT SATISFIED
CURRENT VERDICT = NO GO
TARGET AFTER RULES + TESTS = GO AVEC CONDITIONS
TARGET AFTER OPERATIONAL PROOF = GO
```

La règle prioritaire est simple : **une décision peut bloquer le passage à `GO`, mais elle ne doit jamais bloquer la production des preuves nécessaires à sa propre révision.**

