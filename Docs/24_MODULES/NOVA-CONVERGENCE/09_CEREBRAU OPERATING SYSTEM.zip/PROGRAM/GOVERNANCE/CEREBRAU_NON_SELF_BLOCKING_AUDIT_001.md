# CEREBRAU — Non Self-Blocking Audit 001

> Mission : `CEREBRAU-MISSION-RUNTIME-GOVERNANCE-001`  
> Programme : `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001`  
> Type : `AUDIT_READ_ONLY`  
> Date d'audit : `2026-07-23`  
> Verdict : **NO GO**

## 1. Décision exécutive

L'architecture actuelle sait exécuter une mission alors que la décision de certification du PROGRAM est `NO_GO`. Ce fait est démontré à la fois par le Runner, par ses tests et par la campagne courante.

Elle ne garantit toutefois pas qu'une mission nécessaire à la levée d'un blocage reste toujours exécutable. Trois chemins d'auto-blocage sont présents :

1. la doctrine `PROGRAM FREEZE` interdit toute Mission Order et suspend la certification sans réserver de voie `READ_ONLY`, audit, preuve ou certification de levée ;
2. le preflight d'une Campaign exige avant toute mission le rapport de certification d'autorité, tous les manifestes unitaires et les preuves partagées avec leurs hashes ; une mission chargée de créer ou rafraîchir l'un de ces objets peut donc être bloquée par l'objet qu'elle doit produire ;
3. l'Orchestrator Runtime TypeScript conserve un lock actif après `FAILED` et n'expose pas de voie publique de libération, d'expiration ou d'annulation dans le service observé.

Le DAG courant de la Master Gates Matrix n'est pas circulaire : extraction statique de `44` nœuds `MM-*`, `60` arêtes explicites `MM-* → MM-*`, `0` cycle. Le validateur de Campaign rejette aussi les cycles de `dependsOn`. Ces contrôles locaux ne couvrent pas les cycles transverses entre Freeze, Gate, certification, preuve, manifeste, Context Assembly et locks.

Le verdict est donc **NO GO pour la garantie de non-auto-blocage**. Il ne signifie ni que la fondation est indisponible, ni que le PROGRAM courant est incapable de toute exécution.

## 2. Faits certifiés et frontière de l'audit

Les faits fournis à la mission sont retenus sans réinterprétation :

| Fait certifié | Valeur retenue | Effet sur l'audit |
|---|---|---|
| Objet officiel de gouvernance | `WAVE` | La Wave est utilisée dans le graphe officiel. |
| Work Packages | `NOT_OFFICIAL` | Les Work Packages sont exclus de la chaîne normative et exécutable. |
| Fondation | `FOUNDATION_READY = true` | Le verdict ne remet pas en cause la fondation. |
| Modèle Wave | `CANONICAL_WAVE_MODEL = true` | Le modèle Wave est la référence de gouvernance. |
| Contrat `MM-L01-03` | `CANONICAL_MM_L01_03_CONTRACT = true` | Le contrat est traité comme canonique ; son exécution partielle n'invalide pas son identité. |

L'audit porte sur :

- le runtime unitaire PowerShell ;
- le Campaign Runner ;
- l'Orchestrator Runtime TypeScript ;
- le Knowledge Runtime TypeScript ;
- le Context Engine TypeScript ;
- le Mission Context Assembly PowerShell ;
- la gouvernance PROGRAM/Wave/Mission/Gate ;
- les manifestes, preuves, validations et décisions de certification.

Il ne modifie ni code, ni script, ni manifeste, ni Runtime. Le seul test exécuté est un test existant, isolé dans un répertoire temporaire : `Test-CampaignIntegration.ps1`, résultat `6/6 PASS`.

## 3. Architecture réellement observée

Trois chaînes ne doivent pas être confondues :

| Chaîne | Point d'entrée | Dépendance PROGRAM | Usage observé |
|---|---|---|---|
| Mission Runtime | `tools/cerebrau/Invoke-CerebrauMission.ps1` | `program` est une identité de rapport ; aucune décision `GO/NO_GO` n'est consultée | Exécution unitaire effective |
| Campaign Runner | `tools/cerebrau/Invoke-CerebrauCampaign.ps1` puis `Cerebrau.Campaign.psm1` | Couplage fort à `programId`, à l'autorité, à son hash et à un rapport de certification | Orchestration effective |
| Orchestrator Runtime TypeScript | `server/cerebrau-runtime/orchestrator-runtime/**` | Aucun champ PROGRAM ; clé `projectId/missionId` | Tests TypeScript, aucun appel de production trouvé depuis le Campaign Runner |

Le Context Engine TypeScript est encore une quatrième chaîne. Il reconstruit un état à dix providers et consomme des documents PROGRAM, mais ses erreurs de provider deviennent des alertes : elles n'interrompent pas la boucle de reconstruction (`context.service.ts:24-78`). Il n'est pas appelé par le Campaign Runner.

Le contexte de mission effectif est `Cerebrau.ContextAssembly.psm1`, optionnel. En mode Campaign, il exige le Campaign Manifest, la source d'autorité, son rapport de certification et les preuves applicables (`Cerebrau.ContextAssembly.psm1:155-197`). Sans `-ContextAssemblyEnabled`, le runtime unitaire n'en dépend pas.

## 4. Audit des six axes

### Axe 1 — Dépendances circulaires

#### Cycles rejetés ou absents

| Périmètre | Résultat | Preuve |
|---|---|---|
| DAG courant des micro-missions | `PASS` | Analyse statique : 44 nœuds, 60 arêtes `MM→MM`, 0 cycle. |
| `dependsOn` d'une Campaign | `PASS` | Tri de Kahn et rejet `CAMPAIGN_DEPENDENCY_CYCLE`, `Cerebrau.Campaign.psm1:214-247`. |
| Import Runtime TypeScript → PROGRAM | `PASS` | Aucun import de module PROGRAM dans `server/cerebrau-runtime/**`. |
| Context Engine → Mission Runtime | `PASS` | Aucun appel du moteur TypeScript par le Runner ; chaîne distincte. |

#### Cycles effectifs ou réalisables

| ID | Boucle | État | Impact |
|---|---|---|---|
| `NSB-CYCLE-001` | `PROGRAM FREEZE → interdit Mission/audit/certification → preuve de levée non produite → FREEZE non levé` | **Effectif dans la doctrine** | Auto-blocage total possible. |
| `NSB-CYCLE-002` | `Campaign preflight → certificationReportPath doit exister → mission de certification non lancée → rapport non produit` | **Réalisable** | La campagne de remédiation peut être inexécutable. |
| `NSB-CYCLE-003` | `Campaign preflight → sharedEvidence doit déjà être présente et hashée → mission de preuve non lancée → preuve non produite` | **Réalisable** | Une preuve ne peut pas être à la fois sortie à créer et entrée globale obligatoire. |
| `NSB-CYCLE-004` | `manifest authority hash drift → preflight échoue → aucune mission ne démarre → aucune mission gouvernée ne peut réconcilier le manifeste/autorité` | **Observé sur LOT-002**, échappatoire directe seulement technique | Blocage de toutes les missions, même indépendantes. |
| `NSB-CYCLE-005` | `échec mission TS → état FAILED → lock reste ACTIVE → mission corrective même scope ne peut acquérir le lock` | **Présent dans le code TS** | Auto-blocage du runtime jusqu'à reconstruction de l'instance. |
| `NSB-CYCLE-006` | `invalidité d'un manifeste unitaire → Campaign entière invalide → mission indépendante non lancée` | **Réalisable et by design** | Rayon de blocage supérieur au sous-graphe affecté. |

Le contrôle actuel est donc un contrôle de DAG local, non un contrôle de graphe de gouvernance étendu.

### Axe 2 — Capacités d'un PROGRAM en `NO_GO`

| Capacité | Technique | Gouvernance courante | Verdict |
|---|---|---|---|
| Lancer une mission `READ_ONLY` | Le schéma accepte `READ_ONLY_EVIDENCE`; le test d'intégration avec `programDecision=NO_GO` passe | Autorisé tant qu'aucun Freeze ou ordre exclusif contradictoire ne l'interdit | **PASS conditionnel** |
| Produire des preuves | Le runtime écrit journal et rapports avant classification ; les validations de livrables sont postérieures à l'exécution | Bloqué si la preuve à produire est déclarée comme `sharedEvidence` préalable | **PASS conditionnel** |
| Lancer un audit | Aucune whitelist de `missionType`; un audit peut être une mission read-only | Aucune classe d'exception audit n'existe pendant Freeze | **NON GARANTI** |
| Lancer une mission de certification | Un manifeste tel que `MM-L02-04.json` est techniquement exécutable et valide ses sorties après exécution | Une Campaign exige déjà un `certificationReportPath`; le Freeze suspend la certification | **NON GARANTI** |

Preuves positives :

- la Campaign Wave 001 déclare `programDecision: NO_GO` et son état persistant contient `MISSION_STARTED` ;
- `Test-CampaignIntegration.ps1` confirme `program-no-go-preserved` et l'exécution d'une mission indépendante ;
- le Runner conserve la décision PROGRAM comme donnée déclarée et ne la transforme pas en décision de Gate (`Cerebrau.Campaign.psm1:777-811`).

Limite déterminante :

- `PROGRAM_WAVE_ORCHESTRATION.md:541-553` interdit toute Mission Order et suspend la certification pendant Freeze ;
- `PROGRAM_WAVE_ORCHESTRATION.md:722-724` indique, pour la Wave courante, que le Campaign Manifest seul déclenche les missions et qu'aucun lancement manuel n'est autorisé.

Le chemin direct du Mission Runtime est donc une échappatoire technique, pas une voie de gouvernance garantie.

### Axe 3 — Une Gate dépend-elle de sa propre validation ?

Le graphe `dependsOn` courant ne contient aucune auto-arête et aucune boucle. Le Campaign Runner impose aussi l'unicité des `gateId` et rejette une auto-dépendance de mission.

Deux formulations restent sémantiquement réflexives :

- `L01-G06` exige que chaque Gate active possède owner, décision, preuves et horodatage, alors que `MM-L01-03` doit créer la première ligne conforme du registre ;
- `L10-G06` exige un dossier final portant une décision signée, et `MM-L10-05` est précisément la mission de décision finale.

Ces formulations sont exécutables si la décision est une **sortie** évaluée après production. Elles deviennent auto-bloquantes si un orchestrateur les interprète comme une **précondition**.

Le Gate Adapter actuel ne vérifie que le mapping `MissionId → GateId` et les dépendances `MM-*` (`Cerebrau.Campaign.psm1:371-379`). Il ne modélise pas :

- `GateProducesEvidence`;
- `EvidenceValidatesGate`;
- `CertificationDecidesGate`;
- la différence entre précondition et sortie.

Verdict de l'axe : **aucune auto-dépendance explicite courante, mais absence de garantie architecturale**.

### Axe 4 — Dépendance entre manifestes

Le manifeste unitaire est directement validable et exécutable sans Campaign Manifest (`Test-CerebrauMission.ps1:8-149`; `Invoke-CerebrauMission.ps1:155-181`).

Le Campaign Manifest dépend en revanche de tous les manifestes unitaires qu'il référence :

- `missionFile` est obligatoire ;
- chaque fichier doit exister ;
- chaque unité doit être lisible, cohérente et acceptée par `Test-CerebrauMission.ps1`;
- un seul échec invalide le preflight entier avant toute mission (`Cerebrau.Campaign.psm1:335-369`).

Il n'existe pas de dépendance réciproque obligatoire `Mission Manifest → Campaign Manifest` en mode direct. Avec `ContextAssemblyEnabled`, le contexte d'une mission de Campaign relit toutefois le Campaign Manifest.

Verdict :

- indépendance d'un **Mission Manifest** : **PASS** ;
- critère littéral « aucun manifeste ne dépend d'un autre manifeste » : **FAIL** au niveau Campaign ;
- cycle manifeste↔manifeste courant : **non observé** ;
- isolation d'une mission indépendante face à un autre manifeste invalide : **non garantie**.

### Axe 5 — Une mission de preuve est-elle bloquée par la certification qu'elle doit démontrer ?

Dans le runtime unitaire, non :

- les validations `fileExists`, `utf8`, commandes et delta sont exécutées après Codex (`Invoke-CerebrauMission.ps1:343-365`) ;
- l'absence du livrable attendu n'empêche donc pas le démarrage de la mission chargée de le créer.

Dans le Campaign Runner, oui si le contrat est mal composé :

- `authority.certificationReportPath` doit exister avant toute mission (`Cerebrau.Campaign.psm1:303-304`) ;
- chaque `sharedEvidence` est hashée au preflight et tout statut non `VALID` bloque le Start (`Cerebrau.Campaign.psm1:382-389`) ;
- le scheduler ne distingue pas preuve d'entrée et preuve à produire.

La campagne LOT-002 fournit un cas concret de blocage pré-mission : `CAMPAIGN_AUTHORITY_HASH_MISMATCH`, quatre missions `PENDING`, zéro tentative, alors qu'elle contient la mission de certification `MM-L02-04`.

Verdict de l'axe : **PASS unitaire, FAIL Campaign/global**.

### Axe 6 — Indépendance du Runtime par rapport au PROGRAM

| Composant | Constat | Verdict |
|---|---|---|
| Mission Runtime PowerShell | Ne consulte ni statut opérationnel ni décision de certification PROGRAM ; `program` sert à l'identité et au rapport | **Indépendant pour l'exécution** |
| Knowledge Runtime TypeScript | Pipeline scanner/classifier/register/index/validator sans import PROGRAM | **Indépendant** |
| Orchestrator Runtime TypeScript | Modèle `projectId/missionId`, aucune entité PROGRAM | **Indépendant du PROGRAM**, mais lock failure unsafe |
| Context Engine TypeScript | Provider PROGRAM documentaire, erreur convertie en alerte | **Dépendance de contexte non bloquante** |
| Campaign Runner | Exige `programId`, authority source/hash, certification report et programDecision ; état lié à cette frontière | **Couplé au PROGRAM** |
| Mission Context Assembly en Campaign | Relit Campaign, authority certification et preuves | **Couplé conditionnellement** |

Le Runtime d'exécution unitaire reste indépendant de la décision PROGRAM. La chaîne officiellement exclusive de la Wave passe néanmoins par un orchestrateur couplé au PROGRAM. La propriété globale « Runtime indépendant du PROGRAM » est donc **partiellement vraie, non garantie end-to-end**.

## 5. Constats complémentaires

### 5.1 Deux orchestrateurs aux invariants différents

Le Campaign Runner PowerShell est le dispatcher effectif. L'Orchestrator Runtime TypeScript possède une seconde machine d'état, des locks, une queue et des validations, mais aucun appel de production trouvé depuis la chaîne Campaign.

Cette duplication crée un risque de gouvernance :

- le Runner PowerShell rejette les cycles de DAG et récupère un lock Campaign orphelin par PID ;
- le Runtime TypeScript n'a pas de modèle de DAG dans `MissionDefinition` et ne libère le lock qu'en `ACCEPTED`, `REJECTED` ou `CANCELLED` ;
- les garanties de l'un ne prouvent pas celles de l'autre.

### 5.2 Freeze et NO_GO sont deux concepts différents

Le dépôt démontre correctement qu'un statut opérationnel `OPEN` peut coexister avec une décision de certification `NO_GO`. Cette séparation est saine.

Le Freeze annule toutefois cette séparation en interdisant toute mission, y compris celles sans mutation. La doctrine ne définit pas :

- une `RECOVERY_LANE`;
- une `EVIDENCE_LANE`;
- une mission `READ_ONLY` exemptée ;
- l'autorité et les scopes permettant de lever le Freeze ;
- un délai ou une expiration.

### 5.3 Le fail-closed est nécessaire mais trop global

Le contrôle de hash d'autorité est justifié : un moteur ne doit pas exécuter sous une autorité modifiée silencieusement. Le défaut n'est pas le fail-closed ; c'est l'absence d'une voie gouvernée, bornée et indépendante permettant :

- de constater le drift ;
- de produire le diff ;
- de réconcilier l'autorité ;
- de revalider le manifeste ;
- de relancer uniquement les missions affectées.

## 6. Registre des risques

| Risque | Sévérité | Probabilité | Fait déclencheur | Condition de fermeture |
|---|---:|---:|---|---|
| Freeze irréversible par les outils gouvernés | Critique | Moyenne | Audit/certification nécessaires pendant Freeze | Exception officielle read-only/evidence/certification |
| Certification exigée avant mission de certification | Critique | Élevée | Rapport absent, à créer ou périmé | Séparer baseline d'autorité et sortie de certification |
| Preuve exigée avant mission de preuve | Critique | Élevée | Même EvidenceId utilisé comme entrée et sortie | Typage `INPUT_EVIDENCE` / `OUTPUT_EVIDENCE` |
| Lock TS orphelin après échec | Haute | Moyenne | `ExecutionFailed → FAILED` | Release/expiry/recovery déterministe |
| Unité invalide bloque toute Campaign | Haute | Élevée | Un manifeste ou prompt invalide | Preflight par sous-graphe + rescue lane |
| Couplage Campaign à un hash global mutable | Haute | Élevée | Toute évolution de la matrice | Version d'autorité immuable + rebind gouverné |
| Absence de contrôle des cycles transverses | Haute | Moyenne | Nouvelle Gate/preuve/certification | Graphe typé et détecteur de SCC |
| Divergence entre deux orchestrateurs | Haute | Moyenne | Évolution séparée TS/PowerShell | Autorité runtime unique ou invariants contractuels communs |

## 7. Conditions minimales de levée du NO GO

Le verdict pourra devenir `GO AVEC CONDITIONS`, puis `GO`, lorsque les éléments suivants seront officialisés et prouvés :

1. adoption normative du `Non Self-Blocking Principle` ;
2. définition d'une voie de récupération exécutable en `NO_GO`, `BLOCKED`, `REWORK` et `PROGRAM FREEZE` ;
3. autorisation minimale de quatre classes : `READ_ONLY`, `EVIDENCE_PRODUCTION`, `AUDIT`, `CERTIFICATION_REMEDIATION` ;
4. distinction machine entre preuve d'entrée et preuve de sortie ;
5. interdiction qu'un `certificationReportPath` de préflight désigne la sortie de la campagne courante ;
6. contrôle de cycle sur le graphe typé complet, pas seulement `mission.dependsOn` ;
7. isolation du preflight : une unité invalide ne bloque pas une mission indépendante de récupération ;
8. libération/expiration/reprise prouvée de tout lock après échec ;
9. preuve que le Runtime unitaire reste exécutable sans lecture d'une décision PROGRAM ;
10. tests négatifs démontrant qu'une Gate, un Freeze, un drift d'autorité et une preuve manquante ne peuvent bloquer leur propre remédiation.

## 8. Verdict final

```text
CURRENT MICRO-MISSION DAG CIRCULAR = NO
CAMPAIGN DEPENDSON CYCLE DETECTION = YES
PROGRAM NO_GO CAN EXECUTE MISSIONS = YES
READ_ONLY UNDER NO_GO = YES, CONDITIONALLY
AUDIT UNDER FREEZE = NOT GUARANTEED
CERTIFICATION REMEDIATION UNDER FREEZE = NOT GUARANTEED
MISSION MANIFEST DIRECTLY EXECUTABLE = YES
CAMPAIGN MANIFEST INDEPENDENT OF UNIT MANIFESTS = NO
PROOF MISSION FREE FROM ITS OWN CERTIFICATION = NO, NOT GLOBALLY
UNIT RUNTIME INDEPENDENT OF PROGRAM DECISION = YES
END-TO-END RUNTIME INDEPENDENT OF PROGRAM = NO
NON SELF-BLOCKING GUARANTEE = NO

FINAL VERDICT = NO GO
```

