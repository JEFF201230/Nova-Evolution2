# Lots techniques d'implémentation Offer V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Mission | `PROGRAM-OFFER-IMPLEMENTATION-ROADMAP-001` |
| Objet officiel de gouvernance | `WAVE` |
| Lots | 8 lots de construction + 1 lot transverse |
| Couverture | 21/21 briques, une affectation principale par brique |

## 1. Statut des lots

Ces lots sont des unités techniques de planification internes à une `WAVE`.
Ils ne sont pas officiels au sens de la gouvernance, ne remplacent pas la
`WAVE` et ne constituent pas des Work Packages.

Le regroupement optimise :

1. la fermeture précoce des risques de sécurité et de cycle ;
2. des diffs bornés par couche fonctionnelle ;
3. des sorties compilables et testables ;
4. la valeur métier incrémentale ;
5. la réutilisation des contrats avant les consommateurs ;
6. l'absence de rupture grâce à l'additivité et aux bascules réversibles.

## 2. Couverture

| Lot | Briques | Nombre | Dépendances d'entrée | Gate |
|---|---|---:|---|---|
| `LOT-T` | `BR-020` | 1 | aucune au démarrage ; lots 6 à 8 pour clôture | `IG-T` |
| `LOT-01` | `BR-021` | 1 | faits certifiés, `X-07` | `IG-01` |
| `LOT-02` | `BR-015`, `BR-014` | 2 | faits certifiés, `X-03` pour le mapping de capacités | `IG-02` |
| `LOT-03` | `BR-007`, `BR-008`, `BR-009`, `BR-003`, `BR-013` | 5 | `BR-014` pour clôturer `BR-013`, `X-02`, `X-05` | `IG-03` |
| `LOT-04` | `BR-001`, `BR-002`, `BR-005`, `BR-006`, `BR-004`, `BR-010` | 6 | `IG-03 PASS` | `IG-04` |
| `LOT-05` | `BR-011`, `BR-012` | 2 | `IG-02`, `IG-03`, `IG-04`, `X-03` | `IG-05` |
| `LOT-06` | `BR-016`, `BR-017` | 2 | `IG-01`, `IG-02`, `IG-03`, `X-04` | `IG-06` |
| `LOT-07` | `BR-018` | 1 | `IG-06`, `X-05` | `IG-07` |
| `LOT-08` | `BR-019` | 1 | `IG-07`, `X-05`, `X-06` | `IG-08` |
| **Total** |  | **21** |  |  |

## 3. Contrat commun d'autonomie

Un lot est autonome lorsque, une fois ses dépendances d'entrée acceptées :

- son périmètre de fichiers et de contrats est fermé avant développement ;
- il peut être compilé sans branche non livrée d'un autre lot ;
- ses fixtures et doubles de test ne créent aucune nouvelle autorité ;
- ses tests unitaires, contrat, intégration et non-régression sont exécutables
  indépendamment ;
- ses changements SQL éventuels sont additifs et applicables avant le code
  qui les utilise ;
- sa capacité est désactivable sans revenir sur les données déjà écrites ;
- son verdict peut être prononcé sans attendre un lot non dépendant ;
- son déploiement n'altère pas les parcours historiques non basculés.

Un lot échoue localement s'il compile seulement avec une modification hors
périmètre, s'il exige une bascule globale, ou si son rollback détruit des
données.

## 4. LOT-T — Transition continue

**Brique :** `V2-BR-020`.

**But :** appliquer le protocole de coexistence et de retrait à chaque
consommateur affecté par les lots 6 à 8, ainsi qu'aux sources frontend ou
financières legacy concernées.

**Entrées :**

- registre `X-04` des producteurs, consommateurs, données, métriques et owners ;
- mécanisme réversible identifié pour chaque bascule ;
- cible nouvelle déjà acceptée par sa Gate d'implémentation.

**Séquence par consommateur :**

1. inventorier sans mutation ;
2. livrer la source cible et le lineage ;
3. comparer les lectures ;
4. corriger et certifier la non-régression ;
5. basculer par flag/configuration ;
6. geler les nouvelles écritures legacy ;
7. observer au moins un cycle de release complet ;
8. retirer seulement sur décision `IG-T`.

**Compilation/testabilité :** les flags, adaptateurs temporaires et métriques
sont compilés et testés avec les deux chemins ; les tests prouvent qu'un seul
chemin est autoritatif à un instant donné.

**Protection production :** aucune suppression durant la fenêtre de rollback,
aucune double écriture permanente, retour au chemin précédent par configuration.

**Sortie :** matrice des consommateurs à zéro résidu, métriques sans divergence,
cycle d'observation achevé et retrait décidé.

## 5. LOT-01 — Fondation QF/Rights

**Brique :** `V2-BR-021`.

**But :** rendre reproductible et sécurisé le périmètre exact
`AF_QF_RIGHTS`.

**Périmètre strict :**

- `public.qf_active` ;
- `public.qf_config` ;
- `public.rights_config` ;
- `public.user_rights_projection` ;
- `public.compute_qf(uuid)`.

**Impacts autorisés :** DDL versionné, contraintes, index, RLS,
policies, grants/revokes, tests et rollback nécessaires à ces cinq objets.

**Compilation/testabilité :**

- application sur base vierge et base représentative ;
- tests de contrat RPC et consommateurs QF/Rights ;
- tests tenant, rôles et accès interdits ;
- rollback ou correction forward démontrable ;
- aucun objet hors périmètre muté.

**Protection production :** migration testée hors production, privilèges
restrictifs, compatibilité des consommateurs existants, aucune activation Offer.

**Sortie :** `IG-01 PASS`.

## 6. LOT-02 — Cycle Offer sécurisé

**Briques :** `V2-BR-015`, puis `V2-BR-014`.

**But :** fermer la frontière de confiance avant d'introduire l'activation.

**Incréments :**

1. matrice invariant → source autoritative → repository → verrou → erreur ;
2. résolution transactionnelle des préconditions ;
3. état `ACTIVE`, commande `ActivateOffer`, événement `OfferActivated` ;
4. adaptation additive des read models, persistance, audit, outbox, API et
   OpenAPI ;
5. tests de cycle, date, idempotence, concurrence et absence d'effet aval.

**Compilation/testabilité :** le serveur compile avec les contrats v1
conservés ; les suites prouvent que les booléens client ne font pas foi et que
`PUBLISHED` seul n'est pas distribuable.

**Protection production :** nouveau parcours derrière activation contrôlée,
ancienne lecture tolérée jusqu'à bascule `LOT-T`, migration additive séparée.

**Sortie :** `IG-02 PASS`.

## 7. LOT-03 — Contrats Offer V2

**Briques :** `V2-BR-007`, `V2-BR-008`, `V2-BR-009`, `V2-BR-003`,
`V2-BR-013`.

**But :** fournir le vocabulaire versionné et le contrat OfferVersion v2 avant
les objets qui le consomment.

**Incréments :**

1. forme et version du `CompositionContract` ;
2. vocabulaires fermés de `CompositionRules` et `CompatibilityRules` ;
3. types `OfferCharacteristic` ;
4. contrat OfferVersion v2 : identité produit, période, références Rights,
   Budget et Dotation, version de schéma et lineage ;
5. lecteur explicite des versions pré-v2.

**Compilation/testabilité :** sérialisation stable, compatibilité ascendante et
descendante prévue par contrat, fixtures v1/v2, aucun calcul QF/Rights/Finance.

**Protection production :** champs additifs/nullable ou enveloppe versionnée,
aucun backfill sémantique, anciennes commandes maintenues.

**Sortie :** `IG-03 PASS`.

## 8. LOT-04 — Composants et composition

**Briques :** `V2-BR-001`, `V2-BR-002`, `V2-BR-005`, `V2-BR-006`,
`V2-BR-004`, `V2-BR-010`.

**But :** construire le noyau de composition dans le bounded context Offer.

**Incréments :**

1. `BusinessComponent` et son cycle ;
2. `ComponentVersion` et son immutabilité ;
3. configuration conforme au schéma et référence exacte ;
4. snapshot `OfferComposition` et empreinte ;
5. validation déterministe sans effet ;
6. repositories, audit/outbox, RLS et mapping additifs nécessaires.

**Compilation/testabilité :** tests Domain, Application, API et PostgreSQL ;
référence `latest` interdite ; déterminisme et absence d'import/call vers les
domaines protégés prouvés.

**Protection production :** nouvelles structures déployées avant les commandes,
composition nullable pour l'historique, feature désactivée par défaut.

**Sortie :** `IG-04 PASS`.

## 9. LOT-05 — Projection et Workbench

**Briques :** `V2-BR-011`, `V2-BR-012`.

**But :** rendre le noyau administrable sans créer de logique ou de catalogue
autoritatif côté client.

**Incréments :**

1. projection reconstruisible de bibliothèque ;
2. queries et pagination/filtrage serveur ;
3. Workbench lecture seule ;
4. édition de draft et validation ;
5. commandes de review, validation, publication et activation par capacité ;
6. historique, erreurs, conflits, accessibilité et audit.

**Compilation/testabilité :** build client/serveur, tests de contrats API,
RBAC/SOD, ETag/idempotence, double clic, accessibilité et E2E.

**Protection production :** activation par cohorte : lecture, édition,
validation, puis cycle ; aucune écriture directe Supabase/PostgreSQL.

**Sortie :** `IG-05 PASS`.

## 10. LOT-06 — Distribution et Rights

**Briques :** `V2-BR-016`, `V2-BR-017`.

**But :** propager les changements Offer et produire des décisions Rights
traçables sans déplacer le moteur.

**Incréments :**

1. enveloppe d'événement versionnée ;
2. dispatcher supervisé at-least-once ;
3. idempotence, ordre, retry et replay ;
4. query autoritative de bootstrap/réconciliation ;
5. lineage complet Rights et invalidation sur suspension/fermeture ;
6. EBS distribue le résultat, sans forcer `available=true`.

**Compilation/testabilité :** tests multi-tenant, doublons, désordre, panne,
replay, bootstrap, suspension et SLO ; contrats QF/Rights de `LOT-01`
réutilisés.

**Protection production :** consommation en shadow/read-compare, bascule par
consommateur via `LOT-T`, alerte avant autorité du nouveau chemin.

**Sortie :** `IG-06 PASS`.

## 11. LOT-07 — Finance causale

**Brique :** `V2-BR-018`.

**But :** donner une origine Offer/Version/Budget à tout nouveau flux financier
concerné.

**Incréments :**

1. contrat causal et clé idempotente ;
2. handoff backend Subvention/Budget/Ledger ;
3. ajouts de lineage sans réécrire l'historique ;
4. lecture du lineage dans le Cockpit ;
5. rapprochement du producteur legacy avant gel.

**Compilation/testabilité :** tests de réservation, libération, attribution,
consommation, paiement et remboursement ; absence de double mouvement ;
historiques sans preuve marqués legacy/unattributed.

**Protection production :** écriture autoritative unique dans
`budget_ledger`, lecture comparée, bascule et gel par `LOT-T`.

**Sortie :** `IG-07 PASS`.

## 12. LOT-08 — Dotation

**Brique :** `V2-BR-019`.

**But :** implémenter l'attribution et la délivrance d'un avantage autorisé
dans la frontière Dotation déjà certifiée.

**Entrées spécifiques :**

- OfferVersion active ;
- décision Rights éligible et traçable ;
- référence Budget valide ;
- owner d'exploitation nommé.

**Compilation/testabilité :** contrats de handoff, idempotence, reprise,
tenant, concurrence, absence de ledger/catalogue/éligibilité parallèles et
tests E2E jusqu'à la demande de mouvement financier.

**Protection production :** exposition progressive, aucun mouvement direct
hors contrats Budget/Ledger, rollback logique sans suppression de décisions.

**Sortie :** `IG-08 PASS`, puis clôture finale de `LOT-T` après observation.

## 13. Matrice de non-régression commune

| Surface | Garantie exigée à chaque lot |
|---|---|
| Compilation | Paquets affectés et consommateurs de contrats compilent |
| Tests existants | Aucune suite antérieure rouge ou désactivée sans justification acceptée |
| API | Contrats v1 maintenus selon politique ; erreurs stables et non sensibles |
| SQL | Migrations additives, ordre reproductible, contraintes/RLS testés |
| Historique | OfferVersions, Operations et mouvements historiques non réécrits |
| Sécurité | Tenant, rôle, SOD, idempotence et concurrence préservés |
| Domaines protégés | Aucune autorité déplacée et aucun effet interdit |
| Production | Feature désactivable, bascule par cohorte/consommateur, métriques et rollback |

## 14. Règles d'arrêt

Un lot s'arrête immédiatement en cas de :

- compilation impossible sans dépendance non acceptée ;
- migration destructive ou non reproductible ;
- mutation d'une version publiée ou d'un historique sans preuve ;
- disponibilité issue de `PUBLISHED` au lieu de `ACTIVE` ;
- booléen client utilisé comme preuve souveraine ;
- appel interdit à QF, Rights, Budget, Ledger, EBS ou Simulation ;
- fuite cross-tenant ou capacité IAM contournée ;
- double écriture non bornée ;
- impossibilité de revenir au chemin précédent ;
- régression d'un parcours de production non basculé.
