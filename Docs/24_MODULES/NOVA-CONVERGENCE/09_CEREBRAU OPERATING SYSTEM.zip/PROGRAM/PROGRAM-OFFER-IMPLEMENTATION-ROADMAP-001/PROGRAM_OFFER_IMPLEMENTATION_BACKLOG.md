# Backlog d'implémentation Offer V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Mission | `PROGRAM-OFFER-IMPLEMENTATION-ROADMAP-001` |
| Objet officiel de gouvernance | `WAVE` |
| Éléments | 21, correspondant exactement aux 21 briques certifiées |
| Estimation totale | 154 jours-personne idéaux + observation `BR-020` |

## 1. Convention de planification

Les estimations sont des ordres de grandeur pour implémentation, tests,
preuves et correction locale. Elles n'incluent pas les attentes
d'environnement, les validations externes, les congés, ni la marge programme.
Elles ne sont pas des faits certifiés.

| Priorité | Sens |
|---|---|
| `P0` | bloquant de sécurité, de cycle ou de fondation |
| `P1` | noyau nécessaire à la valeur Offer V2 |
| `P2` | opérabilité ou intégration aval nécessaire |
| `P3` | extension après le noyau |
| `P0-T` | contrôle transverse obligatoire avant toute bascule |

| Complexité | Fourchette indicative |
|---|---:|
| `M` | 3 à 5 j-p |
| `L` | 6 à 9 j-p |
| `XL` | 10 j-p ou plus |

## 2. Backlog priorisé

| ID | Brique | Priorité | Complexité | Estimation | Dépendances | Risques principaux | Critères d'acceptation |
|---|---|---:|---:|---:|---|---|---|
| `V2-BR-015` | Résolution autoritative des préconditions serveur | `P0` | `L` | 8 j-p | `X-01`, `X-03` | verrouillage incomplet ; preuve client encore acceptée ; erreur de concurrence ambiguë | Matrice invariant/source/repository complète ; preuves chargées dans la transaction ; payload falsifié sans effet ; tenant, SOD, idempotence et concurrence testés |
| `V2-BR-014` | Offer Activation | `P0` | `XL` | 10 j-p | `BR-015` | publication encore distribuable ; activation implicite ; effets aval non voulus | `ActivateOffer` explicite/idempotent ; `effectiveAt` respecté ; audit/outbox atomiques ; `PUBLISHED` non distribuable ; aucun effet Rights/Budget/Ledger/EBS/Operation |
| `V2-BR-021` | AF_QF_RIGHTS | `P0` | `XL` | 10 j-p | `X-07` | périmètre dépassé ; RLS/grants dangereux ; contrat RPC incompatible | Exactement quatre tables et `compute_qf(uuid)` ; base vierge et peuplée testées ; RLS/grants/RPC restreints ; consommateurs compatibles ; rollback/correction forward prouvé |
| `V2-BR-007` | CompositionContract | `P0` | `M` | 3 j-p | `X-01` | contrat trop ouvert ; version non traçable | Version, types, champs, cardinalités et références sérialisables ; validation stable ; fixtures compatibles ; aucun calcul de domaine protégé |
| `V2-BR-003` | OfferCharacteristic | `P1` | `M` | 3 j-p | `BR-007`, `X-02` | duplication d'une donnée souveraine ; type instable | Valeur typée sans identité autonome ; sérialisation déterministe ; immutabilité après publication ; catalogue produit gouverné utilisé |
| `V2-BR-008` | CompositionRules | `P1` | `M` | 4 j-p | `BR-007` | script libre ; règle non explicable | Vocabulaire fermé ; complétude, cardinalité, dépendance, exclusion et cohérence couvertes ; version de règle restituée dans le rapport |
| `V2-BR-009` | CompatibilityRules | `P1` | `M` | 5 j-p | `BR-007` | règle accordant un droit ; divergence de version | Compatibilités déterministes et versionnées ; incompatibilités structurées ; aucun appel/exécution du domaine référencé |
| `V2-BR-013` | Contrat typé OfferVersion v2 | `P0` | `L` | 8 j-p | `BR-003`, `BR-014`, `X-02`, `X-05` | référence non versionnée ; extension JSON souveraine ; historique réinterprété | Produit, période, règles, Budget, Dotation, schéma et lineage typés ; versions v1 lisibles ; aucune clé libre n'autorise activation/droit/finance |
| `V2-BR-001` | BusinessComponent | `P1` | `L` | 6 j-p | `BR-007` | second domaine/moteur ; agrégat cross-tenant | Agrégat Offer tenant-aware ; cycle et concurrence testés ; audit/outbox ; aucune logique ou donnée souveraine externe |
| `V2-BR-002` | ComponentVersion | `P1` | `L` | 6 j-p | `BR-001`, `BR-008`, `BR-009` | mutation d'une version publiée ; sélection flottante | Cycle `DRAFT/VALIDATED/PUBLISHED/SUPERSEDED` ; contenu immuable dès validation ; version exacte adressable ; règles publiées figées |
| `V2-BR-005` | ComponentConfiguration | `P1` | `M` | 3 j-p | `BR-002` | secret/solde/résultat incorporé ; schéma contourné | Validation contre la ComponentVersion exacte ; erreurs structurées ; aucun secret, binaire, calcul, solde ou état souverain |
| `V2-BR-006` | ComponentReference | `P1` | `M` | 3 j-p | `BR-002` | résolution `latest` ; transfert de souveraineté ; fuite tenant | IDs et version exacts ; référence opaque ; cross-tenant refusé ; relecture historique indépendante des versions futures |
| `V2-BR-004` | OfferComposition | `P1` | `M` | 5 j-p | `BR-003`, `BR-005`, `BR-006`, `BR-013` | snapshot incomplet ; ordre instable ; backfill inventé | Snapshot complet/ordonné/versionné ; empreinte stable ; attaché à une OfferVersion ; pré-composition explicite ; historique non modifié |
| `V2-BR-010` | CompositionValidation | `P1` | `L` | 7 j-p | `BR-002`, `BR-004`, `BR-008`, `BR-009` | non-déterminisme ; effet aval ; validation partielle | Même entrée = même rapport/empreinte ; toutes règles évaluées ; zéro mutation/appel externe ; erreurs et versions de règles restituées |
| `V2-BR-011` | BusinessComponentLibraryProjection | `P1` | `L` | 6 j-p | `BR-001`, `BR-002`, `BR-009` | projection autoritative ; données périmées ; catalogue frontend bis | Projection reconstructible ; filtres/pagination/tenant testés ; versions/cycles/compatibilités cohérents ; reconstruction sans perte d'autorité |
| `V2-BR-012` | CompositionWorkbench | `P2` | `XL` | 12 j-p | `BR-004`, `BR-010`, `BR-011`, `BR-013`, `BR-014`, `X-03` | logique métier côté client ; écriture directe ; SOD contournée | API-only ; rôles/capacités et auteur-validateur ; ETag/idempotence ; accessibilité ; double clic/conflit ; aucun appel QF/Rights/Finance/Simulation |
| `V2-BR-016` | Diffusion Offer vers Rights/EBS | `P1` | `XL` | 12 j-p | `BR-013`, `BR-014`, `BR-021`, `X-04`, contrôle `BR-020` | doublons/désordre ; événement perdu ; EBS devient moteur | Outbox atomique ; enveloppe versionnée ; at-least-once idempotent ; ordre/retry/replay ; query de bootstrap/réconciliation ; SLO et alertes mesurés |
| `V2-BR-017` | Lineage OfferVersion vers Rights | `P1` | `XL` | 10 j-p | `BR-013`, `BR-014`, `BR-016`, `BR-021`, contrôle `BR-020` | droits périmés ; EBS force la disponibilité ; historique maquillé | Toute nouvelle décision porte tenant/Offer/Version/règle/QF/instant/verdict/motif/causalité ; suspension invalide ; legacy marqué ; EBS ne force pas `available` |
| `V2-BR-018` | Lineage financier Offer/Budget/Ledger | `P2` | `XL` | 10 j-p | `BR-013`, `BR-017`, `X-05`, contrôle `BR-020` | double ledger ; double mouvement ; origine historique inventée | Nouveaux flux portent Offer/Version/Budget et IDs applicables ; clé idempotente ; `budget_ledger` cible ; Cockpit expose lineage ; historiques non attribués marqués |
| `V2-BR-019` | Bounded Context Dotation | `P3` | `XL` | 15 j-p | `BR-013`, `BR-017`, `BR-018`, `X-05`, `X-06`, contrôle `BR-020` | second ledger/catalogue/moteur Rights ; owner absent ; attribution dupliquée | Consomme Version active, décision Rights et Budget ; décision idempotente/traçable ; demande les mouvements au Ledger ; aucun catalogue/éligibilité/ledger parallèle |
| `V2-BR-020` | Protocole de coexistence et retrait legacy | `P0-T` | `L` | 8 j-p + observation | `X-04`, `X-07`; clôture après `BR-016` à `BR-019` | bascule globale ; coexistence permanente ; retrait prématuré | Inventaire par consommateur ; lecture comparée ; écarts corrigés ; flag réversible ; écritures legacy gelées ; cycle complet sans rollback ; retrait décidé par Gate |

## 3. Backlog par lot

| Lot | IDs | Charge | Valeur dominante |
|---|---|---:|---|
| `LOT-T` | `BR-020` | 8 j-p + observation | sûreté des bascules |
| `LOT-01` | `BR-021` | 10 j-p | fondation QF/Rights |
| `LOT-02` | `BR-015`, `BR-014` | 18 j-p | cycle Offer sécurisé |
| `LOT-03` | `BR-007`, `BR-008`, `BR-009`, `BR-003`, `BR-013` | 23 j-p | contrats typés |
| `LOT-04` | `BR-001`, `BR-002`, `BR-005`, `BR-006`, `BR-004`, `BR-010` | 30 j-p | noyau de composition |
| `LOT-05` | `BR-011`, `BR-012` | 18 j-p | opérabilité Back Office |
| `LOT-06` | `BR-016`, `BR-017` | 22 j-p | distribution et Rights |
| `LOT-07` | `BR-018` | 10 j-p | causalité financière |
| `LOT-08` | `BR-019` | 15 j-p | attribution/délivrance |
| **Total** | **21 briques** | **154 j-p + observation** |  |

## 4. Definition of Ready commune

Une ligne peut démarrer si :

- ses dépendances directes sont acceptées ;
- ses entrées `X-*` sont disponibles ;
- le périmètre de fichiers, contrats et tests est borné ;
- les critères d'acceptation de la ligne sont transformés en tests ;
- le chemin de déploiement additif et de désactivation est identifié ;
- la cible d'essai, les données de test et la collecte de preuves sont prêtes.

L'absence d'une entrée suspend uniquement la ligne concernée ; elle ne permet
ni d'inventer un contrat ni de modifier l'architecture.

## 5. Definition of Done commune

Une ligne est `DONE` lorsque :

1. l'implémentation respecte exactement la définition et la frontière de la
   brique ;
2. les paquets affectés compilent ;
3. les tests nouveaux et existants sont verts ;
4. les migrations éventuelles sont additives, reproductibles et testées ;
5. sécurité, tenant, rôles, idempotence et concurrence sont couverts selon la
   surface ;
6. les critères d'acceptation spécifiques sont prouvés ;
7. les parcours historiques et domaines protégés sont non régressés ;
8. l'exposition est désactivable et observable ;
9. la Gate du lot accepte les preuves.

## 6. Risques transverses

| Risque | Briques exposées | Réponse obligatoire |
|---|---|---|
| Rupture des contrats v1 | `BR-013`, `BR-014`, `BR-012` | extensions additives/versionnées et tests de fixtures historiques |
| Backfill sémantique | `BR-004`, `BR-013`, `BR-018` | marquage legacy/pre-composition, jamais d'origine inventée |
| Référence flottante | `BR-002`, `BR-006`, `BR-017` | IDs et versions exacts |
| Frontière de confiance client | `BR-014`, `BR-012` | `BR-015`, résolution serveur et tests de mensonge |
| Source UI concurrente | `BR-011`, `BR-012`, `BR-020` | queries autoritatives, suppression progressive des décisions locales |
| Propagation non convergente | `BR-016`, `BR-017` | idempotence, ordre, replay, query et SLO |
| Double autorité financière | `BR-018`, `BR-019`, `BR-020` | `budget_ledger` unique pour les nouveaux mouvements, bascule contrôlée |
| Fuite cross-tenant | toutes les briques persistées/API | RLS, contexte serveur, tests négatifs et audit |
