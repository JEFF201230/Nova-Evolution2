# Gates d'implémentation Offer V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Mission | `PROGRAM-OFFER-IMPLEMENTATION-ROADMAP-001` |
| Objet officiel de gouvernance | `WAVE` |
| Nombre de Gates | 8 Gates de construction + 1 Gate transverse |
| Portée | Implémentation, compilation, tests et non-régression uniquement |

## 1. Doctrine de Gate

Les Gates de ce document ne réauditent pas :

- le Registre Officiel des Briques V2 ;
- la Matrice Officielle de Certification Structurelle ;
- l'Infrastructure V2 figée ;
- l'architecture, la classification ou les frontières des briques ;
- les décisions D01 à D10 ;
- le caractère canonique de la WAVE ou du contrat `MM-L01-03`.

Elles répondent uniquement à quatre questions :

1. **Implémentation :** la brique certifiée est-elle matérialisée dans sa
   frontière exacte ?
2. **Compilation :** les unités affectées et leurs consommateurs compilent-ils ?
3. **Tests :** les preuves unitaires, contrat, intégration, sécurité et E2E
   requises réussissent-elles ?
4. **Non-régression :** les contrats, historiques, autorités et parcours
   existants restent-ils valides ?

Une Gate peut prononcer `PASS`, `FAIL` ou `BLOCKED_BY_EVIDENCE`. Elle ne peut
pas prononcer une décision architecturale.

## 2. Socle de preuves commun

Chaque Gate exige un paquet de preuves rattaché à un commit, une cible et une
WAVE :

| Preuve | Exigence |
|---|---|
| Périmètre | Diff borné aux briques et surfaces autorisées du lot |
| Compilation | Commandes, versions d'outils et résultat complet |
| Tests existants | Résultats avant/après ou baseline de référence et résultat du lot |
| Tests nouveaux | Liens entre critères d'acceptation et cas exécutés |
| SQL | Ordre, cible, application base vide/peuplée, RLS, rollback/correction forward |
| API | Contrat/OpenAPI, compatibilité v1, auth, tenant, erreurs, concurrence, idempotence |
| UI | Build, accessibilité, rôles, erreurs, double soumission et E2E si applicable |
| Runtime | Activation/désactivation, logs, métriques, retry/replay et SLO si applicable |
| Non-régression | Historique Offer/Operation/Finance et domaines protégés |
| Verdict | Écarts connus, responsable, date et décision `PASS/FAIL/BLOCKED_BY_EVIDENCE` |

L'absence d'une preuve obligatoire donne `BLOCKED_BY_EVIDENCE`; elle ne peut
pas être remplacée par une nouvelle analyse d'architecture.

## 3. IG-01 — Fondation QF/Rights

**Couvre :** `V2-BR-021`.

**Implémentation :**

- exactement quatre tables et la RPC `public.compute_qf(uuid)` ;
- contraintes, index, RLS, policies, grants/revokes nécessaires ;
- aucun objet Offer ni sixième objet QF/Rights ajouté.

**Compilation/tests :**

- migration sur base vide et base représentative ;
- contrat RPC et consommateurs QF/Rights ;
- accès autorisés, `anon`, cross-user, cross-tenant et rôle d'exécution ;
- rollback ou correction forward ;
- inventaire du diff SQL limité au périmètre.

**Non-régression :** fonctions QF/Rights existantes encore exécutables selon
leurs contrats ; aucune activation Offer ou disponibilité EBS créée.

**PASS si :** toutes les preuves sont vertes et le périmètre exact est
respecté.

## 4. IG-02 — Cycle Offer sécurisé

**Couvre :** `V2-BR-015`, `V2-BR-014`.

**Implémentation :**

- préconditions souveraines chargées côté serveur en transaction ;
- `ACTIVE`, `ActivateOffer`, `OfferActivated` et adaptations additives ;
- publication, activation et ouverture d'Operation distinctes.

**Compilation/tests :**

- packages Domain, Application, Infrastructure et API Offer ;
- transitions autorisées/refusées, `effectiveAt`, suspension/reprise ;
- mensonges client, rôle, tenant, SOD, idempotence et concurrence ;
- audit/outbox atomiques ;
- OpenAPI et read models alignés.

**Non-régression :**

- commandes v1 compatibles ;
- publication seule non distribuable sur le nouveau parcours ;
- aucune création Rights, Budget, Ledger, EBS, Execution ou Operation par
  activation.

**PASS si :** l'activation explicite est utilisable mais désactivable, sans
preuve client ni effet aval implicite.

## 5. IG-03 — Contrats Offer V2

**Couvre :** `V2-BR-007`, `V2-BR-008`, `V2-BR-009`, `V2-BR-003`,
`V2-BR-013`.

**Implémentation :**

- contrats versionnés, vocabulaires fermés et caractéristiques typées ;
- OfferVersion v2 porte les champs et références certifiés ;
- lecteur explicite des versions pré-v2.

**Compilation/tests :**

- sérialisation/désérialisation et empreintes de fixtures ;
- validation de types, règles et compatibilités ;
- DTO/API/OpenAPI additifs ou versionnés ;
- références versionnées et extensions non souveraines.

**Non-régression :**

- OfferVersions historiques inchangées ;
- `parameters`, `targetPopulation` et `externalReferences` encore lisibles
  selon la compatibilité décidée ;
- aucun calcul Rights, Budget, Dotation, QF ou Simulation.

**PASS si :** v1 et v2 coexistent, sans référence flottante ni champ libre
utilisé comme autorité.

## 6. IG-04 — Composants et composition

**Couvre :** `V2-BR-001`, `V2-BR-002`, `V2-BR-005`, `V2-BR-006`,
`V2-BR-004`, `V2-BR-010`.

**Implémentation :**

- agrégat BusinessComponent et versions ;
- configuration, référence exacte et snapshot ;
- validation déterministe sans effet ;
- persistance, audit/outbox et RLS additifs.

**Compilation/tests :**

- cycles, immutabilité et concurrence ;
- schémas, dépendances, exclusions, cardinalités et compatibilités ;
- référence exacte, cross-tenant et absence de `latest` ;
- base vide/peuplée, projection des données et rollback sûr ;
- déterminisme du rapport et de l'empreinte.

**Non-régression :**

- aucune OfferVersion publiée modifiée ;
- Operations historiques relues à l'identique ;
- aucune migration/écriture sur Rights, Budget, Ledger, EBS, QF ou Simulation ;
- aucune dépendance interdite vers un domaine protégé.

**PASS si :** une composition v2 peut être enregistrée et validée en mode
désactivé, tandis que les versions historiques restent inchangées.

## 7. IG-05 — Projection et Workbench

**Couvre :** `V2-BR-011`, `V2-BR-012`.

**Implémentation :**

- projection de bibliothèque reconstructible ;
- Workbench client exclusif de l'API Offer ;
- capacités IAM et séparation auteur/validateur.

**Compilation/tests :**

- build serveur et client ;
- queries, pagination, filtrage, RLS et cohérence de projection ;
- parcours par rôle, ETag, idempotency key, double clic, retry et conflit ;
- accessibilité clavier, labels et erreurs ;
- séquence draft/review/validate/publish/activate.

**Non-régression :**

- feature désactivée = MVP inchangé ;
- aucune écriture directe Supabase/PostgreSQL ;
- aucun catalogue local autoritatif ;
- aucun appel QF/Rights/Budget/Ledger/EBS/Simulation.

**PASS si :** le Workbench peut être ouvert par cohorte sans déplacer une
seule décision métier vers l'UI.

## 8. IG-06 — Distribution et Rights

**Couvre :** `V2-BR-016`, `V2-BR-017`.

**Implémentation :**

- dispatcher outbox supervisé ;
- enveloppes versionnées, ordre et idempotence ;
- query de bootstrap/réconciliation ;
- lineage Rights complet et disponibilité EBS dérivée.

**Compilation/tests :**

- build Offer, consommateurs Rights et EBS ;
- doublons, désordre, panne, retry, replay et bootstrap ;
- suspension, reprise, fermeture et supersession ;
- multi-tenant, schéma d'événement et compatibilité consommateur ;
- mesure du SLO et alerte de backlog.

**Non-régression :**

- Rights reste le moteur d'éligibilité ;
- EBS reste une projection ;
- historique sans OfferVersion marqué legacy ;
- aucune disponibilité nouvelle issue de `PUBLISHED` ou forcée par EBS.

**PASS si :** la lecture comparée est sans divergence acceptée et un
consommateur pilote peut être basculé réversiblement selon `BR-020`.

## 9. IG-07 — Finance causale

**Couvre :** `V2-BR-018`.

**Implémentation :**

- origine Offer/Version/Budget et identifiants applicables ;
- clé causale/idempotente ;
- `budget_ledger` cible des nouveaux mouvements ;
- exposition du lineage au Cockpit.

**Compilation/tests :**

- build des producteurs/consommateurs financiers affectés ;
- réservations, libérations, attributions, consommations, écritures, paiements
  et remboursements ;
- doublons, reprise, concurrence et rapprochement ;
- contraintes et migrations additives.

**Non-régression :**

- historiques non réécrits et non faussement attribués ;
- aucune nouvelle dépendance à `ledger_entries` ;
- aucun second ledger ou double mouvement.

**PASS si :** tous les nouveaux flux du périmètre portent une causalité
complète et le chemin legacy reste rollbackable jusqu'à `IG-T`.

## 10. IG-08 — Dotation

**Couvre :** `V2-BR-019`.

**Implémentation :**

- attribution/délivrance à partir d'OfferVersion active, Rights et Budget ;
- décision idempotente et traçable ;
- demande de mouvement aux autorités Budget/Ledger ;
- owner d'exploitation effectif.

**Compilation/tests :**

- build de la frontière Dotation et de ses contrats ;
- handoff versionné, tenant, rôle, concurrence, retry et reprise ;
- tests E2E jusqu'à la demande financière ;
- absence de catalogue, moteur Rights ou ledger interne.

**Non-régression :**

- Offer, Rights, Budget, Ledger et EBS gardent leurs responsabilités ;
- aucune disponibilité ou écriture financière sans causalité ;
- capacité désactivable sans suppression de décisions.

**PASS si :** l'attribution/délivrance est exploitable progressivement et sans
autorité parallèle.

## 11. IG-T — Coexistence et retrait legacy

**Couvre :** `V2-BR-020`.

Cette Gate est rejouée à chaque bascule puis prononcée définitivement après le
dernier consommateur.

**Implémentation opérationnelle :**

- inventaire producteur/consommateurs/données/métriques ;
- source cible et lineage actifs ;
- lecture comparée ;
- flag/configuration réversible ;
- gel des nouvelles écritures legacy ;
- observation d'au moins un cycle de release.

**Compilation/tests :**

- les deux chemins compilent pendant la coexistence ;
- tests de sélection d'un seul chemin autoritatif ;
- tests de rollback de configuration ;
- métriques et alertes de divergence ;
- preuve de zéro consommateur avant retrait.

**Non-régression :**

- aucune suppression avant remplacement ;
- aucune double écriture permanente ;
- aucun historique détruit ;
- Simulation reste prévisionnelle et les contenus frontend non autoritatifs.

**PASS final si :** tous les consommateurs ciblés sont basculés, l'observation
est terminée sans rollback, les écritures legacy sont gelées et le retrait
matériel est explicitement accepté.

## 12. Matrice de précédence des Gates

```mermaid
flowchart LR
    IG01[IG-01] --> IG06[IG-06]
    IG02[IG-02] --> IG03[IG-03]
    IG02 --> IG05[IG-05]
    IG02 --> IG06
    IG03 --> IG04[IG-04]
    IG03 --> IG05
    IG03 --> IG06
    IG04 --> IG05
    IG06 --> IG07[IG-07]
    IG07 --> IG08[IG-08]
    IGT[IG-T contrôles] -. accompagne .-> IG06
    IGT -. accompagne .-> IG07
    IGT -. accompagne .-> IG08
    IG08 --> IGTFinal[IG-T final]
```

`IG-01` peut s'exécuter en parallèle de `IG-02/IG-03`. `IG-04/IG-05` peuvent
avancer en parallèle de la branche aval lorsque leurs propres dépendances sont
satisfaites.

## 13. Conditions automatiques de FAIL

Une Gate prononce `FAIL` si au moins une condition suivante est observée :

- compilation rouge ou test antérieur supprimé/désactivé pour obtenir le vert ;
- implémentation hors frontière d'une brique ;
- migration destructive, non reproductible ou mutation d'historique ;
- `PUBLISHED` traité comme `ACTIVE` sur un nouveau parcours ;
- preuve souveraine fournie par le client acceptée ;
- fuite tenant/rôle ou séparation des tâches contournée ;
- référence implicite à une version `latest` ;
- effet vers un domaine protégé non prévu ;
- UI ou projection devenue source de vérité ;
- double ledger, double écriture permanente ou mouvement non idempotent ;
- impossibilité de désactiver la nouvelle capacité sans perte de données.

Le correctif revient à la même Gate. Il ne déclenche ni réaudit documentaire,
ni nouvelle brique, ni réouverture d'architecture.
