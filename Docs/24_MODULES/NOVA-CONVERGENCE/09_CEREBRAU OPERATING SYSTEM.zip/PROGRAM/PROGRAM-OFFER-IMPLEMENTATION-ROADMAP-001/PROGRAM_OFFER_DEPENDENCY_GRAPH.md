# Graphe de dépendances d'implémentation Offer V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Mission | `PROGRAM-OFFER-IMPLEMENTATION-ROADMAP-001` |
| Source des nœuds | Registre Officiel des Briques V2 |
| Nombre de nœuds | 21 |
| Objet officiel de gouvernance | `WAVE` |
| Nature | Graphe de précédence technique et métier, sans nouvelle architecture |

## 1. Sémantique

- `A -> B` signifie que l'acceptation de `A` est requise avant la mise en
  service de `B`.
- Un prérequis « direct » est testé à la Gate d'entrée de la brique.
- Les dépendances transitives restent applicables même si elles ne sont pas
  répétées sur chaque arc.
- `BR-020` est une piste de contrôle continue : elle démarre sans prérequis,
  contrôle chaque bascule, puis sa clôture dépend de `BR-016` à `BR-019`.
- Les entrées métier `X-*` ne sont pas des briques et ne créent aucune
  autorité. Ce sont des décisions ou ressources d'exécution déjà nécessaires
  à la matérialisation des contrats certifiés.

## 2. Graphe complet

```mermaid
flowchart LR
    B07["BR-007 CompositionContract"] --> B03["BR-003 OfferCharacteristic"]
    B07 --> B08["BR-008 CompositionRules"]
    B07 --> B09["BR-009 CompatibilityRules"]
    B07 --> B01["BR-001 BusinessComponent"]

    B15["BR-015 Préconditions serveur"] --> B14["BR-014 Offer Activation"]
    B14 --> B13["BR-013 Contrat OfferVersion v2"]
    B03 --> B13

    B01 --> B02["BR-002 ComponentVersion"]
    B08 --> B02
    B09 --> B02
    B02 --> B05["BR-005 ComponentConfiguration"]
    B02 --> B06["BR-006 ComponentReference"]

    B03 --> B04["BR-004 OfferComposition"]
    B05 --> B04
    B06 --> B04
    B13 --> B04

    B02 --> B10["BR-010 CompositionValidation"]
    B04 --> B10
    B08 --> B10
    B09 --> B10

    B01 --> B11["BR-011 LibraryProjection"]
    B02 --> B11
    B09 --> B11

    B04 --> B12["BR-012 CompositionWorkbench"]
    B10 --> B12
    B11 --> B12
    B13 --> B12
    B14 --> B12

    B21["BR-021 AF_QF_RIGHTS"] --> B16["BR-016 Diffusion Offer/Rights/EBS"]
    B13 --> B16
    B14 --> B16

    B16 --> B17["BR-017 Lineage OfferVersion/Rights"]
    B13 --> B17
    B14 --> B17
    B21 --> B17

    B13 --> B18["BR-018 Lineage financier"]
    B17 --> B18

    B13 --> B19["BR-019 Bounded Context Dotation"]
    B17 --> B19
    B18 --> B19

    B20["BR-020 Protocole legacy<br/>contrôle continu"]
    B20 -. contrôle les bascules .-> B16
    B20 -. contrôle les bascules .-> B17
    B20 -. contrôle les bascules .-> B18
    B20 -. contrôle les bascules .-> B19
```

La clôture de `BR-020` intervient après `BR-019` et après un cycle de release
complet du dernier consommateur sans rollback. Les arcs pointillés sont des
contrôles de bascule, pas des dépendances de construction et ne créent donc
pas de cycle dans le DAG.

## 3. Registre exhaustif des arcs directs

| Depuis | Vers | Nature | Motif d'implémentation |
|---|---|---|---|
| `BR-007` | `BR-003` | technique | Le type de caractéristique appartient au contrat de composition versionné |
| `BR-007` | `BR-008` | technique | Les règles utilisent le vocabulaire fermé du contrat |
| `BR-007` | `BR-009` | technique | Les compatibilités sont versionnées dans le contrat |
| `BR-007` | `BR-001` | technique | Le composant expose un contrat composable identifié |
| `BR-015` | `BR-014` | sécurité | L'activation doit résoudre ses preuves côté serveur |
| `BR-014` | `BR-013` | cycle | Le contrat v2 est introduit après fermeture de l'écart Activation |
| `BR-003` | `BR-013` | modèle | OfferVersion v2 porte les caractéristiques typées |
| `BR-001` | `BR-002` | agrégat | ComponentVersion est une Entity interne de BusinessComponent |
| `BR-008` | `BR-002` | contrat | La version embarque ses règles structurelles publiées |
| `BR-009` | `BR-002` | contrat | La version embarque ses contraintes de compatibilité |
| `BR-002` | `BR-005` | schéma | La configuration est validée par le schéma de la version exacte |
| `BR-002` | `BR-006` | identité | La référence cible une ComponentVersion exacte |
| `BR-003` | `BR-004` | composition | Le snapshot contient les caractéristiques |
| `BR-005` | `BR-004` | composition | Le snapshot contient les configurations figées |
| `BR-006` | `BR-004` | composition | Le snapshot contient les références exactes |
| `BR-013` | `BR-004` | conteneur | OfferComposition appartient à une OfferVersion v2 |
| `BR-002` | `BR-010` | résolution | La validation charge les ComponentVersions exactes |
| `BR-004` | `BR-010` | entrée | Le snapshot est l'entrée principale de validation |
| `BR-008` | `BR-010` | règle | Les règles de composition sont évaluées |
| `BR-009` | `BR-010` | règle | Les compatibilités sont évaluées |
| `BR-001` | `BR-011` | projection | La bibliothèque projette les descripteurs |
| `BR-002` | `BR-011` | projection | La bibliothèque expose versions, schémas et cycles |
| `BR-009` | `BR-011` | projection | La bibliothèque expose les compatibilités utiles |
| `BR-004` | `BR-012` | capacité | Le Workbench édite une composition d'OfferVersion |
| `BR-010` | `BR-012` | capacité | Le Workbench affiche le rapport serveur |
| `BR-011` | `BR-012` | lecture | Le Workbench consomme la bibliothèque projetée |
| `BR-013` | `BR-012` | contrat | Les champs OfferVersion v2 pilotent l'édition typée |
| `BR-014` | `BR-012` | cycle | Le Workbench sépare publication et activation |
| `BR-021` | `BR-016` | fondation | Les consommateurs Rights doivent être reproductibles et sécurisés |
| `BR-013` | `BR-016` | enveloppe | La diffusion transporte l'identité/version typée |
| `BR-014` | `BR-016` | événement | L'activation et les changements de cycle déclenchent la notification |
| `BR-016` | `BR-017` | intégration | Les recalculs et invalidations passent par outbox/query |
| `BR-013` | `BR-017` | lineage | Rights référence la règle et l'OfferVersion typées |
| `BR-014` | `BR-017` | disponibilité | Aucun nouveau droit disponible sans Version active |
| `BR-021` | `BR-017` | données | Le schéma QF/Rights et la RPC doivent être versionnés |
| `BR-013` | `BR-018` | origine | Le contrat porte la référence Budget et l'identité OfferVersion |
| `BR-017` | `BR-018` | causalité | Le droit applicable est conservé dans les flux concernés |
| `BR-013` | `BR-019` | handoff | Dotation consomme OfferVersion active et ses références |
| `BR-017` | `BR-019` | décision | Dotation consomme une décision Rights éligible |
| `BR-018` | `BR-019` | finance | Dotation demande les mouvements aux autorités Budget/Ledger |

Contrôles transverses non cycliques :

| Contrôle | Cibles | Condition |
|---|---|---|
| `BR-020` | `BR-016`, `BR-017`, `BR-018`, `BR-019` | Toute bascule suit inventaire, comparaison, correction, certification, flag réversible, gel, observation, retrait |
| clôture `BR-020` | après `BR-016` à `BR-019` | Aucun consommateur résiduel, un cycle de release sans rollback, décision de Gate |

## 4. Entrées métier externes

| ID | Entrée requise | Briques concernées | Critère de disponibilité |
|---|---|---|---|
| `X-01` | WAVE officielle et responsables de réalisation | toutes | WAVE identifiée, rôles de réalisation et de revue nommés |
| `X-02` | Catalogue produit et mappings `TKR/CHDV/CESU/autre` approuvés | `BR-003`, `BR-013` | codes et propriétaires Produit utilisables dans les tests d'acceptation |
| `X-03` | Mapping IAM des capacités Offer | `BR-012`, `BR-015` | capacités éditeur, validateur, publisher, operator, auditor mappées sans contourner la séparation des tâches |
| `X-04` | Registre des consommateurs et owners | `BR-016`, `BR-020` | chaque consommateur API/outbox/legacy identifié avec métrique et rollback |
| `X-05` | Règles Finance d'origine et d'idempotence | `BR-018`, `BR-019` | réservations, libérations, paiements, remboursements et responsabilités approuvés |
| `X-06` | Owner d'exploitation Dotation | `BR-019` | owner nommé avant exposition de la capacité |
| `X-07` | Cible d'essai, sauvegarde et rollback applicables | toute brique avec SQL/runtime | cible isolée identifiée et retour sûr démontrable |

Ces entrées ne demandent aucune révision architecturale. Si une entrée manque,
seule l'implémentation dépendante est bloquée.

## 5. Chaîne brique → prérequis → ordre → critère de fin

| Ordre | Brique | Prérequis techniques directs | Dépendances métier | Briques suivantes directes | Critère de fin de la brique |
|---:|---|---|---|---|---|
| 1 | `BR-007 CompositionContract` | aucun | `X-01` | `BR-001`, `BR-003`, `BR-008`, `BR-009` | Contrat versionné sérialisable, validé et rétrocompatible |
| 2 | `BR-015 Préconditions serveur` | aucun | `X-01`, `X-03` | `BR-014` | Toutes les preuves souveraines sont résolues en transaction côté serveur ; mensonges client ignorés/rejetés |
| 3 | `BR-021 AF_QF_RIGHTS` | aucun | `X-01`, `X-07` | `BR-016`, `BR-017` | Quatre tables et `compute_qf(uuid)` reproductibles, sécurisées, testées et rollbackables |
| 4 | `BR-001 BusinessComponent` | `BR-007` | `X-01` | `BR-002`, `BR-011` | Agrégat tenant-aware, versionné, audité, sans logique de domaine externe |
| 5 | `BR-003 OfferCharacteristic` | `BR-007` | `X-02` | `BR-004`, `BR-013` | Valeurs typées stables, sérialisables et immuables dans la version publiée |
| 6 | `BR-008 CompositionRules` | `BR-007` | `X-01` | `BR-002`, `BR-010` | Vocabulaire fermé couvrant complétude, cardinalité, dépendance, exclusion et cohérence |
| 7 | `BR-009 CompatibilityRules` | `BR-007` | `X-01` | `BR-002`, `BR-010`, `BR-011` | Compatibilités versionnées, déterministes et sans octroi de droit |
| 8 | `BR-014 Offer Activation` | `BR-015` | `X-01` | `BR-013`, `BR-016`, `BR-017`, `BR-012` | `PUBLISHED -> ACTIVE` explicite, idempotent, audit/outbox atomiques, aucun effet aval implicite |
| 9 | `BR-002 ComponentVersion` | `BR-001`, `BR-008`, `BR-009` | `X-01` | `BR-005`, `BR-006`, `BR-010`, `BR-011` | Cycle complet et immutabilité de `VALIDATED/PUBLISHED/SUPERSEDED` prouvés |
| 10 | `BR-013 Contrat OfferVersion v2` | `BR-003`, `BR-014` | `X-02`, `X-05` | `BR-004`, `BR-012`, `BR-016`, `BR-017`, `BR-018`, `BR-019` | Identité produit, période, références et lineage typés, avec lecture legacy préservée |
| 11 | `BR-005 ComponentConfiguration` | `BR-002` | `X-01` | `BR-004` | Configuration conforme au schéma exact, sans secret ni état souverain |
| 12 | `BR-006 ComponentReference` | `BR-002` | `X-01` | `BR-004` | Référence opaque exacte, cross-tenant refusée, aucune résolution `latest` |
| 13 | `BR-011 LibraryProjection` | `BR-001`, `BR-002`, `BR-009` | `X-01` | `BR-012` | Projection reconstruisible, filtrable, cohérente et non autoritative |
| 14 | `BR-016 Diffusion Offer/Rights/EBS` | `BR-013`, `BR-014`, `BR-021` | `X-04` | `BR-017`; contrôle `BR-020` | Outbox at-least-once, idempotence/ordre/replay et query de réconciliation testés |
| 15 | `BR-004 OfferComposition` | `BR-003`, `BR-005`, `BR-006`, `BR-013` | `X-02` | `BR-010`, `BR-012` | Snapshot complet, ordonné, empreinte déterministe et historique inchangé |
| 16 | `BR-017 Lineage OfferVersion/Rights` | `BR-013`, `BR-014`, `BR-016`, `BR-021` | `X-04` | `BR-018`, `BR-019`; contrôle `BR-020` | Toute nouvelle décision Rights porte la causalité exigée et EBS ne force plus la disponibilité |
| 17 | `BR-010 CompositionValidation` | `BR-002`, `BR-004`, `BR-008`, `BR-009` | `X-01` | `BR-012` | Rapport déterministe, versionné, sans mutation ni appel aux domaines protégés |
| 18 | `BR-018 Lineage financier` | `BR-013`, `BR-017` | `X-05` | `BR-019`; contrôle `BR-020` | Tout nouveau mouvement concerné porte origine Offer/Version/Budget et clé causale |
| 19 | `BR-012 CompositionWorkbench` | `BR-004`, `BR-010`, `BR-011`, `BR-013`, `BR-014` | `X-03` | aucun arc de construction ; contrôles de bascule | Parcours API-only par rôle, SOD, accessibilité, conflits et double soumission testés |
| 20 | `BR-019 Bounded Context Dotation` | `BR-013`, `BR-017`, `BR-018` | `X-05`, `X-06` | clôture `BR-020` | Attribution/délivrance idempotente et traçable, mouvements demandés au ledger souverain |
| 21 | `BR-020 Protocole legacy` | aucun pour démarrer ; `BR-016` à `BR-019` pour clore | `X-04`, `X-07` | aucune | Chaque consommateur basculé réversiblement ; écritures legacy gelées ; cycle observé ; retrait décidé par Gate |

## 6. Matrice exhaustive des impacts

| Brique | Runtime | API | SQL / persistance | UI | Métier |
|---|---|---|---|---|---|
| `BR-001` | Nouvel agrégat Offer dans la composition de dépendances existante | Commandes/queries de cycle sous la racine Offer | Stockage tenant, concurrence, audit/outbox et RLS additifs | Source de la bibliothèque | Descripteurs réutilisables sans absorber les domaines |
| `BR-002` | Cycle et immutabilité de version | Gestion/liste des versions exactes | Entité versionnée, contraintes d'unicité et d'état | Sélection d'une version exacte | Reproductibilité du contrat de composant |
| `BR-003` | Validation de valeurs typées | Champs additifs/versionnés | Stockage dans l'OfferVersion, pas de référentiel parallèle | Éditeur typé | Description intrinsèque de l'offre |
| `BR-004` | Snapshot et empreinte déterministes | Save/read de composition | Attaché à `offer_offer_version`, nullable en expand | Canevas de composition | Relecture exacte d'une version |
| `BR-005` | Validation par schéma de ComponentVersion | Payload de configuration structuré | Dans le snapshot/version, pas d'état souverain séparé | Formulaire guidé | Paramétrage déclaratif borné |
| `BR-006` | Résolution exacte et opaque | IDs/version/contrat explicites | Contraintes tenant et référence exacte | Sélecteur sans `latest` implicite | Autorités externes préservées |
| `BR-007` | Sérialisation/validation du contrat | Version de contrat exposée | Contrat stocké avec les versions/snapshots | Génération guidée des champs | Forme stable de composition |
| `BR-008` | Évaluation de complétude/cardinalité/dépendance/exclusion | Diagnostics structurés | Règles versionnées | Erreurs explicables | Cohérence interne |
| `BR-009` | Évaluation des compatibilités | Diagnostics structurés | Contraintes versionnées/projetées | Prévention des associations incompatibles | Cohérence inter-composants |
| `BR-010` | Service interne pur, sans réseau | Prévalidation et rapport | Pas d'état souverain ; audit/preuve seulement si requis | Rapport de cohérence | Blocage déterministe avant publication/activation |
| `BR-011` | Read model reconstructible | Query de bibliothèque | Projection/vue/index additifs avec RLS | Bibliothèque filtrable | Découverte sans second catalogue |
| `BR-012` | Client du runtime Offer existant | Réutilise commandes/queries Offer, ETag/idempotence | Aucune écriture directe | Workbench complet, RBAC/SOD/accessibilité | Gouvernance humaine de la composition |
| `BR-013` | OfferVersion enrichie et lecteur legacy tolérant | DTO/validation/OpenAPI additifs ou versionnés | Mapping nullable/versionné, aucun backfill sémantique | Champs produit/période/références typés | Contrat produit reproductible |
| `BR-014` | Automate `ACTIVE`, audit/outbox atomiques | `ActivateOffer` et lecture d'état | CHECK/read models/outbox additifs | Action Activation séparée | Publication non distribuable |
| `BR-015` | Lectures/verrous autoritatifs en transaction | Booléens souverains client ignorés puis retirés | Repositories/verrous ; pas de nouvelle autorité | L'UI transmet l'intention seulement | Invariants non falsifiables |
| `BR-016` | Dispatcher supervisé, retry/replay et query | Query de bootstrap/réconciliation et enveloppes versionnées | Outbox, idempotence et ordre consommateur | Statut de convergence seulement | Propagation réactive et réparable |
| `BR-017` | Recalcul/invalidation Rights pilotés par faits Offer | Lineage et motifs exposés selon autorisation | Historique/projection Rights enrichis sans déplacer le moteur | LifeHub/EBS n'affichent que le disponible sourcé | Éligibilité traçable |
| `BR-018` | Handoff financier causal | Identifiants d'origine obligatoires | Ajouts de lineage vers autorités Budget/`budget_ledger`, sans origine inventée | Cockpit expose l'origine | Audit financier de bout en bout |
| `BR-019` | Capacité Dotation conforme à sa frontière certifiée | Handoff Offer/Rights/Budget versionné | Persistance Dotation dans sa frontière ; aucun ledger parallèle | Aucune UI souveraine nouvelle imposée | Attribution et délivrance de l'avantage |
| `BR-020` | Flags, comparaison, métriques et observation | Compatibilité par consommateur | Gel puis retrait différé ; aucun `DROP` avant Gate | Bascule/réduction des sources locales par consommateur | Transition réversible sans rupture |
| `BR-021` | Bootstrap reproductible des consommateurs QF/Rights | RPC `compute_qf(uuid)` restreinte | Exactement quatre tables et une RPC, RLS/grants/tests/rollback | Aucun impact UI obligatoire | Fondation QF/Rights sécurisée |

## 7. Dépendances bloquantes

| Bloqueur | Briques bloquées | Motif |
|---|---|---|
| `BR-015` non acceptée | `BR-014` puis tout nouveau parcours actif | Une activation falsifiable n'est pas acceptable |
| `BR-014` non acceptée | `BR-013`, `BR-016`, `BR-017`, `BR-012` | `PUBLISHED` ne peut servir de disponibilité |
| `BR-013` non acceptée | composition attachée, distribution, Rights, Finance, Dotation | Identité et références causales manquantes |
| `BR-021` non acceptée | `BR-016`, `BR-017` | Fondation QF/Rights non reproductible |
| `BR-016` non acceptée | `BR-017` | Pas de propagation/replay fiable |
| `BR-017` non acceptée | `BR-018`, `BR-019` | Décision Rights non sourcée |
| `BR-018` non acceptée | `BR-019` | Mouvement financier sans causalité complète |
| `X-03` absent | `BR-012` | Capacités UI impossibles à faire respecter |
| `X-04` absent | bascules `BR-016` à `BR-020` | Consommateurs inconnus, rollback non démontrable |
| `X-06` absent | exposition `BR-019` | Exploitation Dotation sans owner |
