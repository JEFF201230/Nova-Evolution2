# Plan officiel d'exécution par WAVES — PROGRAM OFFER V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Domaine | PROGRAM OFFER V2 |
| Mission | `PROGRAM-OFFER-WAVE-PLAN-001` |
| Type | PROGRAM EXECUTION PLANNING |
| Profil | ARCHITECTURE |
| Date | 2026-07-24 |
| Objet officiel de gouvernance | `WAVE` |
| Périmètre | 21 briques V2 certifiées, 8 lots techniques de construction et la piste transverse legacy |
| Décision | `PROGRAM OFFER WAVE PLAN = READY_FOR_REVIEW` |

## 1. Autorité et périmètre

Le présent document est le plan officiel de pilotage de l'exécution de
PROGRAM OFFER V2. Il transforme exclusivement la roadmap, le graphe de
dépendances, le backlog, les lots, les Gates et le chemin critique déjà
validés en une séquence opérationnelle unique de `WAVE`.

Il prend pour acquis, sans réaudit :

- les 21 briques V2 et leurs frontières figées ;
- les 21 revues PROGRAM `VALIDÉES` ;
- les 21 validations structurelles `PASS` ;
- le gel de l'infrastructure V2 ;
- la roadmap, le graphe, le backlog, les lots, les Gates et le chemin critique ;
- les faits certifiés `FOUNDATION_READY`, `CANONICAL_WAVE_MODEL` et
  `CANONICAL_MM_L01_03_CONTRACT`.

`WAVE` est l'unique objet officiel de gouvernance d'exécution. Les lots
`LOT-01` à `LOT-08` et la piste `LOT-T` sont des unités techniques internes
rattachées aux WAVES. Ils ne sont ni officiels au sens de la gouvernance, ni
des Work Packages, ni une séquence concurrente.

Ce plan ne modifie aucune architecture, brique, frontière, dépendance, Gate,
estimation ou autorité. L'effort officiel reste **154 jours-personne idéaux
plus l'observation de `BR-020`** ; le chemin critique reste **81
jours-personne séquentiels plus au moins un cycle de release complet
d'observation**.

## 2. Sources officielles

### 2.1 Sources de construction du plan

Les six documents suivants ont été lus intégralement et constituent les
sources exclusives de l'ordonnancement :

1. [`PROGRAM_OFFER_IMPLEMENTATION_ROADMAP.md`](./PROGRAM_OFFER_IMPLEMENTATION_ROADMAP.md)
2. [`PROGRAM_OFFER_DEPENDENCY_GRAPH.md`](./PROGRAM_OFFER_DEPENDENCY_GRAPH.md)
3. [`PROGRAM_OFFER_IMPLEMENTATION_BACKLOG.md`](./PROGRAM_OFFER_IMPLEMENTATION_BACKLOG.md)
4. [`PROGRAM_OFFER_LOTS.md`](./PROGRAM_OFFER_LOTS.md)
5. [`PROGRAM_OFFER_GATES.md`](./PROGRAM_OFFER_GATES.md)
6. [`PROGRAM_OFFER_CRITICAL_PATH.md`](./PROGRAM_OFFER_CRITICAL_PATH.md)

### 2.2 Références d'autorité

Les quatre documents suivants sont utilisés uniquement comme références
d'autorité. Ils ne sont ni réaudités ni rediscutés :

1. [`V2_OFFICIAL_BRICK_REGISTER.md`](../PROGRAM-V2-STRUCTURAL-CERTIFICATION-001/V2_OFFICIAL_BRICK_REGISTER.md)
2. [`V2_STRUCTURAL_CERTIFICATION_MATRIX.md`](../PROGRAM-V2-STRUCTURAL-CERTIFICATION-001/V2_STRUCTURAL_CERTIFICATION_MATRIX.md)
3. [`V2_INFRASTRUCTURE_FREEZE_REPORT.md`](../PROGRAM-V2-STRUCTURAL-CERTIFICATION-001/V2_INFRASTRUCTURE_FREEZE_REPORT.md)
4. [`V2_OFFICIAL_DOCUMENT_REFERENCE.md`](../PROGRAM-V2-STRUCTURAL-CERTIFICATION-001/V2_OFFICIAL_DOCUMENT_REFERENCE.md)

En cas de besoin de détail d'implémentation, une future mission revient à ces
identifiants officiels ; elle ne reconstitue pas une hiérarchie documentaire
concurrente.

## 3. Règles de gouvernance WAVE

1. La séquence active est
   `PROGRAM-OFFER-WAVE-01 -> PROGRAM-OFFER-WAVE-02 -> PROGRAM-OFFER-WAVE-03 -> PROGRAM-OFFER-WAVE-04`.
2. Une seule WAVE peut être `ACTIVE` à un instant donné.
3. Toutes les autres WAVES restent `QUEUED` tant que la WAVE active n'a pas
   satisfait ses critères de sortie et ses Gates de sortie.
4. Le parallélisme est autorisé uniquement entre travaux explicitement
   indiqués comme parallélisables à l'intérieur de la WAVE active.
5. Un lot n'est jamais une gouvernance parallèle. Son avancement, ses preuves
   et sa Gate sont pilotés par la WAVE à laquelle il est rattaché.
6. `LOT-T` accompagne les WAVES : il démarre dans la WAVE 01, contrôle les
   bascules des WAVES suivantes et se clôt dans la WAVE 04.
7. Une dépendance directe doit être acceptée avant la mise en service de sa
   brique consommatrice. Les dépendances transitives restent applicables.
8. Une WAVE ne peut pas autoriser une brique appartenant à une WAVE ultérieure,
   même si une préparation documentaire ou un harnais de test est techniquement
   anticipable. Les seules anticipations permises sont celles listées dans ce
   plan et elles ne constituent ni implémentation, ni branchement runtime, ni
   exposition.
9. Toute future mission d'implémentation porte l'identifiant de sa WAVE,
   respecte ses briques et travaux autorisés, et produit un point de reprise.
10. Un échec de compilation, test ou preuve revient dans la WAVE et la Gate
    concernées. Il ne rouvre ni l'architecture ni la certification structurelle.
11. Une WAVE n'est `BLOCKED` que lorsqu'une dépendance factuelle ou une entrée
    `X-*` obligatoire manque réellement. Une implémentation planifiée mais non
    encore réalisée n'est pas un blocage.
12. Les seuls statuts de WAVE sont `QUEUED`, `READY`, `ACTIVE`, `BLOCKED`,
    `READY_FOR_REVIEW` et `COMPLETED`.

## 4. CURRENT PROGRAM WORKSITE

```text
PROGRAM WORKSITE = PROGRAM OFFER V2
ACTIVE WAVE = PROGRAM-OFFER-WAVE-01
OTHER WAVES = QUEUED
PARALLEL OFFER WORKSITE = FORBIDDEN
```

PROGRAM OFFER V2 est le chantier PROGRAM unique. Il est interdit :

- d'ouvrir un chantier Offer concurrent ;
- de réauditer l'infrastructure V2 ou les 21 briques certifiées ;
- de lancer une WAVE ultérieure avant la sortie de la WAVE active ;
- d'exécuter une mission Offer sans rattachement explicite à une WAVE ;
- de terminer une mission sans conserver son point de reprise précis.

Le parallélisme interne autorisé ne crée pas un second chantier. Les travaux
restent sous la responsabilité, le statut et les critères de sortie de
l'unique WAVE active.

## 5. Vue synthétique des WAVES

| Ordre | WAVE | Lots techniques internes | Briques en rattachement principal | Dépendances d'entrée | Statut initial | Valeur livrée | Gate(s) de sortie |
|---:|---|---|---|---|---|---|---|
| 1 | `PROGRAM-OFFER-WAVE-01` | `LOT-T` démarrage ; `LOT-01`, `LOT-02`, `LOT-03` | `BR-003`, `BR-007`, `BR-008`, `BR-009`, `BR-013`, `BR-014`, `BR-015`, `BR-021` | Faits certifiés ; `X-01`, `X-02`, `X-03`, `X-04`, `X-05`, `X-07` selon la ligne | `ACTIVE` | Fondation QF/Rights, cycle Offer sécurisé et contrats Offer V2 typés | `IG-01`, `IG-02`, `IG-03` |
| 2 | `PROGRAM-OFFER-WAVE-02` | `LOT-T` contrôles ; `LOT-04`, `LOT-06` | `BR-001`, `BR-002`, `BR-004`, `BR-005`, `BR-006`, `BR-010`, `BR-016`, `BR-017` | WAVE 01 `COMPLETED` ; `IG-01`, `IG-02`, `IG-03` à `PASS` ; `X-04` | `QUEUED` | Composition reproductible, validation déterministe, diffusion supervisée et Rights sourcés | `IG-04`, `IG-06` |
| 3 | `PROGRAM-OFFER-WAVE-03` | `LOT-T` contrôles ; `LOT-05`, `LOT-07` | `BR-011`, `BR-012`, `BR-018` | WAVE 02 `COMPLETED` ; `IG-02`, `IG-03`, `IG-04`, `IG-06` à `PASS` ; `X-03`, `X-05` | `QUEUED` | Workbench gouverné et nouveaux flux financiers causalement traçables | `IG-05`, `IG-07` |
| 4 | `PROGRAM-OFFER-WAVE-04` | `LOT-T` clôture ; `LOT-08` | `BR-019`, `BR-020` (`NOT_APPLICABLE` en implémentation logicielle) | WAVE 03 `COMPLETED` ; `IG-05`, `IG-07` à `PASS` ; `X-05`, `X-06` ; contrôles `BR-020` accumulés | `QUEUED` | Dotation exploitable, dernier consommateur observé et retrait legacy décidable | `IG-08`, puis `IG-T` final |

Couverture : **21/21 briques**. Les huit lots de construction et la piste
legacy sont tous tracés. `BR-020` a son rattachement principal dans la WAVE 04
pour sa clôture, mais son protocole contrôle les WAVES 01 à 04 comme l'impose
`LOT-T`.

## 6. Ordre complet d'exécution

### 6.1 WAVE 01 — fondations, sécurité et contrats

1. Ouvrir les contrôles `BR-020` : inventorier les producteurs, consommateurs,
   données, métriques, owners et mécanismes de rollback, sans bascule ni retrait.
2. Démarrer, dans la WAVE active et sur surfaces sans conflit :
   `BR-015`, `BR-021` et `BR-007`.
3. Après acceptation de `BR-015`, exécuter `BR-014`.
4. Après acceptation de `BR-007`, exécuter en parallèle `BR-003`, `BR-008` et
   `BR-009` si les ressources et surfaces ne sont pas en conflit.
5. Après acceptation de `BR-003` et `BR-014`, et disponibilité de `X-02` et
   `X-05`, exécuter `BR-013`.
6. Présenter les preuves à `IG-01`, `IG-02` et `IG-03`. Les trois verdicts
   doivent être `PASS` pour sortir de la WAVE.

### 6.2 WAVE 02 — composition et distribution Rights

Après sortie de la WAVE 01, ouvrir deux branches internes parallèles :

1. **Branche composition :**
   `BR-001 -> BR-002 -> BR-005/BR-006 -> BR-004 -> BR-010`.
   `BR-005` et `BR-006` sont parallélisables après `BR-002`.
2. **Branche distribution :**
   `BR-016 -> BR-017`, sous contrôle `BR-020` et après disponibilité de
   `X-04`.
3. Les branches peuvent avancer en parallèle, mais aucune modification
   concurrente non maîtrisée du catalogue de contrats Offer/API, du mapping
   `offer_offer_version`, de l'outbox ou des contrats Rights/EBS n'est admise.
4. Présenter les preuves à `IG-04` et `IG-06`. Les deux verdicts doivent être
   `PASS` pour sortir de la WAVE.

### 6.3 WAVE 03 — opérabilité et finance

1. Exécuter `BR-011`, puis `BR-012` après satisfaction de tous ses prérequis
   `BR-004`, `BR-010`, `BR-011`, `BR-013` et `BR-014`.
2. Exécuter `BR-018` après `BR-013` et `BR-017`, sous contrôle `BR-020`.
3. La branche `BR-011 -> BR-012` et `BR-018` sont parallélisables, sous réserve
   d'absence de conflit sur les contrats et ressources partagés.
4. Présenter les preuves à `IG-05` et `IG-07`. Les deux verdicts doivent être
   `PASS` pour sortir de la WAVE.

### 6.4 WAVE 04 — Dotation et clôture legacy

1. Exécuter `BR-019` après `BR-013`, `BR-017`, `BR-018` et disponibilité de
   `X-05` et `X-06`.
2. Présenter `BR-019` à `IG-08`; le verdict doit être `PASS`.
3. Pour chaque dernier consommateur concerné, terminer le protocole `BR-020` :
   lecture comparée, correction, bascule réversible, gel des écritures legacy,
   observation d'au moins un cycle de release complet et preuve de zéro
   consommateur résiduel.
4. Présenter la clôture à `IG-T` final. La WAVE et le programme ne sont
   terminés qu'après `IG-T PASS`.

## 7. Fiche détaillée de chaque WAVE

### 7.1 `PROGRAM-OFFER-WAVE-01` — Fondations sécurisées et contrats Offer V2

| Champ | Définition opérationnelle |
|---|---|
| Identifiant canonique | `PROGRAM-OFFER-WAVE-01` |
| Intitulé | Fondations sécurisées et contrats Offer V2 |
| Objectif fonctionnel | Sécuriser la frontière serveur et le cycle Offer, rendre QF/Rights reproductible et fournir les contrats typés nécessaires à toute composition ou diffusion ultérieure. |
| Briques V2 couvertes | `V2-BR-003`, `V2-BR-007`, `V2-BR-008`, `V2-BR-009`, `V2-BR-013`, `V2-BR-014`, `V2-BR-015`, `V2-BR-021`; démarrage des contrôles `V2-BR-020`. |
| Lots concernés | `LOT-01`, `LOT-02`, `LOT-03`; phase de démarrage de `LOT-T`. |
| Prérequis | Faits certifiés ; WAVE et rôles de réalisation/revue identifiés (`X-01`) ; entrées `X-02`, `X-03`, `X-04`, `X-05`, `X-07` disponibles avant les lignes qui les exigent. |
| Dépendances | `BR-015 -> BR-014`; `BR-007 -> BR-003/BR-008/BR-009`; `BR-003 + BR-014 -> BR-013`. |
| Travaux autorisés | Les incréments exacts de `LOT-01`, `LOT-02`, `LOT-03`; l'inventaire et la préparation des contrôles réversibles de `LOT-T`; compilation, tests, non-régression et preuves correspondantes. |
| Travaux parallélisables | Départs `BR-015`, `BR-021`, `BR-007`; puis `BR-003`, `BR-008`, `BR-009` après `BR-007`; préparation de `X-02` et `X-04` pendant `BR-015/BR-014`. |
| Travaux interdits | Toute brique des WAVES 02 à 04 ; activation implicite ; preuve souveraine client ; calcul QF/Rights/Finance ; bascule ou retrait legacy ; sixième objet dans `AF_QF_RIGHTS`. |
| Valeur fonctionnelle obtenue | Activation explicite et non falsifiable, contrats v1/v2 coexistants, vocabulaire de composition versionné et fondation QF/Rights sécurisée. |
| Impacts production | Changements additifs et désactivables ; ancien parcours maintenu ; aucune distribution depuis `PUBLISHED`; aucune bascule de consommateur ; migration QF/Rights testée hors production. |
| Impacts données | Exactement quatre tables et une RPC pour `BR-021`; adaptations Offer additives/nullable ou versionnées ; aucun backfill sémantique ; historiques inchangés. |
| Risques principaux | Preuve client encore acceptée ; activation implicite ; RLS/grants dangereux ; contrat trop ouvert ; rupture v1 ; référence non versionnée ; historique réinterprété. |
| Critères d'entrée | WAVE 01 `ACTIVE`; périmètres de fichiers/contrats/tests bornés par mission ; cibles d'essai et preuves prêtes ; entrées `X-*` requises disponibles pour chaque ligne démarrée. |
| Critères de sortie | Les huit briques couvertes satisfont leurs critères du backlog ; contrôles `BR-020` initialisés ; compilation et tests verts ; compatibilité historique prouvée ; `IG-01`, `IG-02`, `IG-03` à `PASS`. |
| Gates applicables | `IG-01`, `IG-02`, `IG-03`; `IG-T` est seulement initialisé et n'est pas prononcé final. |
| Livrables attendus | Incréments compilables/testables des lots 01 à 03 ; paquets de preuves des trois Gates ; registre initial des consommateurs et mécanismes de rollback pour `LOT-T`. |
| Point de reprise précis | Après `IG-01 PASS + IG-02 PASS + IG-03 PASS`, conserver les versions acceptées des contrats v1/v2, l'état des flags désactivés, les preuves QF/Rights, la matrice des consommateurs `BR-020` et les entrées encore ouvertes. |
| WAVE suivante débloquée | `PROGRAM-OFFER-WAVE-02`, qui passe de `QUEUED` à `READY`, puis à `ACTIVE` quand la WAVE 01 est `COMPLETED`. |

### 7.2 `PROGRAM-OFFER-WAVE-02` — Composition reproductible et distribution Rights

| Champ | Définition opérationnelle |
|---|---|
| Identifiant canonique | `PROGRAM-OFFER-WAVE-02` |
| Intitulé | Composition reproductible et distribution Rights |
| Objectif fonctionnel | Construire le noyau de composition validable et propager l'Offer active vers Rights/EBS avec lineage, convergence et rollback par consommateur. |
| Briques V2 couvertes | `V2-BR-001`, `V2-BR-002`, `V2-BR-004`, `V2-BR-005`, `V2-BR-006`, `V2-BR-010`, `V2-BR-016`, `V2-BR-017`; contrôles `V2-BR-020`. |
| Lots concernés | `LOT-04`, `LOT-06`; phase de contrôle de `LOT-T`. |
| Prérequis | WAVE 01 `COMPLETED`; `IG-01`, `IG-02`, `IG-03` à `PASS`; registre `X-04` complet avant `BR-016`; cible et rollback applicables. |
| Dépendances | Branche composition selon le DAG officiel ; `BR-013 + BR-014 + BR-021 -> BR-016`; `BR-013 + BR-014 + BR-016 + BR-021 -> BR-017`. |
| Travaux autorisés | Incréments exacts de `LOT-04` et `LOT-06`; shadow/read-compare, métriques, flags et rollback de `LOT-T` par consommateur pilote ; preuves `IG-04/IG-06`. |
| Travaux parallélisables | Branches composition et distribution ; `BR-005/BR-006` après `BR-002`; préparation non branchée des harnais de replay ; contrôles `BR-020` au fil des bascules autorisées. |
| Travaux interdits | `BR-011`, `BR-012`, `BR-018`, `BR-019`; UI active ; bascule globale ; double écriture permanente ; EBS moteur ; référence `latest`; retrait legacy définitif. |
| Valeur fonctionnelle obtenue | Composition exacte, immuable et validée sans effet ; diffusion réparable ; décisions Rights sourcées OfferVersion ; EBS strictement projectif. |
| Impacts production | Structures et commandes désactivées par défaut ; dispatcher supervisé ; pilote basculable et rollbackable ; alertes avant autorité du nouveau chemin ; parcours non basculés inchangés. |
| Impacts données | Persistance Offer additive, snapshot nullable pour l'historique, audit/outbox/RLS ; lineage Rights ajouté sans réécrire l'historique ; aucune mutation Budget/Ledger/QF/Simulation. |
| Risques principaux | Mutation d'une version publiée ; snapshot incomplet ; référence flottante ; non-déterminisme ; doublons/désordre ; événement perdu ; droits périmés ; fuite cross-tenant. |
| Critères d'entrée | Paquets de preuves WAVE 01 acceptés ; contrats et fondation disponibles ; `X-04` complet pour toute bascule ; ressources partagées réservées sans conflit. |
| Critères de sortie | Composition v2 enregistrable et validable en mode désactivé ; diffusion/replay/bootstrap testés ; lineage Rights complet ; lecture comparée sans divergence acceptée ; `IG-04` et `IG-06` à `PASS`. |
| Gates applicables | `IG-04`, `IG-06`; relecture opérationnelle de `IG-T` pour chaque bascule, sans verdict final. |
| Livrables attendus | Incréments compilables/testables des lots 04 et 06 ; rapports déterministes ; preuves de convergence, SLO, alertes et rollback ; matrice `BR-020` mise à jour. |
| Point de reprise précis | Après `IG-04 PASS + IG-06 PASS`, conserver les versions exactes des composants/snapshots, la baseline de validation, le consommateur pilote et son état de flag, les métriques de divergence et la matrice legacy actualisée. |
| WAVE suivante débloquée | `PROGRAM-OFFER-WAVE-03`, qui passe de `QUEUED` à `READY`, puis à `ACTIVE` quand la WAVE 02 est `COMPLETED`. |

### 7.3 `PROGRAM-OFFER-WAVE-03` — Opérabilité Offer et finance causale

| Champ | Définition opérationnelle |
|---|---|
| Identifiant canonique | `PROGRAM-OFFER-WAVE-03` |
| Intitulé | Opérabilité Offer et finance causale |
| Objectif fonctionnel | Rendre Offer administrable exclusivement par ses APIs et donner une origine Offer/Version/Budget à tout nouveau flux financier concerné. |
| Briques V2 couvertes | `V2-BR-011`, `V2-BR-012`, `V2-BR-018`; contrôles `V2-BR-020`. |
| Lots concernés | `LOT-05`, `LOT-07`; phase de contrôle de `LOT-T`. |
| Prérequis | WAVE 02 `COMPLETED`; `IG-02`, `IG-03`, `IG-04`, `IG-06` à `PASS`; mappings IAM `X-03`; règles Finance `X-05`. |
| Dépendances | `BR-001 + BR-002 + BR-009 -> BR-011`; `BR-004 + BR-010 + BR-011 + BR-013 + BR-014 -> BR-012`; `BR-013 + BR-017 -> BR-018`. |
| Travaux autorisés | Incréments exacts de `LOT-05` et `LOT-07`; exposition Workbench par cohortes ; lecture comparée et bascule financière via `LOT-T`; preuves `IG-05/IG-07`. |
| Travaux parallélisables | Branche `BR-011 -> BR-012` et `BR-018`; scénarios Finance/Dotation préparés sans implémenter `BR-019`; collecte continue des preuves `BR-020`. |
| Travaux interdits | Écriture directe UI vers Supabase/PostgreSQL ; catalogue frontend autoritatif ; logique métier client ; second ledger ; origine historique inventée ; implémentation ou exposition de `BR-019`. |
| Valeur fonctionnelle obtenue | Bibliothèque et Workbench gouvernés, API-only, avec SOD ; nouveaux mouvements financiers traçables jusqu'à OfferVersion et `budget_ledger`. |
| Impacts production | Ouverture Workbench progressive par cohorte ; feature désactivable ; chemin financier legacy maintenu rollbackable ; aucune bascule sans lecture comparée. |
| Impacts données | Projection reconstructible et non autoritative ; lineage financier additif ; historiques non réécrits et marqués legacy/unattributed en l'absence de preuve ; aucune dépendance nouvelle à `ledger_entries`. |
| Risques principaux | Source UI concurrente ; SOD contournée ; projection périmée ; rupture contrat v1 ; double mouvement ; double ledger ; origine historique fausse ; conflit sur contrats Finance. |
| Critères d'entrée | Données de projection et scénarios de reconstruction prêts ; IAM mappé ; scénarios financiers et idempotence approuvés ; mécanismes de rollback `LOT-T` disponibles. |
| Critères de sortie | Workbench compilé et testé par rôle/cohorte ; aucune autorité client ; nouveaux flux financiers causalement complets et idempotents ; `IG-05` et `IG-07` à `PASS`. |
| Gates applicables | `IG-05`, `IG-07`; relecture opérationnelle de `IG-T` pour les bascules, sans verdict final. |
| Livrables attendus | Projection et Workbench compilables/testables ; preuves API/UI/accessibilité/E2E ; contrat causal et preuves Finance ; matrice `BR-020` mise à jour. |
| Point de reprise précis | Après `IG-05 PASS + IG-07 PASS`, conserver la cohorte Workbench active, l'état des flags, la baseline de reconstruction, le dernier rapprochement financier, les identifiants causaux testés et la matrice legacy restante. |
| WAVE suivante débloquée | `PROGRAM-OFFER-WAVE-04`, qui passe de `QUEUED` à `READY`, puis à `ACTIVE` quand la WAVE 03 est `COMPLETED`. |

### 7.4 `PROGRAM-OFFER-WAVE-04` — Dotation et clôture de transition

| Champ | Définition opérationnelle |
|---|---|
| Identifiant canonique | `PROGRAM-OFFER-WAVE-04` |
| Intitulé | Dotation et clôture de transition |
| Objectif fonctionnel | Implémenter l'attribution/délivrance Dotation dans sa frontière certifiée, puis terminer la coexistence et décider le retrait legacy après observation. |
| Briques V2 couvertes | `V2-BR-019`; `V2-BR-020`, `NOT_APPLICABLE` en implémentation logicielle mais applicable comme protocole opérationnel de clôture. |
| Lots concernés | `LOT-08`; phase de clôture de `LOT-T`. |
| Prérequis | WAVE 03 `COMPLETED`; `BR-013`, `BR-017`, `BR-018` acceptées ; `IG-07 PASS`; `X-05` et owner `X-06` disponibles ; preuves `BR-020` accumulées. |
| Dépendances | `BR-013 + BR-017 + BR-018 -> BR-019`; clôture `BR-020` après `BR-016` à `BR-019`, `IG-08 PASS` et un cycle de release complet sans rollback du dernier consommateur. |
| Travaux autorisés | Incréments exacts de `LOT-08`; exposition progressive et rollback logique ; séquence finale de `LOT-T` par consommateur ; collecte et présentation des preuves `IG-08/IG-T`. |
| Travaux parallélisables | Préparation des preuves, métriques et scénarios de rollback pendant l'implémentation de `BR-019`; aucune réduction du cycle d'observation. |
| Travaux interdits | Catalogue, moteur Rights ou ledger dans Dotation ; mouvement direct hors Budget/Ledger ; suppression avant remplacement ; bascule globale ; double écriture permanente ; clôture `BR-020` avant observation complète. |
| Valeur fonctionnelle obtenue | Attribution/délivrance Dotation souveraine et traçable ; nouveaux chemins autoritatifs uniques ; legacy gelé et retrait matériel décidable. |
| Impacts production | Exposition par cohorte ; capacité désactivable sans suppression de décision ; observation complète du dernier consommateur ; retrait uniquement après `IG-T PASS`. |
| Impacts données | Persistance Dotation dans sa frontière ; références OfferVersion/Rights/Budget exactes ; aucune réécriture d'historique ni ledger parallèle ; gel des nouvelles écritures legacy avant retrait. |
| Risques principaux | Owner absent ; attribution dupliquée ; second ledger/catalogue/moteur Rights ; mouvement sans causalité ; retrait prématuré ; divergence ou rollback durant l'observation. |
| Critères d'entrée | Owner Dotation effectif ; contrats de handoff prêts ; scénarios E2E et rollback disponibles ; état par consommateur connu ; WAVE 03 entièrement sortie. |
| Critères de sortie | `IG-08 PASS`; tous les consommateurs ciblés basculés ; zéro résidu et zéro divergence inexpliquée ; écritures legacy gelées ; cycle complet sans rollback ; `IG-T PASS` final. |
| Gates applicables | `IG-08`, puis `IG-T` final. |
| Livrables attendus | Incrément Dotation compilable/testable ; preuves E2E et d'exploitation ; matrice finale des consommateurs ; métriques d'observation ; décision de retrait `IG-T`. |
| Point de reprise précis | Après `IG-T PASS`, conserver l'inventaire final à zéro résidu, les métriques du cycle observé, l'état définitif des flags et gels, la preuve de rollback non déclenché et la décision explicite de retrait. |
| WAVE suivante débloquée | Aucune. Le programme rejoint son jalon final après `BR-012` terminé et `IG-T PASS`. |

## 8. Travaux parallélisables autorisés

Le parallélisme ci-dessous est exhaustif au niveau du pilotage. Il reste
interne à l'unique WAVE active.

| WAVE active | Travaux parallélisables | Jonction obligatoire | Limites |
|---|---|---|---|
| WAVE 01 | `BR-021` ; `BR-015 -> BR-014` ; `BR-007 -> BR-003/BR-008/BR-009` ; inventaire `BR-020` | `BR-003 + BR-014 -> BR-013` ; `IG-01 + IG-02 + IG-03` | Pas de bascule ; pas de sixième objet QF/Rights ; conflits Offer/API ordonnés |
| WAVE 02 | Branche `LOT-04` ; branche `BR-016 -> BR-017` ; contrôles `BR-020` | `IG-04 + IG-06` | Pas de concurrence non maîtrisée sur OfferVersion, outbox ou contrats Rights/EBS |
| WAVE 03 | `BR-011 -> BR-012` ; `BR-018` ; contrôles `BR-020` | `IG-05 + IG-07` | Pas de source UI, second ledger ou implémentation Dotation |
| WAVE 04 | `BR-019` ; préparation des preuves et métriques `BR-020` | `IG-08`, observation, puis `IG-T` | L'observation ne commence pour le dernier consommateur qu'après sa bascule ; elle n'est pas compressible |

Préparations transverses permises sans lancer une WAVE future :

- préparer `X-02` et `X-04` pendant `BR-015/BR-014` ;
- préparer les harnais de replay avant `BR-016`, sans branchement runtime ;
- préparer les scénarios Finance et Dotation pendant `BR-016/BR-017`, sans
  implémenter `BR-018` ou `BR-019` avant leur WAVE ;
- collecter les preuves `BR-020` au fil des bascules.

Ces préparations ne peuvent modifier du code, un schéma, un contrat ou des
données appartenant à une brique d'une WAVE ultérieure.

## 9. Chemin critique rattaché aux WAVES

| WAVE | Segment critique | Effort officiel du segment | Condition de passage |
|---|---|---:|---|
| WAVE 01 | `BR-015 -> BR-014 -> BR-013` | 26 j-p | `IG-02 PASS + IG-03 PASS` |
| WAVE 02 | `BR-016 -> BR-017` | 22 j-p | `IG-06 PASS` |
| WAVE 03 | `BR-018` | 10 j-p | `IG-07 PASS` |
| WAVE 04 | `BR-019 -> BR-020 clôture` | 23 j-p + observation | `IG-08 PASS`, cycle complet, `IG-T PASS` |
| **Total** | `BR-015 -> BR-014 -> BR-013 -> BR-016 -> BR-017 -> BR-018 -> BR-019 -> BR-020` | **81 j-p + au moins un cycle de release** | Jalon final |

Les branches `BR-021`, composition et Workbench restent parallèles au chemin
critique dans les marges déjà documentées. Leur rattachement à une WAVE ne
modifie ni le DAG ni les marges officielles. Une WAVE ne sort toutefois que
lorsque toutes ses Gates de sortie sont à `PASS`.

## 10. Gates par WAVE

| WAVE | Gate | Objet de contrôle exclusif | Condition de sortie |
|---|---|---|---|
| WAVE 01 | `IG-01` | Implémentation, tests SQL/RPC/sécurité et non-régression de `BR-021` | `PASS` |
| WAVE 01 | `IG-02` | Implémentation, compilation, tests et non-régression de `BR-015/BR-014` | `PASS` |
| WAVE 01 | `IG-03` | Implémentation, compilation, tests et coexistence v1/v2 de `BR-007/008/009/003/013` | `PASS` |
| WAVE 02 | `IG-04` | Implémentation, compilation, tests et non-régression de `BR-001/002/005/006/004/010` | `PASS` |
| WAVE 02 | `IG-06` | Implémentation, compilation, tests de convergence et non-régression de `BR-016/017` | `PASS` |
| WAVE 03 | `IG-05` | Implémentation, builds, tests API/UI/accessibilité et non-régression de `BR-011/012` | `PASS` |
| WAVE 03 | `IG-07` | Implémentation, compilation, tests financiers et non-régression de `BR-018` | `PASS` |
| WAVE 04 | `IG-08` | Implémentation, compilation, tests E2E et non-régression de `BR-019` | `PASS` |
| WAVES 01 à 04 | `IG-T` | Preuves de coexistence, sélection d'un chemin autoritatif, rollback, observation et retrait de `BR-020` | Rejouée aux bascules ; `PASS` final en WAVE 04 |

Ces Gates sont exactement celles de `PROGRAM_OFFER_GATES.md`. Elles contrôlent
uniquement l'implémentation, la compilation, les tests, la non-régression et la
preuve d'intégration. Elles ne réauditent aucun document, ne rouvrent aucune
architecture, ne remettent en cause aucune brique certifiée et ne créent
aucune Gate structurelle.

Les verdicts de Gate restent `PASS`, `FAIL` ou `BLOCKED_BY_EVIDENCE`. Ils ne
sont pas des statuts de WAVE.

## 11. Règles de passage entre WAVES

1. Tous les travaux de la WAVE active atteignent leur Definition of Done
   officielle.
2. Tous les paquets affectés et consommateurs de contrats compilent.
3. Tous les tests nouveaux et existants requis sont verts.
4. Les preuves d'implémentation, d'intégration et de non-régression sont
   rattachées à la WAVE, à la cible et à l'incrément exécuté.
5. Toutes les Gates de sortie de la WAVE prononcent `PASS`.
6. Le point de reprise de la WAVE est enregistré, y compris flags,
   consommateurs, données, métriques, rollback et dépendances restantes.
7. La WAVE active passe à `COMPLETED`.
8. La WAVE suivante passe de `QUEUED` à `READY`.
9. La WAVE suivante ne passe à `ACTIVE` qu'après confirmation qu'aucune autre
   WAVE ne l'est.

`FAIL` ramène les travaux à corriger dans la même WAVE. Une preuve obligatoire
absente donne `BLOCKED_BY_EVIDENCE` à la Gate ; la WAVE n'est mise `BLOCKED`
que si cette absence correspond à une dépendance factuelle empêchant
réellement l'exécution. Aucun de ces cas n'autorise le lancement de la WAVE
suivante.

## 12. Registre des statuts

| Statut WAVE | Usage autorisé |
|---|---|
| `QUEUED` | WAVE ordonnée mais non ouverte ; aucun travail d'implémentation de ses briques n'est autorisé. |
| `READY` | Toutes les dépendances d'entrée sont satisfaites et la WAVE peut devenir active dès que l'emplacement actif est libre. |
| `ACTIVE` | Unique WAVE dont les travaux autorisés peuvent être exécutés. |
| `BLOCKED` | Une dépendance factuelle ou une entrée obligatoire empêche réellement la poursuite ; le bloqueur et les briques affectées sont nommés. |
| `READY_FOR_REVIEW` | Travaux de la WAVE terminés et paquet de preuves complet, en attente des verdicts de ses Gates. |
| `COMPLETED` | Toutes les Gates de sortie sont à `PASS` et le point de reprise est conservé. |

Flux nominal :

```text
QUEUED -> READY -> ACTIVE -> READY_FOR_REVIEW -> COMPLETED
```

`BLOCKED` est une déviation factuelle temporaire depuis `READY`, `ACTIVE` ou
`READY_FOR_REVIEW`. Une fois la dépendance satisfaite, la WAVE revient au
statut compatible avec son avancement. Aucun statut supplémentaire n'est
autorisé.

Registre initial :

| WAVE | Statut initial |
|---|---|
| `PROGRAM-OFFER-WAVE-01` | `ACTIVE` |
| `PROGRAM-OFFER-WAVE-02` | `QUEUED` |
| `PROGRAM-OFFER-WAVE-03` | `QUEUED` |
| `PROGRAM-OFFER-WAVE-04` | `QUEUED` |

## 13. Point de départ opérationnel

Le point de départ est `PROGRAM-OFFER-WAVE-01`. Avant chaque mission de cette
WAVE, le responsable confirme uniquement les entrées d'exécution de la ligne
concernée :

- WAVE, responsable de réalisation et responsable de revue (`X-01`) ;
- entrée métier `X-*` spécifique à la brique ;
- périmètre de fichiers, contrats et tests borné ;
- cible d'essai, données de test et collecte de preuves prêtes ;
- déploiement additif, désactivation et rollback identifiés.

L'absence factuelle d'une entrée suspend seulement la ligne concernée. Les
autres travaux explicitement parallélisables de WAVE 01 peuvent continuer.
Elle ne déclenche ni audit structurel, ni nouvelle architecture, ni
qualification automatique de toute la WAVE en `BLOCKED`.

Ordre de démarrage recommandé dans la WAVE :

1. première mission sur `V2-BR-015` ;
2. en parallèle autorisé, missions bornées sur `V2-BR-021`, `V2-BR-007` et
   initialisation opérationnelle de `V2-BR-020` ;
3. poursuite exclusive selon les dépendances internes de la section 6.1.

## 14. Première mission d'implémentation recommandée

| Champ | Définition |
|---|---|
| Mission recommandée | `PROGRAM-OFFER-WAVE-01-BR015-IMPLEMENTATION-001` |
| WAVE | `PROGRAM-OFFER-WAVE-01` |
| Lot interne | `LOT-02` |
| Brique unique | `V2-BR-015 — Résolution autoritative des préconditions serveur` |
| Objectif | Matérialiser la résolution serveur transactionnelle des preuves souveraines nécessaires aux commandes Offer, sans accepter les booléens ou compteurs du client comme preuves. |
| Prérequis | WAVE 01 `ACTIVE`; `X-01` et mapping IAM `X-03` disponibles ; périmètre de commandes/repositories/tests borné ; cible d'essai prête. |
| Périmètre autorisé | Matrice invariant/source autoritative/repository/verrou/erreur ; chargement transactionnel des preuves ; rejet ou ignorance des preuves client ; tests de rôle, tenant, SOD, idempotence et concurrence ; compilation et non-régression des unités Offer affectées. |
| Périmètre interdit | `V2-BR-014` et l'état `ACTIVE`; toute autre brique ; effet Rights, Budget, Ledger, EBS, Execution ou Operation ; changement de contrat V2 non requis par `BR-015`; réaudit architectural. |
| Incrément attendu | Une implémentation `BR-015` bornée, compilable et testable, désactivable selon le chemin prévu, avec tests négatifs de payload falsifié et paquet de preuves destiné à `IG-02`. |
| Critères de réussite factuels | Matrice complète ; preuves chargées dans la transaction ; payload falsifié sans effet ; tenant, rôles, SOD, idempotence et concurrence testés ; suites existantes vertes ; aucune brique hors périmètre modifiée. |
| Gate | Contribution au paquet de preuves `IG-02`; aucune nouvelle Gate et aucun verdict `IG-02 PASS` avant l'implémentation de `BR-014`. |
| Point de reprise précis | WAVE 01 reste `ACTIVE`; preuve `BR-015` consolidée dans `IG-02`; commandes/repositories couverts et résultats de tests enregistrés ; prochaine mission autorisée sur `BR-014`; travaux parallèles `BR-021`, `BR-007` et contrôles `BR-020` inchangés dans leur droit d'exécution. |

Cette mission est décrite uniquement. Elle n'est pas exécutée par le présent
plan.

## 15. Point de reprise PROGRAM

### 15.1 État au terme de la présente mission de planification

```text
PROGRAM WORKSITE = PROGRAM OFFER V2
WAVE PLAN = READY_FOR_REVIEW
ACTIVE WAVE = PROGRAM-OFFER-WAVE-01
ACTIVE WAVE SCOPE = LOT-T initiation + LOT-01 + LOT-02 + LOT-03
OTHER WAVES = QUEUED
PARALLEL OFFER WORKSITE = FORBIDDEN
IMPLEMENTATION EXECUTED BY THIS MISSION = NONE
NEXT MISSION = PROGRAM-OFFER-WAVE-01-BR015-IMPLEMENTATION-001
```

### 15.2 Point de reprise obligatoire après chaque future mission

Chaque mission conserve au minimum :

- l'identifiant de mission et la WAVE active ;
- la brique unique ou les briques explicitement autorisées ;
- le dernier incrément compilable et testé ;
- les critères d'acceptation prouvés et ceux restant ouverts ;
- les résultats de compilation, tests, non-régression et intégration ;
- la Gate alimentée et son état de preuve, sans inventer de verdict ;
- l'état des flags, cohortes, consommateurs, données et rollback ;
- les dépendances `BR-*` et entrées `X-*` encore requises ;
- le prochain travail exact autorisé dans la même WAVE ;
- la confirmation que les autres WAVES restent `QUEUED`.

Le point de reprise ne peut ni déclarer une WAVE suivante active, ni réduire
le périmètre de preuve, ni rouvrir l'architecture.

## 16. Contrôle final de conformité

| Critère | Résultat |
|---|---|
| 21 briques rattachées à une WAVE ou `NOT_APPLICABLE` | `PASS` — 20 briques à implémenter rattachées une fois ; `BR-020` rattachée à la WAVE 04 et conservée `NOT_APPLICABLE` en implémentation logicielle |
| Huit lots et piste legacy tracés | `PASS` — `LOT-01` à `LOT-08` et `LOT-T` |
| Nouvelle brique, lot ou architecture | `NONE` |
| Dépendances officielles modifiées | `NONE` |
| Ordre fondé sur le DAG et les priorités | `PASS` |
| Une seule WAVE initiale active | `PASS` — WAVE 01 |
| Chantier Offer parallèle | `FORBIDDEN` |
| Gates limitées à l'implémentation | `PASS` |
| Première mission exécutable identifiée | `PASS` — `PROGRAM-OFFER-WAVE-01-BR015-IMPLEMENTATION-001` |
| Point de reprise PROGRAM fourni | `PASS` |
| Code, SQL, migration, schéma ou contrat modifié | `NONE` |
| Documents sources modifiés | `NONE` |

```text
PROGRAM OFFER WAVE PLAN = READY_FOR_REVIEW
```
