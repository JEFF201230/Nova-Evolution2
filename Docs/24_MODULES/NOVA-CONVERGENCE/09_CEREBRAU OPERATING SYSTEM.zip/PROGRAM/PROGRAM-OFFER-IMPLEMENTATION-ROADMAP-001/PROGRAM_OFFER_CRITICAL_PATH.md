# Chemin critique d'implémentation Offer V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Mission | `PROGRAM-OFFER-IMPLEMENTATION-ROADMAP-001` |
| Méthode | CPM sur le DAG des 21 briques |
| Unité | jours-personne idéaux séquentiels |
| Horizon calculé | 81 j-p + un cycle de release d'observation |
| Objet officiel de gouvernance | `WAVE` |

## 1. Hypothèses de calcul

Le calcul utilise les estimations du backlog et les arcs directs du graphe.
Il suppose :

- une ressource disponible par activité démarrable ;
- aucune attente d'environnement ou d'autorité ;
- aucune reprise après échec de Gate ;
- une exécution parallèle lorsque les dépendances le permettent ;
- la finalisation de `BR-020` après `BR-019`, même si ses contrôles commencent
  dès le début ;
- un jalon final commun après `BR-012` et la clôture `BR-020`.

Le résultat est une structure de précédence, pas un engagement calendaire. Les
revues, files d'attente, fenêtres de déploiement et le cycle de release
augmentent la durée réelle.

## 2. Chemin critique

```text
BR-015 Préconditions serveur                         8 j-p
  -> BR-014 Offer Activation                       10 j-p
  -> BR-013 Contrat typé OfferVersion v2            8 j-p
  -> BR-016 Diffusion Offer/Rights/EBS              12 j-p
  -> BR-017 Lineage OfferVersion/Rights             10 j-p
  -> BR-018 Lineage financier                       10 j-p
  -> BR-019 Bounded Context Dotation                15 j-p
  -> BR-020 clôture coexistence/retrait              8 j-p
                                                    -------
                                                     81 j-p
```

Après ces 81 j-p idéaux, `BR-020` impose encore au moins un cycle de release
complet sans rollback avant retrait final. Ce temps écoulé n'est pas convertible
en jours-personne et ne doit pas être compressé.

```mermaid
flowchart LR
    B15["BR-015<br/>8"] --> B14["BR-014<br/>10"]
    B14 --> B13["BR-013<br/>8"]
    B13 --> B16["BR-016<br/>12"]
    B16 --> B17["BR-017<br/>10"]
    B17 --> B18["BR-018<br/>10"]
    B18 --> B19["BR-019<br/>15"]
    B19 --> B20["BR-020 clôture<br/>8 + observation"]
```

Toute dérive d'une activité critique décale la clôture à durée égale, sauf
réduction de charge validée par une meilleure exécution. Une réduction de
périmètre ou de preuve n'est pas une optimisation admissible.

## 3. Calcul au plus tôt et marge totale

`ES` est le début au plus tôt, `EF` la fin au plus tôt et la marge le retard
absorbé avant impact sur la fin globale. Les valeurs sont des j-p cumulés
depuis le démarrage.

| Brique | Durée | ES | EF | Marge totale | Critique |
|---|---:|---:|---:|---:|---|
| `BR-001` | 6 | 3 | 9 | 39 | non |
| `BR-002` | 6 | 9 | 15 | 39 | non |
| `BR-003` | 3 | 3 | 6 | 12 | non |
| `BR-004` | 5 | 26 | 31 | 31 | non |
| `BR-005` | 3 | 15 | 18 | 39 | non |
| `BR-006` | 3 | 15 | 18 | 39 | non |
| `BR-007` | 3 | 0 | 3 | 12 | non |
| `BR-008` | 4 | 3 | 7 | 41 | non |
| `BR-009` | 5 | 3 | 8 | 40 | non |
| `BR-010` | 7 | 31 | 38 | 31 | non |
| `BR-011` | 6 | 15 | 21 | 48 | non |
| `BR-012` | 12 | 38 | 50 | 31 | non |
| `BR-013` | 8 | 18 | 26 | 0 | **oui** |
| `BR-014` | 10 | 8 | 18 | 0 | **oui** |
| `BR-015` | 8 | 0 | 8 | 0 | **oui** |
| `BR-016` | 12 | 26 | 38 | 0 | **oui** |
| `BR-017` | 10 | 38 | 48 | 0 | **oui** |
| `BR-018` | 10 | 48 | 58 | 0 | **oui** |
| `BR-019` | 15 | 58 | 73 | 0 | **oui** |
| `BR-020` | 8 | 73 | 81 | 0 | **oui** |
| `BR-021` | 10 | 0 | 10 | 16 | non |

La marge de `BR-020` concerne son effort de clôture. Ses activités de contrôle
par consommateur démarrent à `ES=0` et accompagnent les bascules.

## 4. Branches parallélisables

### 4.1 Fondation QF/Rights

```text
BR-021 (0 -> 10)
  --------------------\
                       -> BR-016 au plus tôt à 26
BR-015 -> BR-014 -> BR-013
```

`BR-021` dispose de 16 j-p de marge théorique. Elle reste prioritaire `P0`
car une difficulté SQL/sécurité peut consommer rapidement cette marge et
bloquer `BR-016/017`.

### 4.2 Noyau de composition

```text
BR-007
  -> BR-001 -> BR-002 -> BR-005/006
  -> BR-003 --------------------------\
  -> BR-008/009                         -> BR-004 -> BR-010
BR-014 -> BR-013 ----------------------/
```

Cette branche termine au plus tôt à j-p 38. Elle peut être menée en parallèle
de la préparation de la distribution, mais `BR-012` ne démarre qu'après
`BR-004`, `BR-010`, `BR-011`, `BR-013` et `BR-014`.

### 4.3 Projection et Workbench

```text
BR-001/002/009 -> BR-011
BR-004/010/011/013/014 -> BR-012 (fin au plus tôt : 50)
```

Cette branche n'allonge pas le chemin critique tant qu'elle reste dans sa
marge de 31 j-p. La marge ne permet pas d'exposer l'UI avant `IG-05`.

## 5. Jonctions bloquantes

| Jonction | Entrées obligatoires | Sortie bloquée | Mesure de pilotage |
|---|---|---|---|
| `J1 — Activation` | `BR-015` | `BR-014` | couverture de la matrice des préconditions |
| `J2 — OfferVersion v2` | `BR-003`, `BR-014`, `X-02`, `X-05` | `BR-013` | décisions métier disponibles, tests v1/v2 prêts |
| `J3 — Distribution` | `BR-013`, `BR-014`, `BR-021`, `X-04` | `BR-016` | consumer registry complet, fondation et cycle acceptés |
| `J4 — Rights` | `BR-016` et autres prérequis `BR-017` | `BR-017` | replay/suspension et lineage testés |
| `J5 — Finance` | `BR-013`, `BR-017`, `X-05` | `BR-018` | règles causales et idempotence prêtes |
| `J6 — Dotation` | `BR-013`, `BR-017`, `BR-018`, `X-06` | `BR-019` | owner et contrats de handoff disponibles |
| `J7 — Retrait final` | `IG-06`, `IG-07`, `IG-08`, observation | clôture `BR-020` | zéro consommateur, zéro divergence, rollback non déclenché |

## 6. Dépendances métier susceptibles de devenir critiques

| Entrée | Marge avant impact | Risque de calendrier | Action de préparation |
|---|---:|---|---|
| `X-02` catalogue/mappings Produit | avant fin de `BR-014` | bloque `BR-013` | préparer codes, versions et cas d'acceptation pendant `BR-015/014` |
| `X-04` registre consommateurs | avant fin de `BR-013` | bloque `BR-016` | inventorier dès `LOT-T` |
| `X-05` règles Finance | avant fin de `BR-017` | bloque `BR-018` | préparer contrats et scénarios durant `BR-016/017` |
| `X-06` owner Dotation | avant fin de `BR-018` | bloque `BR-019` | nomination avant `IG-07` |
| `X-07` cible/rollback | dès le départ pour `BR-021` | peut consommer sa marge de 16 j-p | réserver environnement et données avant lancement |

## 7. Ressources à ne pas exécuter en conflit

Le parallélisme logique ne doit pas produire de concurrence non maîtrisée sur :

- le même catalogue de contrats Offer/API ;
- le même mapping `offer_offer_version` ;
- les CHECKs d'état, audit et outbox Offer ;
- la même cible SQL ou fenêtre de migration ;
- les contrats Rights/EBS entre `BR-016` et `BR-017` ;
- les contrats Finance entre `BR-018` et `BR-019`.

Lorsque deux briques modifient la même surface, une intégration ordonnée est
requise même si leur travail de préparation est parallèle.

## 8. Stratégie de réduction du délai sans réduction de preuve

Les optimisations autorisées sont :

1. démarrer `BR-021`, `BR-015` et `BR-007` en parallèle ;
2. préparer `X-02` et `X-04` pendant `BR-015/014` ;
3. paralléliser `BR-001`, `BR-003`, `BR-008` et `BR-009` après `BR-007` ;
4. paralléliser `BR-005`, `BR-006` et `BR-011` après leurs prérequis ;
5. préparer les harnais de replay/distribution avant `BR-016`, sans brancher
   le runtime ;
6. préparer les scénarios Finance et Dotation pendant `BR-016/017` ;
7. collecter les preuves de `BR-020` au fil de chaque bascule.

Ne sont pas des optimisations admissibles :

- fusionner publication et activation ;
- omettre les tests SQL, tenant, replay ou non-régression ;
- exposer une UI avant autorité serveur ;
- raccourcir le cycle d'observation legacy ;
- paralléliser deux écritures concurrentes sur la même source de vérité ;
- retirer un consommateur ou un historique pour réduire la charge.

## 9. Seuils d'alerte

| Indicateur | Seuil | Effet |
|---|---|---|
| dérive d'une brique critique | > 0 j-p sans récupération identifiée | nouvelle date de fin calculée |
| consommation de marge `BR-021` | ≥ 8 j-p | pilotage quotidien jusqu'à `IG-01` |
| entrée `X-02` non prête | à 50 % de `BR-014` | risque direct sur `BR-013` |
| registre `X-04` incomplet | au démarrage de `BR-013` | `BR-016` classée bloquée |
| owner `X-06` absent | au démarrage de `BR-018` | `BR-019` classée bloquée |
| divergence de lecture legacy/cible | toute divergence inexpliquée | aucune bascule `BR-020` |
| échec de rollback | un seul cas | arrêt du lot concerné |

## 10. Verdict d'ordonnancement

```text
NODES = 21
CRITICAL_NODES = 8
IDEAL_TOTAL_EFFORT = 154 person-days
CRITICAL_PATH = 81 sequential person-days
NON_COMPRESSIBLE_ELAPSED_TIME = at least one release observation cycle
PARALLEL_START = BR-007 + BR-015 + BR-021 + BR-020 controls
FINAL_JOIN = BR-012 complete + BR-020 final PASS
```
