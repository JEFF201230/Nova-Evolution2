# Roadmap officielle d'implémentation des briques Offer V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Mission | `PROGRAM-OFFER-IMPLEMENTATION-ROADMAP-001` |
| Type | Planification d'implémentation |
| Date | 2026-07-24 |
| Objet officiel de gouvernance | `WAVE` |
| Périmètre | 21 briques V2 certifiées, ni plus ni moins |
| Nature du livrable | Ordonnancement ; aucune autorisation d'exécution ou de production |

## 1. Décision de planification

La présente roadmap transforme les 21 briques du registre officiel V2 en ordre
d'implémentation. Elle prend pour acquis, sans les réauditer :

- l'Infrastructure V2 figée ;
- le Registre Officiel des Briques V2 ;
- la Matrice Officielle de Certification Structurelle V2 ;
- le Référentiel des Documents Officiels V2 ;
- les faits certifiés `FOUNDATION_READY`, `CANONICAL_WAVE_MODEL` et
  `CANONICAL_MM_L01_03_CONTRACT`.

Elle ne modifie aucun code, schéma, runtime, contrat ou document d'autorité.
Les « lots » cités sont uniquement des regroupements techniques d'exécution
dans une `WAVE`. Ils ne sont ni des Work Packages officiels, ni des objets de
gouvernance.

## 2. Règles d'exécution

1. Une brique n'entre en réalisation que lorsque tous ses prérequis directs
   sont acceptés par leur Gate d'implémentation.
2. Chaque modification future est additive, réversible par désactivation ou
   migration forward, et compatible avec les lectures historiques.
3. Une OfferVersion publiée n'est jamais réécrite.
4. Publication, activation et ouverture d'Operation restent trois actes
   distincts.
5. Les preuves souveraines sont résolues côté serveur.
6. Aucun lot ne déplace les autorités Offer, Rights, Budget, Ledger, Dotation,
   EBS, QF ou Simulation.
7. Chaque lot doit compiler, réussir ses tests et démontrer la non-régression
   avant exposition progressive.
8. Le protocole `V2-BR-020` encadre toute bascule de consommateur dès le début
   du chantier et ne peut être clos qu'après observation du dernier retrait.

## 3. Ordre topologique complet

L'ordre ci-dessous est l'ordre de démarrage de référence. Les lignes d'un même
rang sont parallélisables sous réserve de capacité d'équipe et d'absence de
conflit sur une même ressource.

| Rang | Briques démarrables | Résultat de rang |
|---:|---|---|
| 1 | `V2-BR-007`, `V2-BR-015`, `V2-BR-021`; démarrage du contrôle `V2-BR-020` | Contrat de composition, frontière serveur et fondation QF/Rights pris en charge |
| 2 | `V2-BR-001`, `V2-BR-003`, `V2-BR-008`, `V2-BR-009`, `V2-BR-014` | Racines du modèle, règles et activation explicite disponibles |
| 3 | `V2-BR-002`, `V2-BR-013` | Versions de composants et contrat OfferVersion v2 disponibles |
| 4 | `V2-BR-005`, `V2-BR-006`, `V2-BR-011`, `V2-BR-016` | Configuration, références, projection et diffusion technique disponibles |
| 5 | `V2-BR-004`, `V2-BR-017` | Snapshot de composition et lineage Rights disponibles |
| 6 | `V2-BR-010`, `V2-BR-018` | Validation déterministe et lineage financier disponibles |
| 7 | `V2-BR-012`, `V2-BR-019` | Workbench et Dotation implémentables sur les contrats acceptés |
| 8 | clôture `V2-BR-020` | Derniers consommateurs basculés, observation terminée, retrait certifiable |

À l'intérieur d'un rang, l'ordre des identifiants n'est pas une dépendance.
Le détail exhaustif des arcs est porté par
[`PROGRAM_OFFER_DEPENDENCY_GRAPH.md`](./PROGRAM_OFFER_DEPENDENCY_GRAPH.md).

## 4. Séquence de livraison par lots

| Séquence | Lot technique | Briques | Gate de sortie | Valeur livrée |
|---:|---|---|---|---|
| T | `LOT-T — Transition continue` | `BR-020` | `IG-T` | Bascule réversible et retrait sans rupture, appliqués par consommateur |
| 1 | `LOT-01 — Fondation QF/Rights` | `BR-021` | `IG-01` | Cinq objets QF/Rights reproductibles et sécurisés |
| 2 | `LOT-02 — Cycle Offer sécurisé` | `BR-015`, `BR-014` | `IG-02` | Activation explicite, idempotente, auditée et non falsifiable |
| 3 | `LOT-03 — Contrats Offer V2` | `BR-007`, `BR-008`, `BR-009`, `BR-003`, `BR-013` | `IG-03` | Contrats typés et versionnés, compatibles avec l'historique |
| 4 | `LOT-04 — Composants et composition` | `BR-001`, `BR-002`, `BR-005`, `BR-006`, `BR-004`, `BR-010` | `IG-04` | Composition reproductible et validation sans effet |
| 5 | `LOT-05 — Projection et Workbench` | `BR-011`, `BR-012` | `IG-05` | Administration Offer via API, sans source UI concurrente |
| 6 | `LOT-06 — Distribution et Rights` | `BR-016`, `BR-017` | `IG-06` | Propagation supervisée et décisions Rights sourcées OfferVersion |
| 7 | `LOT-07 — Finance causale` | `BR-018` | `IG-07` | Nouveaux flux financiers traçables jusqu'à OfferVersion |
| 8 | `LOT-08 — Dotation` | `BR-019` | `IG-08` | Attribution/délivrance souveraine sans ledger parallèle |

`LOT-T` démarre avant la première bascule, accompagne les lots 1 à 8 et se
termine après au moins un cycle de release complet sans rollback du dernier
consommateur. Les autres lots peuvent être développés en parallèle uniquement
si leurs arcs d'entrée sont satisfaits.

## 5. Fenêtres de parallélisme

| Fenêtre | Voie A | Voie B | Voie C | Jonction |
|---|---|---|---|---|
| P1 | `BR-021` | `BR-015 -> BR-014` | `BR-007 -> BR-003/008/009/001` | `BR-013` et `BR-016` |
| P2 | `BR-001/002/005/006/004/010` | `BR-016 -> BR-017` après ses prérequis | préparation UI sans activation | `BR-012` et `BR-018` |
| P3 | `BR-011 -> BR-012` | `BR-017 -> BR-018 -> BR-019` | contrôles `BR-020` | clôture du programme |

La préparation UI de P2 ne permet aucune mutation réelle avant `IG-05`. La
préparation des contrats aval ne permet aucune diffusion avant `IG-06`.

## 6. Jalons d'implémentation

| Jalon | Condition exacte | Décision permise |
|---|---|---|
| `M0 — READY` | Faits certifiés et WAVE applicables | Ouvrir les lots techniques autorisés |
| `M1 — FOUNDATION` | `IG-01 PASS` | Raccorder ultérieurement Rights aux contrats Offer |
| `M2 — SAFE_CYCLE` | `IG-02 PASS` | Utiliser `ACTIVE` pour les nouveaux parcours |
| `M3 — TYPED_OFFER` | `IG-03 PASS` | Persister une composition typée additive |
| `M4 — COMPOSABLE` | `IG-04 PASS` | Exposer projection et capacités applicatives de composition |
| `M5 — OPERABLE` | `IG-05 PASS` | Ouvrir progressivement le Workbench |
| `M6 — DISTRIBUTED` | `IG-06 PASS` | Basculer un consommateur Rights/EBS selon `BR-020` |
| `M7 — FINANCE_LINEAGED` | `IG-07 PASS` | Accepter de nouveaux mouvements financiers sourcés |
| `M8 — DOTATION_READY` | `IG-08 PASS` | Ouvrir l'attribution/délivrance Dotation |
| `M9 — LEGACY_RETIRED` | `IG-T PASS` | Retirer les seuls producteurs legacy prouvés sans consommateur |

## 7. Politique de déploiement sans rupture

Chaque lot suit la même séquence :

```text
implémentation désactivée
  -> compilation
  -> tests unitaires et de contrat
  -> tests d'intégration sur cible isolée
  -> test de compatibilité historique
  -> déploiement additif
  -> exposition par cohorte/flag
  -> observation
  -> extension ou rollback logique
```

Un échec remet le lot à corriger ; il ne rouvre ni l'architecture ni la
certification structurelle. Aucun `DROP`, renommage destructif, backfill
sémantique d'historique ou double écriture permanente n'est admis.

## 8. Charge de planification

Les estimations du backlog totalisent **154 jours-personne idéaux**, hors
aléas, revues, temps d'attente d'environnement et cycle d'observation final.
Ce total n'est pas une durée calendaire. Avec parallélisme, le chemin critique
porte **81 jours-personne séquentiels** plus au moins un cycle de release
d'observation pour `BR-020`.

Les détails, hypothèses et marges sont décrits dans :

- [`PROGRAM_OFFER_IMPLEMENTATION_BACKLOG.md`](./PROGRAM_OFFER_IMPLEMENTATION_BACKLOG.md) ;
- [`PROGRAM_OFFER_CRITICAL_PATH.md`](./PROGRAM_OFFER_CRITICAL_PATH.md).

## 9. Critère de clôture de la mission d'implémentation

La roadmap est exécutée lorsque les 21 lignes du registre ont un résultat
d'implémentation accepté :

- 20 briques avec preuve d'implémentation, compilation, tests et
  non-régression ;
- `V2-BR-020`, classée `NOT_APPLICABLE` en implémentation logicielle, avec
  preuve d'application du protocole à chaque consommateur et de clôture du
  dernier cycle d'observation ;
- toutes les Gates `IG-01` à `IG-08` et `IG-T` à `PASS` ;
- aucun producteur legacy retiré sans remplacement prouvé ;
- aucune nouvelle brique, autorité ou architecture introduite.
