# Référentiel officiel d'exécution — PROGRAM OFFER V2

| Propriété | Valeur |
|---|---|
| Programme | VEEDDA |
| Domaine | PROGRAM OFFER V2 |
| Mission | `PROGRAM-OFFER-EXECUTION-RULES-001` |
| Type | PROGRAM GOVERNANCE |
| Profil | ARCHITECTURE |
| Date | 2026-07-24 |
| Objet officiel de gouvernance | `WAVE` |
| Autorité d'exécution | Référentiel unique pour l'exécution des WAVES et des missions PROGRAM OFFER |
| Décision | `PROGRAM OFFER EXECUTION RULES = READY_FOR_REVIEW` |

## 1. Autorité, portée et invariants

Le présent document est l'autorité normative unique de gouvernance pour
l'exécution des WAVES et des futures missions d'implémentation de PROGRAM
OFFER V2. Une mission future applique ces règles ; elle ne crée pas de règle
de gouvernance locale, parallèle ou supplémentaire.

Il constitue la suite directe, sans retour en arrière, de :

- `PROGRAM-V2-STRUCTURAL-CERTIFICATION-001` ;
- `PROGRAM-OFFER-IMPLEMENTATION-ROADMAP-001` ;
- `PROGRAM-OFFER-WAVE-PLAN-001`.

Les éléments suivants sont des entrées définitives, prises pour acquises sans
réanalyse :

- l'Infrastructure V2 figée ;
- les 21 briques V2 certifiées et leurs frontières ;
- le WAVE PLAN ;
- le graphe de dépendances ;
- les lots techniques ;
- les Gates ;
- le backlog ;
- le chemin critique ;
- les faits certifiés `FOUNDATION_READY`, `CANONICAL_WAVE_MODEL` et
  `CANONICAL_MM_L01_03_CONTRACT`.

`WAVE` demeure l'unique objet officiel de gouvernance d'exécution. Les lots
sont uniquement des unités techniques internes rattachées à une WAVE. Ils ne
sont ni des objets officiels de gouvernance, ni des Work Packages, ni une
séquence concurrente.

Le présent référentiel ne modifie aucun ordre, rattachement, périmètre,
prérequis, Gate, critère de Gate, brique, lot, chemin critique ou décision
d'architecture. Les documents figés conservent leur autorité sur leur contenu ;
le présent document gouverne exclusivement la manière de les exécuter.

Les termes normatifs ont le sens suivant :

- **DOIT** : obligation sans dérogation par une mission ;
- **NE DOIT PAS** : interdiction sans dérogation par une mission ;
- **PEUT** : faculté utilisable seulement si toutes les obligations restent
  satisfaites ;
- **preuve** : élément traçable, reproductible et rattaché à la mission, à la
  WAVE, à l'incrément exact et à la cible vérifiée ;
- **validation Program** : décision explicite du Program Director ; elle ne se
  déduit jamais du seul achèvement technique.

## 2. Principes impératifs d'exécution

1. Une seule WAVE PEUT être `ACTIVE` à un instant donné.
2. Une mission d'implémentation NE PEUT être exécutée que dans la WAVE
   `ACTIVE`.
3. L'ordre officiel des WAVES, des dépendances et des Gates DOIT être respecté.
4. Le parallélisme est autorisé uniquement à l'intérieur de la WAVE active,
   pour les travaux déclarés parallélisables par le WAVE PLAN, sans conflit de
   ressources ni incompatibilité runtime.
5. Un échec reste dans la mission, la brique, le lot technique, la Gate et la
   WAVE concernés. Il ne rouvre ni l'architecture ni la certification
   structurelle.
6. Aucun avancement déclaré ne remplace une preuve obligatoire.
7. Aucun statut de mission, de WAVE ou de Gate ne peut être déduit
   implicitement. Toute transition DOIT être enregistrée.
8. Les verdicts de Gate `PASS`, `FAIL` et `BLOCKED_BY_EVIDENCE` ne sont pas des
   statuts de WAVE.

## 3. Cycle de vie normatif d'une WAVE

Le flux nominal obligatoire est :

```text
QUEUED -> READY -> ACTIVE -> READY_FOR_REVIEW -> COMPLETED
```

Une transition ne peut sauter aucun état. Un retour n'est autorisé que dans
les cas de correction ou d'interruption définis par le présent référentiel.

### 3.1 Définition des états

| État | Définition normative |
|---|---|
| `QUEUED` | WAVE ordonnée mais non ouverte. Aucun travail d'implémentation de ses briques n'est autorisé. |
| `READY` | Toutes les conditions d'entrée sont satisfaites. La WAVE attend l'ouverture explicite par le Program Director et la libération de l'unique emplacement actif. |
| `ACTIVE` | Unique WAVE dans laquelle les missions autorisées peuvent être exécutées. |
| `READY_FOR_REVIEW` | Toutes les missions prévues sont exécutées, vérifiées et soumises ; le paquet de preuves de WAVE est complet et les verdicts de Gates sont attendus. Aucun nouveau périmètre n'est autorisé. |
| `COMPLETED` | Toutes les missions sont terminées, toutes les conditions de sortie sont satisfaites, toutes les Gates de sortie sont à `PASS` et le point de reprise est enregistré. |

`BLOCKED` reste, conformément au WAVE PLAN figé, un état suspensif hors du
flux nominal. Il est utilisable uniquement lorsqu'une dépendance factuelle ou
une entrée obligatoire empêche réellement la poursuite. Le registre DOIT
nommer le bloqueur, les missions et briques affectées, la preuve du blocage et
la condition de reprise.

Une WAVE suspendue revient à son dernier état compatible parmi `READY`,
`ACTIVE` ou `READY_FOR_REVIEW` lorsque le bloqueur est levé. `BLOCKED`
n'autorise ni l'ouverture d'une autre WAVE, ni le contournement d'une
dépendance.

### 3.2 Transition `QUEUED -> READY`

La transition est autorisée uniquement si :

1. la WAVE précédente est `COMPLETED`, sauf pour la première WAVE déjà ouverte
   par le WAVE PLAN ;
2. toutes les dépendances d'entrée de la WAVE sont satisfaites ;
3. toutes les Gates précédentes requises ont prononcé `PASS` ;
4. les entrées métier obligatoires applicables sont disponibles ou chaque
   absence est explicitement bornée à un travail non démarré ;
5. le périmètre des briques, lots, missions, cibles et preuves est conforme au
   WAVE PLAN ;
6. aucune incompatibilité runtime connue n'empêche l'exécution ;
7. le Program Director enregistre la disponibilité de la WAVE.

La transition vers `READY` ne constitue pas l'ouverture de la WAVE et
n'autorise aucune implémentation.

### 3.3 Transition `READY -> ACTIVE`

La transition est autorisée uniquement si :

1. toutes les conditions de `READY` sont encore vraies ;
2. la WAVE précédente est `COMPLETED` ;
3. toutes les dépendances requises sont satisfaites ;
4. toutes les Gates précédentes requises sont à `PASS` ;
5. aucune autre WAVE n'est `ACTIVE` ;
6. aucune incompatibilité de contrats, schémas, versions, configuration,
   environnement, déploiement ou consommateurs n'empêche l'exécution
   runtime ;
7. le mécanisme de désactivation ou de retour au chemin précédent est
   identifié pour les surfaces concernées ;
8. le Program Director prononce et enregistre l'ouverture.

Une incompatibilité runtime constatée interdit la transition. Elle DOIT être
consignée comme bloqueur factuel et traitée dans le périmètre déjà autorisé ;
elle n'autorise aucune nouvelle architecture.

### 3.4 Transition `ACTIVE -> READY_FOR_REVIEW`

La transition est autorisée uniquement si :

1. toutes les missions prévues pour la WAVE ont atteint
   `READY_FOR_REVIEW` ou `COMPLETED` ;
2. aucune mission n'a un échec technique, un critère de réussite ouvert ou une
   preuve obligatoire absente ;
3. les compilations, tests et contrôles de non-régression exigés sont verts ;
4. les paquets de preuves de toutes les missions sont consolidés par Gate ;
5. les contrôles transverses applicables, notamment ceux de `IG-T`, sont
   documentés ;
6. le point de reprise de WAVE est complet ;
7. aucune modification hors périmètre n'est présente.

À cet état, seules la revue, la correction d'écarts et la consolidation des
preuves sont autorisées. Toute correction technique replace la WAVE en
`ACTIVE`. Une correction strictement documentaire de preuve peut rester en
`READY_FOR_REVIEW` si elle ne change ni l'incrément, ni les résultats, ni le
périmètre vérifié.

### 3.5 Transition `READY_FOR_REVIEW -> COMPLETED`

La transition est autorisée uniquement si toutes les conditions de sortie de
la section 7 sont satisfaites et si le Program Director prononce la validation
de WAVE.

Un verdict de Gate `FAIL` replace la WAVE en `ACTIVE` pour correction dans son
périmètre. Un verdict `BLOCKED_BY_EVIDENCE` maintient la WAVE en
`READY_FOR_REVIEW`, sauf si l'absence correspond à un bloqueur factuel
empêchant réellement la poursuite ; dans ce seul cas, la WAVE passe
temporairement à `BLOCKED`.

## 4. Conditions d'entrée d'une WAVE

Avant toute activation, une fiche d'entrée DOIT attester :

| Contrôle d'entrée | Condition obligatoire |
|---|---|
| Ordre | La WAVE est la prochaine WAVE du WAVE PLAN. |
| WAVE précédente | Elle est `COMPLETED`, sauf cas initial déjà fixé par le WAVE PLAN. |
| Dépendances | Toutes les dépendances directes et transitives nécessaires au démarrage sont satisfaites. |
| Gates précédentes | Tous les verdicts requis sont `PASS`. |
| Missions | Chaque mission de démarrage possède son contrat complet et sa Definition of Ready. |
| Entrées `X-*` | Les entrées applicables sont disponibles ; une absence suspend la seule ligne concernée lorsqu'un parallélisme officiel reste possible. |
| Runtime | Aucun conflit connu de contrat, schéma, version, configuration, environnement, ressource ou consommateur. |
| Réversibilité | Désactivation, observation et retour au chemin précédent sont identifiés selon la surface. |
| Gouvernance | Aucune autre WAVE n'est `ACTIVE` et aucun chantier Offer parallèle n'est ouvert. |
| Décision | L'ouverture est explicitement enregistrée par le Program Director. |

Une déclaration non prouvée, une intention de corriger plus tard ou une
dérogation locale ne satisfait pas une condition d'entrée.

## 5. Cycle de vie normatif d'une mission

Le flux obligatoire d'une mission est :

```text
CREATED
  -> EXECUTED
  -> VERIFIED
  -> READY_FOR_REVIEW
  -> PROGRAM_VALIDATED
  -> COMPLETED
```

Ces états correspondent respectivement à : mission créée, mission exécutée,
mission vérifiée, mission prête pour revue, validation Program et mission
terminée.

### 5.1 `CREATED`

Une mission est `CREATED` lorsque son contrat contient au minimum :

- un identifiant unique ;
- sa WAVE ;
- sa brique officielle ;
- son lot technique interne ;
- son objectif borné ;
- ses dépendances et entrées ;
- son périmètre autorisé et son périmètre interdit ;
- ses critères de réussite factuels ;
- ses preuves attendues ;
- sa Gate de contribution ;
- son mécanisme de désactivation ou de reprise lorsqu'il est applicable ;
- son point de reprise initial et la mission suivante envisagée.

La création d'une mission rattachée à une WAVE non active peut servir
uniquement à la préparation documentaire expressément permise. Elle
n'autorise aucune implémentation. L'exécution ne commence que si sa WAVE est
`ACTIVE` et sa Definition of Ready satisfaite.

### 5.2 Transition `CREATED -> EXECUTED`

La mission devient `EXECUTED` uniquement lorsque :

1. le travail autorisé est réalisé dans la seule frontière de sa brique ;
2. aucune surface interdite ni brique extérieure n'est modifiée ;
3. l'incrément exact est identifié ;
4. les changements et effets attendus sont inventoriés ;
5. le point de reprise après exécution est enregistré.

`EXECUTED` signifie que l'exécution est achevée ; il ne signifie ni que le
résultat est vérifié, ni qu'il est accepté.

### 5.3 Transition `EXECUTED -> VERIFIED`

La mission devient `VERIFIED` uniquement lorsque :

1. les unités affectées et les consommateurs de contrats requis compilent ;
2. les tests nouveaux et existants requis sont verts ;
3. les tests couvrent les critères de réussite de la mission ;
4. la non-régression applicable est démontrée ;
5. l'absence de modification hors périmètre est contrôlée ;
6. les preuves sont reproductibles et rattachées à l'incrément exact ;
7. les écarts éventuels sont tous fermés.

La vérification DOIT être distincte de la simple déclaration d'exécution.

### 5.4 Transition `VERIFIED -> READY_FOR_REVIEW`

La mission devient `READY_FOR_REVIEW` uniquement lorsque :

1. la matrice critères de réussite/preuves est complète ;
2. le paquet de preuves est lisible, localisable et consolidé ;
3. la contribution à la Gate officielle est identifiée sans inventer de
   verdict ;
4. le point de reprise complet est fourni ;
5. la mission suivante autorisée et les dépendances restantes sont nommées ;
6. le responsable de réalisation demande explicitement la revue Program.

### 5.5 Transition `READY_FOR_REVIEW -> PROGRAM_VALIDATED`

Le Program Director peut prononcer `PROGRAM_VALIDATED` uniquement après avoir
confirmé :

- le respect intégral du contrat de mission ;
- la conformité des preuves ;
- la réussite des contrôles minimums de la section 9 ;
- le respect de la WAVE, de la brique, du lot et de la Gate ;
- l'absence de modification de l'architecture et du gel V2 ;
- la complétude du point de reprise.

La validation d'une mission accepte sa contribution. Elle ne prononce pas à
elle seule le `PASS` d'une Gate couvrant plusieurs missions.

En cas de rejet :

- une correction d'implémentation ou de test ramène la mission à `EXECUTED` ;
- une correction de vérification ou de preuve ramène la mission à `VERIFIED` ;
- aucun rejet ne permet de changer de WAVE, de brique ou d'architecture.

### 5.6 Transition `PROGRAM_VALIDATED -> COMPLETED`

La mission devient `COMPLETED` lorsque :

1. la décision de validation Program est enregistrée ;
2. son statut de contribution à la Gate est enregistré sans surdéclaration ;
3. son point de reprise final est publié dans l'état PROGRAM ;
4. la prochaine mission autorisée ou la mise en revue de la WAVE est indiquée.

Une mission `COMPLETED` n'est pas rouverte. Un défaut découvert ultérieurement
fait l'objet d'une mission corrective dans la même gouvernance et ne réécrit
pas l'historique de validation.

## 6. Règles obligatoires des missions

Toute mission DOIT :

1. appartenir à exactement une WAVE officielle ;
2. appartenir à exactement une brique officielle ;
3. être rattachée à exactement un lot technique existant, sans conférer à ce
   lot un statut de gouvernance ;
4. respecter les dépendances de sa brique et l'ordre de sa WAVE ;
5. définir un périmètre autorisé et un périmètre interdit ;
6. définir son point de reprise avant exécution et le mettre à jour après
   chaque interruption et à sa clôture ;
7. définir les preuves attendues et leur mode de collecte ;
8. définir des critères de réussite factuels et vérifiables ;
9. identifier la Gate officielle qu'elle alimente ;
10. conserver la traçabilité entre objectif, changements, tests, preuves,
    verdict et point de reprise.

Une mission intégrée ou transverse reste rattachée à une seule brique. Toute
interaction avec une autre brique se limite à l'usage de son contrat déjà
accepté ; elle n'autorise pas sa modification.

## 7. Conditions de sortie d'une WAVE

Une WAVE est `COMPLETED` uniquement si toutes les conditions suivantes sont
simultanément vraies :

1. toutes ses missions sont `COMPLETED` ;
2. tous les paquets affectés et consommateurs de contrats requis compilent ;
3. tous les tests nouveaux et existants requis sont verts ;
4. la non-régression est démontrée sur toutes les surfaces applicables ;
5. toutes les preuves obligatoires sont disponibles, reproductibles et
   rattachées à la WAVE, aux missions, aux incréments et aux cibles ;
6. toutes ses Gates de sortie ont prononcé `PASS` ;
7. les contrôles `IG-T` applicables à la WAVE sont enregistrés ;
8. aucun écart bloquant, aucune preuve manquante et aucun changement hors
   périmètre ne subsistent ;
9. le point de reprise de WAVE et l'état PROGRAM sont complets ;
10. le Program Director a enregistré la validation de WAVE.

Une compilation partielle, un sous-ensemble de tests vert, une preuve
déclarative, une Gate non prononcée ou une dérogation implicite interdit le
statut `COMPLETED`.

## 8. Gestion normative des interruptions

### 8.1 Reprise

Toute interruption DOIT produire immédiatement un point de reprise contenant
au minimum l'état défini à la section 11. La reprise :

1. s'effectue dans la même mission et la même WAVE ;
2. repart du dernier incrément vérifié, ou à défaut du dernier incrément
   explicitement identifié comme sûr ;
3. revalide les dépendances, le runtime, les flags, les données, les
   consommateurs et les preuves devenues susceptibles d'obsolescence ;
4. rejoue les contrôles affectés par l'interruption ;
5. conserve la trace de l'interruption et de la décision de reprise.

Une reprise ne permet pas d'élargir le périmètre. Un besoin hors périmètre est
signalé au Program Director et reste non exécuté.

### 8.2 Rollback documentaire

Le rollback documentaire consiste à revenir au dernier état documentaire
validé lorsqu'un statut, une preuve, un compte rendu ou un point de reprise est
erroné. Il DOIT :

- identifier le document ou l'enregistrement invalidé ;
- conserver la trace, la raison et l'auteur de la correction ;
- restaurer le dernier statut prouvé ;
- marquer l'information remplacée comme non valide sans effacer l'historique ;
- mettre à jour le point de reprise.

Le rollback documentaire NE PEUT modifier un document d'autorité figé,
réécrire une preuve technique, transformer un échec en succès ni tenir lieu de
rollback runtime. Un rollback runtime suit exclusivement le mécanisme
réversible déjà prévu par la mission et la brique.

### 8.3 Poursuite

Lorsqu'une mission est interrompue, les autres missions PEUVENT poursuivre
uniquement si :

- elles appartiennent à la même WAVE `ACTIVE` ;
- le WAVE PLAN autorise leur parallélisme ;
- elles ne dépendent pas du résultat interrompu ;
- elles ne partagent aucun conflit de fichiers, contrats, données, runtime,
  déploiement ou ressources ;
- leur poursuite ne réduit aucune preuve ni capacité de rollback.

Sinon, la poursuite est interdite. Une ligne bloquée ne qualifie toute la WAVE
de `BLOCKED` que si elle empêche réellement tous les travaux autorisés ou la
sortie de WAVE.

### 8.4 Changement de WAVE

Une mission NE PEUT jamais changer, ouvrir, fermer ou activer une WAVE.

Un changement de WAVE est autorisé uniquement lorsque :

1. la WAVE active est `COMPLETED` ;
2. son point de reprise final est enregistré ;
3. la WAVE suivante dans l'ordre officiel satisfait ses conditions d'entrée ;
4. le Program Director prononce d'abord sa disponibilité `READY`, puis son
   ouverture `ACTIVE` ;
5. toutes les autres WAVES restent `QUEUED`.

Une interruption, un `FAIL`, un `BLOCKED_BY_EVIDENCE` ou un statut `BLOCKED`
ne permet jamais de contourner la WAVE courante.

## 9. Non-régression et critères minimums de validation

### 9.1 Compilation

La preuve de compilation DOIT couvrir :

- toutes les unités modifiées ;
- toutes les unités affectées ;
- les consommateurs des contrats modifiés ou vérifiés ;
- les builds serveur, client, contrats ou autres surfaces applicables ;
- les commandes exécutées, versions d'outils, cible, date et résultat complet.

Toute compilation rouge interdit `VERIFIED`, `PROGRAM_VALIDATED` et
`COMPLETED`.

### 9.2 Tests

Les tests minimums DOIVENT inclure, selon la surface :

- les tests nouveaux dérivés des critères de réussite ;
- les suites existantes pertinentes ;
- les tests unitaires, de contrat et d'intégration ;
- les tests de sécurité, tenant, rôles et séparation des tâches ;
- les tests d'idempotence, concurrence, retry, replay et erreurs ;
- les tests de compatibilité historique ;
- les tests E2E et d'accessibilité lorsqu'ils sont applicables.

Un test antérieur ne peut être supprimé, neutralisé, ignoré ou assoupli pour
obtenir un résultat vert. Toute exception déjà prévue par une autorité figée
DOIT être explicitement prouvée ; une mission ne peut en créer une nouvelle.

### 9.3 Preuves

Le paquet minimum de preuves DOIT contenir :

- l'identité de la mission, de la WAVE, de la brique et du lot ;
- l'incrément ou la révision exacte vérifiée et la cible ;
- l'inventaire borné des changements ;
- les résultats complets de compilation ;
- les résultats complets des tests nouveaux et existants ;
- la matrice critères de réussite/preuves ;
- les contrôles de non-régression ;
- les éléments de sécurité, runtime, observation et réversibilité applicables ;
- les écarts, leur résolution et le responsable ;
- la contribution à la Gate, sans inventer son verdict ;
- le point de reprise.

Une preuve absente ne peut être remplacée par une opinion, une nouvelle règle,
une analyse d'architecture ou une validation orale.

### 9.4 Seuil minimum de passage

La validation est interdite si l'une des conditions suivantes est vraie :

- compilation rouge ou incomplète ;
- test obligatoire rouge, désactivé ou non exécuté ;
- critère de réussite non prouvé ;
- régression constatée ;
- preuve obligatoire absente ;
- modification hors frontière de la brique ;
- incompatibilité runtime non résolue ;
- rollback ou désactivation requis mais non démontré ;
- dépendance ou Gate contournée ;
- architecture, gel V2, autorité ou historique modifiés.

Le minimum requis est donc : compilation verte, tests obligatoires verts,
non-régression verte, preuves complètes, périmètre conforme et absence de
condition automatique de `FAIL` définie par les Gates officielles.

## 10. Décisions réservées au Program Director

Les décisions suivantes sont exclusivement réservées au Program Director :

| Décision réservée | Portée |
|---|---|
| Validation de mission | Prononcer `PROGRAM_VALIDATED` après revue du contrat, des résultats, des preuves et du point de reprise. |
| Validation de WAVE | Autoriser `READY_FOR_REVIEW -> COMPLETED` après `PASS` de toutes les Gates de sortie. |
| Ouverture de la WAVE suivante | Prononcer `QUEUED -> READY`, puis `READY -> ACTIVE`, dans l'ordre officiel et après clôture de la WAVE précédente. |
| Validation finale | Constater que toutes les WAVES sont `COMPLETED`, que toutes les Gates requises sont à `PASS` et que les preuves finales sont complètes. |
| Certification finale | Émettre la décision finale de conformité de l'exécution au périmètre V2 figé. Cette décision ne constitue pas une nouvelle certification architecturale. |

Le Program Director :

- NE PEUT déléguer à une mission l'ouverture d'une WAVE ;
- NE PEUT valider implicitement par silence ou par avancement technique ;
- NE PEUT déroger aux dépendances, aux Gates, aux conditions de sortie, au
  WAVE PLAN ou au gel V2 ;
- DOIT enregistrer chaque décision, sa date, son objet et les preuves sur
  lesquelles elle repose ;
- DOIT laisser la WAVE et la mission dans leur état courant si les conditions
  ne sont pas toutes prouvées.

## 11. Point de reprise PROGRAM obligatoire

Après chaque mission, qu'elle soit terminée, rejetée, interrompue ou bloquée,
le PROGRAM DOIT publier un état de reprise unique contenant :

| Champ obligatoire | Contenu attendu |
|---|---|
| État courant | Statut PROGRAM, statut de la WAVE et statut exact de la mission. |
| WAVE active | Identifiant de l'unique WAVE `ACTIVE`, ou absence explicitement justifiée pendant une transition validée. |
| Mission courante | Identifiant, brique, lot, objectif et dernier incrément sûr. |
| Mission suivante | Prochain travail exact autorisé dans la même WAVE, ou revue/clôture si aucun travail ne reste. |
| Dépendances restantes | Dépendances `BR-*`, entrées `X-*`, Gates et preuves encore requises. |
| Point exact de reprise | Action précise, emplacement logique, préconditions à revalider et premier contrôle à exécuter. |
| Vérifications | Derniers résultats de compilation, tests, non-régression et intégration. |
| Preuves | Emplacement et état du paquet de preuves ; critères acquis et critères ouverts. |
| Runtime | État des flags, cohortes, consommateurs, données, métriques, observation et rollback applicables. |
| Gouvernance | Confirmation que les autres WAVES restent `QUEUED` et qu'aucun chantier Offer parallèle n'est ouvert. |

Le format minimal de restitution est :

```text
PROGRAM WORKSITE = PROGRAM OFFER V2
PROGRAM STATE = <état courant>
ACTIVE WAVE = <identifiant>
ACTIVE WAVE STATE = <état>
CURRENT MISSION = <identifiant>
CURRENT MISSION STATE = <état>
BRICK = <V2-BR-nnn>
LOT = <LOT-nn ou LOT-T existant>
LAST SAFE INCREMENT = <référence exacte>
COMPILATION = <résultat>
TESTS = <résultat>
NON_REGRESSION = <résultat>
GATE CONTRIBUTION = <Gate et état de preuve>
REMAINING DEPENDENCIES = <liste ou NONE>
NEXT MISSION = <identifiant ou WAVE REVIEW>
EXACT RESUME POINT = <action précise>
OTHER WAVES = QUEUED
PARALLEL OFFER WORKSITE = FORBIDDEN
```

Le point de reprise NE PEUT déclarer une WAVE suivante active, réduire le
périmètre de preuve, masquer un échec, modifier une dépendance ou rouvrir
l'architecture.

## 12. Interdictions absolues

Une mission ne peut jamais :

1. ouvrir, activer ou exécuter une autre WAVE ;
2. modifier une brique extérieure à son rattachement ;
3. réauditer l'architecture ;
4. créer une nouvelle architecture ;
5. modifier le gel V2 ;
6. créer une nouvelle brique, un nouveau lot, une nouvelle WAVE ou une
   nouvelle Gate ;
7. modifier le WAVE PLAN, le graphe de dépendances, le backlog, les lots, les
   Gates ou le chemin critique ;
8. déplacer une autorité de domaine ou créer une autorité concurrente ;
9. contourner une dépendance, une preuve, une Gate ou une décision du Program
   Director ;
10. poursuivre dans une WAVE ultérieure pour contourner un échec ou un
    blocage ;
11. déclarer une mission ou une WAVE terminée sur la base d'une validation
    implicite ;
12. ajouter une règle locale de gouvernance.

Tout besoin qui semble exiger l'une de ces actions est un arrêt de mission. Il
est consigné dans le point de reprise et transmis au Program Director sans
exécution de l'action interdite.

## 13. Règle de décision en cas d'écart

Lorsqu'une situation d'exécution n'est pas immédiatement résolue par une
ligne opérationnelle :

1. l'exécution s'arrête sur la seule ligne affectée ;
2. le dernier état prouvé est conservé ;
3. les autorités figées et le présent référentiel sont appliqués sans
   extrapolation ;
4. l'option la plus restrictive pour le périmètre, les dépendances, les
   preuves et l'ouverture de WAVE prévaut ;
5. le Program Director statue uniquement dans les décisions qui lui sont
   réservées, sans créer de nouvelle architecture ni de nouvelle règle
   d'exécution.

Cette règle suffit à traiter un écart sans instaurer de gouvernance
supplémentaire.

## 14. Contrôle de conformité du référentiel

| Critère | Résultat |
|---|---|
| Gouvernance unique fondée sur `WAVE` | `PASS` |
| Cycle de vie WAVE et transitions définis | `PASS` |
| Cycle de vie mission et transitions définis | `PASS` |
| Conditions d'entrée et de sortie définies | `PASS` |
| Interruptions, reprise et rollback documentaire définis | `PASS` |
| Compilation, tests, preuves et minimum de non-régression définis | `PASS` |
| Décisions du Program Director réservées | `PASS` |
| Point de reprise obligatoire après chaque mission | `PASS` |
| WAVE PLAN, dépendances, lots, Gates, backlog et chemin critique modifiés | `NONE` |
| Architecture V2, gel V2 ou briques modifiés | `NONE` |
| Nouvelle brique, nouveau lot, nouvelle WAVE ou nouvelle Gate | `NONE` |
| Code, SQL ou migration | `NONE` |

```text
PROGRAM OFFER EXECUTION RULES = READY_FOR_REVIEW
```
