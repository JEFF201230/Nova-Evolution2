# CEREBRAU Runtime — Codex Diagnostic Capture Fix

## Identification

- Mission : `CEREBRAU-RUNTIME-CODEX-DIAGNOSTIC-CAPTURE-FIX-001`
- Programme : `CEREBRAU RUNTIME`
- Objet de gouvernance officiel : `WAVE`
- Date de vérification : `2026-07-25`
- Décision : **PASS**

## 1. Cause racine

`Invoke-CerebrauCodexProcess` lisait les lignes de stdout et stderr pour les afficher avec `Out-Host`, mais ne les conservait dans aucun buffer ni fichier. Le transcript officiel était ensuite construit uniquement depuis le fichier temporaire fourni à Codex par `--output-last-message`.

Quand Codex retournait un code non nul avant d’écrire ce dernier message, le diagnostic présent sur stdout ou stderr était perdu et `codex-transcript.txt` pouvait rester vide.

## 2. Comportement avant

- le prompt était transmis par STDIN ;
- stdout et stderr étaient visibles pendant l’exécution via `Out-Host` ;
- stdout et stderr n’étaient pas persistés ;
- seul `output-last-message` alimentait le transcript ;
- un échec précoce pouvait produire un transcript vide ;
- le rapport officiel ne fournissait pas les chemins des flux complets.

## 3. Comportement après

- le transport du prompt par STDIN est inchangé ;
- chaque ligne stdout reste affichée par `Out-Host` et est ajoutée à un `StringBuilder` stdout ;
- chaque ligne stderr reste affichée par `Out-Host` et est ajoutée à un `StringBuilder` stderr ;
- `Invoke-CerebrauCodexProcess` retourne un objet structuré avec `ExitCode`, `Stdout`, `Stderr`, `TerminalEventDetected`, `TerminalSucceeded` et `TerminationForced` ;
- `codex-stdout.log`, `codex-stderr.log` et `codex-transcript.txt` sont créés dans chaque dossier d’exécution et écrits en UTF-8 sans BOM ;
- le transcript applique la priorité stricte suivante :
  1. `output-last-message` non vide ;
  2. stderr complet ;
  3. stdout complet ;
  4. diagnostic structuré mentionnant l’ExitCode et l’absence des trois sources ;
- un ExitCode non nul génère une entrée de journal factuelle avec l’ExitCode, les deux chemins de flux et l’état vide/non vide de `output-last-message` ;
- le rapport officiel contient les chemins des diagnostics, leur source, leurs tailles et un résumé plafonné à 512 caractères ;
- stdout et stderr restent explicitement des diagnostics d’exécution non autoritatifs et leur contenu complet n’est pas copié dans `official-report.json`.

La logique existante de terminaison contrôlée est conservée : détection de `turn.completed`, `turn.failed` et `turn.cancelled`, délai de grâce, arrêt forcé éventuel, et succès forcé uniquement pour un terminal réussi accompagné d’un dernier message non vide.

## 4. Fichiers modifiés

- `tools/cerebrau/Invoke-CerebrauMission.ps1`
- `tools/cerebrau/Test-CerebrauRuntimeE2E.ps1`
- `Docs/PROGRAM/CEREBRAU_RUNTIME_CODEX_DIAGNOSTIC_CAPTURE_FIX_REPORT.md`

Aucun fichier OFFER, VEEDDA métier ou migration SQL n’a été modifié par cette correction. Aucun commit ni push n’a été effectué.

## 5. Tests ajoutés ou adaptés

La suite E2E comprend désormais 28 scénarios, dont :

- succès avec dernier message et persistance des deux flux ;
- échec avec stderr uniquement ;
- échec avec stdout uniquement ;
- échec totalement silencieux et transcript structuré non vide ;
- création vérifiée des fichiers stdout et stderr vides lors d’un échec totalement silencieux ;
- journal factuel pour ExitCode non nul ;
- présence de `CodexStdoutPath`, `CodexStderrPath` et `TranscriptPath` dans la section Codex et le diagnostic officiel ;
- chemins de diagnostics contenant des espaces ;
- UTF-8 sans BOM pour stdout, stderr et chacun des quatre types de transcript ;
- résumé officiel limité sans copie du flux complet ;
- `turn.completed` ;
- `turn.failed` ;
- `turn.cancelled` ;
- arrêt forcé après le délai de grâce.

Le contrôle existant d’identité SHA-256 du prompt transmis par STDIN est conservé.

## 6. Résultats exacts

| Vérification | Résultat |
|---|---:|
| `Test-CerebrauRuntimeE2E.ps1` | SUCCESS — 28/28 |
| Identité SHA-256 prompt/STDIN | PASS — `D87B78E7D8DC10390CBA7A5AE3270E781F3706BA27F4E75A28BD1DDD1D4EE0A7` |
| `Test-CerebrauGovernance.ps1` | SUCCESS — 27/27 |
| `Test-CerebrauReporting.ps1` | SUCCESS — 15/15 |
| `Test-CerebrauExceptionCapture.ps1` | SUCCESS — 13/13 |
| `Test-CerebrauSyntax.ps1` | SUCCESS — ExitCode 0 |
| Analyse syntaxique ciblée des deux scripts modifiés | PASS |
| `Test-CerebrauMission.ps1` | VALID — ExitCode 0 |
| `Test-CerebrauContextAssembly.ps1` | SUCCESS — 23/23 |
| `Test-CerebrauContextRuntime.ps1` | SUCCESS — 14/14 |
| `Test-CerebrauCampaignManifest.ps1` | SUCCESS — 13/13 |
| `Test-CerebrauCampaign.ps1` | SUCCESS — 9/9 suites |
| `Test-CerebrauCampaignE2E.ps1` | SUCCESS — 4/4 suites |
| `Test-CerebrauNSB.ps1` | SUCCESS — 12/12 |
| `Test-OwnerRoleSourceOfTruth.ps1` | PASS — ExitCode 0 |
| `git diff --check` global | PASS — ExitCode 0 (avertissements CRLF non bloquants uniquement) |
| `git diff --check` sur les fichiers de correction | PASS — ExitCode 0 |

Le scénario SHA-256 prouve que les octets de `prompt.md` reçus par STDIN sont inchangés.

## 7. Risques résiduels

- La capture est fondée sur `ReadLineAsync` : elle conserve toutes les lignes mais normalise leurs séparateurs avec le séparateur de ligne de la plateforme.
- En cas d’arrêt forcé, seuls les octets effectivement vidés par le processus avant sa terminaison peuvent être conservés.
- Les fichiers complets peuvent contenir des diagnostics sensibles ; leur protection dépend des contrôles d’accès et de la politique de rétention du dossier de rapports.
- Le résumé du rapport est volontairement tronqué ; l’analyse exhaustive doit utiliser les chemins persistés.

## 8. Décision

**PASS**

Les preuves exécutées établissent la persistance de stdout et stderr, le fonctionnement des quatre niveaux de transcript, l’absence de transcript silencieusement vide sur ExitCode non nul, la conservation exacte du transport STDIN, la compatibilité des chemins avec espaces, l’encodage UTF-8 sans BOM et l’absence de régression dans les suites runtime et gouvernance exécutées.
