# Cerebrau Mission Context Assembly — rapport d'implémentation

## 1. Verdict d'implémentation

La brique additive `Cerebrau Mission Context Assembly` est implémentée sous `tools/cerebrau/`. Elle est désactivée par défaut et ne s'exécute que lorsque `-ContextAssemblyEnabled` est fourni au Campaign Runner ou directement au runtime Mission.

Le résultat d'ensemble est `PARTIAL` au sens du contrat de la Mission : l'implémentation, la compatibilité et les tests sont validés, mais les nombres de tokens ne sont pas exposés de manière autoritative par l'invocation `codex exec` historique et sont donc publiés comme `UNAVAILABLE`.

## 2. Architecture avant

```text
Campaign Manifest
  -> Campaign Runner
  -> Invoke-CerebrauMission.ps1 -MissionFile
  -> Certified Facts Bootstrap + prompt source
  -> codex exec
  -> snapshots Git + validations + Official Report
```

Le Runner validait déjà le Manifest, l'autorité, les dépendances, les scopes et `sharedEvidence`, puis produisait l'evidence index. Le runtime validait déjà la Mission, résolvait `profiles.json`, capturait Git et injectait `certified-facts.json`. Ces informations n'étaient pas assemblées en une projection Mission transmise à Codex.

## 3. Architecture après

```text
Chemin par défaut, inchangé
Campaign Runner
  -> Mission Order
  -> runtime Mission historique
  -> Certified Facts + prompt source
  -> Codex

Chemin optionnel
Campaign Runner -ContextAssemblyEnabled
  -> Mission Order + Campaign Manifest + evidence index
  -> Cerebrau.ContextAssembly.psm1
  -> projection minimale hashée
  -> runtime Mission compatible
  -> contexte fonctionnel + Certified Facts + prompt source
  -> Codex
```

Le module ne décide ni de l'éligibilité ni du statut de la Mission. Il ne modifie aucun Gate, ordre, fait certifié, prompt, profil, hash déclaré, preuve ou décision.

Les faits certifiés fournis sont conservés : `WAVE` reste l'objet officiel de gouvernance, aucun Work Package n'est promu en objet officiel, et les contrats Foundation/MM existants ne sont ni réécrits ni recertifiés par la brique.

## 4. Composants existants réutilisés

| Composant | Réutilisation |
|---|---|
| Campaign Manifest | Source de `campaignId`, autorité, prérequis, preuves, dépendances et scopes Campaign |
| Campaign Runner | Point d'activation unique et transmission automatique du Manifest et de l'evidence index |
| Mission Orders | Contrat de Mission, baselines, lectures, limites d'écriture et livrables |
| Mission prompts | Hashés et transmis inchangés par le canal historique |
| `profiles.json` / resolver | Profil résolu une seule fois par le runtime, puis projeté par référence |
| Certified Facts Bootstrap | Conservé sans modification fonctionnelle ; le fichier reste injecté par le runtime historique |
| Campaign `sharedEvidence` / evidence index | Sélection par `consumers[]`, vérification du hash courant et du statut `VALID` de l'index |
| `baselineEvidence` | Ordre et hashes déclarés conservés ; comparaison sans mise à jour du contrat |
| Scopes et livrables | Projetés depuis les contrats existants, sans nouveau registre |
| Git workspace snapshot | Le snapshot `workspace-before` existant fournit branche, HEAD et état dirty |
| Official Reports | En mode activé seulement, référence l'artefact et les métriques finales |
| Context Engine / COS-200 et Providers | Aucun moteur concurrent n'est créé. Le moteur complet n'est pas invoqué sans nécessité explicite ; une sortie Provider déjà déclarée comme preuve/baseline/read-only reste sélectionnable par les règles ordinaires |
| Knowledge Index | Même règle : sélection uniquement lorsqu'un contrat Mission ou Campaign le référence explicitement |
| Hashes et fingerprints | Les hashes contractuels sont vérifiés, jamais remplacés ; les nouveaux hashes ne scellent que la projection temporaire et les sources non scellées |

## 5. Fichiers

### 5.1 Nouveaux fichiers

- `tools/cerebrau/Cerebrau.ContextAssembly.psm1` : assemblage et métriques ;
- `tools/cerebrau/Test-CerebrauContextAssembly.ps1` : sélection, sécurité et déterminisme ;
- `tools/cerebrau/Test-CerebrauContextRuntime.ps1` : non-régression runtime et intégration Campaign ;
- `Docs/PROGRAM/CONTEXT_ASSEMBLY_BRICK_IMPLEMENTATION_REPORT.md` ;
- `Docs/PROGRAM/CONTEXT_ASSEMBLY_PAIRED_BENCHMARK_PROTOCOL.md`.

### 5.2 Composants existants modifiés au strict raccordement

| Fichier | Modification | Justification |
|---|---|---|
| `tools/cerebrau/Invoke-CerebrauMission.ps1` | Switch public désactivé par défaut, appel conditionnel du module, canal `<CEREBRAU_MISSION_CONTEXT>`, métriques conditionnelles | Point unique entre Mission et Codex ; aucun appel du module lorsque le switch est absent |
| `tools/cerebrau/Cerebrau.Campaign.psm1` | Propagation conditionnelle du switch, du Manifest, de l'evidence index et du contexte de reprise | Réutiliser le Runner et éviter toute étape opérateur supplémentaire |
| `tools/cerebrau/Invoke-CerebrauCampaign.ps1` | Ajout de `-ContextAssemblyEnabled` et propagation à `Start`/`Resume` | Activation binaire au point d'entrée existant |

Les modifications déjà présentes avant cette implémentation dans `Cerebrau.Reporting.psm1`, `Resolve-CerebrauProfile.ps1`, `mission.json`, `prompt.md`, `certified-facts.json` et les fichiers métier du dépôt ont été préservées et ne sont pas attribuables à cette brique. En particulier, le bootstrap Certified Facts existait déjà dans le diff initial du runtime.

## 6. Contrat d'entrée

Entrées obligatoires du module :

- chemin de la Mission Order ;
- profil déjà résolu ;
- snapshot Git `workspace-before` existant ;
- répertoire temporaire du run.

Entrées optionnelles, fournies automatiquement par le Runner :

- Campaign Manifest ;
- Campaign evidence index ;
- indicateur interne de reprise gouvernée ;
- rapport antérieur de la même Mission lorsqu'il existe dans cette reprise.

Une Mission directe sans Campaign est valide. Elle reçoit `campaignId = null` et le diagnostic `CAMPAIGN_MANIFEST_NOT_PROVIDED`.

## 7. Contrat de sortie

`mission-context-assembly.json` est écrit dans le répertoire technique du run. Il contient :

- `schemaVersion`, `generatedAt`, `programId`, `campaignId`, `missionId` ;
- `branch`, `head`, `dirtyState` ;
- `authority`, `applicableEvidence`, `dependencies` ;
- `baselineEvidence`, `readOnlySources`, les scopes et livrables ;
- `certifiedFactsReference`, `sourceHashes`, `selectionDiagnostics` ;
- `functionalPayloadSha256` et `metrics`.

Le contenu métier n'est pas copié. Chaque source est décrite par chemin normalisé, SHA-256, rôle, priorité, taille et raison. La projection fonctionnelle transmise à Codex exclut `generatedAt` et les durées. À entrées identiques, son JSON compact et `functionalPayloadSha256` sont identiques.

Après Codex, `context-assembly-metrics.json` complète les métriques avec verdict, livrables, diagnostics, delta Git et régressions. L'Official Report ne reçoit une propriété `ContextAssembly` que lorsque le switch est actif.

## 8. Sélection et ordre

L'ordre implémenté est : Manifest ; autorité ; certification ; prérequis applicables ; `sharedEvidence` dont `consumers[]` contient la Mission ; Mission Order ; registre/profil résolu ; prompt inchangé ; Certified Facts inchangés ; baselines ; lectures déclarées ; déclarations de scopes et livrables ; rapports de prédécesseurs explicitement requis ; rapport de reprise gouvernée ; identité Git.

Les patterns et répertoires read-only sont conservés comme déclarations et ne provoquent pas l'expansion d'un arbre. Les autres preuves Campaign sont explicitement rejetées avec diagnostic. Aucun dépôt complet, Digital Twin complet, ensemble global d'Official Reports, archive, Knowledge Index ou décision n'est ajouté.

## 9. Déduplication et sécurité

La clé de déduplication est exactement `chemin normalisé + SHA-256`, insensible à la casse du chemin sous Windows. La première occurrence conserve sa priorité ; chaque occurrence suivante est annotée `deduplicated` et incrémente `ContextDuplicateCount`.

Les erreurs bloquantes sont : source absente, sortie du repository, hash déclaré divergent, Mission absente de la Campaign, repository/programme/branche Campaign divergents, Mission Order différente de celle référencée par la Campaign et evidence index incohérent. Une preuve non applicable est exclue et comptée, pas chargée. Un rapport de reprise non gouverné est rejeté. Un worktree dirty est enregistré sans être présenté comme clean et sans décision de statut.

## 10. Métriques

Sont produits :

- `ContextAssemblyEnabled` ;
- `ContextAssemblyDurationMs` — sélection, vérification et sérialisation fonctionnelle, hors persistance finale de l'artefact ;
- `ContextSourceCount`, `ContextSourceBytes`, `ContextPayloadBytes` ;
- `ContextSourcePaths`, `ContextSourceHashes` ;
- `ContextDuplicateCount`, `ContextRejectedSourceCount`, `ContextSelectionDiagnostics` ;
- `CodexDurationMs` (appel du processus Codex isolé), `TotalDurationMs` ;
- `Verdict`, `Deliverables`, `Diagnostics`, `GitDelta`, `RegressionsDetected` ;
- `TokensInput`, `TokensOutput`, `TokensTotal = UNAVAILABLE`.

Aucune estimation de tokens n'est inventée.

## 11. Tests et résultats

### 11.1 Nouvelles suites

| Commande | Résultat |
|---|---:|
| `powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauContextAssembly.ps1` | `23/23 SUCCESS` |
| `powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Test-CerebrauContextRuntime.ps1` | `14/14 SUCCESS` |

Couverture : ordre canonique exact, applicabilité des preuves et du Manifest, déduplication, hashes, fichier absent, hors-scope, absence d'expansion des répertoires read-only, index incohérent, Campaign absente, dirty state, reprise gouvernée et non gouvernée, déterminisme fonctionnel, prompt historique exact, absence d'artefact par défaut, profil historique, durée Codex isolée, échec d'assemblage rapporté sans erreur secondaire, équivalence fonctionnelle A/B synthétique et propagation du switch Campaign.

### 11.2 Suites existantes concernées

| Suite | Résultat |
|---|---:|
| `Test-CerebrauSyntax.ps1` | `SUCCESS` |
| `Test-CerebrauMission.ps1` | `VALID` |
| `Test-CerebrauReporting.ps1` | `15/15 SUCCESS` |
| `Test-CerebrauExceptionCapture.ps1` | `13/13 SUCCESS` |
| `Test-CerebrauRuntimeE2E.ps1` | `15/15 SUCCESS` |
| `Test-CerebrauCampaign.ps1` | `9/9 suites`, `49/49 assertions SUCCESS` |
| Campaign cible, action `Validate` | `VALID`, fingerprint `4B9BE442CA2B48EFD1F83DEA49D6D575580EC1EB814152A11A0CB57963AF4E3A` |
| Assemblage read-only réel `MM-L01-03` | `SUCCESS`, 11 sources, 8 doublons supprimés, 0 rejet, worktree `DIRTY` déclaré |

Aucun test n'a été supprimé, neutralisé ou assoupli.

## 12. Compatibilité ascendante et absence de régression

La preuve automatisée vérifie qu'en l'absence du switch :

- le prompt final est exactement `<CERTIFIED_FACTS>…</CERTIFIED_FACTS>` suivi du prompt source ;
- le modèle et le sandbox résolus sont identiques ;
- aucune propriété `ContextAssembly` n'apparaît dans l'Official Report ;
- aucun artefact de contexte n'est créé ;
- le statut fonctionnel et l'ExitCode restent identiques au run activé synthétique ;
- toutes les suites runtime et Campaign existantes passent.

Le chemin désactivé conserve également l'appel interne historique exact `Invoke-CerebrauMission.ps1 -MissionFile ...`.

## 13. Risques et limites

- Le benchmark réel n'a pas été lancé. Son exécution doit repartir du même snapshot restaurable avant chaque run Campaign.
- Le runtime historique ne persiste pas de télémétrie tokens autoritative ; les champs restent `UNAVAILABLE`.
- Les chemins sont normalisés selon les règles Windows du runtime actuel.
- Le payload référence les contenus au lieu de les dupliquer. Codex conserve donc la responsabilité de lire uniquement les chemins applicables lorsque le prompt l'exige.
- Le worktree de développement était déjà dirty et contenait des modifications métier hors périmètre ; elles ont été conservées. Les assertions de non-régression portent sur les suites et sur le delta de cette implémentation, pas sur la propreté globale antérieure.

## 14. Réversibilité

La désactivation est immédiate : omettre `-ContextAssemblyEnabled`. La suppression complète consiste à retirer le module et les deux tests, puis les seuls blocs conditionnels des trois points de raccordement. Aucun Manifest, Mission Order, prompt, profil, fait certifié, registre, preuve, décision, cache ou base ne doit être migré ou restauré.

## 15. Commande exacte du benchmark

Après validation des préconditions et restauration de l'instantané `S0` avant chaque run :

```powershell
# A
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauCampaign.ps1 -CampaignFile tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json -Action Start

# B — seule variable expérimentale
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/cerebrau/Invoke-CerebrauCampaign.ps1 -CampaignFile tools/cerebrau/campaigns/VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json -Action Start -ContextAssemblyEnabled
```

L'ordre complet et les contrôles d'arrêt sont définis dans `CONTEXT_ASSEMBLY_PAIRED_BENCHMARK_PROTOCOL.md`.

## 16. Verdict obligatoire

CONTEXT ASSEMBLY BRICK IMPLEMENTED = YES

EXISTING COMPONENTS REUSED = YES

ADDITIVE ARCHITECTURE = YES

DEFAULT BEHAVIOR PRESERVED = YES

PROCEDURAL COMPLEXITY ADDED = NO

EXISTING TESTS PASS = YES

NEW TESTS PASS = YES

NO REGRESSION = YES

BENCHMARK SWITCH AVAILABLE = YES

PAIRED BENCHMARK READY = YES

COMMIT = NO

PUSH = NO
