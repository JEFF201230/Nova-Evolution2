# Squad Opening Order — SQUAD-L01-GOVERNANCE

> Squad ID : `SQUAD-L01-GOVERNANCE`
> Squad Name : `L01 Governance`
> Program ID : `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001`
> Wave ID : `VEEDDA-URBANIZATION-WAVE-001`
> Autorité : `Program Director`
> Opening Decision : `APPROVED`
> Squad Status : `READY`
> Horodatage : `2026-07-21T22:53:56+02:00`

## Scope

Préparer l'exécution gouvernée de `MM-L01-03` afin de produire la première ligne du registre de Gate conforme à la Master Gates Matrix pour `L01-G06`.

## Responsibilities

- respecter l'ownership et les Resource Locks définis par la Wave ;
- exécuter uniquement la Mission Order `MM-L01-03` après ordre explicite ;
- maintenir la séparation entre statut opérationnel, décision de Gate et certification ;
- produire et tracer uniquement les livrables déclarés dans le contrat de mission.

## Authorized Files

- `Docs/PROGRAM/PROGRAM_MASTER_GATES_REGISTER.md` ;
- `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/EVIDENCE/MM-L01-03/**`.

## Forbidden Files

- `.git/**` ;
- `client/**` ;
- `frontend/**` ;
- `server/**` ;
- `supabase/**` ;
- toute preuve, tout rapport ou toute décision existante hors livrable `MM-L01-03` ;
- toute Gate autre que la cible déclarée par `MM-L01-03`.

## Resource Locks

Les deux zones autorisées sont définies comme locks exclusifs de la Squad pendant une future exécution. Elles restent `NOT_ACQUIRED` à l'ouverture.

## Dependencies

| Dépendance | État |
|---|---|
| `MM-L01-01` | `SATISFIED` |
| `L01-G04 REGISTERED` | `YES` |
| Campaign associée | `NOT_STARTED` |

## Entry Gate

`PASS` pour le statut `READY`. Ce Squad Opening Order n'autorise pas à lui seul le passage à `RUNNING`.

## Program Director Approval

La Squad est officiellement ouverte en statut `READY`. Aucun travail opérationnel, aucun lock et aucune Mission Order ne sont lancés par cet acte.
