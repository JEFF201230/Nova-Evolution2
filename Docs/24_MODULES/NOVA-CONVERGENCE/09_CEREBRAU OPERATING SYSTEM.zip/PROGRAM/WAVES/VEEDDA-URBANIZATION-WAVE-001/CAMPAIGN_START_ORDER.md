# VEEDDA Urbanization — Campaign 001 Start Order

> Order ID : `PDS-CAMPAIGN-START-ORDER-001`
> Program ID : `PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001`
> Wave ID : `VEEDDA-URBANIZATION-WAVE-001`
> Campaign ID : `VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001`
> Autorité : `Program Director`
> Date : `2026-07-21`
> Horodatage : `2026-07-21T23:09:26+02:00`
> Statut de l'acte : `EFFECTIVE`

## 1. Objet

Le Program Director émet le présent Campaign Start Order et autorise le démarrage de la Campaign `VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001`.

À compter de la publication de cet ordre, la Campaign passe de `NOT_STARTED` à `STARTED` et devient l'autorité opérationnelle exclusive de déclenchement des Mission Orders déclarés dans son Campaign Manifest.

## 2. Fondement et préconditions

| Contrôle | Résultat |
|---|---|
| Initial Wave créée | `YES` |
| Statut opérationnel du PROGRAM | `OPEN` |
| Campaign Manifest | `VALID` |
| Campaign avant le présent ordre | `NOT_STARTED` |
| Contrat `MM-L01-03` | `VALID` |
| Statut initial de `MM-L01-03` | `PLANNED` |
| Blocage final | `NO` |
| Campaign fingerprint | `4B9BE442CA2B48EFD1F83DEA49D6D575580EC1EB814152A11A0CB57963AF4E3A` |

Toutes les préconditions d'ouverture sont satisfaites.

## 3. Décision exécutoire

Le Program Director ordonne :

1. le passage de la Campaign à l'état de gouvernance `STARTED` ;
2. l'activation du moteur d'orchestration de la Campaign ;
3. la prise de contrôle de l'orchestration par le Campaign Manifest ;
4. l'émission automatique de l'ordre d'exécution de `MM-L01-03`, unique Mission Order déclaré dans le Manifest ;
5. l'exécution des Mission Orders exclusivement dans leur ordre contractuel et sous leurs préconditions, scopes, locks et exigences de revue.

Le présent acte n'est pas un lancement manuel de `MM-L01-03`. Le déclenchement de la mission est produit exclusivement par le moteur de Campaign à partir du Manifest.

## 4. Séquence autorisée

La séquence autorisée est strictement la suivante :

`Campaign Start Order` → `Campaign STARTED` → `Campaign Engine activated` → `Campaign Manifest evaluated` → `MM-L01-03 execution order issued automatically` → `MM-L01-03 started if contractually ready`.

Aucune Mission absente du Manifest ne peut être exécutée. Le Manifest ne déclare que `MM-L01-03` et fixe `maxConcurrency` à `1`.

## 5. Limites de l'autorisation

Cet ordre n'autorise aucune modification de Gate hors périmètre, décision existante, preuve existante, runtime ou code. Il n'autorise la création d'aucune Wave, Campaign ou Mission supplémentaire.

La décision de certification du PROGRAM demeure `NO_GO` et n'est ni remplacée ni modifiée par le statut opérationnel `STARTED` de la Campaign.

## 6. Contrôles de l'acte et de son activation

| Contrôle obligatoire | Résultat |
|---|---|
| `CAMPAIGN START ORDER CREATED` | `YES` |
| `CAMPAIGN STATUS` | `STARTED` |
| `CAMPAIGN ENGINE ACTIVATED` | `YES` — événement `CAMPAIGN_STARTED`, séquence `5` |
| `MM-L01-03 EXECUTION ORDER ISSUED` | `YES` — ready set du Manifest, séquence `7` |
| `MM-L01-03 STARTED` | `YES` — événement `MISSION_STARTED`, séquence `8` |
| `EXECUTION TRIGGER` | `CAMPAIGN MANIFEST` |
| `NO REGRESSION` | `YES` — empreintes contractuelles et décisions existantes conservées |

## 7. Trace d'exécution

Le moteur a enregistré le run `RUN-451F65E20A4F4A269D948F668743595D` et l'attempt `ATT-31726B01C4B74D4785D43B04CB9B9E69`.

`MM-L01-03` s'est arrêtée avant toute écriture métier, car ses sources exclusives antérieures ne lui permettent pas de vérifier le présent ordre distinct. Son rapport technique est `PARTIAL` et le livrable de Gate n'a pas été créé. Ce résultat ne remet pas en cause le démarrage de la Campaign ni la preuve de déclenchement automatique ; aucune reprise manuelle de la Mission n'est autorisée par le présent acte.

Le moteur CEREBRAU conserve son état et son journal d'exécution dans les répertoires déclarés par le Campaign Manifest. Ces projections d'orchestration ne créent ni ne modifient une décision de Gate, de LOT ou de PROGRAM.
