# PROGRAM MASTER GATES REGISTER

## LOT-001

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L01-G01` | `LOT-001` | Certifier la baseline de gouvernance gelée du PROGRAM. | Baseline PROGRAM | `EV-P001 — PROGRAM_GOVERNANCE_APPENDIX.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L01-G02` | `LOT-001` | Certifier l'attribution des responsabilités de gouvernance. | RACI des Gates et référentiels | `EV-P001 — PROGRAM_GOVERNANCE_APPENDIX.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L01-G03` | `LOT-001` | Certifier les objectifs et critères MVP. | Plan maître MVP | `EV-P010 — PROGRAM_MASTER_PLAN.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L01-G04` | `LOT-001` | Établir un statut courant unique du PROGRAM. | Décision de statut unique | `EV-P001`<br>`EV-P003`<br>`EV-P004`<br>`EV-P012`<br>`EV-P013`<br>`EV-P017`<br>`EV-R002`<br>`EV-T005`<br>`MM_L01_01_PROGRAM_STATUS_DECISION.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `GO` |
| `L01-G05` | `LOT-001` | Certifier le fonctionnement du profil, du manifeste et du reporting CEREBRAU. | Preflight CEREBRAU PASS | `EV-P005`<br>`EV-P006`<br>`EV-P009`<br>`EV-P011`<br>`MM_L01_02_CEREBRAU_PREFLIGHT_EVIDENCE.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L01-G06` | `LOT-001` | Certifier que chaque Gate active possède owner, décision, preuves et horodatage. | Première décision formelle de Gate | `EV-P001`<br>`EV-P003`<br>`EV-P012`<br>`EV-P014` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |

## LOT-002

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L02-G01` | `LOT-002` | Certifier l'égalité entre le snapshot physique et son inventaire. | Inventaire physique du snapshot | `EV-P015`<br>`EV-R001`<br>`EV-R003` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L02-G02` | `LOT-002` | Certifier le périmètre des fichiers sémantiques, dépendances et builds. | Classification du périmètre sémantique | `EV-P015`<br>`EV-R001`<br>`EV-R003` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L02-G03` | `LOT-002` | Fermer les objets critiques sans owner, justification ou Gate. | Registre des UNKNOWN critiques qualifiés | `EV-P016`<br>`EV-R002`<br>`EV-R004`<br>`EV-R008`<br>`MM_L02_01_CRITICAL_UNKNOWN_REGISTER.csv`<br>`MM_L02_01_OWNERROLE_RESOLUTION_REGISTER.csv` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L02-G04` | `LOT-002` | Certifier la résolution ou l'exclusion testée des imports internes. | Registre de résolution des imports | `EV-R005`<br>`MM_L02_02_INTERNAL_IMPORT_REGISTER.csv`<br>`MM_L02_02_IMPORT_RESOLUTION_REPORT.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L02-G05` | `LOT-002` | Rattacher les producteurs et consommateurs de chaque objet critique. | Registre producteurs-consommateurs critique | `EV-R007`<br>`EV-R002` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L02-G06` | `LOT-002` | Porter une certification repository fondée sur les Gates précédentes. | Décision de certification repository | `EV-R002`<br>`EV-R009`<br>`PROGRAM_DIRECTOR_STATUS_REPORT.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |

## LOT-003

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L03-G01` | `LOT-003` | Certifier l'observation en lecture seule du runtime Supabase. | Rapport d'observation runtime | `EV-T001 — DPDS_000A_RUNTIME_OBSERVATION_REPORT.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L03-G02` | `LOT-003` | Publier le dénominateur des objets du schéma public. | Inventaire runtime public | `EV-T001 — DPDS_000A_RUNTIME_OBSERVATION_REPORT.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L03-G03` | `LOT-003` | Certifier le diff bidirectionnel Repository et Runtime. | Diff Repository-Runtime | `EV-T002 — DPDS_000A_RUNTIME_REPOSITORY_DIFF.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L03-G04` | `LOT-003` | Statuer sur la provenance des migrations et des objets runtime. | Réconciliation migrations-ledger<br>Décision de gouvernance ledger | `EV-T002`<br>`EV-T005`<br>`EV-Z004`<br>`MM_L03_01_MIGRATION_RECONCILIATION_REPORT.md`<br>`SUPABASE_FORENSIC_AUDIT_REPORT.md`<br>`LOT-003_LEDGER_GOVERNANCE_DECISION.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §8` | `GO_WITH_DEROGATION` |
| `L03-G05` | `LOT-003` | Observer les versions, commits, dates et états frontend et backend. | Preuve de déploiement frontend-backend | `EV-T004`<br>`EV-T005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L03-G06` | `LOT-003` | Comparer les hashes déployés et repository des Edge Functions. | Archives et hashes des Edge Functions | `EV-T004`<br>`EV-T005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L03-G07` | `LOT-003` | Certifier l'existence nominale des variables requises dans chaque runtime. | Matrice des variables par runtime | `EV-T004 — DPDS_000A_RUNTIME_DEPLOYMENT_REPORT.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |

## LOT-004

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L04-G01` | `LOT-004` | Certifier les huit Sources of Truth locales. | Registre SOT repository | `EV-R007 — DPDS_000_SOURCE_OF_TRUTH_REGISTER.csv` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L04-G02` | `LOT-004` | Localiser les huit Sources of Truth entre Repository et Runtime. | Rapport de localisation runtime SOT | `EV-T003 — DPDS_000A_RUNTIME_SOURCE_OF_TRUTH_REPORT.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L04-G03` | `LOT-004` | Attribuer une autorité approuvée à chaque concept critique. | Décisions d'autorité des concepts | `EV-P007`<br>`EV-P018`<br>`EV-T003` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L04-G04` | `LOT-004` | Certifier un producteur autorisé unique pour chaque SOT critique. | Registre des writers autorisés | `EV-P008`<br>`EV-R007`<br>`EV-Z002` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L04-G05` | `LOT-004` | Rattacher les consommateurs critiques à un contrat, une SOT et une fraîcheur. | Registre des contrats consommateurs | `EV-P008`<br>`EV-P018`<br>`EV-R007`<br>`EV-Z002` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L04-G06` | `LOT-004` | Écarter les projections et fixtures comme autorités primaires. | Preuve de non-autorité des projections | `EV-P007`<br>`EV-Z003`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |

## LOT-005

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L05-G01` | `LOT-005` | Certifier le registre des workflows observés. | Registre workflows | `EV-R006 — DPDS_000_WORKFLOW_REGISTER.csv` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L05-G02` | `LOT-005` | Localiser le noyau d'approbation et l'événement QF. | Définition et flux du noyau QF | `EV-Z001`<br>`EV-Z003`<br>`EV-Z004` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L05-G03` | `LOT-005` | Certifier la classification des objets de la frontière QF. | Registre des frontières QF | `EV-Z002 — DPDS_000R_DEPENDENCY_BOUNDARY_REGISTER.csv` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L05-G04` | `LOT-005` | Prouver le producteur reproductible des préconditions QF. | Preuve du producteur dossier-analyse | `EV-Z008 — DPDS_000R_EXECUTIVE_DECISION.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L05-G05` | `LOT-005` | Fermer toutes les frontières critiques non résolues. | Registre des frontières critiques fermé | `EV-Z002`<br>`EV-Z008` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L05-G06` | `LOT-005` | Faire passer les écritures QF centrales par une interface unique testée. | Preuve du writer unique QF | `EV-Z004`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L05-G07` | `LOT-005` | Porter la décision de fermeture de la zone QF. | Décision de zone fermée | `EV-Z008 — DPDS_000R_EXECUTIVE_DECISION.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |

## LOT-006

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L06-G01` | `LOT-006` | Certifier les réponses 401 et 403 de l'authentification QF. | Tests auth API QF | `EV-Z001`<br>`EV-Z008` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L06-G02` | `LOT-006` | Limiter l'approbation QF au rôle métier autorisé. | Validation du rôle approbateur<br>Tests de rôle | `EV-M001`<br>`EV-Z001`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L06-G03` | `LOT-006` | Certifier RLS, grants et policies des cinq tables QF. | Migration RLS-grants-policies<br>Tests SQL | `EV-Z004`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L06-G04` | `LOT-006` | Protéger la source `qf_history` et son writer autorisé. | Contrat de sécurité qf_history<br>Tests tenant | `EV-Z001`<br>`EV-Z004` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L06-G05` | `LOT-006` | Certifier le binding d'identité des Edge Functions QF. | Contrôle token-payload<br>Tests cross-user | `EV-Z001`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L06-G06` | `LOT-006` | Certifier la matrice rôle, tenant et objet de la zone. | Matrice sécurité PASS | `EV-P010`<br>`EV-Z007` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |

## LOT-007

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L07-G01` | `LOT-007` | Certifier la séquence transactionnelle atomique dans le code. | Preuve de séquence transactionnelle | `EV-Z001`<br>`EV-Z003` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L07-G02` | `LOT-007` | Certifier la structure des cinq tables QF. | Diff structurel QF | `EV-Z004 — DPDS_000R_REPOSITORY_RUNTIME_ZONE_DIFF.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L07-G03` | `LOT-007` | Certifier l'idempotence séquentielle et concurrente. | Tests d'idempotence PASS | `EV-Z005`<br>`EV-Z008` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L07-G04` | `LOT-007` | Certifier le rollback sans mutation partielle. | Tests de failpoints et rollback | `EV-Z007`<br>`EV-Z008` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L07-G05` | `LOT-007` | Certifier le résultat déterministe de deux approbations simultanées. | Test de concurrence | `EV-Z005 — DPDS_000R_ZONE_RISK_REGISTER.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L07-G06` | `LOT-007` | Rattacher la décision à une version documentaire et son checksum. | Contrat Document Core<br>Tests document-version | `EV-Z002`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L07-G07` | `LOT-007` | Certifier publisher, retry, ordre, replay et dead-letter de l'outbox. | Contrat outbox<br>Métriques de consommation | `EV-Z003`<br>`EV-Z004`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |

## LOT-008

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L08-G01` | `LOT-008` | Alimenter les cartes QF par un read model contractuel sans fixture productive. | Preuve du read model QF | `EV-Z001`<br>`EV-Z003`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L08-G02` | `LOT-008` | Afficher l'approbation uniquement après le succès HTTP de l'API. | Preuve UI-API<br>Test du faux commit | `EV-Z003`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L08-G03` | `LOT-008` | Certifier les états UI pour les erreurs contractuelles. | Tests UI 401-403-409-422-500 | `EV-Z007 — DPDS_000R_FIRST_CORRECTION_PLAN.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L08-G04` | `LOT-008` | Empêcher le calcul des droits avant une décision QF approuvée. | Contrat décision-droits | `EV-Z003`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L08-G05` | `LOT-008` | Certifier la projection versionnée et fraîche vers EBS et LifeHub. | Contrat de propagation<br>Tests de fraîcheur | `EV-P007`<br>`EV-P008`<br>`EV-A001`<br>`EV-A002`<br>`EV-A003`<br>`EV-A004`<br>`EV-Z003` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L08-G06` | `LOT-008` | Certifier le parcours vertical UI jusqu'à l'affichage avec rollback. | Test E2E vertical<br>Artefact de rollback | `EV-Z007`<br>`EV-Z008` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |

## LOT-009

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L09-G01` | `LOT-009` | Certifier l'inventaire du legacy et des candidats de code mort. | Registre legacy | `EV-P019`<br>`EV-R008` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L09-G02` | `LOT-009` | Qualifier chaque legacy atteignant un workflow MVP. | Qualification des legacy critiques | `EV-P009`<br>`EV-P019`<br>`EV-R008` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L09-G03` | `LOT-009` | Décider le maintien, la migration ou le retrait des objets runtime-only critiques. | Décisions sur le runtime-only | `EV-T002`<br>`EV-T003` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L09-G04` | `LOT-009` | Décider le déploiement ou l'abandon des objets repository-only critiques. | Décisions sur le repository-only | `EV-T002 — DPDS_000A_RUNTIME_REPOSITORY_DIFF.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L09-G05` | `LOT-009` | Certifier l'absence de suppression legacy non sécurisée. | Registres d'inventaire et d'exclusion | `EV-P009`<br>`EV-R001`<br>`EV-T005`<br>`EV-Z006` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L09-G06` | `LOT-009` | Certifier l'absence d'import des legacy QF V1 dans la zone atomique. | Registre d'exclusion QF | `EV-Z006 — DPDS_000R_EXCLUSION_REGISTER.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |

## LOT-010

| Gate | LOT | Objectif | Preuves requises | Preuves disponibles | Doctrine | Décision |
|---|---|---|---|---|---|---|
| `L10-G01` | `LOT-010` | Certifier la présence du référentiel de pilotage du PROGRAM. | Master Gates Matrix | `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §7` | `GO` |
| `L10-G02` | `LOT-010` | Certifier `GO` pour les LOTS 001 à 009. | Décisions LOT-001 à LOT-009 | `PROGRAM-VEEDDA-URBANIZATION_MASTER_GATES_MATRIX.md §§5–13`<br>`PROGRAM_DIRECTOR_STATUS_REPORT.md` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L10-G03` | `LOT-010` | Certifier la chaîne QF vers droits, EBS et affichages. | Preuve de chaîne MVP QF | `EV-Z003`<br>`EV-Z008` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L10-G04` | `LOT-010` | Certifier les tests positifs, négatifs, sécurité, concurrence et rollback des workflows MVP. | Matrice de tests MVP<br>Résultats PASS | `EV-P006`<br>`EV-P010`<br>`EV-R006` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L10-G05` | `LOT-010` | Fermer ou faire accepter les risques critiques. | Registre des risques<br>Acceptations Direction | `EV-P009`<br>`EV-Z005` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
| `L10-G06` | `LOT-010` | Porter la décision finale signée sur un dossier de preuves fraîches. | Dossier final de certification<br>Signatures requises | `EV-P002`<br>`EV-P003`<br>`EV-P004`<br>`EV-P013` | `PROGRAM_GOVERNANCE_CERTIFICATION_DOCTRINE.md §9` | `NO_GO` |
