# PROGRAM-CEREBRAU-CONTEXT-ACCELERATOR-ASSEMBLY-001

> Type : `PROGRAM / ARCHITECTURE / PERFORMANCE / READ_ONLY`
> Date d'audit : `2026-07-22`
> Périmètre d'écriture : ce rapport uniquement
> Objet : vérifier si les composants existants suffisent à fournir automatiquement à Codex un contexte minimal avant une Mission Order

## 1. Résultat exécutif

CEREBRAU possède déjà les informations nécessaires pour **déterminer** un contexte de mission borné : autorité, dépendances, preuves, hashes, prompt, profil, scopes, fichiers attendus, état Git, rapports et faits certifiés.

La chaîne active ne possède toutefois pas de raccordement existant permettant au Campaign Runner de **fournir automatiquement** cet assemblage à Codex :

- le Campaign Runner valide le Manifest, l'autorité, les dépendances et les preuves, puis appelle uniquement `Invoke-CerebrauMission.ps1 -MissionFile` ;
- le runtime Mission transmet à Codex le prompt de Mission préfixé par `tools/cerebrau/certified-facts.json` ;
- le Campaign Runner ne transmet ni son evidence index, ni les contenus de `sharedEvidence`, ni un `CerebrauProjectState` ;
- le Context Engine est exécutable et consommé par le Knowledge Center applicatif, mais il n'est appelé ni par le Campaign Runner ni par le runtime Mission ;
- le type `CONTEXT_SNAPSHOT` du Campaign Manifest est une catégorie de preuve hashée, pas un canal d'injection ;
- les métriques nécessaires au benchmark ne sont pas toutes instrumentées.

Conclusion : un **plan de lecture minimal** peut être dérivé avec les composants existants, mais l'assemblage automatique demandé n'est pas opérable sans modifier un composant existant. Une telle modification est interdite par la présente mission. Aucun nouveau logiciel, runtime ou mécanisme n'est proposé.

## 2. Méthode et limites

L'audit repose sur les fichiers présents dans le worktree et sur les rapports officiels existants. Aucun benchmark, Mission Order, Campaign, test avec mutation ou appel réseau n'a été exécuté.

Les mots « utilisé actuellement » désignent ci-dessous l'utilisation dans le chemin actif `Campaign Runner → Mission runtime → Codex`. Une utilisation uniquement applicative, documentaire, postérieure à Codex ou dans une suite de tests est signalée séparément.

## 3. Phase 1 — Inventaire

| Composant | Fichier principal | Rôle existant | État | Maturité | Utilisé actuellement | Réutilisable |
|---|---|---|---|---|---|---|
| Program | `Docs/PROGRAMS/PROGRAM-VEEDDA-URBANIZATION-ORCHESTRATION-001/**` | Porter plans, décisions, Gates, dépendances et sources de vérité du PROGRAM | Présent | Gouvernance active, qualité variable par document | `OUI`, seulement lorsque le Manifest ou la Mission le référence | `OUI` |
| Wave | `Docs/PROGRAM/WAVES/VEEDDA-URBANIZATION-WAVE-001/**` et Live Wave Register | Porter ouverture, Squad, locks et ordre Campaign | Présent | Gouvernance active | `NON` comme entrée automatique du runtime ; lecture seulement si le prompt la demande | `OUI` comme autorité explicitement référencée |
| Campaign Manifest | `tools/cerebrau/campaigns/*.json` | Déclarer autorité, politiques, preuves partagées, DAG, missions et scopes | Présent, schéma fermé | MVP opérationnel | `OUI` | `OUI` |
| Campaign Runner | `Invoke-CerebrauCampaign.ps1`, `Cerebrau.Campaign.psm1` | Valider, ordonnancer, vérifier les hashes, journaliser et appeler le runtime Mission | Présent | MVP opérationnel avec limites connues | `OUI` | `OUI` |
| Mission Orders | `tools/cerebrau/missions/veedda/*.json` | Déclarer profil, prompt, dépendances, scopes, baselines, validations et livrables | Présentes | Opérationnelles | `OUI` | `OUI` |
| Mission prompts | `tools/cerebrau/missions/veedda/*.prompt.md` | Donner à Codex l'autorité, le travail et les sources autorisées | Présents | Opérationnels | `OUI` | `OUI`, sans modification dans cette mission |
| Runtime Mission | `tools/cerebrau/Invoke-CerebrauMission.ps1` | Valider la Mission, résoudre le profil, capturer Git, lancer Codex et produire le rapport | Présent | Opérationnel | `OUI` | `OUI` |
| Profiles Registry | `tools/cerebrau/profiles.json`, `Resolve-CerebrauProfile.ps1` | Résoudre modèle, raisonnement, sandbox et approval policy | Présent | Opérationnel | `OUI` | `OUI` |
| Certified Facts Registry | `tools/cerebrau/certified-facts.json` | Porter cinq faits courts certifiés | Présent | MVP opérationnel ; gain de performance non démontré | `OUI` | `OUI` |
| Certified Facts Bootstrap | lignes 173–179 de `Invoke-CerebrauMission.ps1` | Préfixer automatiquement le prompt par `<CERTIFIED_FACTS>` | Présent | Opérationnel, tests antérieurs documentés | `OUI` | `OUI` |
| Context Engine / COS-200 | `server/cerebrau-context/**`, `COS-200.md` | Reconstruire un `CerebrauProjectState` en lecture seule | Implémentation présente ; COS-200 reste `DRAFT` | MVP exécutable et testé ; intégration Mission absente | `NON` ; utilisé par le Knowledge Center applicatif | `OUI` hors chaîne Mission actuelle |
| Context Providers | `server/cerebrau-context/providers/**` | Lire Project, Program, Epic, Lot, Knowledge, Architecture, Decision, Agent, Git et Component dans un ordre fixe | Dix Providers présents | Opérationnels au niveau MVP | `NON` dans une Mission | `OUI` |
| Knowledge Index | `06_REFERENCE/KNOWLEDGE_INDEX*.md` | Indexer documents, relations, alias, statuts, Programs, Epics, Lots et décisions | Famille d'index présente ; entrées principales `ACTIVE` | Référentiel actif | `NON` directement ; lu par les Providers | `OUI` |
| Official Reports | `tools/cerebrau/reports/**/official-report.{json,md}` | Porter statut, durée Codex, Git delta, validations et diagnostics | 61 paires JSON/Markdown présentes lors de l'audit | Opérationnels, autorité bornée à chaque run | `OUI` après Codex ; avant Codex seulement si explicitement référencés | `OUI` |
| Campaign evidence index | `tools/cerebrau/reports/campaigns/**/evidence-index.json` | Consolider provenance, consommateurs, hash et validité des preuves | Produit par le Runner | Opérationnel | `OUI` pour l'éligibilité ; `NON` comme contenu transmis à Codex | `OUI` |
| Hash Registry fonctionnel | Manifest authority/evidence hashes, `baselineEvidence`, fingerprints et rapports | Sceller les entrées et détecter la dérive | Distribué, aucun registre autonome unique constaté | Opérationnel pour les contrôles implémentés | `OUI` partiellement | `OUI`, sans créer de registre supplémentaire |
| Dependency Graph | `PROGRAM_DEPENDENCY_GRAPH.md` et `missions[].dependsOn` | Décrire les dépendances PROGRAM et ordonnancer le DAG Campaign | Présent | DAG Campaign opérationnel | `OUI` pour `dependsOn` ; graphe PROGRAM seulement s'il est référencé | `OUI` |
| Git snapshots | `workspace-before.json`, `workspace-after.json`, `mission-delta.json` | Figer branche, HEAD, worktree et mutations observées | Produits par le runtime | Opérationnels | `OUI`, mais principalement pour validation et rapport | `OUI` |
| Runtime Contract | `ORCHESTRATOR_RUNTIME_CONTRACT_V1.md` | Définir conceptuellement contexte, stores, locks et cycle Orchestrator | `DRAFT_VALIDABLE`, non implémentation | Conceptuel | `NON` | `OUI` comme contrainte documentaire seulement |
| Canonical Dictionary | `ORCHESTRATOR_CANONICAL_DICTIONARY_V1.md` | Fixer le vocabulaire Orchestrator | `DRAFT_VALIDABLE` | Terminologique | `NON` | `OUI` comme vocabulaire seulement |
| Digital Twin | `Docs/30_VEEDDA_DIGITAL_TWIN/VEEDDA_DIGITAL_TWIN_MASTER.md` | Décrire le système VEEDDA observé, workflows, données et gaps | Référentiel `CERTIFIED` pour la cartographie observée | Exploitable, produit non certifié fonctionnellement | `NON` dans les Campaign/Mission manifests inspectés | `OUI` seulement si explicitement requis |
| Knowledge Center API | `server/routes.ts` et `GdbcseKnowledgeCenter.tsx` | Exposer `reconstructContext()` à l'application | Route et consommateur UI présents | Connecté applicativement | `NON` dans la chaîne Mission | `NON` comme canal Mission actuel |

### 3.1 Contrôles factuels importants

- `contextProviders` contient exactement dix Providers dans l'ordre COS-200.
- `reconstructContext()` retourne `CerebrauProjectState`, `alerts`, `missingSources` et `generatedAt`.
- Le Context Engine n'a ni persistance, ni API dédiée propre, ni vectorisation, ni écriture documentaire.
- Le schéma Campaign accepte `CONTEXT_SNAPSHOT`, mais le Runner ne fait qu'en vérifier le chemin, le consommateur et le SHA-256.
- La Campaign LOT-002 utilise déjà deux preuves étiquetées `CONTEXT_SNAPSHOT`; ce sont des registres documentaires, pas des sorties `CerebrauProjectState` injectées à Codex.
- `baselineEvidence` est disponible dans les Mission Orders. Pour `MM-L01-03`, son recalcul est ordonné par le prompt ; le validateur unitaire inspecté ne fournit pas à lui seul une injection de ces contenus.

## 4. Phase 2 — Cartographie du flux actuel

```text
Program
  └─ documents, décisions, Gates, dependency graph
       ↓ références explicites
Wave
  └─ opening/start orders, Squad, scopes et locks documentaires
       ↓ Campaign Manifest associé
Campaign
  └─ authority + policies + sharedEvidence + missions[] + DAG
       ↓
Campaign Runner
  ├─ valide branche, autorité, hashes, preuves, dépendances et scopes
  ├─ calcule ready set, state, journal et evidence index
  └─ appelle Invoke-CerebrauMission.ps1 -MissionFile <fichier>
       ↓
Mission Order / runtime Mission
  ├─ résout profile + prompt
  ├─ préfixe certified-facts.json
  ├─ capture workspace-before
  └─ exécute codex exec ... -
       ↓
Codex
  └─ reçoit réellement : <CERTIFIED_FACTS> + prompt de Mission
```

### 4.1 Informations disponibles avant le lancement de Codex

| Information | Disponible avant Codex | Utilisée pour le préflight | Transmise à Codex automatiquement |
|---|---:|---:|---:|
| Program ID et décision déclarée | `OUI` | `OUI` | `NON`, sauf présence dans le prompt/faits |
| Wave et ordres de gouvernance | `OUI` dans le dépôt | `NON` génériquement | `NON` |
| Campaign ID, politiques et DAG | `OUI` | `OUI` | `NON` |
| Autorité et SHA-256 | `OUI` | `OUI` | `NON` |
| Shared evidence applicable et hashes | `OUI` | `OUI` | `NON` |
| Evidence index Campaign | `OUI` après préflight | `OUI` | `NON` |
| Mission Order complète | `OUI` | `OUI` | `NON` comme objet ; Codex peut la relire si le prompt l'ordonne |
| Prompt de Mission | `OUI` | `OUI` | `OUI` |
| Profil résolu et paramètres runtime | `OUI` | `OUI` | Appliqués par la CLI, pas fournis comme contexte métier |
| Certified Facts | `OUI` | `OUI` si fichier présent | `OUI` |
| Baseline evidence et hashes | `OUI` | Selon prompt/runtime concerné | `NON` automatiquement |
| Scopes et fichiers attendus | `OUI` | `OUI` pour validations de sortie | `NON` comme bloc structuré |
| Git branche, HEAD et snapshot | `OUI` | `OUI` | `NON` |
| `CerebrauProjectState` | Calculable par un composant existant | `NON` | `NON` |
| Rapports antérieurs | `OUI` | Seulement si référencés | `NON` |

Le point de rupture est donc précis : les métadonnées existent et sont validées, mais la plupart ne franchissent pas la frontière `Campaign Runner / runtime Mission → entrée standard de Codex`.

## 5. Phase 3 — Évaluation de l'assemblage

### 5.1 Ce qui peut être assemblé sans développement

Les composants actuels permettent de calculer en lecture seule un plan déterministe contenant :

1. l'autorité Campaign et son hash ;
2. les seules preuves dont `consumers[]` contient la Mission ;
3. la Mission Order, son prompt et son profil ;
4. les baselines hashées et les sources `scopes.readOnly` ;
5. les dépendances antérieures nécessaires ;
6. les chemins autorisés, interdits et attendus ;
7. l'identité Git du run ;
8. les Certified Facts déjà injectés.

Cet assemblage est une **sélection logique existante**, pas un nouveau composant.

### 5.2 Pourquoi l'assemblage automatique n'est pas possible aujourd'hui

| Condition nécessaire | État actuel |
|---|---|
| Le Runner sélectionne les sources minimales | Partiellement : il sélectionne les preuves applicables, mais ne produit pas un payload destiné au modèle |
| Le Runner ou le runtime appelle le Context Engine | `NON` |
| Le contenu des preuves Campaign est injecté | `NON`, seuls chemins/hashes sont contrôlés |
| Une entrée runtime accepte un contexte assemblé sans changer le prompt | `NON` |
| Un flag binaire existant active/désactive l'assemblage | `NON` |
| La Campaign courante déclare une sortie Context Engine | `NON` |
| Les métriques exhaustives du benchmark sont capturées | `NON` |

Le seul canal automatique existant est le bootstrap global `certified-facts.json`. Le réutiliser pour un contexte dynamique exigerait de modifier ce registre ou son producteur, ce qui est interdit et ne serait pas une comparaison à prompt/contexte constant.

Le raccordement nécessiterait donc une modification de logiciel existant. Cette mission ne la conçoit pas, ne la recommande pas et ne l'implémente pas. Aucun nouveau composant n'est justifié.

## 6. Phase 4 — Contexte minimal déterministe

### 6.1 Règle de sélection

Pour une Mission `M`, l'ensemble minimal dérivable est l'union ordonnée suivante, avec déduplication par `chemin normalisé + SHA-256` :

1. Campaign Manifest sélectionné ;
2. `authority.sourcePath` et `authority.certificationReportPath` ;
3. `externalPrerequisites` requis par `M` ;
4. `sharedEvidence` requis par `M` et dont `consumers[]` contient `M` ;
5. Mission Order `missions[M].missionFile` ;
6. profil résolu dans `profiles.json` ;
7. `promptFile` inchangé ;
8. `certified-facts.json` inchangé, s'il existe ;
9. chaque `baselineEvidence` dans l'ordre déclaré ;
10. chaque chemin de `scopes.readOnly` non déjà chargé ;
11. rapport terminal d'un prédécesseur uniquement si le contrat l'exige comme preuve ;
12. rapport de l'attempt courant uniquement pour une reprise gouvernée ;
13. branche, HEAD, état du worktree, `resourceScopes`, `allowedPaths`, `forbiddenPaths`, `expectedFiles` et `deliverables`.

Le Context Engine complet ne doit pas être ajouté automatiquement à cet ensemble : il lit un corpus transversal de dix Providers et n'est pas garanti minimal pour chaque Mission. Il reste réutilisable seulement lorsqu'une Mission existante le demande explicitement.

### 6.2 Catégories exactes

| Catégorie | Inclure | Ignorer |
|---|---|---|
| Archives | Seulement une archive nommée comme autorité, preuve, baseline ou reprise | Toutes les archives historiques non référencées |
| Rapports | Certification d'autorité, shared evidence consommée, prédécesseur requis, rapport de reprise | Autres runs, transcripts et rapports voisins |
| Contrats | Campaign Manifest, Mission Order, prompt et profil résolu | Contrats d'incubation non référencés |
| Preuves | Seulement `requiresEvidence`, baselines et prérequis applicables | Preuves destinées à d'autres missions |
| Hashes | Autorité, preuves applicables, Mission, prompt, baselines, fingerprint et HEAD | Hashes de corpus non utilisé |
| Décisions | Décision Program déclarée, Gate/LOT directement ciblés et décisions explicitement applicables | Décisions d'autres Lots/Gates |
| Fichiers impactés | `resourceScopes`, `allowedPaths`, `expectedFiles`, `deliverables` et fichiers cibles aussi présents en lecture | Code et documentation hors scope |
| Digital Twin | Seulement s'il est référencé par le contrat de la Mission | Sinon intégralement ignoré |
| Knowledge Index | Seulement les entrées nécessaires à une source explicitement demandée | Index secondaires non sélectionnés |

### 6.3 Application à `MM-L01-03`

Ordre minimal constaté :

1. `VEEDDA-URBANIZATION-WAVE-001-CAMPAIGN-001.json` ;
2. Master Gates Matrix et son hash d'autorité ;
3. `PROGRAM_CERTIFICATION_VERIFICATION_REPORT.md` ;
4. `L01-G04_REGISTRATION_REPORT.md` ;
5. `MM-L01-03.json` ;
6. profil `ARCHITECTURE` de `profiles.json` ;
7. `MM-L01-03.prompt.md` ;
8. `certified-facts.json` ;
9. `L01-G04_DECISION_PACKAGE.md` ;
10. `PROGRAM_MASTER_GATES_REGISTER.md` ;
11. `OPEN_WAVE_READINESS_REPORT.md`.

La Matrix, le rapport de certification et le rapport L01-G04 sont dédupliqués lorsqu'ils réapparaissent comme baseline ou source read-only. Aucun `CerebrauProjectState`, Digital Twin ou rapport historique de run n'est requis par ce contrat.

## 7. Phase 5 — Benchmark apparié

### 7.1 Comparaison demandée

```text
A — Campaign Runner → runtime Mission → Certified Facts + prompt → Codex

B — Campaign Runner → assemblage existant → runtime Mission → contexte minimal + Certified Facts + prompt → Codex
```

La condition B ne possède aucun mode d'activation existant. L'exécuter imposerait de changer le runtime, le Runner, le prompt, le Manifest ou Certified Facts. Toute option violerait les interdictions et introduirait plus d'une variable. Le benchmark n'a donc pas été exécuté.

### 7.2 Protocole prêt sur le plan méthodologique

Si un mécanisme binaire préexistant et autorisé devenait observable, chaque paire devrait conserver exactement : Mission Order, dépôt, branche, HEAD, index, fichiers suivis et non suivis, modèle, prompt et hash, profil, reasoning effort, sandbox, approval policy, version Codex, runtime et hash, Campaign Manifest, preuves, locks et paramètres CLI.

Ordre expérimental : au minimum trois paires contrebalancées `AB`, `BA`, `AB`, avec restauration vérifiée du même snapshot avant chaque run. Une paire dont les verdicts ou livrables divergent est invalide pour la mesure de performance.

### 7.3 Disponibilité des mesures

| Mesure demandée | Source actuelle | Prête |
|---|---|---:|
| `DurationMs` | `official-report.json → Codex.DurationMs` | `OUI` |
| Tokens utilisés | Non persistés autoritativement dans le rapport officiel | `NON` |
| Temps avant première modification | Aucun événement exhaustif de première écriture | `NON` |
| Temps d'analyse | Aucun segment temporel séparé | `NON` |
| Temps total | Mesurable extérieurement, non normalisé dans un artefact commun A/B | `PARTIEL` |
| Nombre de fichiers lus | Aucune télémétrie exhaustive des lectures Codex | `NON` |
| Nombre de rapports lus | Dérivable seulement si toutes les lectures sont connues | `NON` |
| Nombre d'archives utilisées | Dérivable seulement si toutes les lectures sont connues | `NON` |
| Verdict | Rapport officiel | `OUI` |
| Livrables | Git delta, expected files et hashes | `OUI` |
| Diagnostics | Rapport officiel | `OUI` |
| Régressions | Git delta, validations et comparaison fonctionnelle | `OUI` |

### 7.4 Calculs prévus

Pour chaque métrique quantitative `M` :

- `gain absolu = moyenne(A) - moyenne(B)` ;
- `gain % = (moyenne(A) - moyenne(B)) / moyenne(A) × 100` ;
- publier moyenne, médiane, minimum, maximum et dispersion ;
- un gain positif n'est attribuable à l'assemblage que si les sorties sont fonctionnellement équivalentes et que l'effet dépasse la variance des paires contrebalancées.

### 7.5 Référence au benchmark Certified Facts existant

Le benchmark apparié existant sur `MM-L01-01` ne mesure que la présence de Certified Facts. Avec une seule paire, il observe `+43,28 %` de durée, `+11,23 %` de tokens, un verdict différent et une régression de scope. Son propre verdict est `CAUSAL IMPACT OF CERTIFIED FACTS = NOT PROVEN`. Il ne peut donc servir ni de condition B, ni de preuve causale pour l'assemblage étudié ici.

## 8. Verdict final

Les composants actuels suffisent à **identifier** le contexte minimal, mais pas à réaliser automatiquement le flux B demandé. L'absence porte sur le raccordement au runtime et sur l'instrumentation du benchmark, pas sur un besoin de nouvelle base, nouveau cache, nouvelle gouvernance ou nouveau moteur.

EXISTING COMPONENTS SUFFICIENT = NO

ASSEMBLY POSSIBLE = NO

NEW SOFTWARE REQUIRED = NO

NEW RUNTIME REQUIRED = NO

NEW GOVERNANCE REQUIRED = NO

BENCHMARK READY = NO

CAUSAL BENCHMARK POSSIBLE = NO

Interprétation obligatoire : `NO` pour la suffisance et l'assemblage signifie « non opérable automatiquement dans la chaîne actuelle sans modifier un composant existant ». Cela ne constitue pas une proposition de nouveau logiciel. Aucun développement n'a été réalisé.
