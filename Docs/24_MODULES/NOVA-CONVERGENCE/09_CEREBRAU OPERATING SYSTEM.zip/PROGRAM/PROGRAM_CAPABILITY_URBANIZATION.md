# PROGRAM CAPABILITY URBANIZATION

## 1. Inventaire des 44 micro-missions

### 1.1 Dénominateur documentaire

- La Master Gates Matrix contient 44 relations uniques `Gate ↔ micro-mission`.
- 7 micro-missions disposent d'un manifeste JSON et d'un prompt individuel : `MM-L01-01`, `MM-L01-02`, `MM-L02-01` à `MM-L02-04` et `MM-L03-01`.
- 37 micro-missions sont définies uniquement par la Master Gates Matrix.
- 5 micro-missions sont enregistrées `Terminée`; 39 sont enregistrées `À faire`.
- 5 dossiers de mission EVIDENCE existent et contiennent 25 fichiers observés au total.
- Pour les missions sans manifeste, le livrable est limité au résultat attendu nommé dans la Master Gates Matrix; aucun nom de fichier ni acteur n'est ajouté.

### 1.2 Inventaire

| Micro-mission | Gate | Objectif réel | Prérequis direct | Livrable attendu | Preuve produite | Acteur démontré | Type de certification |
|---|---|---|---|---|---|---|---|
| `MM-L01-01` | `L01-G04` | Réconcilier le statut PROGRAM, G-000 et DPDS. | AUCUN | Décision de statut unique | `MM_L01_01_PROGRAM_STATUS_DECISION.md` | Profil `ARCHITECTURE`; revue humaine requise | Gouvernance |
| `MM-L01-02` | `L01-G05` | Prouver le preflight CEREBRAU opérant. | AUCUN | Preuve PT-005/PT-006/PT-007 PASS | `MM_L01_02_CEREBRAU_PREFLIGHT_EVIDENCE.md` | Profil `ARCHITECTURE`; revue humaine requise | Preuve CEREBRAU |
| `MM-L01-03` | `L01-G06` | Enregistrer une première Gate conforme. | `MM-L01-01` | Première ligne du registre de Gate | AUCUNE | NON SPÉCIFIÉ | Gouvernance |
| `MM-L02-01` | `L02-G03` | Qualifier les UNKNOWN critiques. | AUCUN | Registre critique et rapport de qualification | Dossier `EVIDENCE/MM-L02-01` : 15 fichiers; rapport principal `MM_L02_01_QUALIFICATION_REPORT.md` | Profil `ARCHITECTURE`; revue humaine requise | Qualification repository |
| `MM-L02-02` | `L02-G04` | Qualifier les imports internes. | AUCUN | Registre de résolution et rapport | `MM_L02_02_INTERNAL_IMPORT_REGISTER.csv`<br>`MM_L02_02_IMPORT_RESOLUTION_REPORT.md` | Profil `ARCHITECTURE`; revue humaine requise | Preuve repository |
| `MM-L02-03` | `L02-G05` | Fermer producteurs et consommateurs des objets critiques. | `MM-L02-01` | Registre producteurs-consommateurs critique et rapport | AUCUNE | Profil `ARCHITECTURE`; revue humaine requise | Preuve repository |
| `MM-L02-04` | `L02-G06` | Prononcer la certification repository. | `MM-L02-01`<br>`MM-L02-02`<br>`MM-L02-03` | Décision de certification repository | AUCUNE | Profil `ARCHITECTURE`; revue humaine requise | Certification |
| `MM-L03-01` | `L03-G04` | Réconcilier migrations, ledger et provenance runtime. | AUCUN | Registre de provenance et rapport de réconciliation | `MM_L03_01_MIGRATION_RUNTIME_PROVENANCE_REGISTER.csv`<br>`MM_L03_01_MIGRATION_RECONCILIATION_REPORT.md` | Profil `ARCHITECTURE`; revue humaine requise | Preuve runtime |
| `MM-L03-02` | `L03-G05` | Prouver les versions et commits frontend/backend déployés. | `PRQ-EXT-001` | Preuve de déploiement frontend/backend | AUCUNE | NON SPÉCIFIÉ | Preuve runtime |
| `MM-L03-03` | `L03-G06` | Comparer les hashes repository et déployés des Edge Functions. | `PRQ-EXT-002` | Registre des hashes des 16 Edge Functions | AUCUNE | NON SPÉCIFIÉ | Preuve runtime |
| `MM-L03-04` | `L03-G07` | Prouver l'existence nominale des variables par runtime. | `MM-L03-02` | Matrice des variables par runtime | AUCUNE | NON SPÉCIFIÉ | Preuve runtime |
| `MM-L04-01` | `L04-G03` | Décider l'autorité de chaque concept critique. | `MM-L02-04`<br>`MM-L03-01`<br>`MM-L03-03`<br>`MM-L03-04` | Décisions d'autorité sans conflit | AUCUNE | NON SPÉCIFIÉ | Décision architecture/métier |
| `MM-L04-02` | `L04-G04` | Désigner un writer autorisé unique par SOT critique. | `MM-L04-01` | Registre des writers autorisés | AUCUNE | NON SPÉCIFIÉ | Preuve d'autorité |
| `MM-L04-03` | `L04-G05` | Rattacher les consommateurs aux contrats et SOT. | `MM-L04-01` | Registre consommateurs/ContractId/SotId/fraîcheur | AUCUNE | NON SPÉCIFIÉ | Preuve d'interface |
| `MM-L04-04` | `L04-G06` | Prouver la non-autorité des fixtures et projections. | `MM-L04-02`<br>`MM-L04-03` | Preuve SOT de non-autorité | AUCUNE | NON SPÉCIFIÉ | Preuve SOT |
| `MM-L05-01` | `L05-G04` | Prouver le producteur des préconditions QF. | `PRQ-REF-001` | Preuve producteur dossier/analyse | AUCUNE | NON SPÉCIFIÉ | Preuve workflow |
| `MM-L05-02` | `L05-G05` | Fermer les frontières critiques QF. | `MM-L05-01`<br>`MM-L06-06`<br>`MM-L07-03`<br>`MM-L07-05` | Registre de fermeture des quatre frontières | AUCUNE | NON SPÉCIFIÉ | Preuve de zone |
| `MM-L05-03` | `L05-G06` | Prouver le writer unique des cinq tables QF. | `MM-L06-03` | Preuve du writer unique testé | AUCUNE | NON SPÉCIFIÉ | Preuve workflow/sécurité |
| `MM-L05-04` | `L05-G07` | Prononcer la fermeture de la zone QF. | `MM-L05-01`<br>`MM-L05-02`<br>`MM-L05-03`<br>`MM-L08-06` | Décision `ZONE READY FOR CORRECTION` | AUCUNE | NON SPÉCIFIÉ | Certification de zone |
| `MM-L06-01` | `L06-G01` | Prouver les réponses auth 401/403 de l'API QF. | `PRQ-EXT-003` | Tests auth PASS | AUCUNE | NON SPÉCIFIÉ | Test sécurité |
| `MM-L06-02` | `L06-G02` | Valider le rôle approbateur exclusif. | `MM-L05-01` | Validation métier et tests de rôle | AUCUNE | NON SPÉCIFIÉ | Sécurité métier |
| `MM-L06-03` | `L06-G03` | Certifier RLS, grants et policies des tables QF. | `MM-L03-01`<br>`MM-L06-02` | Preuve RLS/grants/policies et tests | AUCUNE | NON SPÉCIFIÉ | Sécurité DB |
| `MM-L06-04` | `L06-G04` | Sécuriser `qf_history` et son writer. | `MM-L04-01` | Contrat sécurité et test writer unique | AUCUNE | NON SPÉCIFIÉ | Test sécurité |
| `MM-L06-05` | `L06-G05` | Prouver le binding token/payload des Edge QF. | `MM-L03-03` | Contrôle d'identité et tests cross-user | AUCUNE | NON SPÉCIFIÉ | Test sécurité Edge |
| `MM-L06-06` | `L06-G06` | Certifier la matrice rôle/tenant/objet. | `MM-L06-01` à `MM-L06-05` | Matrice sécurité PASS | AUCUNE | NON SPÉCIFIÉ | Certification sécurité |
| `MM-L07-01` | `L07-G03` | Prouver l'idempotence séquentielle et concurrente. | `MM-L06-06` | Tests d'idempotence PASS | AUCUNE | NON SPÉCIFIÉ | Test transactionnel |
| `MM-L07-02` | `L07-G04` | Prouver le rollback sans résidu. | `MM-L07-01`<br>`MM-L07-04` | Tests failpoints/rollback PASS | AUCUNE | NON SPÉCIFIÉ | Test transactionnel |
| `MM-L07-03` | `L07-G05` | Prouver le résultat d'une double approbation concurrente. | `MM-L07-01` | Test de concurrence | AUCUNE | NON SPÉCIFIÉ | Test concurrence |
| `MM-L07-04` | `L07-G06` | Prouver le contrat document/version/checksum. | `PRQ-EXT-004` | Contrat Document Core et tests | AUCUNE | NON SPÉCIFIÉ | Test documentaire |
| `MM-L07-05` | `L07-G07` | Certifier publisher, retry, replay et dead-letter. | `MM-L07-02` | Contrat outbox et métriques | AUCUNE | NON SPÉCIFIÉ | Test/contrat outbox |
| `MM-L08-01` | `L08-G01` | Prouver le read model QF sans fixture productive. | `MM-L05-01`<br>`MM-L06-06` | Preuve du read model réel | AUCUNE | NON SPÉCIFIÉ | Preuve UI |
| `MM-L08-02` | `L08-G02` | Prouver l'accusé UI après HTTP 200 uniquement. | `MM-L08-01`<br>`MM-L07-02` | Preuve UI→API | AUCUNE | NON SPÉCIFIÉ | Test UI/API |
| `MM-L08-03` | `L08-G03` | Prouver les états UI des erreurs contractuelles. | `MM-L08-02` | Tests UI 401/403/409/422/500 | AUCUNE | NON SPÉCIFIÉ | Test UI |
| `MM-L08-04` | `L08-G04` | Prouver décision approuvée avant calcul des droits. | `MM-L07-05`<br>`MM-L04-01` | Contrat décision→droits | AUCUNE | NON SPÉCIFIÉ | Preuve workflow |
| `MM-L08-05` | `L08-G05` | Prouver la propagation versionnée et fraîche vers EBS/LifeHub. | `MM-L08-04` | Contrat de propagation et tests dégradés | AUCUNE | NON SPÉCIFIÉ | Preuve consommateur |
| `MM-L08-06` | `L08-G06` | Prouver le parcours vertical et le rollback. | `MM-L08-01` à `MM-L08-05` | Test E2E vertical et artefact | AUCUNE | NON SPÉCIFIÉ | Certification E2E |
| `MM-L09-01` | `L09-G02` | Qualifier les legacy atteignant le MVP. | `MM-L02-01` | Classification legacy critique | AUCUNE | NON SPÉCIFIÉ | Preuve legacy |
| `MM-L09-02` | `L09-G03` | Décider le sort des objets runtime-only critiques. | `MM-L03-01`<br>`MM-L04-01` | Décisions owner/SOT/maintenir-migrer-retirer | AUCUNE | NON SPÉCIFIÉ | Preuve drift runtime |
| `MM-L09-03` | `L09-G04` | Décider le sort des objets repository-only critiques. | `MM-L02-03`<br>`MM-L04-01` | Décisions déployer/abandonner | AUCUNE | NON SPÉCIFIÉ | Preuve drift repository |
| `MM-L10-01` | `L10-G02` | Consolider les décisions des LOTS 001 à 009. | LOT-001 à LOT-009 `GO` | Tableau des LOTS amont | AUCUNE | NON SPÉCIFIÉ | Consolidation |
| `MM-L10-02` | `L10-G03` | Certifier la chaîne QF→droits→EBS→LifeHub. | LOT-005 à LOT-008 `GO` | Preuve de chaîne MVP | AUCUNE | NON SPÉCIFIÉ | Preuve MVP |
| `MM-L10-03` | `L10-G04` | Certifier la matrice de tests MVP. | LOT-005 à LOT-009 `GO` | Matrice et résultats PASS | AUCUNE | NON SPÉCIFIÉ | Certification tests |
| `MM-L10-04` | `L10-G05` | Fermer ou faire accepter les risques critiques. | LOT-001 à LOT-009 `GO` | Registre des risques et acceptations | AUCUNE | NON SPÉCIFIÉ | Gouvernance risques |
| `MM-L10-05` | `L10-G06` | Prononcer la décision finale du PROGRAM. | `MM-L10-01` à `MM-L10-04`<br>`L10-G01 GO` | Décision finale signée | AUCUNE | NON SPÉCIFIÉ | Certification finale |

### 1.3 Résultat de la détection comparative

| Critère comparé | Résultat démontré |
|---|---|
| Même signature complète objectif + prérequis + preuve + acteur + certification | 0 doublon complet |
| Même Gate | 0 doublon; 44 Gates distinctes |
| Même prérequis vide | 5 missions racines : `MM-L01-01`, `MM-L01-02`, `MM-L02-01`, `MM-L02-02`, `MM-L03-01` |
| Même acteur démontré | 7 manifestes déclarent le profil `ARCHITECTURE` et une revue humaine; acteur non spécifié pour 37 missions |
| Même famille de preuve | Regroupements explicites par repository, runtime, autorité, workflow, sécurité, transaction, UI, drift et certification |
| Suppression possible d'une mission comme doublon | AUCUNE démontrée |

## 2. Work Packages proposés

Les Work Packages sont une vue de pilotage. Ils ne fusionnent pas les preuves et ne changent ni les 44 identifiants ni leurs décisions.

| Work Package | Objectif unique | Micro-missions exclusives | Prérequis de package | Livrables consolidés | Gates couvertes |
|---|---|---|---|---|---|
| `WP-01 Gouvernance et preflight` | Fermer la cohérence de pilotage et son dispositif de preuve. | `MM-L01-01` à `MM-L01-03` | Aucun pour 01/02; 01 pour 03 | Décision de statut, preuve preflight, première Gate enregistrée | `L01-G04` à `L01-G06` |
| `WP-02 Repository certifiable` | Qualifier le repository puis prononcer sa certification. | `MM-L02-01` à `MM-L02-04` | Chaîne 01/02 → 03 → 04 | UNKNOWN, imports, producteurs/consommateurs, décision repository | `L02-G03` à `L02-G06` |
| `WP-03 Runtime et déploiements` | Prouver provenance, déploiements, identité Edge et variables. | `MM-L03-01` à `MM-L03-04` | `PRQ-EXT-001`, `PRQ-EXT-002`; 02 → 04 | Ledger/provenance, versions, hashes, variables | `L03-G04` à `L03-G07` |
| `WP-04 Autorités et SOT` | Établir autorités, writers, consommateurs et non-autorité des projections. | `MM-L04-01` à `MM-L04-04` | Sorties WP-02/WP-03; 01 → 02/03 → 04 | Décisions d'autorité et registres SOT | `L04-G03` à `L04-G06` |
| `WP-05 Fermeture workflow QF` | Fermer les préconditions, frontières et écritures de la zone QF. | `MM-L05-01` à `MM-L05-04` | WP-06, WP-07, WP-08 et `PRQ-REF-001` selon les missions | Producteur, frontières, writer unique, décision de zone | `L05-G04` à `L05-G07` |
| `WP-06 Sécurité QF` | Certifier identité, rôle, accès DB, source QF et Edge. | `MM-L06-01` à `MM-L06-06` | WP-03/WP-04/WP-05 et `PRQ-EXT-003` | Tests auth/rôle/tenant/objet et matrice sécurité | `L06-G01` à `L06-G06` |
| `WP-07 Transactions et données` | Certifier idempotence, rollback, concurrence, documents et outbox. | `MM-L07-01` à `MM-L07-05` | WP-06 et `PRQ-EXT-004` | Tests transactionnels, contrat document, contrat outbox | `L07-G03` à `L07-G07` |
| `WP-08 UI et consommateurs` | Certifier le parcours UI et ses projections aval. | `MM-L08-01` à `MM-L08-06` | WP-04 à WP-07 selon les missions | Read model, UI/API, erreurs, droits, EBS/LifeHub, E2E | `L08-G01` à `L08-G06` |
| `WP-09 Legacy et drift` | Qualifier legacy, runtime-only et repository-only. | `MM-L09-01` à `MM-L09-03` | WP-02 à WP-04 selon les missions | Classifications et décisions de drift | `L09-G02` à `L09-G04` |
| `WP-10 Certification PROGRAM` | Consolider les LOTS, la chaîne MVP, les tests, les risques et la décision finale. | `MM-L10-01` à `MM-L10-05` | LOT-001 à LOT-009 et `L10-G01` | Dossier et décision finale | `L10-G02` à `L10-G06` |

### Contrôle de partition

- 10 Work Packages.
- 44 affectations de micro-missions.
- 44 micro-missions uniques affectées.
- 0 micro-mission non affectée.
- 0 micro-mission affectée à plusieurs Work Packages.

## 3. Capabilities proposées

Chaque Capability est justifiée par les noms stables des LOTS et par les types de preuve de la Master Gates Matrix.

| Capability | Justification existante | Work Packages | Micro-missions | Gates |
|---|---|---|---:|---:|
| `CAP-01 Gouvernance et certification` | LOT-001 « Architecture & Gouvernance »; LOT-010 « Harmonisation & Certification MVP »; types gouvernance/certification | WP-01, WP-10 | 8 | 8 |
| `CAP-02 Repository et drift` | LOT-002 « Repository »; LOT-009 « Legacy & Drift »; preuves repository/legacy/drift | WP-02, WP-09 | 7 | 7 |
| `CAP-03 Runtime` | LOT-003 « Runtime »; quatre preuves runtime | WP-03 | 4 | 4 |
| `CAP-04 Architecture et Sources of Truth` | LOT-004 « Sources of Truth »; décision architecture/métier, autorité, interface et SOT | WP-04 | 4 | 4 |
| `CAP-05 Workflows et intégration` | LOT-005 « Workflows & Attack Zones » et LOT-008 « UI & Consommateurs »; preuves workflow/UI/consommateurs/E2E | WP-05, WP-08 | 10 | 10 |
| `CAP-06 Sécurité` | LOT-006 « Sécurité »; six contrôles d'identité, rôle, tenant, DB et Edge | WP-06 | 6 | 6 |
| `CAP-07 Transactions et données` | LOT-007 « Transactions & Données »; idempotence, rollback, concurrence, document et outbox | WP-07 | 5 | 5 |

Total : 7 Capabilities, 10 Work Packages, 44 micro-missions et 44 Gates de remédiation/certification.

Les Capabilities `Documentation` et `Infrastructure` ne sont pas retenues : les données montrent une modalité documentaire pour 7 manifestes, mais aucun groupe autonome de micro-missions ayant la documentation ou l'infrastructure comme objectif unique.

## 4. Grappes d'exécution

Une grappe ne contient que des missions sans dépendance directe entre elles. Ses prérequis doivent être satisfaits avant son ouverture. Une grappe rend plusieurs Gates traitables; elle ne les déclare pas automatiquement `GO`.

| Grappe | Condition d'ouverture | Micro-missions parallèles | Gates rendues traitables | Dépendance interne |
|---|---|---|---|---|
| `GX-01 Racines probatoires` | AUCUNE | `MM-L01-01`, `MM-L01-02`, `MM-L02-01`, `MM-L02-02`, `MM-L03-01` | `L01-G04`, `L01-G05`, `L02-G03`, `L02-G04`, `L03-G04` | AUCUNE |
| `GX-02 Prérequis externes` | `PRQ-EXT-001`, `PRQ-EXT-002`, `PRQ-REF-001`, `PRQ-EXT-003`, `PRQ-EXT-004` satisfaits pour leur mission respective | `MM-L03-02`, `MM-L03-03`, `MM-L05-01`, `MM-L06-01`, `MM-L07-04` | `L03-G05`, `L03-G06`, `L05-G04`, `L06-G01`, `L07-G06` | AUCUNE |
| `GX-03 Suites des racines` | Sorties requises de GX-01 | `MM-L01-03`, `MM-L02-03`, `MM-L09-01` | `L01-G06`, `L02-G05`, `L09-G02` | AUCUNE |
| `GX-04 Consolidation initiale` | `MM-L02-01/02/03`, `MM-L03-02`, `MM-L05-01` terminées selon chaque mission | `MM-L02-04`, `MM-L03-04`, `MM-L06-02` | `L02-G06`, `L03-G07`, `L06-G02` | AUCUNE |
| `GX-05 Autorité et accès DB` | Dépendances de `MM-L04-01` et `MM-L06-03` satisfaites | `MM-L04-01`, `MM-L06-03` | `L04-G03`, `L06-G03` | AUCUNE |
| `GX-06 Autorités détaillées et drift` | Sorties GX-03 à GX-05 requises | `MM-L04-02`, `MM-L04-03`, `MM-L05-03`, `MM-L06-04`, `MM-L06-05`, `MM-L09-02`, `MM-L09-03` | 7 Gates correspondantes | AUCUNE |
| `GX-07 Consolidations SOT et sécurité` | Missions sources de GX-06 terminées | `MM-L04-04`, `MM-L06-06` | `L04-G06`, `L06-G06` | AUCUNE |
| `GX-08 Racines transaction/UI` | `MM-L06-06` et prérequis de `MM-L08-01` satisfaits | `MM-L07-01`, `MM-L08-01` | `L07-G03`, `L08-G01` | AUCUNE |
| `GX-09 Rollback et concurrence` | `MM-L07-01` et `MM-L07-04` terminées | `MM-L07-02`, `MM-L07-03` | `L07-G04`, `L07-G05` | AUCUNE |
| `GX-10 Outbox et commande UI` | `MM-L07-02` et `MM-L08-01` terminées | `MM-L07-05`, `MM-L08-02` | `L07-G07`, `L08-G02` | AUCUNE |
| `GX-11 Frontières et contrats UI` | Dépendances directes des trois missions satisfaites | `MM-L05-02`, `MM-L08-03`, `MM-L08-04` | `L05-G05`, `L08-G03`, `L08-G04` | AUCUNE |
| `GX-12 Certification parallèle` | LOTS amont requis `GO` | `MM-L10-01`, `MM-L10-02`, `MM-L10-03`, `MM-L10-04` | `L10-G02` à `L10-G05` | AUCUNE |

Quatre jonctions restent nécessairement séquentielles dans le graphe démontré et ne sont donc pas présentées comme grappes :

1. `MM-L08-05`, après `MM-L08-04`;
2. `MM-L08-06`, après `MM-L08-01` à `MM-L08-05`;
3. `MM-L05-04`, après `MM-L05-01` à `MM-L05-03` et `MM-L08-06`;
4. `MM-L10-05`, après `MM-L10-01` à `MM-L10-04` et `L10-G01 GO`.

Les regrouper artificiellement avec leurs propres prérequis violerait la contrainte d'absence de dépendance interne.

## 5. Gains estimés

### 5.1 Comparaison objective

| Mesure | Exécution actuelle | Exécution industrialisée proposée | Écart démontrable |
|---|---:|---:|---:|
| Micro-missions probatoires | 44 | 44 | 0; aucune preuve supprimée |
| Unités de pilotage opérationnel | 44 micro-missions | 10 Work Packages | -34 unités, soit -77,27 % |
| Niveaux de portefeuille | Non formalisés par Capability | 7 Capabilities | 7 domaines de pilotage justifiés |
| Gates liées aux missions | 44 | 44 | 0; décisions inchangées |
| Grappes parallèles explicites | Ordre P1 à P15 par Gate | 12 grappes multi-Gates + 4 jonctions séquentielles | Parallélisme rendu explicite sans changer le graphe |
| Missions avec manifeste/prompt | 7 | 7 | 0 |
| Missions sans manifeste/prompt | 37 | 37 | 0; dette documentaire non résolue par l'urbanisation |
| Missions avec dossier EVIDENCE | 5 | 5 | 0 |

Calculs : `(44 - 10) / 44 = 77,27 %` de réduction des unités de pilotage; les 10 Work Packages restent intégralement traçables aux 44 missions.

### 5.2 Gains non démontrables

- Gain de durée : INCONNU, aucune durée unitaire certifiée n'est disponible.
- Gain financier : INCONNU, aucun coût par mission ou revue n'est disponible.
- Gain de charge humaine : INCONNU, aucune capacité ni charge historique n'est publiée.
- Nombre de rapports évités : 0 démontré; chaque Gate conserve sa preuve et sa décision propres.
- Réduction du chemin critique : 0 démontré; les dépendances et les quatre jonctions séquentielles sont inchangées.

Le gain démontré porte sur le pilotage, la consolidation et la lisibilité, non sur la suppression d'activités probatoires.

## 6. Roadmap d'industrialisation

| Étape | Action de gouvernance | Entrée existante | Sortie de pilotage | Modification du PROGRAM |
|---|---|---|---|---|
| `U1` | Approuver la partition de référence. | 44 relations Gate/micro-mission | 10 Work Packages, partition 44/44 | AUCUNE |
| `U2` | Affecter chaque Work Package à sa Capability de pilotage. | 10 Work Packages | 7 vues Capability | AUCUNE |
| `U3` | Utiliser les Work Packages comme enveloppes de planification. | Master Gates Matrix et Execution Order | Suivi à 10 unités avec drill-down vers 44 missions | AUCUNE |
| `U4` | Ouvrir une grappe uniquement lorsque tous ses prérequis sont satisfaits. | Dépendances existantes | Jusqu'à 12 grappes multi-Gates | AUCUNE |
| `U5` | Traiter séparément les quatre jonctions séquentielles. | Graphe existant | Fermetures sans dépendance interne artificielle | AUCUNE |
| `U6` | Conserver la décision au niveau de chaque Gate. | Doctrine et Master Register | `GO`, `GO_WITH_DEROGATION` ou `NO_GO` inchangés | AUCUNE |
| `U7` | Consolider la vue Capability après chaque décision de Gate. | Décisions existantes | Pilotage agrégé sans propagation inventée | AUCUNE |

Conclusion factuelle : les 44 micro-missions peuvent être remplacées comme unités de pilotage par 10 Work Packages regroupés en 7 Capabilities. Elles ne peuvent pas être supprimées comme unités de preuve, car aucun doublon complet n'est démontré et chaque mission reste liée à une Gate distincte.

