# PROGRAM-CEREBRAU-CERTIFIED-FACTS-BENCHMARK-001

## 1. Verdict exécutif

Le benchmark met en évidence un signal brut favorable après activation du MVP : la durée moyenne observée baisse de `121 765,5 ms` (`37,95 %`) et la consommation totale de tokens baisse de `606 793` (`53,28 %`) par rapport aux deux missions de gouvernance pré-MVP retenues.

Ce signal ne constitue toutefois pas une preuve causale de l'efficacité du registre. Aucune mission identique n'a été rejouée avant et après. La mission post-MVP est une inscription ciblée de Gate, tandis que les missions pré-MVP validaient plusieurs sources puis préparaient un dossier de décision. Son prompt métier est également beaucoup plus court. Le registre ajoute un bloc de `215` caractères et ne retire mécaniquement aucune partie du prompt source.

Conclusion objective : les gains de temps et de tokens sont observés, aucune régression fonctionnelle n'est observée, mais le gain attribuable au seul MVP Certified Facts n'est pas démontré. L'extension du registre ne doit pas être recommandée sur ce seul échantillon.

## 2. Périmètre et méthode

### 2.1 Exécutions retenues

Le registre et son injection ont été créés par l'exécution `bootstrap-20260721T205937134`, terminée le 21 juillet 2026 à 21:03:16 `+02:00`. Cette exécution d'implémentation n'est pas incluse dans la base principale : elle n'est ni une mission métier post-MVP utilisant déjà l'injection, ni une mission de gouvernance comparable aux deux missions antérieures.

Base principale :

| Période | Exécution | Mission observée | Raison de sélection |
|---|---|---|---|
| Avant | `bootstrap-20260721T203809602` | `PROGRAM-VEEDDA-FINAL-BLOCKER-VALIDATION-001` | Vérifie directement les faits ensuite certifiés : modèle Wave, contrat MM-L01-03 et blocage L01-G04. |
| Avant | `bootstrap-20260721T205209302` | `PROGRAM-L01-G04-DECISION-PACKAGE-001` | Réutilise explicitement les mêmes faits de gouvernance et prépare la décision L01-G04. |
| Après | `bootstrap-20260721T222131616` | `PROGRAM-L01-G04-REGISTER-001` | Première exécution officielle terminée dont le prompt capturé commence par `<CERTIFIED_FACTS>`. |

Les trois exécutions utilisent le même dépôt, le profil `ARCHITECTURE`, le modèle `gpt-5.6-sol`, le niveau de raisonnement `high`, Codex `0.144.6` et le sandbox `workspace-write`.

### 2.2 Sources de mesure

- Temps, statut, delta Git et validations : `official-report.json` et `execution-journal.jsonl` de chaque exécution sous `tools/cerebrau/reports/`.
- Tokens et prompt réellement reçu : dernier événement `token_count` et message utilisateur des journaux locaux `C:\Users\JEFF1\.codex\sessions\2026\07\21\rollout-*.jsonl` correspondant aux exécutions.
- Qualité fonctionnelle : `FINAL_BLOCKER_VALIDATION_REPORT.md`, `L01-G04_DECISION_PACKAGE.md`, `L01-G04_DECISION_PREPARATION_REPORT.md`, `PROGRAM_MASTER_GATES_REGISTER.md`, `L01-G04_REGISTRATION_REPORT.md`, rapports officiels et `CERTIFIED_FACTS_MVP_REPORT.md`.

Les compteurs de tokens ne sont pas recopiés dans les rapports officiels CEREBRAU. Ils restent néanmoins des compteurs Codex exacts pour les sessions concernées.

### 2.3 Limite de comparabilité

Cette étude est observationnelle, et non un A/B contrôlé. Les missions ont des objectifs, des livrables et des prompts différents. Les écarts chiffrés sont donc des gains observés entre cohortes, pas une estimation causale certifiée du registre.

## 3. Mesure 1 — Temps d'exécution

### 3.1 Données brutes

| Période | Exécution | StartedAt | FinishedAt | DurationMs |
|---|---|---|---|---:|
| Avant | `bootstrap-20260721T203809602` | `2026-07-21 20:38:09.816 +02:00` | `2026-07-21 20:42:34.209 +02:00` | `264 388` |
| Avant | `bootstrap-20260721T205209302` | `2026-07-21 20:52:09.507 +02:00` | `2026-07-21 20:58:26.777 +02:00` | `377 265` |
| Après | `bootstrap-20260721T222131616` | `2026-07-21 22:21:31.831 +02:00` | `2026-07-21 22:24:51.935 +02:00` | `199 061` |

Moyenne avant : `(264 388 + 377 265) / 2 = 320 826,5 ms`.

### 3.2 Gains observés

| Comparaison | Gain absolu | Gain en % |
|---|---:|---:|
| Après vs validation du blocage | `65 327 ms` | `24,71 %` |
| Après vs préparation de décision | `178 204 ms` | `47,24 %` |
| Après vs moyenne avant | `121 765,5 ms` | `37,95 %` |

Le temps de l'étape `CODEX_EXECUTION` passe d'une moyenne avant de `314 872 ms` à `194 352 ms`, soit `120 520 ms` de moins (`38,28 %`). Cette étape explique `98,98 %` de l'écart total observé. Le reste, environ `1 245,5 ms`, relève des variations de capture et de persistance autour de l'exécution.

### 3.3 Attribution au registre

Le temps économisé causalement grâce au registre est **non déterminable** avec les exécutions disponibles. La différence brute est de `121 765,5 ms`, mais aucune fraction ne peut être attribuée avec certitude au registre.

Le chargement et la concaténation de `certified-facts.json` se produisent avant la création du chronomètre utilisé pour `DurationMs`. Le coût propre de lecture/injection du registre n'est donc pas instrumenté par cette métrique. Seul un éventuel effet indirect sur le travail du modèle pourrait apparaître dans `CODEX_EXECUTION`.

## 4. Mesure 2 — Consommation de tokens

### 4.1 Données brutes

| Période | Exécution | Input | Input en cache | Output | Total |
|---|---|---:|---:|---:|---:|
| Avant | `bootstrap-20260721T203809602` | `1 096 557` | `991 232` | `12 066` | `1 108 623` |
| Avant | `bootstrap-20260721T205209302` | `1 151 523` | `1 045 248` | `17 792` | `1 169 315` |
| Après | `bootstrap-20260721T222131616` | `524 013` | `481 536` | `8 163` | `532 176` |

Moyenne avant : `(1 108 623 + 1 169 315) / 2 = 1 138 969 tokens`.

### 4.2 Économies observées

| Comparaison | Économie de tokens | Économie en % |
|---|---:|---:|
| Après vs validation du blocage | `576 447` | `52,00 %` |
| Après vs préparation de décision | `637 139` | `54,49 %` |
| Après vs moyenne avant | `606 793` | `53,28 %` |

En excluant l'input servi depuis le cache, puis en ajoutant l'output, la moyenne avant est de `120 729 tokens` contre `50 640` après : économie observée de `70 089 tokens` (`58,05 %`).

### 4.3 Sensibilité au choix de la base

L'exécution d'implémentation immédiatement antérieure au premier usage a consommé `502 777 tokens` pour `219 497 ms`. Comparée à cette seule exécution, la mission post-MVP est plus rapide de `20 436 ms` (`9,31 %`) mais consomme `29 399 tokens` de plus (`+5,85 %`). Le sens du résultat token dépend donc du choix d'une mission non équivalente, ce qui confirme qu'aucune conclusion causale robuste ne peut être tirée sans replay apparié.

## 5. Mesure 3 — Qualité fonctionnelle

### 5.1 Verdicts et décisions

| Contrôle | Avant | Après | Résultat |
|---|---|---|---|
| Objet officiel de gouvernance | `Wave` | Le rapport d'inscription ne reconnaît aucun Work Package officiel et ne crée aucune Wave. | Cohérent. |
| Work Packages | `NOT OFFICIAL` | `NOT OFFICIAL` maintenu dans le rapport d'inscription. | Identique. |
| Modèle canonique Wave | `YES` | Aucun verdict contraire ; aucune Wave recréée. | Cohérent, mais non retesté. |
| Contrat canonique MM-L01-03 | `YES` | Aucun verdict contraire ; aucun contrat recréé. | Cohérent, mais non retesté. |
| Fondation prête | Contexte certifié `YES` | Aucun constat contraire. | Cohérent, mais non retesté. |
| Décision L01-G04 | Package : recommandation `GO`, sans enregistrement. | `GO` officiellement inscrit conformément à la décision du Program Director. | Propagation conforme. |
| PROGRAM global | `NO_GO` maintenu. | `NO_GO` maintenu. | Identique. |
| G-000 | `NOT_CERTIFIED` maintenu. | `NOT_CERTIFIED` maintenu. | Identique. |

Le passage de `L01-G04 REGISTERED = NO` à `YES` n'est pas une divergence : il est l'effet métier explicitement demandé par la mission d'inscription.

### 5.2 Livrables

Les livrables ne peuvent pas être « les mêmes » au sens d'un A/B, car les missions ne sont pas identiques. Chaque mission a toutefois produit exactement ses livrables attendus :

- avant : `FINAL_BLOCKER_VALIDATION_REPORT.md` ;
- avant : `L01-G04_DECISION_PACKAGE.md` et `L01-G04_DECISION_PREPARATION_REPORT.md` ;
- après : modification ciblée de `PROGRAM_MASTER_GATES_REGISTER.md` et création de `L01-G04_REGISTRATION_REPORT.md`.

Les rapports officiels classent les trois exécutions `READY_FOR_REVIEW` et toutes leurs validations de périmètre requises sont passées.

### 5.3 Contrôles et régression

- La préparation de décision a contrôlé `8/8` empreintes probatoires.
- L'inscription post-MVP a contrôlé les SHA-256 des deux sources obligatoires, les empreintes avant/après du registre, l'unicité de la ligne `L01-G04`, la valeur terminale unique `GO` et l'absence d'effet sur les autres Gates, Wave, Campaigns et missions.
- Le rapport du MVP consigne `2/2 PASS` pour le test ciblé avec/sans registre et `15/15 PASS` pour la suite runtime existante sans registre.
- Le comportement sans fichier est déclaré identique et aucune régression runtime n'a été détectée.

Aucune régression fonctionnelle n'est observée. Cette conclusion porte sur la cohérence de la chaîne de gouvernance et les contrôles disponibles ; elle ne remplace pas un test de non-régression par replay de la même mission.

## 6. Mesure 4 — Impact runtime

### 6.1 Parties du prompt évitées

**Parties supprimées automatiquement : aucune.** Le MVP préfixe le registre, puis transmet le prompt source complet sans réduction.

Le prompt post-MVP capturé contient :

- bloc `<CERTIFIED_FACTS>` : `215` caractères ;
- séparateur : `2` caractères ;
- prompt de mission : `916` caractères ;
- total transmis : `1 133` caractères.

La moyenne des deux prompts pré-MVP est de `3 006,5` caractères. La réduction apparente de `62,31 %` provient du fait que la mission d'inscription a été rédigée plus brièvement et poursuit un objectif plus étroit ; elle n'est pas produite par l'injection.

Les faits certifiés peuvent conceptuellement éviter de revérifier : l'objet officiel `Wave`, le statut des Work Packages, la readiness de fondation, le modèle canonique Wave et le contrat canonique MM-L01-03. La seule mission post-MVP observée ne demandait cependant pas ces vérifications. Aucun évitement effectif de ces travaux n'est donc démontré dans l'échantillon après.

### 6.2 Parties restant dominantes

- `CODEX_EXECUTION` représente `194 352 ms` sur `199 061 ms`, soit `97,63 %` de la durée post-MVP.
- L'input représente `524 013` des `532 176` tokens totaux, soit `98,47 %`.
- La mission post-MVP effectue encore `14` appels d'outil, contre `15,5` en moyenne avant : réduction limitée à `9,68 %`.
- Les lectures des Decision Packages, le contrôle des empreintes, la vérification du registre, l'édition ciblée et les contrôles de périmètre restent les travaux dominants.

Le registre n'agit ni sur le nombre de contrôles obligatoires, ni sur la capture Git, ni sur la validation de périmètre, ni sur la génération du rapport officiel.

## 7. Gains réellement observés

- Durée totale moyenne : `-121 765,5 ms`, soit `-37,95 %`.
- Étape modèle : `-120 520 ms`, soit `-38,28 %`.
- Tokens totaux : `-606 793`, soit `-53,28 %`.
- Tokens hors input en cache, output inclus : `-70 089`, soit `-58,05 %`.
- Appels d'outil : `-1,5` en moyenne, soit `-9,68 %`.
- Statut officiel conservé à `READY_FOR_REVIEW` et aucune régression fonctionnelle observée.

Ces gains sont des différences entre missions successives de complexité différente. Ils ne sont pas certifiés comme effets du registre.

## 8. Limites actuelles du MVP et du benchmark

1. Une seule exécution métier post-MVP terminée est disponible.
2. Aucune mission identique n'a été exécutée avec et sans injection sur le même état du dépôt.
3. La mission après est plus courte et plus simple que les missions avant ; son prompt métier ne sollicite pas la plupart des faits injectés.
4. Le registre ajoute du texte mais ne retire aucune section des prompts existants.
5. `DurationMs` n'inclut pas le temps de lecture et de concaténation du registre.
6. Les tokens sont présents dans les journaux de sessions Codex, pas dans les rapports officiels CEREBRAU.
7. Les faits sont injectés comme contexte déclaratif ; le MVP ne prouve pas à lui seul qu'une mission s'abstient de les revérifier.
8. L'absence de replay identique empêche de vérifier littéralement les mêmes verdicts, livrables, décisions et contrôles.

## 9. Prochains leviers d'optimisation sans refonte

Les leviers suivants utilisent le mécanisme et les traces déjà disponibles ; ils ne requièrent ni refonte, ni nouveau composant, ni cache :

1. Rejouer une même mission strictement en lecture seule sur un même snapshot, une fois sans registre et une fois avec registre, puis répéter l'appariement pour neutraliser la variance.
2. Conserver exactement le même modèle, profil, niveau de raisonnement, version Codex, prompt et état Git pour chaque paire.
3. Exploiter les compteurs `token_count` existants et les étapes du journal existant pour les comparaisons, sans modifier le runtime pendant le benchmark.
4. Pour les futures missions uniquement, référencer explicitement les clés certifiées lorsque leur usage permet d'omettre une nouvelle demande de validation documentaire ; ne pas modifier rétroactivement les prompts existants.
5. N'ajouter de nouveaux faits au registre qu'après preuve appariée d'une réduction de relecture, de temps ou de tokens sans divergence fonctionnelle.

Le prochain levier prioritaire est donc la preuve appariée, pas l'extension du contenu du registre.

EXECUTION TIME IMPROVED = YES

TOKEN CONSUMPTION REDUCED = YES

FUNCTIONAL REGRESSION = NO

CERTIFIED FACTS MVP = NOT_EFFECTIVE

RECOMMEND EXTENSION = NO
