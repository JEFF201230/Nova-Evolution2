# API REGISTER

Version : 1.0

Statut : DRAFT

Source scannee : `server/`

Date de scan : 2026-06-28

---

## 1. Synthese

Le backend expose une application Express initialisee dans `server/index.ts`.

Point d'entree principal :

- `server/index.ts`

Enregistrement principal des routes :

- `server/routes.ts`

Middlewares globaux :

- `cors`
- `express.json()`
- `express.urlencoded({ extended: false })`

Authentification principale observee :

- Bearer token lu depuis `Authorization`
- validation via `supabaseAdmin.auth.getUser(token)`
- chargement du profil applicatif dans `profiles`

---

## 2. Endpoints montes

| Methode | Endpoint | Fichier | Ligne | Authentification | Controle d'acces | Dependances principales | Description |
|---|---|---:|---:|---|---|---|---|
| GET | `/` | `server/index.ts` | 55 | Non | Aucun | Express | Healthcheck texte `CSE Backend is running.` |
| OPTIONS | `*` | `server/index.ts` | 47 | Non | CORS | `cors` | Preflight CORS global. |
| GET | `/api/profile/me` | `server/routes.ts` | 517 | Oui | Profil utilisateur existant | `profiles` | Retourne le profil de l'utilisateur authentifie. |
| POST | `/api/organizations` | `server/routes.ts` | 541 | Oui | Utilisateur authentifie | `organizations` | Cree ou met a jour l'organisation rattachee a l'utilisateur. |
| POST | `/api/budgets` | `server/routes.ts` | 704 | Oui | Profil avec `organization_id` | `profiles`, `budgets`, `budget_status_events` | Cree un budget et journalise le statut initial. |
| POST | `/api/budgets/validate` | `server/routes.ts` | 788 | Oui | Profil avec `organization_id` | `profiles`, `budgets`, `budget_status_events`, `budget_ledger` | Valide un budget ASC, rend les anciens budgets actifs legacy, cree l'ecriture ledger de credit. |
| POST | `/api/budgets/:id/close` | `server/routes.ts` | 953 | Oui | Role dans `ADMIN`, `SECRETAIRE`, `TRESORIER`, `SUPERADMIN` via evaluation de cloture | `profiles`, `budgets`, `subventions`, `subvention_payments`, `budget_ledger`, `budget_status_events` | Cloture un budget `LEGACY_ACTIVE` si aucun blocage de cloture n'est detecte. |
| GET | `/api/budgets/latest` | `server/routes.ts` | 1067 | Oui | Profil avec `organization_id` | `profiles`, `budgets` | Retourne le dernier budget ASC actif de l'organisation. |
| GET | `/api/budgets/legacy` | `server/routes.ts` | 1099 | Oui | Profil avec `organization_id` | `profiles`, `budgets`, `subventions` | Retourne les syntheses des budgets ASC en `LEGACY_ACTIVE`. |
| GET | `/api/budgets/:id/lifecycle` | `server/routes.ts` | 1127 | Oui | Budget `LEGACY_ACTIVE` de l'organisation | `profiles`, `budgets`, `subventions`, `subvention_payments`, `budget_ledger`, `v_grand_livre_asc`, `budget_status_events` | Retourne l'etat lifecycle detaille d'un budget legacy. |
| GET | `/api/financial/grand-livre/asc` | `server/routes.ts` | 1435 | Oui | Budget ASC de l'organisation | `profiles`, `budgets`, `v_grand_livre_asc` | Retourne le grand livre ASC pour le budget donne ou le budget actif. |
| GET | `/api/subventions` | `server/routes.ts` | 1517 | Oui | `SUPERADMIN` ou `ADMIN` | `subventions` | Liste toutes les subventions. |
| PATCH | `/api/subventions/:id` | `server/routes.ts` | 1549 | Oui | `SUPERADMIN` ou `ADMIN` | `subventions`, RPC `approve_subvention`, RPC `pay_subvention` | Met a jour le statut d'une subvention, avec RPC dediees pour `APPROVED` et `PAID`. |
| GET | `/api/mes/vigile` | `server/routes.ts` | 1649 | Oui | Utilisateur authentifie | `supabaseAdmin.auth.getUser`, `runVigile` | Retourne la decision Vigile MES depuis un contexte minimal construit dans la route. |

---

## 3. Routes observees non montees dans le point d'entree principal

| Methode | Endpoint local | Fichier | Ligne | Etat observe | Dependances |
|---|---|---:|---:|---|---|
| POST | `/` | `server/routes/users.ts` | 8 | Router Express exporte, aucun montage detecte dans `server/index.ts` ou `server/routes.ts` | Prisma `user` |
| GET | `/` | `server/routes/users.ts` | 17 | Router Express exporte, aucun montage detecte dans `server/index.ts` ou `server/routes.ts` | Prisma `user` |

Routes d'authentification :

- `server/routes/auth.ts` indique que les routes d'inscription, connexion, deconnexion et session ont ete supprimees au profit de Supabase Auth.

---

## 4. Controleurs

| Controleur | Fichier | Fonctions | Etat observe | Dependances |
|---|---|---|---|---|
| Auth Controller legacy | `server/controllers/auth.controller.ts` | `registerUser`, `loginUser` | Fonctions exportees, aucun montage detecte dans les routes scannees | `bcryptjs`, `jsonwebtoken`, Prisma, schemas Zod utilisateur |
| MES Vigile API handler | `server/api/mes.vigile.ts` | `getMesVigile` | Handler exporte, endpoint equivalent implemente directement dans `server/routes.ts` | `runVigileFromSupabase`, variables Supabase |

---

## 5. Services et modules metier

| Module | Fichier | Exports principaux | Role | Dependances |
|---|---|---|---|---|
| SendGrid client | `server/services/sendgridClient.ts` | `sgMail`, `SENDGRID_EMAIL_FROM` | Configure l'envoi email SendGrid | `@sendgrid/mail`, `SENDGRID_API_KEY`, `SENDGRID_EMAIL_FROM` |
| Relance email | `server/services/sendRelance.ts` | `sendRelance` | Envoie des emails de relance de dossier incomplet | SendGrid, `FRONTEND_URL` |
| Emails subvention | `server/email.ts` | `sendSubventionCreated`, `sendSubventionApproved`, `sendSubventionRejected`, `sendSubventionPaid` | Emails transactionnels de subventions | `@sendgrid/mail` |
| Storage memoire | `server/storage.ts` | `IStorage`, `MemStorage`, `storage` | Stockage applicatif en memoire, sessions Express | `express-session`, `memorystore`, `crypto` |
| Object Storage | `server/objectStorage.ts` | `ObjectStorageService`, `objectStorageClient`, `ObjectNotFoundError` | Acces objets publics/prives via Google Cloud Storage | `@google-cloud/storage`, `PUBLIC_OBJECT_SEARCH_PATHS`, `PRIVATE_OBJECT_DIR` |
| ACL objets | `server/objectAcl.ts` | `setObjectAclPolicy`, `getObjectAclPolicy`, `canAccessObject` | Gestion ACL d'objets | `@google-cloud/storage` |
| Prisma client | `server/prisma/client.ts` | `prisma` | Client Prisma central | `@prisma/client` |
| Supabase Admin | `server/src/supabase/supabaseAdmin.ts` | `supabaseAdmin` | Client Supabase service role, bypass RLS | `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` |
| Supabase Public | `server/src/supabase/supabasePublic.ts` | `supabasePublic` | Client Supabase anon pour validation JWT/RLS | `SUPABASE_URL`, `SUPABASE_ANON_KEY` |
| Vigile | `server/vigile/index.ts` | `runVigile` | Decision de parcours MES | `vigile/rules`, adaptateur validation |
| Vigile Supabase | `server/vigile/run-from-supabase.ts` | `runVigileFromSupabase` | Charge les donnees Vigile depuis Supabase | `employee_profile`, `qf_history`, `foyer_salarie`, `attestations` |
| Validation FS/QF | `server/consistency/validateFSQFConsistency.ts` | `validateFSQFConsistency` | Controle de coherence FS/QF | Aucun service externe direct observe |
| Validation QF | `server/qf/validation/validateQF.ts` | `validateQF` | Validation entree QF | Aucun service externe direct observe |
| Robot precompute gate | `server/robot/robotPreComputeGate.ts` | `robotPreComputeGate` | Controle de preconditions robot | Aucun service externe direct observe |
| Robot AT scheduler | `server/robot/at/atScheduler.ts` | `runATScheduler` | Orchestration AT | Modules `robot/at/*` |
| Robot AT persistence | `server/robot/at/robotATLogRepository.pg.ts` | `RobotATLogRepositoryPG` | Persistance logs AT | `robot_at_logs`, `supabaseAdmin` |

---

## 6. Middlewares

| Middleware | Fichier | Montage observe | Role | Dependances |
|---|---|---|---|---|
| CORS global | `server/index.ts` | Oui | Autorise origins dynamiques, credentials, headers `Content-Type` et `Authorization`, methodes `GET/POST/PUT/PATCH/DELETE/OPTIONS` | `cors` |
| Body JSON | `server/index.ts` | Oui | Parse JSON | `express.json()` |
| Body URL encoded | `server/index.ts` | Oui | Parse formulaires URL encoded | `express.urlencoded()` |
| Auth local `authenticateUser` | `server/routes.ts` | Oui, appele dans les routes protegees | Valide Bearer token Supabase puis charge `profiles.id, role` | `supabaseAdmin.auth.getUser`, table `profiles` |
| `authMiddleware` exporte | `server/middleware/auth.middleware.ts` | Aucun montage detecte | Decode JWT, verifie l'utilisateur via Supabase Admin, injecte `req.user` | `jsonwebtoken`, `supabaseAdmin.auth.admin.getUserById` |

---

## 7. Authentification et autorisation

Authentification active dans `server/routes.ts` :

1. Lecture de `Authorization: Bearer <token>`.
2. Validation via `supabaseAdmin.auth.getUser(token)`.
3. Lecture du profil applicatif dans `profiles`.
4. Retour `{ id, role }` au handler.

Routes protegees :

- toutes les routes `/api/*` montees dans `server/routes.ts`.

Exceptions :

- `GET /`
- `OPTIONS *`

Controles de role explicites :

- `GET /api/subventions` : `SUPERADMIN` ou `ADMIN`.
- `PATCH /api/subventions/:id` : `SUPERADMIN` ou `ADMIN`.
- `POST /api/budgets/:id/close` : roles autorises dans `ADMIN`, `SECRETAIRE`, `TRESORIER`, `SUPERADMIN` via `evaluateBudgetClosure`.

Auth legacy / alternative :

- `server/controllers/auth.controller.ts` genere des JWT locaux avec `JWT_SECRET`, mais aucun montage detecte.
- `server/middleware/auth.middleware.ts` decode un JWT puis verifie Supabase Admin, mais aucun montage detecte.
- `server/routes/auth.ts` documente la suppression des routes d'auth locales au profit de Supabase Auth.

---

## 8. Dependances de donnees

Tables et vues Supabase observees :

- `profiles`
- `organizations`
- `budgets`
- `budget_status_events`
- `budget_ledger`
- `subventions`
- `subvention_payments`
- `v_grand_livre_asc`
- `employee_profile`
- `qf_history`
- `foyer_salarie`
- `attestations`
- `robot_at_logs`

RPC Supabase observees :

- `approve_subvention`
- `pay_subvention`

Tables Prisma observees :

- `user` via `PrismaClient` dans `server/routes/users.ts` et `server/controllers/auth.controller.ts`.

---

## 9. Dependances techniques

Dependances runtime principales declarees dans `server/package.json` :

- `express`
- `cors`
- `dotenv`
- `@supabase/supabase-js`
- `@prisma/client`
- `jsonwebtoken`
- `@sendgrid/mail`
- `zod`
- `jspdf`
- `jspdf-autotable`
- `xlsx`
- `nanoid`

Dependances importees dans le code mais non declarees dans `server/package.json` observe :

- `bcryptjs`
- `@google-cloud/storage`
- `express-session`
- `memorystore`

---

## 10. Observations de scan

- `server/routes.ts` contient les endpoints applicatifs effectivement montes par `server/index.ts`.
- `server/routes/users.ts` expose un router Express mais aucun montage n'a ete detecte dans le point d'entree scanne.
- `server/controllers/auth.controller.ts` et `server/middleware/auth.middleware.ts` semblent appartenir a une couche auth legacy ou non branchee.
- `server/api/mes.vigile.ts` expose un handler dedie, mais l'endpoint `/api/mes/vigile` est implemente directement dans `server/routes.ts`.
- La route `PATCH /api/subventions/:id` depend de RPC Supabase pour les transitions `APPROVED` et `PAID`.
- La majorite des routes API depend de `supabaseAdmin`, donc de la cle `SUPABASE_SERVICE_ROLE_KEY`.

---

## 11. Fichiers scannes principaux

- `server/index.ts`
- `server/routes.ts`
- `server/routes/users.ts`
- `server/routes/auth.ts`
- `server/controllers/auth.controller.ts`
- `server/api/mes.vigile.ts`
- `server/middleware/auth.middleware.ts`
- `server/services/sendgridClient.ts`
- `server/services/sendRelance.ts`
- `server/email.ts`
- `server/storage.ts`
- `server/objectStorage.ts`
- `server/objectAcl.ts`
- `server/prisma/client.ts`
- `server/src/supabase/supabaseAdmin.ts`
- `server/src/supabase/supabasePublic.ts`
- `server/vigile/`
- `server/robot/`
- `server/qf/`
- `server/consistency/`
- `server/utils/`
