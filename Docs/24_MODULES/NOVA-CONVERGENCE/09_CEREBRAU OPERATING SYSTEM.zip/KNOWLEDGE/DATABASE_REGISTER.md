# Database Register

Version : 1.0

Statut : SCAN LOCAL

Date du scan : 2026-06-28

Perimetre scanne :

- `supabase/migrations/`
- `supabase/sql/`
- `supabase/functions/`
- `supabase/config.toml`

Mode d'execution :

- lecture seule ;
- aucune requete executee contre la base ;
- aucun dump distant ;
- inventaire deduit des fichiers presents dans `supabase/`.

---

## 1. Tables

| Table | Source DDL | Role observe | Colonnes principales |
|---|---|---|---|
| `public.budgets` | `supabase/migrations/20260101000000_create_budgets.sql`, enrichie par `20260225213235_budget_votes_transfers_asc_aep.sql`, `20260528120000_add_budget_status_mvp.sql`, `20260326000100_create_budgets.sql` | Budgets ASC/AEP et statut budgetaire. | `id`, `name`, `company_name`, `organization_id`, `year`, `budget_type`, `provided_amount`, `is_active`, `vote_status`, `status`, `created_at` |
| `public.subvention_models` | `supabase/migrations/20260101000010_create_subvention_models.sql` | Modeles de simulation de subvention. | `id`, `code`, `label`, `metadata`, `created_at` |
| `public.subvention_factors` | `supabase/migrations/20260101000010_create_subvention_models.sql` | Facteurs de simulation. | `id`, `code`, `label`, `type`, `config`, `created_at` |
| `public.subvention_model_factors` | `supabase/migrations/20260101000010_create_subvention_models.sql` | Liaison modele/facteur. | `id`, `model_id`, `factor_id`, `factor_code`, `weight`, `config`, `created_at` |
| `public.budget_ledger` | `supabase/migrations/20260222000000_create_budget_ledger.sql`, enrichie par `20260222202000_add_operation_id_to_ledger_v26.sql` | Ledger budgetaire append-only. | `id`, `budget_id`, `subvention_id`, `movement_type`, `amount`, `operation_id`, `created_by`, `label`, `metadata`, `created_at` |
| `public.subventions` | `supabase/migrations/20260222000001_create_subventions.sql`, enrichie par `20260222194550_patch_subventions_add_statut_refunded.sql`, `20260222195145_lock_subventions_budget_id_not_null.sql` | Demandes/subventions rattachees aux budgets. | `id`, `beneficiaire_id`, `budget_id`, `montant`, `statut`, `category`, `description`, `motif`, `operator_id`, `created_at`, `updated_at` |
| `public.subvention_payments` | `supabase/migrations/20260222205500_create_subvention_payments_v29.sql` | Paiements de subventions avec idempotence par operation. | `id`, `subvention_id`, `budget_id`, `operation_id`, `amount`, `statut`, `created_at`, `created_by` |
| `public.budget_votes` | `supabase/migrations/20260225213235_budget_votes_transfers_asc_aep.sql` | Votes budgetaires. | `id`, `budget_id`, `voted_by`, `vote_date`, `vote_result`, `meeting_reference`, `created_at` |
| `public.budget_transfers` | `supabase/migrations/20260225213235_budget_votes_transfers_asc_aep.sql` | Transferts inter-budgets. | `id`, `from_budget_id`, `to_budget_id`, `amount`, `transfer_date`, `vote_reference`, `created_at` |
| `public.ledger_accounts` | `supabase/migrations/20260617_0001_create_ledger_accounts.sql` | Plan comptable ASC. | `id`, `account_code`, `account_label`, `account_family`, `budget_type`, `is_active`, `created_at`, `updated_at` |
| `public.ledger_account_mapping` | `supabase/migrations/20260617_0002_create_ledger_account_mapping.sql` | Mapping mouvement ledger vers compte comptable. | `id`, `budget_type`, `movement_type`, `account_id`, `is_active`, `created_at`, `updated_at` |
| `public.budget_status_events` | `supabase/migrations/20260622000200_create_budget_status_events.sql` | Journal des changements de statut budgetaire. | `id`, `budget_id`, `from_status`, `to_status`, `source`, `route`, `changed_by`, `metadata`, `changed_at` |

Tables referencees par les Edge Functions mais sans DDL trouve dans `supabase/` :

| Table/vue referencee | Sources | Observation |
|---|---|---|
| `public.profiles` | `supabase/functions/salarie-fiche/index.ts`, `supabase/migrations/20260615_create_grand_livre_asc_views.sql` | Referencee pour beneficiaires/operateurs, DDL absent du perimetre scanne. |
| `public.simulations` | `supabase/functions/save-simulation/index.ts` | Referencee par Edge Function, DDL absent du perimetre scanne. |
| `public.user_qf_input` | `supabase/functions/compute-qf/index.ts`, `supabase/functions/salarie-fiche/index.ts` | Referencee par Edge Functions, DDL absent du perimetre scanne. |
| `public.foyer_salarie` | `supabase/functions/compute-qf/index.ts` | Referencee par Edge Function, DDL absent du perimetre scanne. |
| `public.qf_config` | `supabase/functions/compute-qf/index.ts` | Referencee par Edge Function, DDL absent du perimetre scanne. |
| `public.parts_rules` | `supabase/functions/compute-qf/index.ts` | Referencee par Edge Function, DDL absent du perimetre scanne. |
| `public.qf_history` | `supabase/functions/compute-qf/index.ts`, `supabase/functions/compute-rights/index.ts` | Referencee par Edge Functions, DDL absent du perimetre scanne. |
| `public.qf_foyer` | `supabase/functions/compute-qf/index.ts` | Referencee par Edge Function, DDL absent du perimetre scanne. |
| `public.rights_config` | `supabase/functions/compute-rights/index.ts` | Referencee par Edge Function, DDL absent du perimetre scanne. |
| `public.rights_history` | `supabase/functions/compute-rights/index.ts` | Referencee par Edge Function, DDL absent du perimetre scanne. |
| `public.user_rights_projection` | `supabase/functions/compute-rights/index.ts` | Referencee par Edge Function, DDL absent du perimetre scanne. |
| `public.v_budget_cse_legal` | fonctions `simulate-*` | Vue referencee par fonctions de simulation, DDL absent du perimetre scanne. |

---

## 2. Vues

| Vue | Source DDL | Dependances observees | Role |
|---|---|---|---|
| `public.v_budget_balance` | `supabase/migrations/20260222183223_create_view_v_budget_balance.sql`, patchee par `20260222191655_patch_view_v_budget_balance_reserve.sql` et `20260222192258_fix_view_v_budget_balance_drop_recreate.sql` | `public.budget_ledger` | Balance par budget avec `CREDIT`, `DEBIT`, `RESERVE`, `RELEASE`. |
| `public.v_budget_balance_by_type` | `supabase/migrations/20260225213235_budget_votes_transfers_asc_aep.sql` | `public.budget_ledger`, `public.budgets` | Balance consolidee par `organization_id`, `year`, `budget_type`. |
| `public.v_grand_livre_asc` | `supabase/migrations/20260615_create_grand_livre_asc_views.sql` | `public.budget_ledger`, `public.budgets`, `public.subventions`, `public.subvention_payments`, `public.profiles`, `public.ledger_account_mapping`, `public.ledger_accounts` | Grand livre ASC avec libelles, beneficiaires, operateurs, comptes comptables et solde ligne a ligne. |
| `public.v_balance_asc` | `supabase/migrations/20260615_create_grand_livre_asc_views.sql` | `public.v_grand_livre_asc` | Synthese ASC par budget avec credits, debits, reserves, releases, balance et dernier mouvement. |

Prototype non migration :

| Vue | Source | Observation |
|---|---|---|
| `public.v_grand_livre_asc` | `supabase/sql/prototypes/grand_livre_asc_v1.sql` | Prototype anterieur a la migration `20260615_create_grand_livre_asc_views.sql`. |
| `public.v_balance_asc` | `supabase/sql/prototypes/grand_livre_asc_v1.sql` | Prototype anterieur a la migration `20260615_create_grand_livre_asc_views.sql`. |

---

## 3. RPC SQL

| RPC | Signature active observee | Source finale observee | Droits | Role |
|---|---|---|---|---|
| `public.approve_subvention` | `approve_subvention(p_subvention_id uuid)` | `supabase/migrations/20260222201000_patch_rpc_approve_idempotence_v23.sql` | `grant execute ... to authenticated` | Reserve une subvention via mouvement `RESERVE`, verifie le solde disponible et passe la subvention en `APPROVED`. |
| `public.pay_subvention` | `pay_subvention(p_subvention_id uuid, p_operation_id uuid, p_created_by uuid)` | `supabase/migrations/20260612000100_patch_pay_subvention_created_by.sql` | `grant execute ... to authenticated` | Cree un paiement idempotent, ecrit `RELEASE` et `DEBIT`, puis passe la subvention en `PAID`. |
| `public.refund_subvention` | `refund_subvention(p_subvention_id uuid, p_amount numeric)` | `supabase/migrations/20260222193508_rpc_refund_subvention.sql` | `grant execute ... to authenticated` | Ecrit une compensation `CREDIT` et passe la subvention en `REFUNDED` si remboursement total. |

Anciennes signatures historiques observees :

- `public.pay_subvention(uuid)` dans `20260222184447_rpc_pay_subvention.sql` et `20260222191528_refactor_ledger_reserve_release_v2.sql`.
- `public.pay_subvention(uuid, uuid)` dans `20260222195900_patch_rpc_pay_idempotence_v24.sql`, `20260222204500_patch_pay_subvention_operation_id_v28.sql`, `20260222211000_patch_pay_subvention_use_subvention_payments_v30.sql`.
- `public.approve_subvention(uuid)` est redefinie plusieurs fois avant la version idempotente V2.3.

---

## 4. Fonctions Edge Supabase

| Fonction | Chemin | Tables/vues consommees observees |
|---|---|---|
| `compute-qf` | `supabase/functions/compute-qf/index.ts` | `user_qf_input`, `foyer_salarie`, `qf_config`, `parts_rules`, `qf_history`, `qf_foyer` |
| `compute-rights` | `supabase/functions/compute-rights/index.ts` | `qf_history`, `rights_config`, `rights_history`, `user_rights_projection` |
| `salarie-fiche` | `supabase/functions/salarie-fiche/index.ts` | `user_qf_input`, `profiles` |
| `save-simulation` | `supabase/functions/save-simulation/index.ts` | `simulations` |
| `simulate-v2-4` | `supabase/functions/simulate-v2-4/index.ts` | `subvention_models`, `subvention_model_factors`, `subvention_factors`, `v_budget_cse_legal` |
| `simulate-v2-5` | `supabase/functions/simulate-v2-5/index.ts` | `subvention_models`, `subvention_model_factors`, `subvention_factors`, `v_budget_cse_legal` |
| `simulate-v2-6` | `supabase/functions/simulate-v2-6/index.ts` | `subvention_models`, `subvention_model_factors`, `subvention_factors`, `v_budget_cse_legal` |

Versions archivees sous `supabase/functions/Versions-Functions/` :

- `simulate-subvention-model`
- `simulate-v1`
- `simulate-v1-backup`
- `simulate-v1-stable`
- `simulate-v2`
- `simulate-v2-1-test`
- `simulate-v2-2-test`
- `simulate-v2-3-test`
- `simulate-v2-test`

Ces versions consomment principalement `subvention_models`, `subvention_model_factors`, `subvention_factors` et `v_budget_cse_legal`.

---

## 5. Triggers

Aucun `CREATE TRIGGER` actif n'a ete trouve dans `supabase/`.

Mentions explicites :

- `supabase/migrations/20260617_0001_create_ledger_accounts.sql` indique un MVP sans trigger automatique.
- `supabase/migrations/20260617_0002_create_ledger_account_mapping.sql` indique un MVP sans trigger automatique.

---

## 6. Contraintes

| Objet | Contrainte | Source | Definition observee |
|---|---|---|---|
| `public.budgets` | Primary key | `20260101000000_create_budgets.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.budgets` | `budget_type_enum` | `20260101000000_create_budgets.sql`, `20260225213235_budget_votes_transfers_asc_aep.sql` | Enum `ASC`, `AEP`. |
| `public.subvention_models` | Primary key | `20260101000010_create_subvention_models.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.subvention_models` | Unique | `20260101000010_create_subvention_models.sql` | `code text unique not null` |
| `public.subvention_factors` | Primary key | `20260101000010_create_subvention_models.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.subvention_factors` | Unique | `20260101000010_create_subvention_models.sql` | `code text unique not null` |
| `public.subvention_model_factors` | Primary key | `20260101000010_create_subvention_models.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.budget_ledger` | Primary key | `20260222000000_create_budget_ledger.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.subventions` | Primary key | `20260222000001_create_subventions.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.subventions` | `budget_id not null` | `20260222195145_lock_subventions_budget_id_not_null.sql` | `alter column budget_id set not null` |
| `public.subventions` | `statut_allowed_values` | `20260222194550_patch_subventions_add_statut_refunded.sql` | `PENDING`, `APPROVED`, `REJECTED`, `PAID`, `REFUNDED` |
| `public.subvention_payments` | Primary key | `20260222205500_create_subvention_payments_v29.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.subvention_payments` | Foreign key | `20260222205500_create_subvention_payments_v29.sql` | `subvention_id references public.subventions(id) on delete restrict` |
| `public.subvention_payments` | Unique | `20260222205500_create_subvention_payments_v29.sql` | `operation_id uuid not null unique` |
| `public.subvention_payments` | Check | `20260222205500_create_subvention_payments_v29.sql` | `amount > 0` |
| `public.subvention_payments` | Check | `20260222205500_create_subvention_payments_v29.sql` | `statut in ('INITIATED','EXECUTED','FAILED')` |
| `public.budget_votes` | Primary key | `20260225213235_budget_votes_transfers_asc_aep.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.budget_votes` | Foreign key | `20260225213235_budget_votes_transfers_asc_aep.sql` | `budget_id references budgets(id) on delete cascade` |
| `public.budget_votes` | Check | `20260225213235_budget_votes_transfers_asc_aep.sql` | `vote_result in ('APPROVED','REJECTED')` |
| `public.budget_transfers` | Primary key | `20260225213235_budget_votes_transfers_asc_aep.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.budget_transfers` | Foreign key | `20260225213235_budget_votes_transfers_asc_aep.sql` | `from_budget_id references budgets(id) on delete cascade` |
| `public.budget_transfers` | Foreign key | `20260225213235_budget_votes_transfers_asc_aep.sql` | `to_budget_id references budgets(id) on delete cascade` |
| `public.budget_transfers` | Check | `20260225213235_budget_votes_transfers_asc_aep.sql` | `amount > 0` |
| `public.ledger_accounts` | Primary key | `20260617_0001_create_ledger_accounts.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.ledger_accounts` | Checks | `20260617_0001_create_ledger_accounts.sql` | `account_code`, `account_label`, `account_family` non vides ; `budget_type in ('ASC')` |
| `public.ledger_account_mapping` | Primary key | `20260617_0002_create_ledger_account_mapping.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.ledger_account_mapping` | Checks | `20260617_0002_create_ledger_account_mapping.sql` | `budget_type in ('ASC')`; `movement_type in ('CREDIT','RESERVE','RELEASE','DEBIT')` |
| `public.ledger_account_mapping` | Foreign key | `20260617_0002_create_ledger_account_mapping.sql` | `account_id references public.ledger_accounts(id) on update cascade on delete restrict` |
| `public.budget_status_events` | Primary key | `20260622000200_create_budget_status_events.sql` | `id uuid primary key default gen_random_uuid()` |
| `public.budget_status_events` | Foreign key | `20260622000200_create_budget_status_events.sql` | `budget_id references public.budgets(id)` |

Contrainte desactivee/commentee :

- `public.subventions.budget_id -> public.budgets(id)` est mentionnee dans `20260222195145_lock_subventions_budget_id_not_null.sql`, mais la creation de FK est commentee comme temporairement desactivee.
- `public.subvention_payments.budget_id -> public.budgets(id)` est mentionnee dans `20260222205500_create_subvention_payments_v29.sql`, mais indiquee comme desactivee temporairement.
- FK `auth.users` pour `budget_votes.voted_by` indiquee comme desactivee.

---

## 7. Index

| Index | Table | Source | Definition observee |
|---|---|---|---|
| `unique_operation_movement` | `public.budget_ledger` | `20260222202000_add_operation_id_to_ledger_v26.sql` | Unique sur `(operation_id, movement_type)` avec `where operation_id is not null`. |
| `idx_ledger_operation_id` | `public.budget_ledger` | `20260222202000_add_operation_id_to_ledger_v26.sql` | Index sur `operation_id`. |
| `idx_subvention_payments_subvention` | `public.subvention_payments` | `20260222205500_create_subvention_payments_v29.sql` | Index sur `subvention_id`. |
| `idx_subvention_payments_budget` | `public.subvention_payments` | `20260222205500_create_subvention_payments_v29.sql` | Index sur `budget_id`. |
| `ledger_accounts_account_code_budget_type_uidx` | `public.ledger_accounts` | `20260617_0001_create_ledger_accounts.sql` | Unique sur `(account_code, budget_type)`. |
| `ledger_accounts_budget_type_idx` | `public.ledger_accounts` | `20260617_0001_create_ledger_accounts.sql` | Index sur `budget_type`. |
| `ledger_accounts_is_active_idx` | `public.ledger_accounts` | `20260617_0001_create_ledger_accounts.sql` | Index sur `is_active`. |
| `ledger_account_mapping_active_movement_uidx` | `public.ledger_account_mapping` | `20260617_0002_create_ledger_account_mapping.sql` | Unique sur `(budget_type, movement_type)` avec `where is_active = true`. |
| `ledger_account_mapping_lookup_idx` | `public.ledger_account_mapping` | `20260617_0002_create_ledger_account_mapping.sql` | Index sur `(budget_type, movement_type, is_active)`. |
| `ledger_account_mapping_account_id_idx` | `public.ledger_account_mapping` | `20260617_0002_create_ledger_account_mapping.sql` | Index sur `account_id`. |
| `idx_budget_status_events_budget_id_changed_at` | `public.budget_status_events` | `20260622000200_create_budget_status_events.sql` | Index sur `(budget_id, changed_at desc)`. |
| `idx_budget_status_events_to_status` | `public.budget_status_events` | `20260622000200_create_budget_status_events.sql` | Index sur `to_status`. |
| `idx_budget_status_events_changed_at` | `public.budget_status_events` | `20260622000200_create_budget_status_events.sql` | Index sur `changed_at`. |

Index explicitement supprimes :

- `public.unique_debit_per_subvention`
- `public.unique_reserve_per_subvention`
- `public.unique_release_per_subvention`

Source : `supabase/migrations/20260222203000_drop_strict_unique_debit_v27.sql`.

---

## 8. Relations

Relations SQL avec contrainte active observee :

| Source | Cible | Source DDL | Regle |
|---|---|---|---|
| `budget_votes.budget_id` | `budgets.id` | `20260225213235_budget_votes_transfers_asc_aep.sql` | `on delete cascade` |
| `budget_transfers.from_budget_id` | `budgets.id` | `20260225213235_budget_votes_transfers_asc_aep.sql` | `on delete cascade` |
| `budget_transfers.to_budget_id` | `budgets.id` | `20260225213235_budget_votes_transfers_asc_aep.sql` | `on delete cascade` |
| `subvention_payments.subvention_id` | `subventions.id` | `20260222205500_create_subvention_payments_v29.sql` | `on delete restrict` |
| `ledger_account_mapping.account_id` | `ledger_accounts.id` | `20260617_0002_create_ledger_account_mapping.sql` | `on update cascade on delete restrict` |
| `budget_status_events.budget_id` | `budgets.id` | `20260622000200_create_budget_status_events.sql` | Pas de clause delete explicite. |

Relations applicatives sans contrainte SQL active observee :

| Source | Cible presumee | Preuve locale | Observation |
|---|---|---|---|
| `subventions.budget_id` | `budgets.id` | RPC `approve_subvention`, `pay_subvention`, `refund_subvention`; migration `20260222195145_lock_subventions_budget_id_not_null.sql` | FK stricte commentee/desactivee dans la migration. |
| `budget_ledger.budget_id` | `budgets.id` | Vues `v_budget_balance_by_type`, `v_grand_livre_asc`, RPC budgetaires | Pas de FK active trouvee dans les migrations scannees. |
| `budget_ledger.subvention_id` | `subventions.id` | Vues `v_grand_livre_asc`, RPC budgetaires | Pas de FK active trouvee dans les migrations scannees. |
| `subvention_payments.budget_id` | `budgets.id` | Migration `20260222205500_create_subvention_payments_v29.sql` | FK indiquee comme desactivee temporairement. |
| `v_grand_livre_asc.beneficiaire_id` | `profiles.id` | Vue `20260615_create_grand_livre_asc_views.sql` | Relation de lecture par `left join`, DDL `profiles` absent du perimetre scanne. |
| `v_grand_livre_asc.operator_id` | `profiles.id` | Vue `20260615_create_grand_livre_asc_views.sql` | Relation de lecture par `left join`, DDL `profiles` absent du perimetre scanne. |
| `subvention_model_factors.model_id` | `subvention_models.id` | Nommage et table de liaison | Pas de FK active trouvee dans les migrations scannees. |
| `subvention_model_factors.factor_id` | `subvention_factors.id` | Nommage et table de liaison | Pas de FK active trouvee dans les migrations scannees. |

---

## 9. Observations de scan

- Aucun trigger actif n'a ete detecte.
- Aucun fichier RLS/policy actif n'a ete detecte par le scan textuel.
- Plusieurs migrations redefinissent les memes RPC ; le registre retient la derniere signature observee dans l'ordre des migrations.
- `supabase/migrations/20260101110219_dossier_complet_rpc.sql` contient uniquement `...` et ne fournit pas de DDL exploitable.
- `supabase/migrations/20260222232545_ledger_v3_pay_subvention.sql` est vide.
- `supabase/migrations/DISABLED_patch.sql` est present mais son nom indique un patch desactive ; il n'est pas considere comme source active du registre.

