# FUNCTIONAL REGISTER

Version : 1.0

Statut : DRAFT

Source scannee : `client/`, `server/`, `supabase/`

Date de scan : 2026-06-28

Mode d'analyse : lecture du code uniquement.

---

## 1. Synthese fonctionnelle

VEEDDA CSE est une application de gestion des budgets et subventions CSE.

Les fonctions observees dans le code se repartissent en quatre domaines :

- Espace CSE / GDBCSE : fiche entreprise, calcul budgetaire, validation budget, cockpit subventions, cockpit financier, grand livre ASC, lifecycle budgetaire.
- Espace salarie : profil, quotient familial, justificatifs, situation budgetaire personnelle, demandes et catalogue d'aides.
- Moteur QF et droits : calcul backend du quotient familial, calcul des droits CSE, projection des droits.
- Financial core / ledger : ecritures budgetaires, reservation, paiement, liberation, exports PDF/Excel et vues de grand livre.

Authentification observee :

- Supabase Auth cote client.
- Bearer token cote API Express.
- Redirection par role applicatif : `SUPERADMIN`, `ADMIN`, `TRESORIER`, `SECRETAIRE`, `BENEFICIAIRE`.

---

## 2. Roles et acces

| Role | Acces fonctionnel observe | Source |
|---|---|---|
| `SUPERADMIN` | Redirection vers `/superadmin`; acces API subventions; acces cloture budget via roles autorises. | `client/src/App.tsx`, `server/routes.ts` |
| `ADMIN` | Redirection vers `/gdbcse`; acces gestion subventions; acces cloture budget. | `client/src/App.tsx`, `server/routes.ts` |
| `TRESORIER` | Redirection vers `/gdbcse`; role autorise pour cloture budget. | `client/src/App.tsx`, `server/routes.ts` |
| `SECRETAIRE` | Redirection vers `/gdbcse`; role autorise pour cloture budget. | `client/src/App.tsx`, `server/routes.ts` |
| `BENEFICIAIRE` | Redirection vers `/mon-espace-salarie`; acces espace salarie, parcours QF, dashboard salarie. | `client/src/App.tsx` |

Regles d'acces observees :

- Les routes GDBCSE sont protegees par `CseProtected`.
- Les routes salarie sont protegees par `SalarieProtected` ou `SalarieGuard`.
- Les API `/api/subventions` et `/api/subventions/:id` acceptent uniquement `SUPERADMIN` ou `ADMIN`.
- La cloture budgetaire accepte `ADMIN`, `SECRETAIRE`, `TRESORIER`, `SUPERADMIN`.

---

## 3. Parcours publics et authentification

### 3.1 Connexion

Ecran :

- `/auth`

Fonction :

- Authentifier l'utilisateur.
- Rediriger automatiquement selon le role charge depuis le profil applicatif.

Regles :

- `SUPERADMIN` -> `/superadmin`
- `ADMIN`, `TRESORIER`, `SECRETAIRE` -> `/gdbcse`
- `BENEFICIAIRE` -> `/mon-espace-salarie`

Sources :

- `client/src/App.tsx`
- `client/src/pages/auth-page.tsx`

### 3.2 Reinitialisation mot de passe

Ecran :

- `/reset-password`

Fonction :

- Permettre la mise a jour du mot de passe utilisateur.

Source :

- `client/src/pages/reset-password-page.tsx`

---

## 4. Domaine GDBCSE

### 4.1 Navigation interne GDBCSE

Le module GDBCSE est monte sur `/gdbcse`.

Il ne repose pas sur des sous-routes URL classiques pour chaque page : la vue active est geree par l'etat `window.history.state.active` et par l'evenement `gdbcse:navigate`.

Vues observees :

| Vue interne | Ecran rendu | Fonction |
|---|---|---|
| `welcome` | `GdbcseWelcome` | Accueil du module GDBCSE. |
| `fiche-entreprise` | `GdbcseFicheEntreprise` | Saisie et mise a jour des informations entreprise / CSE. |
| `calculer` | `GdbcseCalculer` | Calcul budget ASC/AEP, sauvegarde et validation budget. |
| `simulation` | `GdbcseSimulation` | Simulation et projection de dispositifs CSE. |
| `dashboard` | `GdbcseDashboard` | Cockpit operationnel des subventions. |
| `subvention` | `GestionSubventions` | Gestion detaillee des subventions. |
| `financial-cockpit` | `GdbcseFinancialCockpit` | Pilotage financier et exports. |
| `financial-history` | `GdbcseFinancialHistory` | Historique financier. |
| `grand-livre-asc` | `GdbcseGrandLivreAsc` | Grand livre ASC. |
| `budget-lifecycle` | `GdbcseBudgetLifecycle` | Cycle de vie budgetaire. |
| `budget-lifecycle-budget` | `GdbcseBudgetLifecycle view="budget-detail"` | Detail budget legacy. |
| `budget-lifecycle-journal` | `GdbcseBudgetLifecycle view="journal"` | Journal lifecycle. |

Source :

- `client/src/gdbcse/layouts/GdbcseLayout.tsx`

### 4.2 Fiche entreprise

Ecran :

- GDBCSE vue `fiche-entreprise`

Fonctions :

- Creer ou mettre a jour l'organisation rattachee a l'utilisateur.
- Renseigner les informations d'identite entreprise.
- Renseigner les informations CSE et contacts.
- Calculer un etat de completion via `is_complete`.

Donnees fonctionnelles observees :

- Nom, nom commercial, forme juridique.
- SIREN, SIRET, code APE, immatriculation, TVA.
- Dates de creation, reference effectif, mise en place CSE, cloture.
- Adresse, email, telephone, site web.
- Tranche effectif, effectif exact, multi-sites, nombre d'etablissements.
- CSE constitue, perimetre CSE, convention collective.
- Budget fonctionnement, budget ASC.
- Secretaire et tresorier.

Regles :

- Si une organisation existe deja pour l'utilisateur, elle est mise a jour.
- Sinon une organisation est creee.
- `is_complete` depend de champs obligatoires : nom, SIREN, code APE, forme juridique, date creation, adresse, code postal, ville, pays, email, tranche effectif, `cseConstitue`.

Sources :

- `client/src/gdbcse/pages/GdbcseFicheEntreprise.tsx`
- `server/routes.ts`

### 4.3 Calculateur budget CSE

Ecran :

- GDBCSE vue `calculer`

Fonctions :

- Calculer les budgets ASC et AEP.
- Projeter les budgets sur plusieurs annees.
- Sauvegarder un budget.
- Valider un budget pour le rendre actif.
- Exporter les resultats en PDF et Excel.

Parametres metier :

- Entreprise.
- Masse salariale.
- Nombre de salaries.
- Nombre d'annees de projection.
- Croissance annuelle.
- Taux ASC N-2, N-1, N.
- Taux ASC d'accord.
- Sommes engagees.

Regles de calcul observees :

- Taux ASC historique = moyenne des taux ASC N-2, N-1, N.
- Taux ASC applicable = maximum entre taux ASC historique et taux ASC d'accord.
- Taux AEP legal = `0,20 %` si effectif inferieur a 2000 salaries, `0,22 %` si effectif au moins egal a 2000 salaries.
- Budget ASC = masse salariale * taux ASC applicable.
- Budget AEP = masse salariale * taux AEP legal.
- Budget total = ASC + AEP.
- Budget disponible = budget ASC - sommes engagees.
- Projections : recalcul annuel avec croissance de masse salariale.

Parcours :

1. L'utilisateur renseigne ou charge les donnees du budget actif.
2. L'ecran calcule les KPI et projections.
3. L'utilisateur peut sauvegarder un nouveau budget avec `vote_status = PENDING` et `is_active = false`.
4. L'utilisateur peut valider ce budget.
5. La validation active le nouveau budget et alimente le cockpit subventions.

Regles backend de validation :

- La validation charge le profil et l'organisation.
- Les anciens budgets ASC valides et actifs passent en `LEGACY_ACTIVE`.
- Le budget cible passe en `ACTIVE`, `vote_status = VALIDATED`, `is_active = true`.
- Une ecriture ledger `CREDIT` est creee sur le budget actif.
- Des evenements sont ajoutes a `budget_status_events`.

Sources :

- `client/src/gdbcse/pages/GdbcseCalculer.tsx`
- `server/routes.ts`

### 4.4 Cockpit Subventions CSE

Ecran :

- GDBCSE vue `dashboard`

Fonctions :

- Afficher le budget ASC actif.
- Charger les demandes de subvention.
- Afficher les KPI budgetaires.
- Lister les demandes en attente de decision.
- Valider, refuser, mettre en attente ou payer des demandes selon les actions disponibles.
- Afficher l'historique operationnel.
- Afficher la politique budgetaire appliquee.

KPI observes :

- Budget global.
- Budget consomme.
- Budget engage.
- Disponible reel.
- Taux d'utilisation.

Regles de consolidation :

- Budget consomme = somme des subventions du budget actif dont le statut est `APPROVED`, `VALIDATED`, `PAID` ou `PAYE`.
- Budget engage = somme des subventions du budget actif dont le statut est `PENDING` ou `ON_HOLD`.
- Disponible reel = budget global - budget consomme - budget engage.
- Taux d'utilisation = budget consomme / budget global.

Statuts de subvention observes :

- `PENDING`
- `APPROVED`
- `ON_HOLD`
- `REJECTED`
- `PAID`
- variantes historiques observees : `PAYE`, `VALIDEE`, `REFUNDED`

Actions observees :

- Valider une demande -> `APPROVED`.
- Refuser une demande -> `REJECTED`.
- Mettre en attente -> `ON_HOLD`.
- Payer une demande -> `PAID`.

Regles ledger associees :

- Validation d'une subvention : reserve le montant dans le ledger via `RESERVE`.
- Paiement d'une subvention : libere la reservation via `RELEASE` puis constate le paiement via `DEBIT`.

Politique budgetaire visible dans le cockpit :

- Modele base sur le quotient familial.
- Plafond de base affiche : 200 EUR.
- Multiplicateurs visibles : T1 x1.2, T2 x1.0, T3 x0.8.
- Justificatif obligatoire affiche au-dela de 100 EUR.

Sources :

- `client/src/gdbcse/pages/GdbcseDashboard.tsx`
- `server/routes.ts`
- `supabase/migrations/*approve_subvention*.sql`
- `supabase/migrations/*pay_subvention*.sql`

### 4.5 Gestion detaillee des subventions

Ecran :

- GDBCSE vue `subvention`

Fonctions :

- Charger le budget actif.
- Charger les subventions.
- Afficher des analyses par categorie, dispositif, periode et detail.
- Visualiser la repartition et l'utilisation des demandes.

Source :

- `client/src/gdbcse/pages/GestionSubventions.tsx`

### 4.6 Cockpit financier

Ecrans :

- GDBCSE vue `financial-cockpit`
- GDBCSE vue `financial-history`
- GDBCSE vue `grand-livre-asc`

Fonctions :

- Charger le budget actif.
- Charger les subventions.
- Charger le grand livre ASC.
- Calculer des indicateurs financiers.
- Visualiser les mouvements ledger.
- Exporter des rapports financiers PDF et Excel.

Mouvements financiers observes :

- `CREDIT` : credit budgetaire.
- `RESERVE` : reservation budgetaire.
- `RELEASE` : liberation budgetaire.
- `DEBIT` : paiement budgetaire.

Regles de balance :

- Solde = CREDIT - DEBIT - RESERVE + RELEASE.
- Le grand livre ASC expose les montants debit, credit, reserve, release et le solde apres ligne.

Sources :

- `client/src/gdbcse/pages/GdbcseFinancialCockpit.tsx`
- `client/src/gdbcse/pages/GdbcseFinancialHistory.tsx`
- `client/src/gdbcse/pages/GdbcseGrandLivreAsc.tsx`
- `client/src/gdbcse/financial/exporters/`
- `supabase/migrations/20260615_create_grand_livre_asc_views.sql`

### 4.7 Budget Lifecycle

Ecran :

- GDBCSE vue `budget-lifecycle`

Fonctions :

- Identifier les budgets ASC en `LEGACY_ACTIVE`.
- Charger le budget actif courant.
- Charger le detail d'un budget legacy.
- Afficher les demandes, paiements, ledger, historique et timeline.
- Evaluer la capacite de cloture.
- Afficher l'avancement du cycle de vie.

Etapes lifecycle observees :

- Creation.
- Validation.
- Exploitation.
- Fermeture.
- Cloture.
- Archivage.

Statuts budgetaires observes :

- `DRAFT`
- `CREATED`
- `VALIDATED`
- `ACTIVE`
- `LEGACY_ACTIVE`
- `CLOSED`
- `ARCHIVED`

Regles de cloture :

- Le budget doit appartenir a l'organisation de l'utilisateur.
- Le budget doit etre `LEGACY_ACTIVE`.
- L'utilisateur doit avoir un role autorise.
- Aucune subvention ouverte ne doit rester.
- Aucun paiement `INITIATED` ne doit rester.
- Le solde reserve doit etre nul.

Raisons de blocage observees :

- `UNAUTHORIZED_TO_CLOSE_BUDGET`
- `OPEN_SUBVENTIONS_EXIST`
- `INITIATED_PAYMENTS_EXIST`
- `RESERVE_BALANCE_NOT_ZERO`

Source :

- `client/src/gdbcse/pages/GdbcseTransitionBudgetaire.tsx`
- `client/src/gdbcse/pages/GdbcseBudgetLifecycle.tsx`
- `client/src/gdbcse/hooks/useLifecycle.ts`
- `server/routes.ts`

---

## 5. Domaine salarie

### 5.1 Mon espace salarie

Ecran :

- `/mon-espace-salarie`

Fonctions :

- Afficher la situation du salarie.
- Afficher le profil utilisateur.
- Afficher le quotient familial courant.
- Afficher les droits CSE calcules.
- Afficher les dernieres consommations.
- Afficher la situation budgetaire personnelle.
- Donner acces aux actions : mise a jour profil, accompagnement QF, nouvelle demande, mes demandes, catalogue.

Donnees affichees :

- Nom, prenom, email, telephone, date de naissance.
- Situation familiale.
- Statut dossier.
- QF courant.
- Categorie / tranche.
- Taux de prise en charge.
- Aide mensuelle CSE.
- Dernieres subventions approuvees.
- Budget annuel, consomme, solde.

Regles :

- Si aucun historique QF n'existe, l'utilisateur est redirige vers la passerelle QF.
- Les droits sont lus depuis `user_rights_projection`.
- Les consommations recentes sont les subventions `APPROVED` du beneficiaire.

Sources :

- `client/src/mon-espace-salarie/pages/MonEspacePage.tsx`
- `client/src/mon-espace-salarie/layouts/MonEspaceLayout.tsx`

### 5.2 Dashboard salarie

Ecrans :

- `/dashboard-salarie`
- `/dashboard-salarie/catalogue`
- `/dashboard-salarie/nouvelle-demande`
- `/dashboard-salarie/demandes`
- `/dashboard-salarie/mes-demandes` redirige vers `/dashboard-salarie/demandes`

Onglets observes :

- `apercu`
- `catalogue`
- `nouvelle`
- `demandes`

Fonctions :

- Consulter les aides disponibles.
- Creer une nouvelle demande de subvention.
- Suivre ses demandes.
- Filtrer les demandes par statut, categorie et periode.
- Telecharger une attestation.

Categories observees :

- Vacances.
- Sport.
- Culture.
- Enfants.
- Bien-etre.
- Autre.

Regles de demande :

- Une demande a une categorie, un montant, une description et un beneficiaire.
- Les montants sont stockes en centimes dans `subventions.montant`.
- Le statut initial d'une demande creee par le salarie est `PENDING`.
- Les plafonds annuels internes sont controles cote interface avant validation du panier.
- Les demandes peuvent etre rattachees au budget actif.

Regles URSSAF visibles :

- Pour sport et culture, le texte indique qu'il n'existe pas de plafond URSSAF chiffre dans l'ecran.
- Le montant de 196 EUR est presente comme plafond interne choisi par le CSE, pas comme plafond legal universel.

Sources :

- `client/src/pages/DashboardSalarie.tsx`

### 5.3 Parcours fiche salarie

Ecrans :

- `/salarie/bienvenue`
- `/salarie/fiche`
- `/salarie/regles-calcul`
- `/salarie/quotient-familial`
- `/salarie/comment-calcul`
- `/salarie/justificatifs`

Fonctions :

- Accueillir le salarie dans le parcours.
- Collecter ou mettre a jour les informations du profil.
- Collecter les donnees familiales dans `foyer_salarie`.
- Expliquer les regles de calcul.
- Collecter les ressources et calculer le QF.
- Afficher le resultat du calcul.
- Gerer les justificatifs.

Regles observees dans la fiche :

- Nettoyage du numero de telephone.
- Controle de dates futures.
- Calcul d'age.
- Controle d'anciennete / delai apres inscription.
- Persistance dans `profiles` et `foyer_salarie`.
- Appel possible a la fonction Supabase `salarie-fiche`.

Sources :

- `client/src/salarie/fiche.tsx`
- `client/src/salarie/regles-calcul.tsx`
- `client/src/salarie/quotient-familial/etape3.tsx`
- `client/src/salarie/quotient-familial/etape4.tsx`
- `client/src/salarie/justificatifs.tsx`

### 5.4 Parcours quotient familial

Ecran principal observe :

- `/salarie/quotient-familial`

Fonctions :

- Saisir les revenus.
- Saisir les prestations.
- Saisir la composition familiale.
- Verifier la coherence avec la fiche salarie.
- Appeler le Vigile MES.
- Lancer le calcul QF backend.
- Avancer le dossier vers l'ecran de resultat.

Champs de calcul observes :

- Revenu fiscal de reference.
- Revenus du conjoint.
- Autres revenus.
- Allocations familiales.
- Aide au logement.
- Autres prestations.
- Nombre d'enfants.
- Enfant en situation de handicap.
- Garde alternee.

Regles de saisie :

- Revenu fiscal de reference requis.
- Nombre d'enfants non negatif.
- Revenu total annuel nul interdit pour le calcul.
- Alerte si revenu total declare inferieur a 3000 EUR et superieur a 0.
- Les brouillons autosave sont neutralises : persistance uniquement sur action utilisateur "Continuer".

Regles de coherence :

- Le nombre d'enfants saisi pour le QF est compare au nombre d'enfants de la fiche salarie.
- Si incoherence, le calcul est bloque et l'utilisateur doit corriger sa fiche.
- Le endpoint `/api/mes/vigile` peut aussi bloquer l'acces QF selon la decision metier.

Sources :

- `client/src/salarie/quotient-familial/etape3.tsx`
- `server/routes.ts`

### 5.5 Passerelle QF

Ecrans :

- `/bridge/qf-accompagnement`
- `/bridge/qf-avantages`

Fonctions :

- Accompagner le salarie vers la mise a jour ou le recalcul QF.
- Afficher les avantages lies au QF.
- Proteger l'acces via `BridgeQfGuard`.

Regles :

- Le guard lit le dernier `qf_history`.
- Selon le contexte, l'acces est combine avec `SalarieProtected`.
- Un flag `VITE_USE_MES_VIGILE` peut modifier l'enveloppe de protection.

Sources :

- `client/src/bridge-qf/guards/BridgeQfGuard.tsx`
- `client/src/bridge-qf/pages/QfActivation.tsx`
- `client/src/bridge-qf/pages/QfAvantages.tsx`

---

## 6. Moteur QF et droits

### 6.1 Calcul du quotient familial

Fonction :

- Supabase Edge Function `compute-qf`.

Entree :

- `user_id`
- `as_of` optionnel
- `force_recompute` optionnel

Sources de donnees :

- `user_qf_input`
- `foyer_salarie`
- `qf_config`
- `parts_rules`
- `qf_history`

Regles :

- Seule la configuration QF active et valide a la date `as_of` est utilisee.
- Le calcul est backend-first.
- Les donnees legacy QF V1 ne doivent plus etre utilisees selon le commentaire de gouvernance du code.
- Le nombre de parts est calcule depuis la situation familiale et le nombre d'enfants.
- Le QF est calcule via une formule configuree, actuellement de type division.
- Les contraintes min/max et l'arrondi viennent de `qf_config.config`.
- La tranche et le taux de prise en charge viennent de `qf_config.config.presentation.tranches`.
- L'idempotence repose sur un hash des inputs et de la configuration.

Sortie :

- Ecriture append-only dans `qf_history`.
- Upsert dans `qf_foyer` observe comme compatibilite.

Erreurs fonctionnelles observees :

- `QF_INPUT_MISSING`
- `NO_ACTIVE_CONFIG`
- `INVALID_CONFIG`
- `PARTS_RULES_MISSING`
- `INPUT_VALIDATION_ERROR`
- `CALCULATION_ERROR`
- `QF_PRESENTATION_MISSING`
- `TRANCHES_CONFIG_MISSING`

Source :

- `supabase/functions/compute-qf/index.ts`

### 6.2 Calcul des droits CSE

Fonction :

- Supabase Edge Function `compute-rights`.

Entree :

- `user_id`
- `as_of` optionnel
- `force_recompute` optionnel

Sources de donnees :

- Dernier `qf_history`.
- `rights_config`.
- `rights_history`.
- `user_rights_projection`.

Regles :

- Le QF doit deja etre calcule.
- La configuration de droits active et valide est chargee.
- Le calcul cherche les droits correspondant a la tranche QF.
- Chaque droit calcule applique un plafond et un taux.
- L'idempotence repose sur un hash du snapshot QF et de la configuration.
- Le resultat est historise dans `rights_history`.
- La projection courante est mise a jour dans `user_rights_projection`.

Erreurs fonctionnelles observees :

- `QF_NOT_CALCULATED`
- `QF_INCOMPLETE`
- `NO_ACTIVE_RIGHTS_CONFIG`
- `INVALID_RIGHTS_CONFIG`
- `QF_TRANCHE_MISSING`
- `RIGHTS_CALCULATION_ERROR`

Source :

- `supabase/functions/compute-rights/index.ts`

---

## 7. Financial core et ledger

### 7.1 Cycle budgetaire ASC

Fonctions :

- Creation budget.
- Validation budget.
- Passage des anciens budgets actifs en `LEGACY_ACTIVE`.
- Cloture des budgets legacy.
- Journalisation des changements de statut.

Regles :

- Un budget cree est initialise en statut de vote.
- Un budget valide devient actif.
- La validation d'un budget cree une ecriture `CREDIT` egale au montant fourni.
- Les budgets ASC actifs precedents valides deviennent legacy actifs.
- La cloture est bloquee tant que les controles metier ne sont pas satisfaits.

Sources :

- `server/routes.ts`
- `supabase/migrations/20260326000100_create_budgets.sql`
- `supabase/migrations/20260622000200_create_budget_status_events.sql`

### 7.2 Cycle subvention-finance

Parcours :

1. Le salarie cree une demande de subvention.
2. La demande est en `PENDING`.
3. Le CSE approuve la demande.
4. Une ecriture `RESERVE` est creee.
5. Le CSE paie la demande.
6. Une ecriture `RELEASE` libere la reserve.
7. Une ecriture `DEBIT` constate le paiement.
8. La demande passe en `PAID`.

Regles :

- Une subvention ne peut etre approuvee que si elle est `PENDING`.
- L'approbation controle le solde disponible : CREDIT - DEBIT - RESERVE + RELEASE.
- Si le solde est insuffisant, l'approbation echoue.
- Une subvention ne peut etre payee que si elle est `APPROVED`.
- Les paiements sont idempotents par `operation_id`.
- La derniere migration observee du paiement exige un `p_created_by`.

Sources :

- `server/routes.ts`
- `supabase/migrations/20260222201000_patch_rpc_approve_idempotence_v23.sql`
- `supabase/migrations/20260612000100_patch_pay_subvention_created_by.sql`

### 7.3 Grand livre ASC

Fonction :

- Fournir une lecture comptable des mouvements ASC.

Donnees exposees :

- Budget.
- Mouvement.
- Operation.
- Reference.
- Libelle.
- Beneficiaire.
- Operateur.
- Debit.
- Credit.
- Reserve.
- Release.
- Solde apres ligne.
- Source metier.
- Compte comptable.

Regles :

- Les mouvements sont ordonnes par date, operation et ligne ledger.
- Le solde apres ligne suit la formule CREDIT - DEBIT - RESERVE + RELEASE.
- Les libelles metier sont derives du type de mouvement.

Sources :

- `server/routes.ts`
- `supabase/migrations/20260615_create_grand_livre_asc_views.sql`
- `client/src/gdbcse/pages/GdbcseGrandLivreAsc.tsx`

---

## 8. Exports et documents

Exports observes :

- PDF budget CSE depuis le calculateur.
- Excel budget CSE depuis le calculateur.
- PDF / Excel financiers depuis le cockpit financier.
- Grand livre ASC exportable.
- Attestation salarie telechargeable depuis le dashboard salarie.

Bibliotheques observees :

- `jspdf`
- `jspdf-autotable`
- `xlsx`
- `exceljs`
- `file-saver`
- `html2canvas`

Sources :

- `client/src/gdbcse/pages/GdbcseCalculer.tsx`
- `client/src/gdbcse/pages/GdbcseFinancialCockpit.tsx`
- `client/src/gdbcse/financial/exporters/`
- `client/src/pages/DashboardSalarie.tsx`

---

## 9. Notifications, emails et relances

Fonctions observees cote serveur :

- Emails transactionnels de subvention : creation, approbation, rejet, paiement.
- Relances email de dossiers incomplets.

Statut :

- Services presents dans le code.
- Montage fonctionnel complet non verifie dans les routes principales scannees.

Sources :

- `server/email.ts`
- `server/services/sendRelance.ts`
- `server/emails/README.md`

---

## 10. Points fonctionnels visibles mais partiellement branches

| Element | Observation | Impact |
|---|---|---|
| Auth legacy locale | Controleurs JWT locaux presents, mais routes auth Supabase privilegiees. | A traiter comme legacy / non principal. |
| Certains textes affiches encodes incorrectement | Plusieurs fichiers contiennent des caracteres mal encodes. | Impact UI documentaire, pas necessairement logique metier. |
| `DashboardSalarie` contient des references d'attachments | Commentaires sur association de fichiers, implementation cible non completement verifiee dans les routes API principales. | A confirmer avant documentation definitive du stockage pieces jointes. |
| Ancien moteur QF dans `MonEspacePage` | Plusieurs blocs sont neutralises ou commentes comme legacy. | Le moteur canonique observe est `compute-qf` + `qf_history`. |
| `GdbcseSimulation` est tres volumineux | Le scan confirme une simulation GDBCSE, mais le detail complet des algorithmes necessite un registre dedie. | Risque de documentation incomplete sur les scenarios de simulation. |

---

## 11. Sources principales scannees

- `client/src/App.tsx`
- `client/src/gdbcse/layouts/GdbcseLayout.tsx`
- `client/src/gdbcse/pages/GdbcseCalculer.tsx`
- `client/src/gdbcse/pages/GdbcseDashboard.tsx`
- `client/src/gdbcse/pages/GestionSubventions.tsx`
- `client/src/gdbcse/pages/GdbcseFinancialCockpit.tsx`
- `client/src/gdbcse/pages/GdbcseFinancialHistory.tsx`
- `client/src/gdbcse/pages/GdbcseGrandLivreAsc.tsx`
- `client/src/gdbcse/pages/GdbcseTransitionBudgetaire.tsx`
- `client/src/gdbcse/hooks/useLifecycle.ts`
- `client/src/pages/DashboardSalarie.tsx`
- `client/src/mon-espace-salarie/pages/MonEspacePage.tsx`
- `client/src/salarie/fiche.tsx`
- `client/src/salarie/quotient-familial/etape3.tsx`
- `client/src/bridge-qf/guards/BridgeQfGuard.tsx`
- `server/index.ts`
- `server/routes.ts`
- `supabase/functions/compute-qf/index.ts`
- `supabase/functions/compute-rights/index.ts`
- `supabase/migrations/20260615_create_grand_livre_asc_views.sql`
- `supabase/migrations/20260612000100_patch_pay_subvention_created_by.sql`
- `supabase/migrations/20260622000200_create_budget_status_events.sql`

