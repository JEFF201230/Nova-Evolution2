﻿# KNOWLEDGE INDEX V2

Version : 2.0
Statut : AUTO-GENERE / LECTURE SEULE
Date de scan : 2026-06-28
Perimetre : `Docs/`
Mode : lecture seule sur les sources ; generation du present fichier uniquement.
Git : aucun `git add`, aucun commit.

---

## 1. Sources canoniques

Les registres produits actuellement detectes dans le perimetre documentaire sont les sources canoniques de cet index.

| Registre | Role | Chemin |
|---|---|---|
| Functional Register | Registre des domaines, parcours, regles metier et fonctions observees. | `Docs/KNOWLEDGE/FUNCTIONAL_REGISTER.md` |
| Database Register | Registre des tables, vues, RPC, fonctions Edge, contraintes et relations observees. | `Docs/KNOWLEDGE/DATABASE_REGISTER.md` |
| API Register | Registre des endpoints, middlewares, services backend et dependances observees. | `Docs/KNOWLEDGE/API_REGISTER.md` |
| Program Register | Registre de pilotage programme du CEREBRAU Operating System. | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/PROGRAM_REGISTER.md` |
| Lot Register | Registre des lots COS. | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/LOT_REGISTER.md` |

## 2. Synthese automatique

- Documents et artefacts indexes : 318
- Domaines indexes : 13
- Modules indexes : 10
- Categories Knowledge detectees : 18
- Registres, references Knowledge et lots COS detectes : 26

## 3. Index par domaine

| Domaine | Documents | Modules principaux | Categories dominantes |
|---|---:|---|---|
| `00_GOUVERNANCE` | 52 | GDBCSE / Financial Core, Espace salarie / QF / Droits, Transverse, Robot AT / Automatisation | ARCHIVE, GOVERNANCE, README, LOT |
| `00_LEGACY_GLOBAL` | 2 | Legacy / Historique | DOC, PATCH |
| `01_SYNTHESES` | 21 | Transverse, GDBCSE / Financial Core, Espace salarie / QF / Droits, Robot AT / Automatisation | SYNTHESIS, ARCHIVE |
| `02_BIBLE_ERREURS` | 5 | Robot AT / Automatisation, Espace salarie / QF / Droits, GDBCSE / Financial Core, Transverse | ERROR |
| `03_PATCHES_ET_EVOLUTIONS` | 18 | Espace salarie / QF / Droits, Robot AT / Automatisation | PATCH |
| `04_MODULES` | 64 | GDBCSE / Financial Core, Espace salarie / QF / Droits, Robot AT / Automatisation, STAR / Design / Exports | MODULE, ARCHITECTURE, LOT, GOVERNANCE |
| `05_CEREBRAU` | 7 | Transverse, GDBCSE / Financial Core, Legacy / Historique | ARCHITECTURE, DECISION |
| `06_INNOVATIONS & EVOLUTIONS` | 4 | Robot AT / Automatisation, STAR / Design / Exports, GDBCSE / Financial Core | PATCH, ROADMAP |
| `07_STAR_FACTORY` | 21 | STAR / Design / Exports, GDBCSE / Financial Core | DESIGN, PROMPT, LOT |
| `08_CODEX` | 73 | STAR / Design / Exports, GDBCSE / Financial Core, Transverse, Robot AT / Automatisation | DESIGN, VISION, PROMPT, GOVERNANCE |
| `09_CEREBRAU OPERATING SYSTEM` | 43 | CEREBRAU Operating System, GDBCSE / Financial Core, Data / API / Supabase | DOC, LOT, README, REFERENCE |
| `KNOWLEDGE` | 4 | CEREBRAU Operating System, Data / API / Supabase | REFERENCE, AUDIT |
| `ROOT_DOCS` | 4 | Transverse, CEREBRAU Operating System | DOC, README |

## 4. Index par composant

| Composant | Role | Documents | Chemins racines |
|---|---|---:|---|
| Registres Knowledge | Registres produits canoniques | 3 | Docs<br>KNOWLEDGE<br>API_REGISTER.md<br>Docs/KNOWLEDGE/API_REGISTER.md<br>DATABASE_REGISTER.md |
| CEREBRAU Operating System | Vision, agents, workflows, regles, reference, lots | 43 | Docs<br>09_CEREBRAU OPERATING SYSTEM<br>01_CORE<br>DEVELOPMENT_ARCHITECTURE.md<br>Docs/09_CEREBRAU OPERATING SYSTEM/01_CORE |
| Project Management COS | Programmes et lots COS | 16 | Docs<br>09_CEREBRAU OPERATING SYSTEM<br>02_PROJECT_MANAGEMENT<br>COS-001.md<br>Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT |
| Gouvernance | Cadre, validations, methodologie, archives | 52 | Docs<br>00_GOUVERNANCE<br>_ARCHIVES<br>01_architecture_base_veedda.md<br>Docs/00_GOUVERNANCE/_ARCHIVES |
| Syntheses | Memoire projet et resumes transverses | 21 | Docs<br>01_SYNTHESES<br>2026-02_CEREBRAU_SYNTHESE_AVANCEMENT_VEEDDA_CSE.md<br>Docs/01_SYNTHESES/2026-02_CEREBRAU_SYNTHESE_AVANCEMENT_VEEDDA_CSE.md<br>99_SYNTHESES |
| Bible erreurs | Erreurs connues et incidents documentes | 5 | Docs<br>02_BIBLE_ERREURS<br>AUTH<br>AUTH-001_Authentification_non_unifiee.md<br>Docs/02_BIBLE_ERREURS/AUTH |
| Patches et evolutions | Corrections, evolutions et roadmaps | 22 | Docs<br>03_PATCHES_ET_EVOLUTIONS<br>ADAPTATION_COMPUTE_QF_ETAPE4.md<br>Docs/03_PATCHES_ET_EVOLUTIONS/ADAPTATION_COMPUTE_QF_ETAPE4.md<br>ANALYSE_ETAPE4_QF.md |
| Modules fonctionnels | Documentation module par module | 64 | Docs<br>04_MODULES<br>AT<br>AT_RULES.md<br>Docs/04_MODULES/AT |
| Architecture CEREBRAU | Architecture systeme et fonctionnelle | 7 | Docs<br>05_CEREBRAU<br>02_ARCHITECTURE<br>CEREBRAU_VEEDDA_BUDGET_LIFECYCLE_ARCHITECTURE.md.txt<br>Docs/05_CEREBRAU/02_ARCHITECTURE |
| STAR Factory | Design system, UI, inbox et assets | 21 | Docs<br>07_STAR_FACTORY<br>DESIGN SYSTEM STAR<br>DESIGN SYSTEM STAR.txt<br>Docs/07_STAR_FACTORY/DESIGN SYSTEM STAR |
| Codex production | Audits, prompts, exports, references et maquettes | 73 | Docs<br>08_CODEX<br>FINANCIAL_INFO_MODAL_ARCHITECTURE.md<br>Docs/08_CODEX/FINANCIAL_INFO_MODAL_ARCHITECTURE.md<br>FINANCIAL_INFO_RENDERING_ARCHITECTURE.md |

## 5. Index par module

| Module | Documents | Domaines sources | Documents pivots |
|---|---:|---|---|
| CEREBRAU Operating System | 48 | 09_CEREBRAU OPERATING SYSTEM, 04_MODULES, KNOWLEDGE, 00_GOUVERNANCE, 01_SYNTHESES | `Docs/00_GOUVERNANCE/CEREBRAU_CLOTURE.md`<br>`Docs/04_MODULES/AT/BACKOFFICE_AT_PILOTAGE.md`<br>`Docs/04_MODULES/AT/ROBOT_AT_PILOTAGE.md`<br>`Docs/04_MODULES/INFRA-FINANCEMENT DISTRIBUTION PILOTAGE QVT/VEEDDA — Modèle économique infrastructure de financement + distribution + pilotage QVT.txt`<br>`Docs/09_CEREBRAU OPERATING SYSTEM/01_CORE/DEVELOPMENT_ARCHITECTURE.md`<br>`Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-001.md` |
| Data / API / Supabase | 5 | KNOWLEDGE, 04_MODULES, 09_CEREBRAU OPERATING SYSTEM | `Docs/04_MODULES/SGBD/VEEDDA_ARCHITECTURE_SGBD_IDENTITE.md`<br>`Docs/04_MODULES/SGBD/VEEDDA_DATAFLOW_REFERENCE.md`<br>`Docs/KNOWLEDGE/API_REGISTER.md`<br>`Docs/KNOWLEDGE/DATABASE_REGISTER.md` |
| Espace salarie / QF / Droits | 33 | 03_PATCHES_ET_EVOLUTIONS, 00_GOUVERNANCE, 04_MODULES, 01_SYNTHESES, 02_BIBLE_ERREURS | `Docs/00_GOUVERNANCE/CEREBRAU_VEEDDA-CSE_PRA_STABILISATION_CALCUL_PARCOURS_QF_2026-02-03.md`<br>`Docs/00_GOUVERNANCE/CEREBRAU_VEEDDA-CSE_STABILISATION_CALCUL_PARCOURS_QF_2026-02-02.md`<br>`Docs/00_GOUVERNANCE/GOUVERNANCE_VALIDATION_METIER_FS_QF_AUTH.md`<br>`Docs/00_GOUVERNANCE/QF_V2_CONTRAT_ECHANGE_METIER_2026-01-30.md`<br>`Docs/00_GOUVERNANCE/SYNTHESE_GLOBALE_VEEDDA_CSE_VIGILE_ROBOT_AUTOSAVE_QF.md`<br>`Docs/04_MODULES/MES/MES_CONFIG_SCHEMA.md` |
| GDBCSE / Financial Core | 103 | 04_MODULES, 00_GOUVERNANCE, 08_CODEX, 01_SYNTHESES, 07_STAR_FACTORY | `Docs/00_GOUVERNANCE/CEREBRAU_GDBCSE_Subventions_API_Graphiques_2026-03-13.md`<br>`Docs/04_MODULES/GDBCSE/ARCHI/dbml/gdbcse_ledger_erd.dbml`<br>`Docs/04_MODULES/GDBCSE/ARCHI/dbml/gdbcse_ledger_erd.dbml.txt`<br>`Docs/04_MODULES/GDBCSE/ARCHI/mermaid/gdbcse_ledger_erd_mermaid.md`<br>`Docs/04_MODULES/GDBCSE/ARCHI/mermaid/V2-gdbcse_ledger_erd_mermaid.md`<br>`Docs/04_MODULES/GDBCSE/ARCHI/plantuml/gdbcse_ledger_components.puml` |
| Gouvernance / Securite / PRA | 2 | 04_MODULES | `Docs/04_MODULES/PRA.md`<br>`Docs/04_MODULES/PRA/PRA_SAUVEGARDE_PRE_VIGILE_2026-01-29.md` |
| Legacy / Historique | 4 | 05_CEREBRAU, 00_LEGACY_GLOBAL | `Docs/05_CEREBRAU/02_ARCHITECTURE/LEGACY_BUDGETS_REFERENCE.md.txt` |
| Robot AT / Automatisation | 22 | 04_MODULES, 08_CODEX, 03_PATCHES_ET_EVOLUTIONS, 06_INNOVATIONS & EVOLUTIONS, 00_GOUVERNANCE | `Docs/00_GOUVERNANCE/CEREBRAU_DECLARATION_PROJET_SECURISÉ_2026-02-03.md`<br>`Docs/00_GOUVERNANCE/VEEDDA_CSE_GOUVERNANCE_STABILISATION_PRE-VIGILE_2026-01.md`<br>`Docs/04_MODULES/AT/AT_RULES.md`<br>`Docs/04_MODULES/AT/ROBOT_AT_EVENTS_SCHEMA.md`<br>`Docs/04_MODULES/AT/ROBOT_AT_PROCESSUS.md`<br>`Docs/04_MODULES/AT/ROBOT_AT_SPEUDOCORE.md` |
| Simulation / Projection | 2 | 08_CODEX |  |
| STAR / Design / Exports | 61 | 08_CODEX, 07_STAR_FACTORY, 04_MODULES, 00_GOUVERNANCE, 06_INNOVATIONS & EVOLUTIONS | `Docs/00_GOUVERNANCE/CEREBRAU_DESIGNSTAR_V1_2026-02-25.md`<br>`Docs/04_MODULES/GESTION TRANSITION BUDGETAIRE ET CONTINUITE OPERATIONNELLE/Architecture MVP — Gestion des transitions budgétaires et continuité opérationnelle.txt`<br>`Docs/04_MODULES/GESTION TRANSITION BUDGETAIRE ET CONTINUITE OPERATIONNELLE/VEEDDA — MATRICE OFFICIELLE MVP.txt`<br>`Docs/07_STAR_FACTORY/INBOX/DashboardPilotage.tsx`<br>`Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/EXCEL_STAR_EXPORT_ARCHITECTURE.md`<br>`Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_1_COUVERTURE_VALIDATION.pdf` |
| Transverse | 38 | 01_SYNTHESES, 08_CODEX, 00_GOUVERNANCE, 05_CEREBRAU, ROOT_DOCS | `Docs/00_GOUVERNANCE/README.md`<br>`Docs/00_GOUVERNANCE/RELEASE_VIGILE_STABLE_2026-01-30.md`<br>`Docs/00_GOUVERNANCE/VEEDDA_METHODOLOGIE_OFFICIELLE_V1.0.md`<br>`Docs/04_MODULES/VEEDDA_ARCHITECTURE_REFERENCE_CEREBRAU.md`<br>`Docs/05_CEREBRAU/architecture_base_veedda.md`<br>`Docs/05_CEREBRAU/architecture_fonctionnelle_veedda.md` |

## 6. Index par categorie documentaire

| Categorie | Documents |
|---|---:|
| `ARCHITECTURE` | 29 |
| `ARCHIVE` | 44 |
| `AUDIT` | 6 |
| `DECISION` | 1 |
| `DESIGN` | 39 |
| `DOC` | 27 |
| `ERROR` | 5 |
| `EXPORT` | 1 |
| `GOVERNANCE` | 25 |
| `LOT` | 21 |
| `MODULE` | 40 |
| `PATCH` | 22 |
| `PROMPT` | 15 |
| `README` | 4 |
| `REFERENCE` | 5 |
| `ROADMAP` | 1 |
| `SYNTHESIS` | 16 |
| `VISION` | 17 |

## 7. Registres, references Knowledge et lots produits

| ID | Type | Module | Chemin |
|---|---|---|---|
| `DOC-0271` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-001.md` |
| `DOC-0272` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-002.md` |
| `DOC-0273` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-003.md` |
| `DOC-0274` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-004.md` |
| `DOC-0275` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-005.md` |
| `DOC-0276` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-006.md` |
| `DOC-0277` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-007.md` |
| `DOC-0278` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-008.md` |
| `DOC-0279` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-009.md` |
| `DOC-0280` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-100.md` |
| `DOC-0281` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-101.md` |
| `DOC-0282` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-102.md` |
| `DOC-0283` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-103.md` |
| `DOC-0284` | `LOT` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-200.md` |
| `DOC-0285` | `REFERENCE` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/LOT_REGISTER.md` |
| `DOC-0286` | `REFERENCE` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/PROGRAM_REGISTER.md` |
| `DOC-0294` | `DOC` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/KNOWLEDGE_AGENT.md` |
| `DOC-0303` | `DOC` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/04_WORKFLOWS/KNOWLEDGE_OPERATIONS_MANUAL.md` |
| `DOC-0304` | `GOVERNANCE` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/05_RULES/KNOWLEDGE_GOVERNANCE.md` |
| `DOC-0306` | `DOC` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/06_REFERENCE/KNOWLEDGE_INDEX_ENGINE.md` |
| `DOC-0307` | `DOC` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/06_REFERENCE/KNOWLEDGE_INDEX_SCHEMA.md` |
| `DOC-0308` | `DOC` | CEREBRAU Operating System | `Docs/09_CEREBRAU OPERATING SYSTEM/06_REFERENCE/KNOWLEDGE_INDEX_STORAGE.md` |
| `DOC-0314` | `REFERENCE` | Data / API / Supabase | `Docs/KNOWLEDGE/API_REGISTER.md` |
| `DOC-0315` | `REFERENCE` | Data / API / Supabase | `Docs/KNOWLEDGE/DATABASE_REGISTER.md` |
| `DOC-0316` | `REFERENCE` | CEREBRAU Operating System | `Docs/KNOWLEDGE/FUNCTIONAL_REGISTER.md` |
| `DOC-0317` | `AUDIT` | CEREBRAU Operating System | `Docs/KNOWLEDGE/KNOWLEDGE_AUDIT.md` |

## 8. Index par document

| ID | Type | Domaine | Module | Format | Chemin |
|---|---|---|---|---|---|
| `DOC-0001` | `ARCHIVE` | 00_GOUVERNANCE | Transverse | `md` | `Docs/00_GOUVERNANCE/_ARCHIVES/01_architecture_base_veedda.md` |
| `DOC-0002` | `ARCHIVE` | 00_GOUVERNANCE | Espace salarie / QF / Droits | `md` | `Docs/00_GOUVERNANCE/_ARCHIVES/02_moteur_qf.md` |
| `DOC-0003` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `md` | `Docs/00_GOUVERNANCE/_ARCHIVES/03_moteur_subvention.md` |
| `DOC-0004` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `md` | `Docs/00_GOUVERNANCE/_ARCHIVES/04_cockpit_decisionnel.md` |
| `DOC-0005` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `md` | `Docs/00_GOUVERNANCE/_ARCHIVES/05_ledger_budget_cse.md` |
| `DOC-0006` | `ARCHIVE` | 00_GOUVERNANCE | Transverse | `md` | `Docs/00_GOUVERNANCE/_ARCHIVES/06_architecture_saas_veedda.md` |
| `DOC-0007` | `ARCHIVE` | 00_GOUVERNANCE | Espace salarie / QF / Droits | `md` | `Docs/00_GOUVERNANCE/_ARCHIVES/FEUILLE_DE_ROUTE_PROJET_TEST_CORE_VIGILE_ROBOT_QF_V2-300126.md` |
| `DOC-0008` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/diagram-Architecture du cockpit décisionnel_5.png` |
| `DOC-0009` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/diagram-Cycle complet d’une subvention-6.png` |
| `DOC-0010` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_Cockpit.png` |
| `DOC-0011` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `htm` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger.htm` |
| `DOC-0012` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/1d8ccafe-19e1-432b-8b24-81312bcb0425.png` |
| `DOC-0013` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/2e7a66fe-f9ca-4982-97f8-2652f043f782.png` |
| `DOC-0014` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/34dbdc07-7937-4733-a2a4-09689f7e3ef9.png` |
| `DOC-0015` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/4b40d233-e171-4474-b56e-e9b6d95cddf5.png` |
| `DOC-0016` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/5454a94b-4be4-4c0b-bca8-90a1dedf28f3.png` |
| `DOC-0017` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/5d8986df-8033-412b-b330-cc16c130dfb8.png` |
| `DOC-0018` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/74a898db-dc42-4f76-bdfb-c961a2ef57e0.png` |
| `DOC-0019` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/987fd824-311b-439c-8958-3c036119a834.png` |
| `DOC-0020` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/a749e751-28fa-4b88-92af-35d7329f1c0d.png` |
| `DOC-0021` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/a93fc03d-e19b-4401-aafd-19e7820a9a35.png` |
| `DOC-0022` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/ansi-1f6vhsjh.css` |
| `DOC-0023` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/code-block-editor-pane-fzo1sbww.css` |
| `DOC-0024` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/code-block-m2vhenll.css` |
| `DOC-0025` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/conversation-small-1rwf4ooe.css` |
| `DOC-0026` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/cot-message-lq73ofyy.css` |
| `DOC-0027` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/d465180f-0a91-45d4-a7d3-863032e5d75f.png` |
| `DOC-0028` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/d6a69e31-4e81-41be-9e33-9d0dc1791128.png` |
| `DOC-0029` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/f7571ae8-3815-4e09-9b42-1407b3ab1f7a.png` |
| `DOC-0030` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/index-ivzj8m6u.css` |
| `DOC-0031` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/jj.png` |
| `DOC-0032` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/product-variants-ga945uk2.css` |
| `DOC-0033` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/root-mc5qyvd8.css` |
| `DOC-0034` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/silk-hq-lutwos9z.css` |
| `DOC-0035` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/table-components-ca43bz4f.css` |
| `DOC-0036` | `ARCHIVE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `css` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/Diagramme_ledger_files/writing-block-editor-hs3au5w2.css` |
| `DOC-0037` | `ARCHIVE` | 00_GOUVERNANCE | Espace salarie / QF / Droits | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/diagramme_moteur_qf.png` |
| `DOC-0038` | `ARCHIVE` | 00_GOUVERNANCE | Transverse | `png` | `Docs/00_GOUVERNANCE/_ARCHIVES/Images/erd_veedda.png` |
| `DOC-0039` | `ARCHIVE` | 00_GOUVERNANCE | Transverse | `md` | `Docs/00_GOUVERNANCE/_ARCHIVES/TABLES_CONFORMITES/# CEREBRAU — Gouvernance Budgétaire.md` |
| `DOC-0040` | `LOT` | 00_GOUVERNANCE | CEREBRAU Operating System | `md` | `Docs/00_GOUVERNANCE/CEREBRAU_CLOTURE.md` |
| `DOC-0041` | `GOVERNANCE` | 00_GOUVERNANCE | Robot AT / Automatisation | `md` | `Docs/00_GOUVERNANCE/CEREBRAU_DECLARATION_PROJET_SECURISÉ_2026-02-03.md` |
| `DOC-0042` | `GOVERNANCE` | 00_GOUVERNANCE | STAR / Design / Exports | `md` | `Docs/00_GOUVERNANCE/CEREBRAU_DESIGNSTAR_V1_2026-02-25.md` |
| `DOC-0043` | `GOVERNANCE` | 00_GOUVERNANCE | GDBCSE / Financial Core | `md` | `Docs/00_GOUVERNANCE/CEREBRAU_GDBCSE_Subventions_API_Graphiques_2026-03-13.md` |
| `DOC-0044` | `GOVERNANCE` | 00_GOUVERNANCE | Espace salarie / QF / Droits | `md` | `Docs/00_GOUVERNANCE/CEREBRAU_VEEDDA-CSE_PRA_STABILISATION_CALCUL_PARCOURS_QF_2026-02-03.md` |
| `DOC-0045` | `GOVERNANCE` | 00_GOUVERNANCE | Espace salarie / QF / Droits | `md` | `Docs/00_GOUVERNANCE/CEREBRAU_VEEDDA-CSE_STABILISATION_CALCUL_PARCOURS_QF_2026-02-02.md` |
| `DOC-0046` | `GOVERNANCE` | 00_GOUVERNANCE | Espace salarie / QF / Droits | `md` | `Docs/00_GOUVERNANCE/GOUVERNANCE_VALIDATION_METIER_FS_QF_AUTH.md` |
| `DOC-0047` | `GOVERNANCE` | 00_GOUVERNANCE | Espace salarie / QF / Droits | `md` | `Docs/00_GOUVERNANCE/QF_V2_CONTRAT_ECHANGE_METIER_2026-01-30.md` |
| `DOC-0048` | `README` | 00_GOUVERNANCE | Transverse | `md` | `Docs/00_GOUVERNANCE/README.md` |
| `DOC-0049` | `GOVERNANCE` | 00_GOUVERNANCE | Transverse | `md` | `Docs/00_GOUVERNANCE/RELEASE_VIGILE_STABLE_2026-01-30.md` |
| `DOC-0050` | `GOVERNANCE` | 00_GOUVERNANCE | Espace salarie / QF / Droits | `md` | `Docs/00_GOUVERNANCE/SYNTHESE_GLOBALE_VEEDDA_CSE_VIGILE_ROBOT_AUTOSAVE_QF.md` |
| `DOC-0051` | `GOVERNANCE` | 00_GOUVERNANCE | Robot AT / Automatisation | `md` | `Docs/00_GOUVERNANCE/VEEDDA_CSE_GOUVERNANCE_STABILISATION_PRE-VIGILE_2026-01.md` |
| `DOC-0052` | `GOVERNANCE` | 00_GOUVERNANCE | Transverse | `md` | `Docs/00_GOUVERNANCE/VEEDDA_METHODOLOGIE_OFFICIELLE_V1.0.md` |
| `DOC-0053` | `PATCH` | 00_LEGACY_GLOBAL | Legacy / Historique | `md` | `Docs/00_LEGACY_GLOBAL/LEGACY GLOBAL - GENESE ET EVOLUTION DU PROJET -VEEDA _ CSE BUDGET APP.md` |
| `DOC-0054` | `DOC` | 00_LEGACY_GLOBAL | Legacy / Historique | `md` | `Docs/00_LEGACY_GLOBAL/LEGACY_HISTORIQUE.md` |
| `DOC-0055` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/2026-02_CEREBRAU_SYNTHESE_AVANCEMENT_VEEDDA_CSE.md` |
| `DOC-0056` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `txt` | `Docs/01_SYNTHESES/99_SYNTHESES/# CEREBRAU — REPRISE VEEDDA.txt` |
| `DOC-0057` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `txt` | `Docs/01_SYNTHESES/99_SYNTHESES/#19-02-26- 🧠 CEREBRAU — VEEDDA CSE.txt` |
| `DOC-0058` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/2026-02_CEREBRAU_SYNTHESE_AVANCEMENT_VEEDDA_CSE.md` |
| `DOC-0059` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2025-11_to_2026-02-19_v2026.02.19-01.md` |
| `DOC-0060` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2025-11_to_2026-02-19_v3026.02.19-01.md` |
| `DOC-0061` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2026-02-03_au_2026-02-18_v2026.02.18-01.md` |
| `DOC-0062` | `SYNTHESIS` | 01_SYNTHESES | Espace salarie / QF / Droits | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2026-02-04_VIGILE-QF-GATE-CI_v2026.02.19-01.md` |
| `DOC-0063` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2026-02-05_REPLIT-STABLE_CURSOR_v2026.02.05-01.md` |
| `DOC-0064` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2026-02-05_REPLIT-STABLE_v2026.02.05-01.md` |
| `DOC-0065` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2026-02-06_BIS-REPLIT-STABLE_CURSOR_v2026.02.05-01.md` |
| `DOC-0066` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2026-02-06_REPLIT-STABLE_v2026.02.05-01.md` |
| `DOC-0067` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2026-02-06_to_2026-02-19_v03026.02.19-02.md` |
| `DOC-0068` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2026-02-06_to_2026-02-19_v2026.02.19-02.md` |
| `DOC-0069` | `SYNTHESIS` | 01_SYNTHESES | Espace salarie / QF / Droits | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/CEREBRAU_2026-02-19_VIGILE-QF-GATE-CI_v2026.02.19-01.md` |
| `DOC-0070` | `ARCHIVE` | 01_SYNTHESES | CEREBRAU Operating System | `txt` | `Docs/01_SYNTHESES/99_SYNTHESES/HISTORIQUE_ARCHITECTURAL/BUDGET_LEGACY_CLOTURE.md.txt` |
| `DOC-0071` | `ARCHIVE` | 01_SYNTHESES | GDBCSE / Financial Core | `txt` | `Docs/01_SYNTHESES/99_SYNTHESES/HISTORIQUE_ARCHITECTURAL/DBS_SUBVENTIONS.md.txt` |
| `DOC-0072` | `ARCHIVE` | 01_SYNTHESES | GDBCSE / Financial Core | `txt` | `Docs/01_SYNTHESES/99_SYNTHESES/HISTORIQUE_ARCHITECTURAL/FICHE_ENTREPRISE_GDBCSE.md.txt` |
| `DOC-0073` | `ARCHIVE` | 01_SYNTHESES | GDBCSE / Financial Core | `txt` | `Docs/01_SYNTHESES/99_SYNTHESES/HISTORIQUE_ARCHITECTURAL/FINANCIAL_CORE_LEDGER_CEREBRAU.md.txt` |
| `DOC-0074` | `ARCHIVE` | 01_SYNTHESES | Robot AT / Automatisation | `txt` | `Docs/01_SYNTHESES/99_SYNTHESES/HISTORIQUE_ARCHITECTURAL/MOTEUR_NARRATIF_STRATEGIQUE.md.txt` |
| `DOC-0075` | `SYNTHESIS` | 01_SYNTHESES | Transverse | `md` | `Docs/01_SYNTHESES/99_SYNTHESES/MEMOIRE_PROJET_CEREBRAU.md` |
| `DOC-0076` | `ERROR` | 02_BIBLE_ERREURS | Robot AT / Automatisation | `md` | `Docs/02_BIBLE_ERREURS/AUTH/AUTH-001_Authentification_non_unifiee.md` |
| `DOC-0077` | `ERROR` | 02_BIBLE_ERREURS | Transverse | `md` | `Docs/02_BIBLE_ERREURS/Bible des Erreurs — Projet VEEDDA_CSE Budget App.md` |
| `DOC-0078` | `ERROR` | 02_BIBLE_ERREURS | GDBCSE / Financial Core | `txt` | `Docs/02_BIBLE_ERREURS/MODULE DBS -GDBCSE SUBVENTIONS/BIBLE ERREUR DU CEREBRO - MODULE DBS - GDBCSE SUBVENTION.txt` |
| `DOC-0079` | `ERROR` | 02_BIBLE_ERREURS | Espace salarie / QF / Droits | `md` | `Docs/02_BIBLE_ERREURS/ROUTING/ROUTING-001 — Redirections fantômes et contextes applicatifs.md` |
| `DOC-0080` | `ERROR` | 02_BIBLE_ERREURS | Robot AT / Automatisation | `md` | `Docs/02_BIBLE_ERREURS/URSSAF/URSSAF-001 — Incohérence des plafonds (validation vs affichage).md` |
| `DOC-0081` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/ADAPTATION_COMPUTE_QF_ETAPE4.md` |
| `DOC-0082` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/ANALYSE_ETAPE4_QF.md` |
| `DOC-0083` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Robot AT / Automatisation | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/ANALYSE_SECURITE_DASHBOARD_LECTURE_SEULE.md` |
| `DOC-0084` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/AUDIT_COMPUTE_RIGHTS_SF_V2.md` |
| `DOC-0085` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/AUDIT_MOTEUR_CALCUL_QF.md` |
| `DOC-0086` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/COMPUTE_RIGHTS_DOCUMENTATION.md` |
| `DOC-0087` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/COMPUTE_RIGHTS_SUMMARY.md` |
| `DOC-0088` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/DIFF_COMPUTE_RIGHTS_SF_V2.md` |
| `DOC-0089` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/EXEMPLE_QF_CONFIG_JSON.md` |
| `DOC-0090` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/LOCALISATION_MOTEUR_QF.md` |
| `DOC-0091` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/PATCH_COMPUTE_QF_DATA_DRIVEN.md` |
| `DOC-0092` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/PATCH_COMPUTE_RIGHTS_SF_V2_APPLIQUE.md` |
| `DOC-0093` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/PATCHES_COMPUTE_RIGHTS_SF_V2.md` |
| `DOC-0094` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Robot AT / Automatisation | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/RAPPORT_ANTI_DECALAGE.md` |
| `DOC-0095` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Robot AT / Automatisation | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/replit.md` |
| `DOC-0096` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/SCHEMA_ARCHITECTURE_QF_V2.md` |
| `DOC-0097` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/SCHEMA_VISUEL_MODULE_SALARIE.md` |
| `DOC-0098` | `PATCH` | 03_PATCHES_ET_EVOLUTIONS | Espace salarie / QF / Droits | `md` | `Docs/03_PATCHES_ET_EVOLUTIONS/SYNTHESE_PATCHES_COMPUTE_RIGHTS_SF_V2.md` |
| `DOC-0099` | `GOVERNANCE` | 04_MODULES | Robot AT / Automatisation | `md` | `Docs/04_MODULES/AT/AT_RULES.md` |
| `DOC-0100` | `LOT` | 04_MODULES | CEREBRAU Operating System | `md` | `Docs/04_MODULES/AT/BACKOFFICE_AT_PILOTAGE.md` |
| `DOC-0101` | `MODULE` | 04_MODULES | Robot AT / Automatisation | `md` | `Docs/04_MODULES/AT/ROBOT_AT_EVENTS_SCHEMA.md` |
| `DOC-0102` | `LOT` | 04_MODULES | CEREBRAU Operating System | `md` | `Docs/04_MODULES/AT/ROBOT_AT_PILOTAGE.md` |
| `DOC-0103` | `MODULE` | 04_MODULES | Robot AT / Automatisation | `md` | `Docs/04_MODULES/AT/ROBOT_AT_PROCESSUS.md` |
| `DOC-0104` | `MODULE` | 04_MODULES | Robot AT / Automatisation | `md` | `Docs/04_MODULES/AT/ROBOT_AT_SPEUDOCORE.md` |
| `DOC-0105` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `dbml` | `Docs/04_MODULES/GDBCSE/ARCHI/dbml/gdbcse_ledger_erd.dbml` |
| `DOC-0106` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/GDBCSE/ARCHI/dbml/gdbcse_ledger_erd.dbml.txt` |
| `DOC-0107` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/ARCHI/mermaid/gdbcse_ledger_erd_mermaid.md` |
| `DOC-0108` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/ARCHI/mermaid/V2-gdbcse_ledger_erd_mermaid.md` |
| `DOC-0109` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `puml` | `Docs/04_MODULES/GDBCSE/ARCHI/plantuml/gdbcse_ledger_components.puml` |
| `DOC-0110` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/GDBCSE/ARCHI/plantuml/gdbcse_ledger_components.puml.txt` |
| `DOC-0111` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `puml` | `Docs/04_MODULES/GDBCSE/ARCHI/plantuml/gdbcse_rpc_sequences.puml` |
| `DOC-0112` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/GDBCSE/ARCHI/plantuml/gdbcse_rpc_sequences.puml.txt` |
| `DOC-0113` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/ARCHI/README_ARCHI_GDBCSE_LEDGER_V2.2.md` |
| `DOC-0114` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/GDBCSE_BUDGET_LIFECYCLE_REFERENCE.md` |
| `DOC-0115` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/GDBCSE/GDBCSE_LEGACY_BUDGETS_SPECIFICATION.md.txt` |
| `DOC-0116` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/gestion_subventions.md` |
| `DOC-0117` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/LEDGER/README_ARCHI_GDBCSE_LEDGER_V2.2.md` |
| `DOC-0118` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/AUDIT_ARCHITECTURE_LEGACY.md` |
| `DOC-0119` | `DESIGN` | 04_MODULES | GDBCSE / Financial Core | `png` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/BUDGET_LIFECYCLE_FIGMA.png.png` |
| `DOC-0120` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `docx` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/BUDGET-LEGACY-DIMENSIONS.docx` |
| `DOC-0121` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `docx` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/BudgetLifecycleLegacyBudget.tsx.docx` |
| `DOC-0122` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `docx` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/BudgetLifecycleLegacyBudget2.docx` |
| `DOC-0123` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `css` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/gdbcse-transition-budgetaire.css` |
| `DOC-0124` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `docx` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/JSX-BUDGET-LEGACY.docx` |
| `DOC-0125` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/MATRICE_METIER_LEGACY.md` |
| `DOC-0126` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/PLAN_IMPLEMENTATION.md` |
| `DOC-0127` | `LOT` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/GDBCSE/LIFECYCLE/VEEDDA_FINANCIAL_CORE_VALIDATION_CLOTURE_LEGACY_ACTIVE_CLOSED.md` |
| `DOC-0128` | `ARCHITECTURE` | 04_MODULES | STAR / Design / Exports | `txt` | `Docs/04_MODULES/GESTION TRANSITION BUDGETAIRE ET CONTINUITE OPERATIONNELLE/Architecture MVP — Gestion des transitions budgétaires et continuité opérationnelle.txt` |
| `DOC-0129` | `EXPORT` | 04_MODULES | STAR / Design / Exports | `pdf` | `Docs/04_MODULES/GESTION TRANSITION BUDGETAIRE ET CONTINUITE OPERATIONNELLE/Matrice fonctionnelle MVP — Budget LEGACY_ACTIVE.pdf` |
| `DOC-0130` | `MODULE` | 04_MODULES | STAR / Design / Exports | `txt` | `Docs/04_MODULES/GESTION TRANSITION BUDGETAIRE ET CONTINUITE OPERATIONNELLE/VEEDDA — MATRICE OFFICIELLE MVP.txt` |
| `DOC-0131` | `LOT` | 04_MODULES | CEREBRAU Operating System | `txt` | `Docs/04_MODULES/INFRA-FINANCEMENT DISTRIBUTION PILOTAGE QVT/VEEDDA — Modèle économique infrastructure de financement + distribution + pilotage QVT.txt` |
| `DOC-0132` | `MODULE` | 04_MODULES | Espace salarie / QF / Droits | `md` | `Docs/04_MODULES/MES/MES_CONFIG_SCHEMA.md` |
| `DOC-0133` | `MODULE` | 04_MODULES | Espace salarie / QF / Droits | `md` | `Docs/04_MODULES/MES/MES_PARCOURS_SALARIE_REFERENCE.md` |
| `DOC-0134` | `MODULE` | 04_MODULES | Espace salarie / QF / Droits | `md` | `Docs/04_MODULES/MES/MES_VIGILE_SPEC.md` |
| `DOC-0135` | `MODULE` | 04_MODULES | Espace salarie / QF / Droits | `md` | `Docs/04_MODULES/MES/VIGILE_MES_OVERVIEW.md` |
| `DOC-0136` | `MODULE` | 04_MODULES | Espace salarie / QF / Droits | `md` | `Docs/04_MODULES/MES/VIGILE_MES_SCHEMA.md` |
| `DOC-0137` | `MODULE` | 04_MODULES | Gouvernance / Securite / PRA | `md` | `Docs/04_MODULES/PRA.md` |
| `DOC-0138` | `MODULE` | 04_MODULES | Gouvernance / Securite / PRA | `md` | `Docs/04_MODULES/PRA/PRA_SAUVEGARDE_PRE_VIGILE_2026-01-29.md` |
| `DOC-0139` | `MODULE` | 04_MODULES | Espace salarie / QF / Droits | `md` | `Docs/04_MODULES/QF/QF_V2_OVERVIEW.md` |
| `DOC-0140` | `GOVERNANCE` | 04_MODULES | Espace salarie / QF / Droits | `md` | `Docs/04_MODULES/QF/QF_V2_RULES.md` |
| `DOC-0141` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SGBD/Documentation Architecture SQL — VEEDDA-GDBCSE.txt` |
| `DOC-0142` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/SGBD/LEDGER_V2_REFERENCE.md` |
| `DOC-0143` | `ARCHITECTURE` | 04_MODULES | Data / API / Supabase | `md` | `Docs/04_MODULES/SGBD/VEEDDA_ARCHITECTURE_SGBD_IDENTITE.md` |
| `DOC-0144` | `MODULE` | 04_MODULES | Data / API / Supabase | `md` | `Docs/04_MODULES/SGBD/VEEDDA_DATAFLOW_REFERENCE.md` |
| `DOC-0145` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/# 📊 Modèle de génération de popula.txt` |
| `DOC-0146` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/# 🧠 Moteur de décision VEEDDA (MVP.txt` |
| `DOC-0147` | `ARCHITECTURE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/ARCHITECTURE_CIBLE_MOTEUR_VEEDDA_2026-04-09.md` |
| `DOC-0148` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `docx` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/Engine-simulate-subvention-model.docx` |
| `DOC-0149` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `docx` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/Moteur compute_simulation docu.docx` |
| `DOC-0150` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/MOTEUR-PROJECTION-NARRATIVE ENGINE/CATALOGUE-DES-LAYERS/Catalogue officiel des layers VEEDDA..txt` |
| `DOC-0151` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/MOTEUR-PROJECTION-NARRATIVE ENGINE/CATALOGUE-DES-LAYERS/Matrice de décision narrative.txt` |
| `DOC-0152` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/MOTEUR-PROJECTION-NARRATIVE ENGINE/CATALOGUE-DES-LAYERS/Orchestrateur Final.txt` |
| `DOC-0153` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/MOTEUR-PROJECTION-NARRATIVE ENGINE/Moteur-projectionNarrativeEngine.txt` |
| `DOC-0154` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/Moteur-projectionNarrativeEngine.txt` |
| `DOC-0155` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/VEEDDA_MODELE_IMPACT_SOCIAL.md` |
| `DOC-0156` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `md` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/VEEDDA_MODELE_IMPACT_SOCIAL.V2.md` |
| `DOC-0157` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/VEEDDA_Modeles_Sociaux_2026-04-09_21-46-04.txt` |
| `DOC-0158` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/📊 MOTEUR VEEDDA — ÉTAT ACTUEL (MVP CONNECTÉ) 01-04-26.txt` |
| `DOC-0159` | `MODULE` | 04_MODULES | GDBCSE / Financial Core | `txt` | `Docs/04_MODULES/SIMULATE_SUBVENTION_MODEL/🔵 1. STRATÉGIE (priority).txt` |
| `DOC-0160` | `ARCHITECTURE` | 04_MODULES | Transverse | `md` | `Docs/04_MODULES/VEEDDA_ARCHITECTURE_REFERENCE_CEREBRAU.md` |
| `DOC-0161` | `MODULE` | 04_MODULES | Robot AT / Automatisation | `docx` | `Docs/04_MODULES/📦 DOCUMENTATION COMPLÈTE .docx` |
| `DOC-0162` | `MODULE` | 04_MODULES | Robot AT / Automatisation | `txt` | `Docs/04_MODULES/📦 DOCUMENTATION COMPLÈTE .txt` |
| `DOC-0163` | `ARCHITECTURE` | 05_CEREBRAU | GDBCSE / Financial Core | `txt` | `Docs/05_CEREBRAU/02_ARCHITECTURE/CEREBRAU_VEEDDA_BUDGET_LIFECYCLE_ARCHITECTURE.md.txt` |
| `DOC-0164` | `ARCHITECTURE` | 05_CEREBRAU | GDBCSE / Financial Core | `txt` | `Docs/05_CEREBRAU/02_ARCHITECTURE/CEREBRAU_VEEDDA_BUDGET_LIFECYCLE_FIGMA_REFERENCE.md.txt` |
| `DOC-0165` | `DECISION` | 05_CEREBRAU | Legacy / Historique | `txt` | `Docs/05_CEREBRAU/02_ARCHITECTURE/LEGACY_BUDGETS_DECISIONS_REFERENCE.md.txt` |
| `DOC-0166` | `ARCHITECTURE` | 05_CEREBRAU | Legacy / Historique | `txt` | `Docs/05_CEREBRAU/02_ARCHITECTURE/LEGACY_BUDGETS_REFERENCE.md.txt` |
| `DOC-0167` | `ARCHITECTURE` | 05_CEREBRAU | Transverse | `md` | `Docs/05_CEREBRAU/architecture_base_veedda.md` |
| `DOC-0168` | `ARCHITECTURE` | 05_CEREBRAU | Transverse | `md` | `Docs/05_CEREBRAU/architecture_fonctionnelle_veedda.md` |
| `DOC-0169` | `ARCHITECTURE` | 05_CEREBRAU | Transverse | `md` | `Docs/05_CEREBRAU/VEEDDA_SYSTEM_ARCHITECTURE.md` |
| `DOC-0170` | `PATCH` | 06_INNOVATIONS & EVOLUTIONS | GDBCSE / Financial Core | `txt` | `Docs/06_INNOVATIONS & EVOLUTIONS/Évolution Financial Core — Transactions budgétaires atomiques.txt` |
| `DOC-0171` | `PATCH` | 06_INNOVATIONS & EVOLUTIONS | Robot AT / Automatisation | `txt` | `Docs/06_INNOVATIONS & EVOLUTIONS/Evolution_Moteur_Simulation_Budget.txt` |
| `DOC-0172` | `ROADMAP` | 06_INNOVATIONS & EVOLUTIONS | STAR / Design / Exports | `md` | `Docs/06_INNOVATIONS & EVOLUTIONS/FEUILLE_DE_ROUTE_VEEDDA_MVP_ENTERPRISE.md` |
| `DOC-0173` | `PATCH` | 06_INNOVATIONS & EVOLUTIONS | Robot AT / Automatisation | `txt` | `Docs/06_INNOVATIONS & EVOLUTIONS/Nouveau Document texte.txt` |
| `DOC-0174` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `txt` | `Docs/07_STAR_FACTORY/DESIGN SYSTEM STAR/DESIGN SYSTEM STAR.txt` |
| `DOC-0175` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `txt` | `Docs/07_STAR_FACTORY/DESIGN SYSTEM STAR/HARMONISATION PATTERN UNIQUE STAR.txt` |
| `DOC-0176` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `txt` | `Docs/07_STAR_FACTORY/DESIGN SYSTEM STAR/ICÔNES SIGNATURE STAR.txt` |
| `DOC-0177` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `txt` | `Docs/07_STAR_FACTORY/DESIGN SYSTEM STAR/SPÉCIFICATIONS COMPLÈTES — MODULE VEEDDA.txt` |
| `DOC-0178` | `PROMPT` | 07_STAR_FACTORY | STAR / Design / Exports | `txt` | `Docs/07_STAR_FACTORY/DESIGN SYSTEM STAR/🤖 PROMPT POUR REPLIT — MODULE VEEDDA.txt` |
| `DOC-0179` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `tsx` | `Docs/07_STAR_FACTORY/INBOX/BudgetSlider.tsx` |
| `DOC-0180` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `tsx` | `Docs/07_STAR_FACTORY/INBOX/CalculateurBudget.tsx` |
| `DOC-0181` | `LOT` | 07_STAR_FACTORY | STAR / Design / Exports | `tsx` | `Docs/07_STAR_FACTORY/INBOX/DashboardPilotage.tsx` |
| `DOC-0182` | `DESIGN` | 07_STAR_FACTORY | GDBCSE / Financial Core | `tsx` | `Docs/07_STAR_FACTORY/INBOX/GestionSubventions.tsx` |
| `DOC-0183` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `tsx` | `Docs/07_STAR_FACTORY/INBOX/KPICard.tsx` |
| `DOC-0184` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `tsx` | `Docs/07_STAR_FACTORY/INBOX/MoteurSimulation.tsx` |
| `DOC-0185` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `png` | `Docs/07_STAR_FACTORY/INBOX/page_calculateur.png` |
| `DOC-0186` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `png` | `Docs/07_STAR_FACTORY/INBOX/page_dashboard.png` |
| `DOC-0187` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `png` | `Docs/07_STAR_FACTORY/INBOX/Page_simulation.png` |
| `DOC-0188` | `DESIGN` | 07_STAR_FACTORY | GDBCSE / Financial Core | `png` | `Docs/07_STAR_FACTORY/INBOX/Page_subvention.png` |
| `DOC-0189` | `PROMPT` | 07_STAR_FACTORY | STAR / Design / Exports | `md` | `Docs/07_STAR_FACTORY/INBOX/PROMPT_REPLIT_VEEDDA.md` |
| `DOC-0190` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `md` | `Docs/07_STAR_FACTORY/INBOX/SPECIFICATIONS_VEEDDA.md` |
| `DOC-0191` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `tsx` | `Docs/07_STAR_FACTORY/INBOX/VeeddaApp.tsx` |
| `DOC-0192` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `tsx` | `Docs/07_STAR_FACTORY/INBOX/VeeddaHeader.tsx` |
| `DOC-0193` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `css` | `Docs/07_STAR_FACTORY/INBOX/veedda-main.css` |
| `DOC-0194` | `DESIGN` | 07_STAR_FACTORY | STAR / Design / Exports | `css` | `Docs/07_STAR_FACTORY/INBOX/veedda-tokens.css` |
| `DOC-0195` | `ARCHITECTURE` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/FINANCIAL_INFO_MODAL_ARCHITECTURE.md` |
| `DOC-0196` | `ARCHITECTURE` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/FINANCIAL_INFO_RENDERING_ARCHITECTURE.md` |
| `DOC-0197` | `AUDIT` | 08_CODEX | GDBCSE / Financial Core | `txt` | `Docs/08_CODEX/GLOBAL-COCKPIT FINANCIER AUDIT.txt` |
| `DOC-0198` | `ARCHITECTURE` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/GRAND_LIVRE_ARCHITECTURE.md` |
| `DOC-0199` | `AUDIT` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/GRAND_LIVRE_DATA_QUALIFICATION_AUDIT.md` |
| `DOC-0200` | `ARCHITECTURE` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/GRAND_LIVRE_SQL_VIEW_ARCHITECTURE.md` |
| `DOC-0201` | `DOC` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/INFO_PARCOURS_FINANCIER/COCKPIT_FINANCIER_PARCOURS_INFORMATIF.md` |
| `DOC-0202` | `DESIGN` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/INFO_PARCOURS_FINANCIER/FINANCIAL_INFO_STAR_TEMPLATE.md` |
| `DOC-0203` | `ARCHITECTURE` | 08_CODEX | STAR / Design / Exports | `md` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/EXCEL_STAR_EXPORT_ARCHITECTURE.md` |
| `DOC-0204` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `md` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/EXPORTS_FINANCIERS_STAR.md` |
| `DOC-0205` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_1_COUVERTURE_VALIDATION.pdf` |
| `DOC-0206` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_1_COUVERTURE_VALIDATION.png` |
| `DOC-0207` | `VISION` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_CENTRE_CORRIGE.pdf` |
| `DOC-0208` | `VISION` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_CENTRE_CORRIGE.png` |
| `DOC-0209` | `VISION` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_CORRIGE.pdf` |
| `DOC-0210` | `VISION` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_CORRIGE.png` |
| `DOC-0211` | `VISION` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_VALIDATION.pdf` |
| `DOC-0212` | `VISION` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_VALIDATION.png` |
| `DOC-0213` | `VISION` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_VALIDEE.pdf` |
| `DOC-0214` | `VISION` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_VALIDEE.png` |
| `DOC-0215` | `VISION` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_VALIDEE_EURO.pdf` |
| `DOC-0216` | `VISION` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_3_VISION_FINANCIERE_VALIDEE_EURO.png` |
| `DOC-0217` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_4_PROJECTION_FINANCIERE_FINALE.pdf` |
| `DOC-0218` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_4_PROJECTION_FINANCIERE_FINALE.png` |
| `DOC-0219` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_4_PROJECTION_FINANCIERE_V1_1.pdf` |
| `DOC-0220` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_4_PROJECTION_FINANCIERE_V1_1.png` |
| `DOC-0221` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_4_PROJECTION_FINANCIERE_VALIDATION.pdf` |
| `DOC-0222` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_4_PROJECTION_FINANCIERE_VALIDATION.png` |
| `DOC-0223` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_5_IMPACT_SOCIAL_VALIDATION.pdf` |
| `DOC-0224` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_5_IMPACT_SOCIAL_VALIDATION.png` |
| `DOC-0225` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_6_ACTIVITE_FINANCIERE_VALIDATION.pdf` |
| `DOC-0226` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_PAGE_6_ACTIVITE_FINANCIERE_VALIDATION.png` |
| `DOC-0227` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `html` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/pdf_star_page1_cover_capture.html` |
| `DOC-0228` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `html` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/pdf_star_page2_ui_capture.html` |
| `DOC-0229` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `html` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/pdf_star_page3_euro_capture.html` |
| `DOC-0230` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `html` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/pdf_star_page4_projection_capture.html` |
| `DOC-0231` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `html` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/pdf_star_page5_impact_social_capture.html` |
| `DOC-0232` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `html` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/pdf_star_page6_activity_capture.html` |
| `DOC-0233` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_V1_1_PAGE_2_UI_CORRIGEE.pdf` |
| `DOC-0234` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_V1_1_PAGE_2_UI_CORRIGEE.png` |
| `DOC-0235` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_V1_1_PAGE_2_VALIDATION.pdf` |
| `DOC-0236` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_V1_1_PAGE_2_VALIDATION.png` |
| `DOC-0237` | `GOVERNANCE` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/PDF_STAR_V1_PAGE_2_VALIDATION.png` |
| `DOC-0238` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `pdf` | `Docs/08_CODEX/MAQUETTE_EXTRACTE_PDF_EXCEL/VEEDDA-Rapport-Financier-CSE-2026-06-15.pdf` |
| `DOC-0239` | `AUDIT` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — FINANCIAL DONUT PAID + FULL CIRCLE AUDIT.md` |
| `DOC-0240` | `AUDIT` | 08_CODEX | GDBCSE / Financial Core | `txt` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — FINANCIAL DONUT PAID + FULL CIRCLE AUDIT.txt` |
| `DOC-0241` | `PROMPT` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — FINANCIAL KPI EXECUTION.md` |
| `DOC-0242` | `AUDIT` | 08_CODEX | Robot AT / Automatisation | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — INTEL CARDS REAL DATA BINDING AUDIT.md` |
| `DOC-0243` | `PROMPT` | 08_CODEX | Robot AT / Automatisation | `txt` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — INTEL CARDS REAL DATA BINDING EXECUTION.md.txt` |
| `DOC-0244` | `PROMPT` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — LEDGER JOURNAL REAL DATA BINDING EXECUTION.md` |
| `DOC-0245` | `PROMPT` | 08_CODEX | GDBCSE / Financial Core | `txt` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — LEDGER SIDE PANEL BUSINESS CONTENT EXECUTION.txt` |
| `DOC-0246` | `PROMPT` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — LEDGER SIDE PANEL EDITORIAL REWRITE EXECUTION.md` |
| `DOC-0247` | `PROMPT` | 08_CODEX | Robot AT / Automatisation | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — PAYMENT QUEUE REAL DATA BINDING EXECUTION.md` |
| `DOC-0248` | `PROMPT` | 08_CODEX | Simulation / Projection | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — PROJECTION FINANCIERE PIXEL PERFECT EMERGENT TO VEEDDA EXECUTION.md` |
| `DOC-0249` | `PROMPT` | 08_CODEX | Simulation / Projection | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX — PROJECTION FINANCIERE PIXEL PERFECT FROM EMERGENT REFERENCES.md` |
| `DOC-0250` | `PROMPT` | 08_CODEX | Robot AT / Automatisation | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_DONUT_MICRO_SEGMENTS_VISUALIZATION.md` |
| `DOC-0251` | `PROMPT` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_FINANCIAL_DONUT_EXECUTION.md` |
| `DOC-0252` | `PROMPT` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_FINANCIAL_DONUT_IMPLEMENTATION.md` |
| `DOC-0253` | `PROMPT` | 08_CODEX | GDBCSE / Financial Core | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_FINANCIAL_DONUT_REDESIGN.md` |
| `DOC-0254` | `PROMPT` | 08_CODEX | GDBCSE / Financial Core | `txt` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_FINANCIAL_DONUT_REDESIGN.md.txt` |
| `DOC-0255` | `VISION` | 08_CODEX | Transverse | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_VISION_FINANCIERE.md.md` |
| `DOC-0256` | `VISION` | 08_CODEX | Transverse | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_VISION_FINANCIERE_PIXEL_PERFECT.md` |
| `DOC-0257` | `VISION` | 08_CODEX | Transverse | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_VISION_FINANCIERE_PIXEL_PERFECT_PHASE_2_HOVER.md` |
| `DOC-0258` | `VISION` | 08_CODEX | Robot AT / Automatisation | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_VISION_FINANCIERE_REAL_DATA_BINDING_EXECUTION.md` |
| `DOC-0259` | `VISION` | 08_CODEX | Robot AT / Automatisation | `md` | `Docs/08_CODEX/PROMPT_CODEX/CODEX_VISION_FINANCIERE_REAL_DATA_BINDING_IMPLEMENTATION.md` |
| `DOC-0260` | `DESIGN` | 08_CODEX | Transverse | `png` | `Docs/08_CODEX/REFERENCES/CODEX-Impact social des dépenses.png` |
| `DOC-0261` | `DESIGN` | 08_CODEX | GDBCSE / Financial Core | `png` | `Docs/08_CODEX/REFERENCES/EMERGENT_LEDGER_SIDE_PANEL_REFERENCE.png` |
| `DOC-0262` | `DESIGN` | 08_CODEX | Transverse | `jpg` | `Docs/08_CODEX/REFERENCES/payment-queue-emergent.png.jpg` |
| `DOC-0263` | `DESIGN` | 08_CODEX | STAR / Design / Exports | `png` | `Docs/08_CODEX/REFERENCES/VEEDDA_PROJECTION_FINANCIERE_ACTUELLE_REFERENCE_UI.png` |
| `DOC-0264` | `DESIGN` | 08_CODEX | Transverse | `png` | `Docs/08_CODEX/REFERENCES/veedda-current.png.png` |
| `DOC-0265` | `VISION` | 08_CODEX | Transverse | `png` | `Docs/08_CODEX/REFERENCES/vision-financiere-emergent.png` |
| `DOC-0266` | `DOC` | 08_CODEX | Transverse | `md` | `Docs/08_CODEX/VEEDDA_PLAN_COMPTABLE_MVP.md` |
| `DOC-0267` | `DOC` | 08_CODEX | Transverse | `md` | `Docs/08_CODEX/VEEDDA_PLAN_COMPTABLE_MVP_V2.md` |
| `DOC-0268` | `DOC` | ROOT_DOCS | CEREBRAU Operating System | `zip` | `Docs/09_CEREBRAU OPERATING SYSTEM.zip` |
| `DOC-0269` | `ARCHITECTURE` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/01_CORE/DEVELOPMENT_ARCHITECTURE.md` |
| `DOC-0270` | `VISION` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/01_CORE/VISION.md` |
| `DOC-0271` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-001.md` |
| `DOC-0272` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-002.md` |
| `DOC-0273` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-003.md` |
| `DOC-0274` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-004.md` |
| `DOC-0275` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-005.md` |
| `DOC-0276` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-006.md` |
| `DOC-0277` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-007.md` |
| `DOC-0278` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-008.md` |
| `DOC-0279` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-009.md` |
| `DOC-0280` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-100.md` |
| `DOC-0281` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-101.md` |
| `DOC-0282` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-102.md` |
| `DOC-0283` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-103.md` |
| `DOC-0284` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/COS-200.md` |
| `DOC-0285` | `REFERENCE` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/LOT_REGISTER.md` |
| `DOC-0286` | `REFERENCE` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/PROGRAM_REGISTER.md` |
| `DOC-0287` | `ARCHITECTURE` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/ARCHITECT_AGENT.md` |
| `DOC-0288` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/BACKEND_AGENT.md` |
| `DOC-0289` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/DEVOPS_AGENT.md` |
| `DOC-0290` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/DOCUMENTATION_AGENT.md` |
| `DOC-0291` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | GDBCSE / Financial Core | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/FINANCIAL_CORE_AGENT.md` |
| `DOC-0292` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/FRONTEND_AGENT.md` |
| `DOC-0293` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/GIT_AGENT.md` |
| `DOC-0294` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/KNOWLEDGE_AGENT.md` |
| `DOC-0295` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | GDBCSE / Financial Core | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/LIFECYCLE_AGENT.md` |
| `DOC-0296` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/ORCHESTRATOR_AGENT.md` |
| `DOC-0297` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/PRODUCT_OWNER_AGENT.md` |
| `DOC-0298` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/QA_AGENT.md` |
| `DOC-0299` | `README` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/README.md` |
| `DOC-0300` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/RUNTIME_AGENT.md` |
| `DOC-0301` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/SECURITY_AGENT.md` |
| `DOC-0302` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | Data / API / Supabase | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/SQL_AGENT.md` |
| `DOC-0303` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/04_WORKFLOWS/KNOWLEDGE_OPERATIONS_MANUAL.md` |
| `DOC-0304` | `GOVERNANCE` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/05_RULES/KNOWLEDGE_GOVERNANCE.md` |
| `DOC-0305` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/06_REFERENCE/CEREBRAU_CONTEXT_ENGINE_MVP_V1.md` |
| `DOC-0306` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/06_REFERENCE/KNOWLEDGE_INDEX_ENGINE.md` |
| `DOC-0307` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/06_REFERENCE/KNOWLEDGE_INDEX_SCHEMA.md` |
| `DOC-0308` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/06_REFERENCE/KNOWLEDGE_INDEX_STORAGE.md` |
| `DOC-0309` | `LOT` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/LOT_TEMPLATE.md` |
| `DOC-0310` | `DOC` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/MASTER_EXECUTION_SPECIFICATION.md` |
| `DOC-0311` | `README` | 09_CEREBRAU OPERATING SYSTEM | CEREBRAU Operating System | `md` | `Docs/09_CEREBRAU OPERATING SYSTEM/README.md` |
| `DOC-0312` | `DOC` | ROOT_DOCS | Transverse | `md` | `Docs/CEREBRAU_STRUCTURE.md` |
| `DOC-0313` | `DOC` | ROOT_DOCS | Transverse | `txt` | `Docs/CEREBRAU_STRUCTURE.txt` |
| `DOC-0314` | `REFERENCE` | KNOWLEDGE | Data / API / Supabase | `md` | `Docs/KNOWLEDGE/API_REGISTER.md` |
| `DOC-0315` | `REFERENCE` | KNOWLEDGE | Data / API / Supabase | `md` | `Docs/KNOWLEDGE/DATABASE_REGISTER.md` |
| `DOC-0316` | `REFERENCE` | KNOWLEDGE | CEREBRAU Operating System | `md` | `Docs/KNOWLEDGE/FUNCTIONAL_REGISTER.md` |
| `DOC-0317` | `AUDIT` | KNOWLEDGE | CEREBRAU Operating System | `md` | `Docs/KNOWLEDGE/KNOWLEDGE_AUDIT.md` |
| `DOC-0318` | `README` | ROOT_DOCS | Transverse | `md` | `Docs/README.md` |

## 9. Regles de lecture

- Pour une question metier, commencer par `FUNCTIONAL_REGISTER.md`, puis filtrer par module dans le present index.
- Pour une question SQL, schema, RPC ou Edge Function, commencer par `DATABASE_REGISTER.md`, puis suivre les documents `ARCHITECTURE`, `REFERENCE` et `CODE`.
- Pour une question endpoint, service backend ou authentification API, commencer par `API_REGISTER.md`.
- Pour une question de pilotage CEREBRAU, commencer par `PROGRAM_REGISTER.md`, `LOT_REGISTER.md`, puis les fiches `COS-*`.
- Les documents `ARCHIVE` sont conserves pour historique et ne doivent pas etre traites comme source active sans verification.
