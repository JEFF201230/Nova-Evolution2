# Knowledge Audit

Date : 2026-06-28

Statut : AUDIT LECTURE SEULE

Perimetre controle :

- `Docs/KNOWLEDGE/API_REGISTER.md`
- `Docs/KNOWLEDGE/DATABASE_REGISTER.md`
- `Docs/KNOWLEDGE/FUNCTIONAL_REGISTER.md`
- `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/PROGRAM_REGISTER.md`
- `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/LOT_REGISTER.md`

Contraintes respectees :

- aucune requete distante ;
- aucune execution applicative ;
- aucune modification des registres audites ;
- aucun `git add` ;
- aucun commit.

---

## 1. Synthese executive

Les trois registres produits dans `Docs/KNOWLEDGE` sont exploitables et globalement coherents avec le code local scanne.

Le niveau de couverture est bon pour l'inventaire technique local :

- API montees documentees : 14 / 14, soit 100 %.
- Objets SQL actifs locaux documentes : 19 / 19, soit 100 % pour les tables, vues et RPC presentes dans les migrations scannees.
- Registres `Docs/KNOWLEDGE` presents : 3 / 3, soit 100 % des registres effectivement produits dans ce dossier.

Le niveau de couverture documentaire CEREBRAU Operating System reste incomplet :

- registres officiels cibles definis par le Knowledge Runtime : 2 / 10 produits, soit 20 % ;
- lots presents dans `02_PROJECT_MANAGEMENT` mais non correctement couverts par `LOT_REGISTER.md` : plusieurs documents existent hors registre ;
- plusieurs fichiers de lots sont vides ;
- plusieurs sources de donnees applicatives sont referencees par le code mais sans DDL local disponible.

Conclusion : la base d'audit est saine pour les trois registres techniques produits, mais la couverture du systeme documentaire global reste partielle.

---

## 2. Registres controles

| Registre | Statut declare | Qualite globale | Couverture observee |
|---|---|---:|---:|
| `API_REGISTER.md` | DRAFT | Bonne | 100 % des endpoints Express montes detectes |
| `DATABASE_REGISTER.md` | SCAN LOCAL | Bonne | 100 % des objets SQL locaux actifs detectes |
| `FUNCTIONAL_REGISTER.md` | DRAFT | Bonne mais large | Domaines principaux couverts, details de simulation incomplets |
| `PROGRAM_REGISTER.md` | Non versionne dans l'en-tete | Minimal | 1 programme documente |
| `LOT_REGISTER.md` | Non versionne dans l'en-tete | Incomplet | 3 entrees seulement, registre non synchronise avec les lots presents |

---

## 3. Coherence

### 3.1 Points coherents

- `API_REGISTER.md` correspond aux routes montees dans `server/index.ts` et `server/routes.ts`.
- Les routes non montees de `server/routes/users.ts` sont correctement signalees comme non montees.
- `DATABASE_REGISTER.md` distingue les objets avec DDL local et les objets seulement references par le code.
- Les signatures finales observees des RPC `approve_subvention`, `pay_subvention` et `refund_subvention` sont coherentes avec les migrations locales.
- `FUNCTIONAL_REGISTER.md` relie correctement les domaines fonctionnels aux fichiers applicatifs principaux.
- `PROGRAM_REGISTER.md` et `LOT_REGISTER.md` sont coherents avec les lots initiaux COS-000C, COS-001 et COS-002.

### 3.2 Incoherences ou limites

- `LOT_REGISTER.md` n'est plus synchronise avec les documents presents : `COS-003.md`, `COS-004.md`, `COS-006.md`, `COS-100.md` et `COS-200.md` existent mais ne sont pas inscrits.
- `PROGRAM_REGISTER.md` rattache `PROGRAM-001` a `COS-003` et `COS-004`, alors que `LOT_REGISTER.md` s'arrete a `COS-002`.
- Le runtime de registres de `COS-100.md` cible 10 registres officiels, mais seuls `PROGRAM_REGISTER.md` et `LOT_REGISTER.md` existent dans `Docs/09_CEREBRAU OPERATING SYSTEM`.
- Les registres `API_REGISTER.md` et `FUNCTIONAL_REGISTER.md` restent en `DRAFT`, alors que leur contenu est deja utilise comme reference d'audit.
- Encodage degrade visible dans `PROGRAM_REGISTER.md` et `LOT_REGISTER.md` sur certains libelles accentues.

---

## 4. Doublons

Doublons de noms detectes dans `Docs/` :

| Nom | Occurrences | Risque |
|---|---:|---|
| `README.md` | 4 | Faible, nom attendu dans plusieurs dossiers |
| `Moteur-projectionNarrativeEngine.txt` | 2 | Moyen, risque de version concurrente |
| `README_ARCHI_GDBCSE_LEDGER_V2.2.md` | 2 | Moyen, deux emplacements pour une reference d'architecture ledger |
| `2026-02_CEREBRAU_SYNTHESE_AVANCEMENT_VEEDDA_CSE.md` | 2 | Moyen, risque de synthese dupliquee |

Doublons fonctionnels observes :

- `DATABASE_REGISTER.md` signale un prototype `grand_livre_asc_v1.sql` et une migration active `20260615_create_grand_livre_asc_views.sql` pour `v_grand_livre_asc` et `v_balance_asc`. La distinction prototype / migration active est correctement faite.
- Plusieurs anciennes signatures de `pay_subvention` et `approve_subvention` existent dans les migrations historiques ; le registre retient correctement la derniere version observee.

---

## 5. Couverture documentaire

### 5.1 Taux de couverture par registre

| Domaine | Reference de couverture | Couvert | Total | Taux |
|---|---|---:|---:|---:|
| API Express montee | Routes detectees dans `server/index.ts` et `server/routes.ts` | 14 | 14 | 100 % |
| Tables SQL locales | `CREATE TABLE` dans migrations scannees | 12 | 12 | 100 % |
| Vues SQL locales actives | `CREATE VIEW` / `CREATE OR REPLACE VIEW` dans migrations actives | 4 | 4 | 100 % |
| RPC SQL principales | Fonctions SQL exposees et grant execute | 3 | 3 | 100 % |
| Edge Functions actives documentees | Fonctions sous `supabase/functions/` hors archives | 7 | 7 | 100 % |
| Registres Knowledge produits | Fichiers `Docs/KNOWLEDGE/*_REGISTER.md` | 3 | 3 | 100 % |
| Registres CEREBRAU OS cibles | Registres listes par Knowledge Runtime | 2 | 10 | 20 % |
| Lots non vides couverts par `LOT_REGISTER.md` | Documents COS non vides presents | 2 | 7 | 29 % |

### 5.2 Lecture du taux global

Le taux global recommande depend du perimetre retenu :

- Perimetre technique local produit : 100 % pour API, DB et Edge Functions inventoriees.
- Perimetre documentaire CEREBRAU OS cible : 20 % pour les registres officiels attendus.
- Perimetre de suivi des lots existants : 29 % si seuls les lots non vides sont pris en compte.

Taux de couverture documentaire consolide recommande pour pilotage : 50 %.

Ce taux correspond a la moyenne simple des trois axes utiles au pilotage :

- registres techniques produits et couverts : 100 % ;
- registres officiels cibles produits : 20 % ;
- synchronisation des lots existants : 29 %.

---

## 6. Documents manquants

### 6.1 Registres officiels cibles non produits

D'apres `COS-100.md` et `KNOWLEDGE_INDEX_STORAGE.md`, les registres suivants sont attendus mais absents :

- `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/EPIC_REGISTER.md`
- `Docs/09_CEREBRAU OPERATING SYSTEM/02_PROJECT_MANAGEMENT/DECISION_REGISTER.md`
- `Docs/09_CEREBRAU OPERATING SYSTEM/06_REFERENCE/ARCHITECTURE_REGISTER.md`
- `Docs/09_CEREBRAU OPERATING SYSTEM/06_REFERENCE/REFERENCE_REGISTER.md`
- `Docs/09_CEREBRAU OPERATING SYSTEM/03_AGENTS/AGENT_REGISTER.md`
- `Docs/09_CEREBRAU OPERATING SYSTEM/04_WORKFLOWS/WORKFLOW_REGISTER.md`
- `Docs/09_CEREBRAU OPERATING SYSTEM/05_RULES/RULE_REGISTER.md`
- `Docs/09_CEREBRAU OPERATING SYSTEM/99_ARCHIVES/ARCHIVE_REGISTER.md`

### 6.2 Lots presents mais non inscrits

Documents non vides presents dans `02_PROJECT_MANAGEMENT`, mais absents de `LOT_REGISTER.md` :

- `COS-003.md`
- `COS-004.md`
- `COS-006.md`
- `COS-100.md`
- `COS-200.md`

Documents vides presents :

- `COS-005.md`
- `COS-007.md`
- `COS-008.md`
- `COS-009.md`
- `COS-101.md`
- `COS-102.md`
- `COS-103.md`

### 6.3 Sources DB referencees sans DDL local

Objets referencees par le code ou les fonctions, sans DDL local trouve dans `supabase/` :

- `profiles`
- `organizations`
- `employee_profile`
- `attestations`
- `robot_at_logs`
- `simulations`
- `user_qf_input`
- `foyer_salarie`
- `qf_config`
- `parts_rules`
- `qf_history`
- `qf_foyer`
- `rights_config`
- `rights_history`
- `user_rights_projection`
- `v_budget_cse_legal`

Le registre base signale deja une partie de ces absences. Les objets utilises par l'API serveur devraient aussi etre rattaches a une source DDL ou declares comme externes / preexistants.

---

## 7. Qualite globale

### 7.1 Points forts

- Les registres techniques sont structures, sources et dates.
- Les limites de scan sont explicites dans `DATABASE_REGISTER.md`.
- Les routes legacy ou non montees ne sont pas confondues avec les routes actives.
- Les migrations historiques sont traitees avec prudence.
- Les documents mentionnent les sources principales scannees, ce qui rend l'audit reproductible.

### 7.2 Points faibles

- Les statuts documentaires sont heterogenes : `DRAFT`, `SCAN LOCAL`, `VALIDE`, `LIVRE`, sans matrice de validation appliquee uniformement.
- Les registres projet ne portent pas d'en-tete complet comparable aux registres `Docs/KNOWLEDGE`.
- Le suivi des lots est incomplet par rapport aux fichiers presents.
- Le systeme cible de registres est documente mais tres partiellement produit.
- Plusieurs documents vides dans `02_PROJECT_MANAGEMENT` creent un bruit documentaire.
- Certains noms de fichiers dupliques peuvent masquer la reference active.

---

## 8. Recommandations

Priorite 1 :

- Synchroniser `LOT_REGISTER.md` avec tous les lots non vides existants.
- Clarifier le statut des lots vides : brouillon reserve, erreur de creation ou placeholder autorise.
- Produire ou planifier explicitement les 8 registres officiels manquants du Knowledge Runtime.

Priorite 2 :

- Ajouter un en-tete standard a `PROGRAM_REGISTER.md` et `LOT_REGISTER.md` : version, statut, date, perimetre, source.
- Passer `API_REGISTER.md` et `FUNCTIONAL_REGISTER.md` de `DRAFT` a un statut de revue ou conserver `DRAFT` avec une raison explicite.
- Creer une convention indiquant quel document prime lorsqu'un nom existe en plusieurs exemplaires.

Priorite 3 :

- Rattacher les tables externes ou preexistantes a une source officielle : migration manquante, dump de reference, schema Supabase existant ou decision de non-versionnement.
- Distinguer dans `DATABASE_REGISTER.md` les objets absents critiques pour execution et les objets absents acceptables car preexistants.
- Ajouter un registre ou une section dediee aux exports et artefacts PDF/Excel si ces livrables deviennent des objets gouvernes.

---

## 9. Verdict

Audit favorable sur les registres techniques produits.

Audit reserve sur la couverture documentaire globale.

Le referentiel est exploitable pour comprendre l'API, la base locale et les grands domaines fonctionnels. Il n'est pas encore complet pour piloter le Knowledge Runtime CEREBRAU OS, principalement a cause des registres officiels manquants et de la desynchronisation du `LOT_REGISTER.md`.
