\# CEREBRAU — Architecture complète du système VEEDDA



VEEDDA est une plateforme SaaS de gestion CSE basée sur trois moteurs :



\- moteur social (Quotient Familial)

\- moteur subvention

\- moteur financier (ledger budgétaire)



Ces moteurs convergent dans le cockpit décisionnel.



---



\# Architecture globale VEEDDA



```mermaid

graph TD



User\[Utilisateur] --> Profile\[Profil salarié]



Profile --> Foyer\[Foyer fiscal]

Foyer --> Revenus\[Revenus]

Revenus --> QF\[Calcul Quotient Familial]



QF --> Policy\[Politique de subvention]



Policy --> Models\[Subvention Models]

Models --> Factors\[Multiplicateurs]



Factors --> Simulation\[Simulation subvention]



Simulation --> Request\[Demande subvention]



Request --> Pending\[Statut PENDING]



Pending --> Cockpit\[Cockpit décisionnel]



Cockpit --> Approve\[Valider]

Cockpit --> Reject\[Refuser]

Cockpit --> Wait\[Mettre en attente]



Approve --> Approved\[Statut APPROVED]

Reject --> Rejected\[Statut REJECTED]



Approved --> Payment\[Paiement]

Payment --> Refunded\[Statut REFUNDED]



Payment --> Ledger\[Budget Ledger]



Ledger --> Budget\[Budget CSE]

Ledger --> Transfers\[Transferts]

Ledger --> Votes\[Votes budgétaires]

Ledger --> Projections\[Projections]



Frontend

React + Vite



↓



API



Supabase



↓



Database



PostgreSQL



Modules principaux VEEDDA

Moteur social



QF



foyer fiscal



justificatifs



Moteur subvention



policy



simulation



demande



décision



Moteur financier



budgets



ledger



paiements



Cockpit décisionnel



Le cockpit CSE affiche :



demandes à traiter

SELECT \*

FROM subventions

WHERE statut = 'PENDING'

historique

SELECT \*

FROM subventions

WHERE statut != 'PENDING'



statuts :



APPROVED



REJECTED



REFUNDED



Workflow global VEEDDA



Utilisateur

↓

Profil

↓

Foyer fiscal

↓

Quotient familial

↓

Simulation subvention

↓

Demande

↓

Décision admin

↓

Paiement

↓

Ledger budgétaire



Synthèse CEREBRAU



Le système VEEDDA repose sur trois piliers :



moteur social (QF)



moteur financier (ledger)



moteur subvention (policy + simulation)



Ces moteurs convergent dans :



le cockpit décisionnel du CSE



qui constitue le centre opérationnel du système.

