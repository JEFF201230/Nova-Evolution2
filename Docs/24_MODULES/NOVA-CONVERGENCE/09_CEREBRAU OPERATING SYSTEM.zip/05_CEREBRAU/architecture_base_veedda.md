\# VEEDDA — Architecture de la base de données



\## Vue d’ensemble



La base VEEDDA repose sur trois moteurs principaux :



1\. Gestion des subventions

2\. Ledger budgétaire CSE

3\. Moteur social (Quotient Familial)



Architecture générale :



Utilisateur

↓

Profil

↓

Foyer fiscal

↓

Quotient Familial

↓

Demande de subvention

↓

Décision

↓

Paiement

↓

Ledger budgétaire



---



\# Domaine 1 — Subventions



Tables principales :



\- subventions

\- subvention\_decisions

\- subvention\_payments



Workflow :



PENDING → APPROVED / REJECTED → REFUNDED



---



\# Domaine 2 — Quotient Familial



Tables :



\- qf\_active

\- qf\_history

\- qf\_config

\- user\_qf\_input

\- foyer\_salarie



Objectif :



Calculer le plafond de subvention selon la situation sociale.



---



\# Domaine 3 — Ledger budgétaire



Tables :



\- budgets

\- budget\_ledger

\- budget\_transfers

\- budget\_votes

\- budget\_projections



Vues analytiques :



\- v\_budget\_balance

\- v\_budget\_balance\_by\_type

\- v\_budget\_cse\_consolidated

\- v\_budget\_cse\_legal



---



\# Domaine 4 — Moteur subvention



Tables :



\- subvention\_models

\- subvention\_model\_factors

\- subvention\_factors

\- subvention\_simulations

\- subvention\_simulation\_metrics



---



\# Domaine 5 — Utilisateurs



Tables :



\- users

\- profiles

\- organizations

\- user\_membership



---



\# Cockpit décisionnel



Cockpit :



SELECT \* FROM subventions

WHERE statut = 'PENDING'



Historique :



SELECT \* FROM subventions

WHERE statut != 'PENDING'

