\# CEREBRAU — Architecture Fonctionnelle VEEDDA



Analyse du backend Supabase et organisation des modules métier.



---



\# 1. Moteur Quotient Familial (QF)



Le moteur QF permet de calculer les plafonds de subventions selon la situation sociale du salarié.



\## Tables principales



| Table | Rôle |

|------|------|

| qf\_active | Quotient familial actif |

| qf\_history | Historique des QF |

| qf\_config | Paramètres de calcul |

| user\_qf\_input | Données déclarées par l'utilisateur |

| bridge\_qf\_drafts | Brouillons de calcul |



---



\## Foyer fiscal



\### foyer\_salarie



Associe un salarié à son foyer fiscal.



---



\### salarie\_justificatifs



Stocke les documents justificatifs :



\- avis d'imposition

\- certificats

\- documents sociaux



---



\# 2. Ledger budgétaire CSE



Le ledger budgétaire assure la gestion comptable du budget CSE.



\## Tables principales



| Table | Rôle |

|------|------|

| budgets | Budget principal |

| budget\_ledger | Ledger comptable |

| budget\_votes | Votes budgétaires |

| budget\_transfers | Transferts entre budgets |

| budget\_projections | Projections budgétaires |



---



\## Ledger



Le ledger enregistre chaque opération financière :



\- dépense

\- crédit

\- écriture budgétaire



---



\## Vues analytiques



| Vue | Rôle |

|------|------|

| v\_budget\_balance | Solde consolidé |

| v\_budget\_balance\_by\_type | Solde par type |

| v\_budget\_cse\_consolidated | Consolidation CSE |

| v\_budget\_cse\_legal | Conformité légale |



---



\# 3. Gestion des utilisateurs



\## Tables principales



| Table | Rôle |

|------|------|

| users | Utilisateurs |

| profiles | Profils enrichis |

| organizations | Organisations CSE |

| user\_membership | Appartenance organisation |



---



\# 4. Gestion des droits



| Table | Rôle |

|------|------|

| rights\_config | Configuration des droits |

| rights\_history | Historique des droits |

| user\_rights\_projection | Projection des droits |



---



\# 5. Communication et logs



| Table | Rôle |

|------|------|

| email\_logs | Historique emails |

| robot\_at\_logs | Logs automatisations |



---



\# Architecture fonctionnelle VEEDDA



Utilisateur

↓

profiles

↓

foyer\_salarie

↓

qf\_active

↓

subventions

↓

subvention\_decisions

↓

subvention\_payments

↓

budget\_ledger



---



\# Architecture applicative



Frontend  

React / Vite



↓



Supabase API



↓



PostgreSQL



Tables principales :



\- subventions

\- subvention\_decisions

\- subvention\_payments

\- budgets

\- qf\_active

\- profiles



---



\# Cockpit décisionnel



Le dashboard interroge :



subventions  

JOIN profiles  

JOIN subvention\_decisions  

JOIN subvention\_payments  



Filtrage :



statut = PENDING



---



\# Historique opérationnel



Affiche les décisions prises :



statut != PENDING



Donc :



\- APPROVED

\- REJECTED

\- REFUNDED



---



\# Conclusion



L’architecture VEEDDA repose sur trois piliers techniques :



1\. Ledger budgétaire CSE

2\. Moteur social (QF)

3\. Gestion des subventions



Ce modèle permet de construire une plateforme SaaS complète de gestion CSE.

