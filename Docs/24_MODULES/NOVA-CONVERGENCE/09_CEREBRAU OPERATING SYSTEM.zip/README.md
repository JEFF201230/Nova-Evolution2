

Chaque dossier a un \*\*rôle précis\*\*.  

Aucun n’est redondant. Aucun n’est optionnel.



---



\## 🧭 00\_GOUVERNANCE — Doctrine fondatrice



Contient les \*\*principes non négociables\*\* du projet :



\- choix architecturaux structurants

\- règles de conception

\- décisions irréversibles

\- synthèses exécutives (`99\_SYNTHESES`)

\- archives de gouvernance (`\_ARCHIVES`)



📌 Ce dossier définit \*\*les lois du projet\*\*.  

Il évolue peu et uniquement par décision consciente.



---



\## 🧠 00\_LEGACY\_GLOBAL — Mémoire longue du projet



Contient l’historique \*\*complet et chronologique\*\* :



\- création sur Replit

\- versions stables (novembre 2025)

\- migration avortée vers Railway

\- choix de Cursor

\- incidents majeurs

\- reprises successives

\- nettoyages structurels

\- dettes assumées



📌 Ce dossier explique \*\*pourquoi le projet est dans son état actuel\*\*.



---



\## 🚨 02\_BIBLE\_ERREURS — Référentiel des erreurs connues



Dossier \*\*critique\*\*.



Il contient les erreurs \*\*identifiées, analysées et documentées\*\*, classées par thème :



\- `AUTH` : authentification, rôles, porosité comptes

\- `ROUTING` : guards, redirections, React Query, GET "/"

\- `URSSAF` : plafonds, cumuls, incohérences métier



📌 Règle impérative :  

👉 \*\*Toute correction doit d’abord être confrontée à cette bible\*\*.



Ce dossier \*\*ne se nettoie jamais\*\*.



---



\## 🔧 03\_PATCHES\_ET\_EVOLUTIONS — Corrections \& contournements



Contient les correctifs \*\*incrémentaux\*\* :



\- patches techniques

\- contournements temporaires

\- évolutions UX / MVP

\- corrections ciblées (sans refonte globale)



📌 Si un patch devient structurel → il migre en gouvernance.  

📌 S’il révèle une erreur profonde → il est référencé dans la Bible des erreurs.



---



\## 🧩 04\_MODULES — Documentation fonctionnelle



Documentation \*\*par module métier\*\*, notamment :



\- `AT` : Aides / Subventions

\- `MES` : Mon Espace Salarié

\- `QF` : moteur QF / règles de calcul

\- `PRA` : sauvegardes, résilience, reprise après incident



Chaque module est documenté selon la logique :

> Objectif → Choix → Développement → Problèmes → Solutions → Résultat



---



\## 🧭 05\_GOUVERNANCE — Gouvernance opérationnelle



Contient les \*\*règles actives et chantiers en cours\*\* :



\- Vigile

\- Robot

\- gouvernance des données

\- neutralisation des guards

\- stratégie de tests

\- décisions opérationnelles actuelles



📌 À distinguer de `00\_GOUVERNANCE` :

\- `00\_` = lois fondatrices

\- `05\_` = règles vivantes



---



\## ✅ RÈGLE DE REPRISE OBLIGATOIRE



Avant toute action sur le projet :



1\. Lire ce README

2\. Lire `00\_GOUVERNANCE`

3\. Lire `00\_LEGACY\_GLOBAL`

4\. Lire `02\_BIBLE\_ERREURS`



👉 Toute action qui ne respecte pas cet ordre est \*\*à risque de régression\*\*.



---



\*\*CEREBRAU validé — Février 2026\*\*



